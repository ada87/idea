/**
 * 上传页面操作对象
 */
;caiyun.ui.model.uploadPanel = {}
;caiyun.ui.model.schemeCache = {}
;var log = {}
;log.debug = function(m) {	
}
;caiyun.ui.model.uploadPanel.active = false
;(function(){
	// 本地缓存全局变量
    var panel = caiyun.ui.model.uploadPanel;
    var util = window.caiyun.util;
    
    var reportInviteFlag = true;
    var inventAct = '../getFree_expansion_Infos!rptMission.action';
    var rptInvitation = function()
    {
		if(rptMisson_switch){
        $.ajax({
        url : inventAct ,
        type : "POST",
        data : {finishCount:1,missionId : 20001},
        dataType : "json",
        success : function(){}
        });}
    };

    var UPLOAD_CONSTANTS = {};
    UPLOAD_CONSTANTS.UIID= {};
    UPLOAD_CONSTANTS.TITLE = {};
    /*UIID*/
    UPLOAD_CONSTANTS.UIID.BOX = "uploadBox";
    UPLOAD_CONSTANTS.UIID.PARENT = "uploadTasksZone";
    UPLOAD_CONSTANTS.UIID.BAR = "uploadBar";
    UPLOAD_CONSTANTS.UIID.BRIEF = "uploadTips";
    UPLOAD_CONSTANTS.UIID.INPUT = "uploadInput";
    UPLOAD_CONSTANTS.UIID.CONTENT = "uploadContent";
    /*文案模板*/
    UPLOAD_CONSTANTS.TITLE.COM = "正在上传:[0]/[1]";
    UPLOAD_CONSTANTS.TITLE.SPD = "速度:[0]/s";
    UPLOAD_CONSTANTS.TITLE.HINT = "上传任务管理";
    UPLOAD_CONSTANTS.TITLE.HINTH5 = "支持从桌面直接拖拽上传哦，快试试吧O(∩_∩)O~";
    /**/
    UPLOAD_CONSTANTS.CATALOGID = ""
    
    var $player = $('#uploadBtn');
    var $brief = $('#uploadBrief');
    var $tips = $('#uploadTips');
    var uibox;
    var closebox;
    
    var values = [];
    var waitlist = [];
    var tasksModel,barModel,briefModel;
    var actionTags = [];
    
    var controlObjects = $([]); 
    
    var eventStatus = {
        0: '<p class="tip-waiting">等待中...</p>',
        5: '<p class="tip-errors">不支持空文件（夹）</p>',
        6: '<p class="tip-errors">文件大小超过2G限制</p>',
        8: '<p class="tip-errors">文件后缀名过长</p>',
        9: '<p class="tip-errors">文件异常</p>',
        10: '<p class="tip-errors">文件名非法</p>',
        start:'<p class="tip-passing">传输中...</p>',
        uploading:'<p class="tip-passing">传输中...</p>',
        failed:'<p class="tip-errors">上传失败</p>',
        ok:'上传完成',
        error : 100,
        'default':'<a onclick="javascript:caiyun.ui.model.uploadPanel.enterFileDir(\'[0]\');return false;" href="javascript:;">打开所在文件夹</a>'
    };
    // 上传选项列表
    var eventOption = {
        0: '取消任务',
        'default' : '删除记录'
    };
    
    var statusTitle = {
    	0:'等待上传',
        start:'开始上传',
        uploading:'正在上传',
        failed:'上传失败',
        'default':'上传完成'
    }
    
    // 上传记录模板
    UPLOAD_CONSTANTS.TITLE.ZONE = new StringBuffer();
    UPLOAD_CONSTANTS.TITLE.ZONE.append('<div id="uploadContent" class="popContent"><div class="detailCon" style="height:325px;">')
    		.append('<div id="uploadTasksZone" class="History-Content2">')
    		.append('<div class="off_line_m_main">')
    		.append('<ul data-bind="foreach:tasks,visible: tasks().length>0">')
    		.append('<li data-bind="attr:{id:number,index:$index}">')
    		.append('<div class="up_m">')
    		.append('<div class="logo_d">')
    		.append('<img src="../images/newportal2/m_file.gif" class="off_line_m_main_logo">')
            .append('<span class="m1" data-bind="text:showName,attr:{title:name}">name</span>')
            .append('<span class="m2" data-bind="text:showSize">size</span>')
            .append('</div>')
    		.append('<div class="t_nav">')
    		.append('<div class="m3" data-bind="html:statusText,css:{\'color_red\':status > 2}"><a href="#"></a></div>')
    		.append('<div class="del-renew"><span href="javascript:;" onfocus="this.blur();"')
    		.append('data-bind="click:$parent.removeTask"></span>')
            .append('</div></div>')
    		.append('</div>')
    		.append('<div class="up_ing"></div>')
     		.append('</li></ul></div></div></div></div>');
    // 全局进度条模板
    UPLOAD_CONSTANTS.TITLE.ZONE.append('<div id="uploadBar" data-bind="visible:totalNumber()>0" class="upload-rate-all">')
	.append('<div class="rate-capacity"><span data-bind="text: totalNumber">0</span>个文件')
	.append('<span data-bind="text: totalSize">0MB</span></div>')
	.append('<div class="rate-leave-time">剩余<span data-bind="text: remainTime">0</span></div>')
	.append('<div class="rate-leave-ing" data-bind="style:{width:totalPercent}"></div>')
	.append('<div id="uploadCancel" title="取消所有任务" data-bind="click:cancelClick" class="upload-allClose"></div>')
	.append('</div>');
    
    // 关闭提示模板
    UPLOAD_CONSTANTS.TITLE.CLSTEMPLATE = new StringBuffer();
    UPLOAD_CONSTANTS.TITLE.CLSTEMPLATE.append('<div style="padding:35px 0 0 35px;height:90px;">')
	.append('<div class="tip-getlink">')
	.append('<span class="ico-sign"></span>')
	.append('<h3>当前还有进行中的上传任务，确认关闭?</h3>')
	.append('</div></div>');
    
    // 当前操作的文件个数
    var countOperatings = function(key) {
    	var current = Math.abs($("#"+key).attr("index")) || 0;
    	current += 1;
    	return current;
    };
    // 计算等待上传的文件个数
    var countWaitings = function() {
    	var selected = 0;
    	for(i in waitlist) {
    		selected += 1;
		}
    	return selected;
    };
    
    // 要接收上传状态数据变化的对象方法
    var uploadReceivers = $([]);
    
    // 广播通知数据变化,暂时为一种,不区分类型
	var broadCast = function(obj) {
		var listeners = uploadReceivers || {};
		$.each(listeners, function() {
			this.call(null,obj);
		});
	};
    
    // 注册监听
    panel.onListen = function(fun) {
    	uploadReceivers.push(fun);
		return this;
	};
	// 删除监听
	panel.removeListen = function(key) {
		delete uploadReceivers[$.trim(key)];
		return this;
	};
    
    // 上传控制回调(HTML5和flash统一)
    var eventHandler = (function(){
        var closeBrowseEnd = function(){
        	log.debug("closeBrowseEnd");
		    if(reportInviteFlag){
				rptInvitation()
				reportInviteFlag = false;////新手任务上传邀请码 只统计每次上传操作的第一次
			}
        	panel.process();
        	popBubble();
        	return false;   	
        	
        	// 默认当前目录上传流程(非按媒体或后缀分类文件或搜索)
        	if(!(caiyun.judgement.isFileTyped(caiyun.constants.fileTypes.typed) 
        			|| caiyun.judgement.isInQueryByPhoneOS() || caiyun.judgement.isSearchCatalog())) {
        		panel.process();
            	return false;
        	}
        	
        	// 资源分类文件加载目录树:上传前选择目标目录流程
        	panel.folderDialog({
    			ids : window.caiyun.operate.getCurrentPathId(),
    			number : countWaitings()
    		});
        	
        };
        // 单个上传文件校验结果通知
        var reportState = function(obj){
        	// 激活用户已上传状态
        	caiyun.ui.model.uploadPanel.active = true;
        	log.debug("reportState");
        	log.debug(obj);
        	caiyun.ui.model.schemeCache[obj.number] = "http";
        	
        	// 保险箱目录上传
        	if(caiyun.judgement.isSafeBox()) {
        		log.debug("SafeBox");
        		caiyun.ui.model.schemeCache[obj.number] = "https";
        	}
        	// 企业空间上传
        	if(caiyun.judgement.isEnterprisePath()) {
        		log.debug("Enterprise");
        		caiyun.ui.model.schemeCache[obj.number] = "enterprise";
        		caiyun.ui.model.schemeCache[obj.number+'_EID'] = caiyun.judgement.getCurrentEnterpriseID();
        	}
        	
        	// 构造单个任务数据
        	var uploadInfo = {};
        	uploadInfo.number = obj.number;
        	uploadInfo.name = obj.name;
        	uploadInfo.showName = util.splitName({"name":obj.name,"maxLen":24});
        	uploadInfo.size = obj.size;
        	uploadInfo.showSize = util.formateSize(obj.size) || "0KB";
        	uploadInfo.status = obj.code;
        	uploadInfo.statusText = eventStatus[obj.code];
        	uploadInfo.statusInfo = "上传状态";
        	uploadInfo.optionText = eventOption[obj.code] || eventOption['default'];
        	uploadInfo.percent = "0%";
        	uploadInfo.speed = "0KB";
        	uploadInfo.completeSize = 0;
        	uploadInfo.fileSpeed = 0;
        	uploadInfo.path = '';
        	// 企业空间/收到的共享/个人目录下记录有效path
        	if(window.caiyun.judgement.isEnterprisePath() && caiyun.judgement.getPathForEnterprise() !== undefined ) {
        		uploadInfo.path = caiyun.judgement.getPathForEnterprise() ;
			}else if(window.caiyun.judgement.isInCurrentCatalogs(window.caiyun.constants.cannotModifyIDs.root_receiveShare)){
				//
				var uploadPath = window.caiyun.judgement.getPath();
				uploadInfo.path = uploadPath;
			}else{
				var uploadPath = window.caiyun.judgement.normalgetPath();
				uploadInfo.path = uploadPath;
			}
        	values[obj.number] = uploadInfo;
        	waitlist[obj.number] = uploadInfo;
        	// 文件校验时需要先设置上传的CatalogID,防止上传目录错误
        	controlNotice.setCatalog(window.caiyun.operate.getCurrentPathId());
        };
        // 上传流程开始
        var startUpload = function(obj){
        	log.debug("startUpload");
        	log.debug(obj);
        	uibox.setUploadTitles(statusTitle['start'],"");
        	window.onbeforeunload = function(){
                return "当前还有进行中的上传任务，确认关闭?";
            };
        };
        // 开始实体监听
        var startFileUpload = function(obj){
        	log.debug("startFileUpload");
        	log.debug(obj);
        	var report = values[obj.number];
        	report.status = 1;
        	report.statusText = eventStatus['uploading'];
        	values[obj.number] = report;
        	broadCast(report);//广播数据
        	scrollAuto(obj);
        };  
        // 上传任务监听
        var uploadListen = function(obj){
        	if(obj) {
        		log.debug("uploadListen");
            	// 获取实时数据更新
            	obj.filePercent = obj.filePercent > 100 ? 100 : obj.filePercent;
            	var speed = obj.speed > 0 ? util.formateSize(obj.speed) : "0B";
            	
            	var report = values[obj.number];
            	report.statusText = obj.filePercent+"%("+speed+"/s)";
            	report.percent = obj.filePercent+"%";
            	report.speed = speed;
            	report.completeSize = obj.fileCompleted;
            	report.fileSpeed = obj.speed;
            	values[obj.number] = report;
            	
            	// 当前上传任务进行状态current/all
            	var current = countOperatings(obj.number);
            	var all = tasksModel.tasks().length;
            	current = current > all ? 1 : current;
            	// 更新状态栏
            	var complete = UPLOAD_CONSTANTS.TITLE.COM.replace(/\[0\]/g,current).replace(/\[1\]/g,all);
            	var speed = UPLOAD_CONSTANTS.TITLE.SPD.replace(/\[0\]/g,speed);
            	uibox.setUploadTitles(complete,speed);
            	
            	broadCast(report);//广播数据
        	}
        };
        // 单个任务上传失败通知
        var reportError = function(obj){
        	log.debug("reportError");
        	log.debug(obj);
        	var report = values[obj.number];
        	report.status = eventStatus['error'];
        	report.statusText = eventStatus['failed'];
        	switch(obj.code){
	            case "io":{
	            	 report.statusInfo="网络异常";
	                 break;
	            }
	            case "http":{
	            	 report.statusInfo="系统问题,稍侯再试";
	                 break;
	            }
	            case "security":{
	            	 report.statusInfo="文件异常,可能被删除";
	                 break;
	            }
	            case "ajax":{
	            	 report.statusInfo=obj.docs;
	                 break;
	            }
        	}
        	report.optionText = eventOption['default'];
        	report.isDone = true;
        	values[obj.number] = report;
        	
        	broadCast(report);//广播数据
        };
        // 单个任务上传完成通知
        var reportFile = function(obj){
        	log.debug("reportFile");
        	log.debug(obj);
        	var report = values[obj.number];
        	report.status = 2;
        	// 保险箱,企业空间无打开文件夹操作
        	var scheme = caiyun.ui.model.schemeCache[obj.number];
			if(scheme == 'https' || scheme == 'enterprise') {
				report.statusText = eventStatus['ok'];
			}else {
				report.statusText = eventStatus['default'].replace(/\[0\]/g,obj.id);
			}
        	report.optionText = eventOption['default'];
        	report.isDone = true;
        	report.percent = "100%";
        	values[obj.number] = report;
        	broadCast(report);//广播数据       	
        	
        	// 上报批次上传成功的文件列表{'fid':fileID,'cid':contentID,'cname':contentName,'ctype':contentType}
			if(obj.actionTag !== '0') {
				// 如果是批量上传的文件(obj.actionTag不为0,由flash传递),去操作缓存actionTags中查询
				var thisTag = actionTags[obj.actionTag];
				// 如果没有记录,创建本批次.queue
				if(typeof(thisTag) === 'undefined') {
					thisTag = {'queue':[{'fid':obj.number,'cid':obj.id,'cname':obj.name,'ctype':obj.type}]};
				}else {
					// 有记录则增加一条新纪录到本批次.queue
					var action = {'fid':obj.number,'cid':obj.id,'cname':obj.name,'ctype':obj.type};
					thisTag.queue.push(action);
				}
				// 更新操作缓存actionTags
				actionTags[obj.actionTag] = thisTag;
				// 判断是否是批量操作的最后一个文件(obj.isQueueLast此时有值,由flash传递);
				if(obj.isQueueLast) {
					// 获取本同批次的文件列表,上报上传行为
					var thisQueue = thisTag.queue;
					log.debug("本批上传完成");
					
					// 本批次文件是否属于保险箱上传
					var scheme = caiyun.ui.model.schemeCache[obj.number];
					// 遍历此批上传
					var subObjects = new StringBuffer();
					var maxQueLen = thisQueue.length;
					//上报多于9个文件批量上传信息时只选取前9个文件信息进行上报
					maxQueLen = Math.min(maxQueLen,9);
					for (var i = 0; i < maxQueLen; i++) {
						if(scheme == 'https') {
							break;
						}
						// 文件属于图片大类是type上报为图片:1
						var suffixs = "bmp|iff|ilbm|tiff|tif|png|gif|jpeg|jpg|mng|xpm|psd|psp|xcf|pcx|ppm|dxf|cdr";
					    var reportType = thisQueue[i].ctype.toLowerCase() !=='' && suffixs.indexOf(thisQueue[i].ctype.toLowerCase()) != -1 ? '1' : '0';
					    
						// 非保险箱上传时上报'<obj>文件或目录名|对象类型(默认1:文件)|id||文件类型|</obj>'
						subObjects.append('<obj>').append(thisQueue[i].cname).append('|').append('1').append('|')
						.append(thisQueue[i].cid).append('||').append(reportType).append('|</obj>');
					}
					if(scheme !== 'https') {
						// 上报批量上传行为数据
						var space = obj.catalogId;
						// 处理企业空间的情况
						if(report.path !== '') {
							space = report.path;
						}
						var data = {eventType:1,space:space,subObjects:subObjects.toString(),
								objectNum:thisQueue.length,extInfo:""};
						var reportParas = {
								type     : 'post',
				                url      : "../webdisk2/timeLineAction!createEvents.action?date=" + new Date().getTime(),
				                dataType : 'json',
				                async 	 : true,
				                data     : data,
				                success  : function(json){log.debug(json)},
				                error   : function(){return false;}
				        };
				        $.ajax(reportParas);
					}
				}
			}
			
		    // 上传操作的BI-pv统计
			var html5 = obj.isFromBrowser || '';
			var eid = caiyun.ui.model.schemeCache[obj.number+"_EID"] || '';
			
			// BI统计
			var uploadParam = {contentID:obj.id,entryShareCatalogID:''};
			// 查询字段path
            if(window.caiyun.judgement.isEnterprisePath()){
                $.extend(uploadParam,{
                    'path':window.caiyun.judgement.getPathForEnterprise()
                });
            }else if(window.caiyun.judgement.isInCurrentCatalogs(window.caiyun.constants.cannotModifyIDs.root_receiveShare)){
				var uploadPath = window.caiyun.judgement.getPath();
				$.extend(uploadParam,{
					path: uploadPath
				});
			}
	        var params = {
					type     : 'post',
					dataType : 'json',
	                url      : "../webdisk2/getContentInfo!queryContentInfo.action?date=" + new Date().getTime(),
	                data     : uploadParam,
	                error   : function(){return false;}
	        };
	        params.success = function(json) {
	        	if(json.contentInfoObj) {
	        		var c = json.contentInfoObj;
	        		caiyun.pvlog('fileOper','upload',obj.id,c.contentType,obj.size,obj.type,eid,html5);
	        	}
	        }
	        $.ajax(params);    
            
			// 删除scheme缓存对象
			delete caiyun.ui.model.schemeCache[obj.number];
			delete values[obj.number];
			delete caiyun.ui.model.schemeCache[obj.number+"_EID"];
        };
        
        // 当前上传队列完成通知
        var loadDone = function(obj){
        	log.debug("loadDone");
        	uibox.setUploadTitles(statusTitle['default'],"");
        	window.onbeforeunload = null;
        	// 重置概要气泡框briefModel
        	briefModel.name('当前上传任务已完成，请点击查看');
    		briefModel.percent('');
    		briefModel.speed('');
    		briefModel.position('');
    		// 重置总体进度条barModel-保存BARDOM内容后删除
    		var $newBar = $("#"+UPLOAD_CONSTANTS.UIID.BAR).clone(false);
    		ko.removeNode(document.getElementById(UPLOAD_CONSTANTS.UIID.BAR));
    		// 重置总体进度条barModel-使用ko重新绑定新BARDOM
    		$("#"+UPLOAD_CONSTANTS.UIID.CONTENT).after($newBar);
    		barModel = new BarModel(0,"0MB","0%",0);
        	ko.applyBindings(barModel,document.getElementById(UPLOAD_CONSTANTS.UIID.BAR));
        	// 气泡通知
    		popBubble();
    		// 重新加载空间容量，延迟刷新文件视图
    		caiyun.initdata.setDiskSize();
    		setTimeout("caiyun.operate.reLoad();",2000);
        };
        
        // 上传前校验不通过通知
        var noPassing = function(obj){
        	log.debug("noPassing");
        	log.debug(obj);
        	// flash通知上传队列为空时触发load done
        	if(obj.code === '2') {
        		loadDone(null);
        	}
        };
        
        return {
        	closeBrowseEnd : closeBrowseEnd,
        	reportState : reportState,
        	startUpload : startUpload,
        	startFileUpload : startFileUpload,
        	uploadListen : uploadListen,
        	reportError : reportError,
        	reportFile : reportFile,
        	loadDone : loadDone,
        	noPassing : noPassing
        };
    })();
    
    // taskChangeViewHandler注册上传监听,数据处理后更新需要的视图
    var taskChangeViewHandler = function(report) {
    	// 计算进度和任务信息
    	var current = countOperatings(report.number);
    	var all = tasksModel.tasks().length;
    	current = current > all ? 1 : current;
    	// 全局完成大小
    	var totalSize = 0;
    	var totalComplete = 0;
		for (var i = 0; i < all; i++) {
			var t = tasksModel.tasks()[i];
			if(!(t.status > 2)) {
				totalSize += t.size;
				if(t.status ===2) {
					// 累计已完成的大小
					totalComplete += t.size;
				}
			}
		}
    	// 更新气泡区briefModel
		briefModel.name('正在上传：'+report.showName);
		briefModel.percent(' - '+report.percent);
		briefModel.speed('('+report.speed+'/s)');
		briefModel.position(current+'/'+all+'文件');
		// 更新总体进度条barModel
		barModel.totalNumber(all);
		barModel.totalSize(util.formateSize(totalSize));
		// 计算全局百分比
		barModel.totalPercent(Math.min((totalComplete+report.completeSize)/totalSize,1)*100+'%');
		// 计算剩余时长
		var fSpeed = isFinite(report.fileSpeed) ? report.fileSpeed : 1024000;
		var rTime = Math.max((totalSize-totalComplete-report.completeSize)/report.fileSpeed,0);
		rTime = isFinite(rTime) ? rTime : 60;
		rTime = rTime < 60 ? Math.floor(rTime)+'秒钟' : Math.floor((rTime/60))+'分钟';
		barModel.remainTime(rTime);
    };
    
    // 弹出气泡提示区
	var popBubble = function(){
		$tips.show('normal');
		setTimeout("$('#uploadTips').hide('normal')",5000);
	};
	
	// 动态调整滚动条位置
	var scrollAuto = function(obj) {
		var $zone = $("#uploadTasksZone");
        var $task = $("#"+obj.number);
        $zone.animate({scrollTop:($task.offset().top - $zone.offset().top)},0);
	}
    
    // UI流程通知BIZ操作window.caiyun.ui.model.uploadPanel.notice
    var controlNotice = {
    	// 设置上传目录
    	setCatalog : function(targetId){
    		controlObjects.each(function() {
				this.setCatalog(targetId);
			});
		},
		// 提请上传
	    submit : function(){
	    	controlObjects.each(function() {
				this.submit();
			});
		},
		// 停止上传
		stop : function(number){
			controlObjects.each(function() {
				this.stop(number);
			});
		},
		// 是否上传队列完成
		done : function(){
			controlObjects.each(function() {
				this.done();
			});
		}
	};
    panel.notice = controlNotice;
    
    // 取消所有未完成的任务
	panel.cancelUploads = function() {
		try {
			var cancels = [];
			var len = tasksModel.tasks().length;
			for (var i = 0; i < len; i++) {
				var t = tasksModel.tasks()[i];
				// 等待上传状态flash传递,status取字符'0'
				if(t.status===1 || t.status ==='0') {
					cancels.push(t);
				}
			}
			for(i in cancels) {
				tasksModel.tasks.remove(cancels[i]);
			}
			controlNotice.stop();
		} catch (e) {
			log.debug("cancel uploads error");
		}
	};
	
	// 移除已经完成的记录
	panel.removeCompletes = function() {
		try {
			var removes = [];
			var len = tasksModel.tasks().length;
			for (var i = 0; i < len; i++) {
				var t = tasksModel.tasks()[i];
				if(t.status===2) {
					removes.push(t);
				}
			}
			for(i in removes) {
				tasksModel.tasks.remove(removes[i]);
			}
		} catch (e) {
			log.debug("remove completes error");
		}
	};
	
	// 退出整个上传界面
	panel.reset = function() {
		log.debug("reset");
		// 清除数据
		tasksModel.tasks.removeAll();
		caiyun.ui.model.schemeCache = {};
		eventHandler.uploadListen(null);
        window.onbeforeunload = null;
        values = [];
        try {
        	controlNotice.stop();
        }catch(e){
        	log.debug("stop upload error");
        };
        // 关闭界面
        uibox.setUploadTitles(statusTitle['default'],"");
        closebox.close();
        panel.hide();
        // 刷新视图
        caiyun.operate.reLoad();
	}
	
	// 取消等待上传流程
	panel.cancel = function(process) {
		// 重置等待任务列表
		for(i in waitlist) {
			controlNotice.stop(waitlist[i].number);
		}
		waitlist = [];
	}
	
	// 关闭回调
	panel.close = function() {
		log.debug("close");
		if(controlNotice.done()){
			closebox.show();
        } else {
        	panel.reset();
        }
	};
	
	// 执行实体上传流程
	panel.process = function(targetId) {
		// 激活等待任务列表
		try {
			for(i in waitlist) {
				tasksModel.addTask(waitlist[i]);
				broadCast(waitlist[i]);
			}
		} catch (e) {
			log.debug("start process error");
			log.debug(e);
		}
		waitlist = [];
    	controlNotice.submit();
	}
	 
	
	// 打开上传成功文件所在目录
    panel.enterFileDir = function(contentId) {
    	panel.hide();
    	var pid = contentId || '';
    	window.caiyun.ui.model.fileContent.switchToView(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW);
    	caiyun.operate.enterDirLocate({'contID':pid});
    };
	
	// 显示上传框体
    panel.show = function(){
    	uibox.show();
    };
	
	// 隐藏上传框体
    panel.hide = function(){
    	uibox.hide();
	};
	
	// UI绑定
	var bindingUI = function() {
		// 对话框
		var boxparam = {};
    	boxparam.html = UPLOAD_CONSTANTS.TITLE.ZONE.toString();
    	boxparam.type = UPLOAD_CONSTANTS.UIID.BOX;
    	boxparam.title = "";
    	boxparam.minBtn = true;
    	boxparam.closeBtn = false;
    	boxparam.btnName = [];
    	boxparam.masked = true;
    	boxparam.closeBox = panel.close;
    	boxparam.miniMize = panel.hide;
    	boxparam.clearUploadListHandle = panel.removeCompletes;
    	uibox = new caiyun.ui.msgBox(boxparam);
    	uibox.show();
    	// 关闭提示框
    	closebox = caiyun.ui.msgBox({title:"系统提示",width:400,middleBtn:false,okHandle:function(){panel.reset();}
    		,html:UPLOAD_CONSTANTS.TITLE.CLSTEMPLATE.toString(),btnName:["确定","取消"]});
    	// 进度控制按钮
    	$brief.unbind('click').click(function(){
    		if(!caiyun.ui.model.uploadPanel.active) {
    			$tips.slideToggle("fast");
    		}
    		else {
    			uibox.show();
    		}
		});
    	$brief.hover(function() {$tips.show()}, function() {$tips.hide()});
	}
	
	// 绑定上传操作对象
	var bindingPlayer = function(param){
		var maxSize = {size:2147483648, unit:"2G"};
		var maxFile = 100;
		
		// uploadParams:上传业务回调配置(同样适用于HTML5)
        var uploadParams = {
            width           : 138,   // * flash 高度
            height          : 38,   // * flash 宽度
            maxFile         : maxFile,    // * 同一批次最大上传个数限制
            maxSize         : maxSize,    // * 单个文件最大字节限制和单位
            closeBrowseEnd  : eventHandler.closeBrowseEnd,// flash弹出的浏览窗口关闭时的事件
            reportState     : eventHandler.reportState,    // falsh将文件放入队列时的回调，状态码非0为不正常文件
            startUpload     : eventHandler.startUpload,    // flash开始上传回调
            startFileUpload : eventHandler.startFileUpload,    // flash单个文件开始上传回调
            uploadListen    : eventHandler.uploadListen,   // 上传监听
            reportError     : eventHandler.reportError,        // 单文件上传异常回调
            reportFile      : eventHandler.reportFile,     // 单文件上传成功回调
            loadDone        : eventHandler.loadDone,            // 全部上传完成回调
            noPassing		: eventHandler.noPassing
        };

        // 增加html5-upload与界面交互,push(WCFGH5)
        if(Html5Util.isHtml5Support()) {
        	// 支持拖拽时提示用户
        	UPLOAD_CONSTANTS.TITLE.HINT = UPLOAD_CONSTANTS.TITLE.HINTH5;
        	//注册
        	Html5Upload.regUi(uploadParams);
        	controlObjects.push(WCFGH5);
        	//绑定页面拖拽监听实现上传
        	Html5Util.bindDragEnter(document, null);
        	Html5Util.bindDragOver(document, null);
        	
        	// 绑定拖拽Drop触发上传
        	Html5Util.bindDrop(document, function(e) {
        		var files = e.dataTransfer.files;
        		WCFGH5.addFiles({	
        			files:files,
        			targetDirID:window.caiyun.operate.getCurrentPathId() || UPLOAD_CONSTANTS.CATALOGID,
        			isSafeBox: window.caiyun.judgement.isSafeBox(),
        			isFromDrag:true
        		});
        	});
        	// BIND标签触发上传
        	$player.click(function() {
                document.getElementById(UPLOAD_CONSTANTS.UIID.INPUT).click();
            });
        	attachInput();
        }else{
        	 // 注册兼容flash上传
        	 $player.ispaceUpload(uploadParams);
             controlObjects.push(WCFG);
        }
    };
    
    // 循环绑定input file
    var attachInput = function() {
    	var $input = $("#"+UPLOAD_CONSTANTS.UIID.INPUT);
    	$input.unbind('change').bind('change', function(evt){
    		WCFGH5.addFiles({
				files: evt.target.files,
				targetDirID: window.caiyun.operate.getCurrentPathId(),
				isSafeBox: window.caiyun.judgement.isSafeBox(),
				isFromDrag:false
			});
    		// input重新赋值，保持文件名change事件有效
    		$input.replaceWith('<input type="file" id="uploadInput" multiple="multiple" style="visibility:hidden"/>');
    		attachInput();
    	});
    };
    
    // 绑定上传操作
    var bindingFunc = function() {
    	// ko bingdings
    	tasksModel = new UploadTaskViewModel();
    	ko.applyBindings(tasksModel,document.getElementById(UPLOAD_CONSTANTS.UIID.PARENT));
    	
    	barModel = new BarModel(0,"0MB","剩余时长");
    	ko.applyBindings(barModel,document.getElementById(UPLOAD_CONSTANTS.UIID.BAR));
    	
    	briefModel = new BriefModel(UPLOAD_CONSTANTS.TITLE.HINT);
    	ko.applyBindings(briefModel,document.getElementById(UPLOAD_CONSTANTS.UIID.BRIEF));
    	// 注册数据监听
    	panel.onListen(tasksModel.replaceTaskView);
    	panel.onListen(taskChangeViewHandler);
    }
    
	// 初始化
	panel.init = function() {
		bindingPlayer();
		bindingUI();
		bindingFunc();
    	panel.hide();
	};
	
	// 添加上传框体到ui列表
	caiyun.ui.initList.push(panel);
})(this)


/**
 * 任务信息概要BriefModel
 */
var BriefModel = function(name,spd,per,pos) {
    this.name = ko.observable(name);
    this.speed = ko.observable(spd);
    this.percent = ko.observable(per);
    this.position = ko.observable(pos);
    
    this.panelView = function() {
    	window.caiyun.ui.model.uploadPanel.show();
    };
};
/**
 * 全局进度条BarModel
 */
var BarModel = function(tNum,tSize,tPer,rTime) {
    this.totalNumber = ko.observable(tNum);
    this.totalSize = ko.observable(tSize);
    this.totalPercent = ko.observable(rTime);
    this.remainTime = ko.observable(rTime);
    
    this.cancelClick = function() {
    	window.caiyun.ui.model.uploadPanel.cancelUploads();
    }
};

/**
 * UploadInfo上传信息对象
 * 
 * @param data:信息数据
 * (number:对象标识;name:文件名;showName:显示名称;size:文件大小byte;showSize:单位大小;
 * status:上传状态;statusText:状态名称;optionText:操作名称;isDone:是否已完成;)
 */
;function UploadInfo(data){
	this.number = ko.observable(data.number);
	this.name = ko.observable(data.name);
	this.showName = ko.observable(data.showName);
	this.size = ko.observable(data.size);
	this.showSize = ko.observable(data.showSize);
	this.status = ko.observable(data.status);
	this.statusText = ko.observable(data.statusText);
	this.statusInfo = ko.observable(data.statusInfo);
	this.optionText = ko.observable(data.optionText);
	this.isDone = ko.observable(data.isDone);
	this.percent = ko.observable(data.percent);
	this.speed = ko.observable(data.speed);
	this.completeSize = ko.observable(data.completeSize);
	this.fileSpeed = ko.observable(data.fileSpeed);
}
/**
 * 上传任务view model
 */
;function UploadTaskViewModel() {
    var self = this;
    // 上传任务列表
    self.tasks = ko.observableArray([]);
    // 返回已完成上传的任务
    self.completeTasks = ko.computed(function() {
        return ko.utils.arrayFilter(self.tasks(), function(task) { 
        		return task.isDone;
        	});
    });
    // 返回未上传的任务
    self.waitingTasks = ko.computed(function() {
        return ko.utils.arrayFilter(self.tasks(), function(task) {
        		return task.status == '0';
        	});
    });
    // 添加新上传任务
    self.addTask = function(uploadInfo) {
        self.tasks.push(uploadInfo);
    };
    // 删除上传任务
    self.removeTask = function(task) {
    	if(task.status < 2) {
    		window.caiyun.ui.model.uploadPanel.notice.stop(task.number);
    	}
    	self.tasks.remove(task);
    };
    ko.observableArray.fn.sortById = function(prop) {
        this.sort(function(l,r) {
            if (l.prop == r.prop) 
                return 0;
            else if (l.prop > r.prop) 
                return -1 ;
            else 
                return 1;
        });
    }
    // 更新当前上传任务视图(KO绑定失败~0~)
    self.replaceTaskView = function(uploadInfo) {
    	// 使用jq选择器查询(TODO:建议使用固定变量)
    	var $task = $("#"+uploadInfo.number);
    	$task.find(".m1").text(uploadInfo.showName);//转义字符
    	$task.find(".m2").html(uploadInfo.showSize);
    	$task.find(".m3").html(uploadInfo.statusText);
    	$task.find(".del-renew").attr("title",uploadInfo.optionText);
    	$task.find(".up_ing").animate({"width":uploadInfo.percent},"normal");
    	$task.find(".off_line_m_main_logo").attr("src",
    			caiyun.util.Icon.getIconByExtName(caiyun.util.getSuffix(uploadInfo.showName),true));
    	// 上传完成或者中途失败进度条还原
    	if(uploadInfo.status == 2 || uploadInfo.status == 100) {
    		$task.find(".up_ing").animate({"width":"0%"},0); 	
    	}
    	// 失败状态码中添加警告样式
    	$task.find(".m3").removeClass("tip-errors");
    	$task.find(".m3").attr("title","上传状态");
        if(uploadInfo.status > 2) {
        	$task.find(".m3").addClass("color_red");
        	$task.find(".m3").attr("title",uploadInfo.statusInfo);
        }
    };
}

/**
 * 上传目标目录树选择框(参考移动复制)
 */
;(function(){
		var panel = window.caiyun.ui.model.uploadPanel || {};
		panel.folderDialog = function(param){
			var CyTree = window.caiyun.ui.CyTree;
			var constants = window.caiyun.constants;
			var judgement = window.caiyun.judgement;
			var operate = window.caiyun.operate;
			var ui = window.caiyun.ui;
			var ajax = window.caiyun.util.caiyunAjax.ajaxRequest;
			var cache = window.caiyun.util.cache;
			var msgBox = ui.msgBox;
			var title = '已选[0]个文件，上传到';
			title = title.replace(/\[0\]/g,param.number);
			var treeFrame;
			var tree;
			
			var init = function(){
				createTreeFrame();
				createTree();
			};
			
			/*
			 * 创建树的弹出框
			 */
			var createTreeFrame = function() {
				var html = '<div id="treeRoot" class="pon_content_02"></div>';
				treeFrame = msgBox({
					html		:  html,
					leftBtn		:  true,
					width		:  650,
					title       :  title,
					height      :  429,
					creatHandle :  createTreeFloder,
					okHandle	:  confirmSelect,
					cancelHandle : cancelSelect
				});
				treeFrame.show();
				constants.safeboxCloseWin["treeFrame"] = treeFrame;
			};
			
			/*
			 * 创建文件夹树
			 */
			var createTree = function() {
				tree = CyTree({
					 renderTo : "treeRoot",
		             root     : getTreeRoot(),
		             select   : nodeSelect
				});
				
				var judgement = window.caiyun.judgement;
				var _id = judgement.isSafeBox() ? constants.rootIds.mySafeBox : constants.rootIds.myFolder;
				tree.selectNodeByID(_id);
				openTreeNode({id:_id});
				
			};			
			
			// 确认上传选择
			var confirmSelect = function(){
				var node = tree.getSelectedNode();
				if($.isFunction(panel.process)){
					panel.process(node.id);
				}
				treeFrame.close();
			};
			
			// 取消选择
			var cancelSelect = function() {
				panel.cancel("tree");
				treeFrame.close();
				return false;
			};
	        
			// 选择节点
	        var nodeSelect = function(node){
	        	tree.selectNodeByID(node.id);
	        	return;
	        };
			
			/*
			 * 根节点的数据拼装
			 */
			var getTreeRoot = function(){
		         var root = [];
			    
		         if(judgement.isSafeBox()){
		         	var safebox = {
			                id      : constants.rootIds.mySafeBox,
			                iconCls : 'ico-floder-root',
			                text    : constants.rootIdsName[constants.rootIds.mySafeBox],
			                click   : function(e) {
				                       openTreeNode({id:e.id});
			                     	 },
			                select  : function(e){
				                       tree.selectNodeByID(e.id);
			                     	 }
			         };
			            	
			        root.push(safebox);
		         }else{
		         	var myFolder = {
			            id      : constants.rootIds.myFolder,
			            iconCls : 'ico-floder-root',
			            text    : constants.rootIdsName[constants.rootIds.myFolder],
			            click   : function(e) {
			                        openTreeNode({id:e.id});
			                      },
			            select  : function(e){
						            tree.selectNodeByID(e.id);
						          }
		            };
		            
		            root.push(myFolder);
		         }
		         
		        return root;
	        };
			
			/*
			 * 树中创建文件夹回调函数
			 */
			var createTreeFloder = function(){
				tree.createInputNode({isBefor:true,submitFun:createFolder});
			};
			
			
			var createFolder = function(obj){
				//新建文件夹流程通过才刷新选中节点
				if(!operate.createFolder({parentcatalogID:obj.parentId,catalogName:obj.folderName,noEnterDir:true})) {
					openTreeNode({id:obj.parentId});
				};
			};
			
			var openTreeNode = function(param){
		        var data = {
		            contentID           : param.id,
		            filtertype          : 1,    
		            entryShareCatalogID : '',           
		            startNumber         : -1,
		            endNumber           : 10,               
		            catalogSortType     : 0,
		            contentSortType     : 0,
		            sortDirection       : 1
		        };
		        var param = {
		            type    : "post", 
		            url     : "../webdisk2/queryContentAndCatalog!disk.action", 
		            dataType: 'json', 
		            data    : data, 
		            succFun : openTreeNodeSuccCallBack
		        };      
		        ajax(param);         
	        };
	        
	         /**
		     * 展开树节点成功的回调函数
		     */
		    var openTreeNodeSuccCallBack = function(param,json){
		        var parentId = param.data.contentID;
		        var catalogInfos = json.dci && json.dci.cataloginfos;
		        tree.clear(parentId);
		        if(!catalogInfos){
		            return;
		        }
		        
		        $.each(catalogInfos, function(i, node) {
		              var tNode = {};
					  tNode.pid = parentId;
					  tNode.id = node.catalogID;
					  tNode.text = node.catalogName;
					  tNode.click = function(e) {
					      openTreeNode({id:e.id});
					  };
					  tNode.select = nodeSelect;
				      tree.addNode(tNode);
		        });     
		    };
		    
			init();
		};
})()
;