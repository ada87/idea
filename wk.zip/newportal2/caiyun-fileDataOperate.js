/**
 * 默认的文件视图
 */
(function() {
    window.caiyun.operate = (function() {
        var constants = window.caiyun.constants;
        var ajax = window.caiyun.util.caiyunAjax.ajaxRequest;
        var cache = window.caiyun.util.cache;
        var fileManager = caiyun.biz.fileManager;
        var fileShareManager = caiyun.biz.fileShare;
        var judgement = caiyun.judgement;
        var sortType = {
            'asc': '0',
            'desc': '1'
        };
        var sortFields = {
            'time': '0',
            'name': '1',
            'type': '2',
            'size': '3'
        };
        // 查询数据初始参数，用于保存状态之用
        var queryParams = {};
        // 查询数据初页数
        var startPage = 1;
        // 已删除的条目数，每次加载时，删除一项加一
        var dropCount = 0;
        // 是否是滚动加载数据请求
        var isScrollLoad = false;
        // 是否滚动中
        var scrolling = false;
        // 是否是按类型查询文件，查询模式：0 按文件夹查询 1 按文件类型查询 2 按文件后缀查询 3 搜索
        var queryType = 0;
        // 当前视图模式，默认web
        var currentView = constants.view.web;

        // 搜索关键词
        var keyWords = "";

        // 搜索范围类型
        var searchType = 0;

        //搜索路径
        var path = "";

        //当前进入的文件夹信息
        var curCataInfo;

        // 文件总数
        var count = 0;
        var listens = {};
        var keys = {
            enterDir: 'enterDir', // 切换文件夹事件
            edit: 'edit', // 切换文件夹事件
            selectData: 'selectData', // 选择数据事件
            loadData: 'loadData', // 数据加载成功事件
            loadReceiveData: 'loadReceiveData', // 收到的分享文件数据加载成功事件
            loadSearchData: 'loadSearchData',
            reload: 'reload', // 重新加载当前文件夹事件
            dropItems: 'dropItems', // 删除文件或者文件项
            userCreateFolder: 'userCreateFolder', // 用户触发创建文件夹事件
            createFolderSuccess: 'createFolderSuccess', // 用户创建文件夹成功事件
            userRename: 'userRename', // 用户触发重命名文件/文件夹事件
            userDelete: 'userDelete', // 用户触发删除文件/文件夹事件
            userDownload: 'userDownload', // 用户触发下载事件
            syncCancel: 'syncCancel', // 同步文件夹用户取消同步
            viewSwitch: 'viewSwitch', // 用户切换显示模式事件
            getFileLink: 'getFileLink', // 用户分享文件链接事件
            getShareInfo: 'getShareInfo', //用户获取分享文件详细信息事件
            createShareFile: 'createShareFile', //用户分享文件事件
            changeNew: 'changeNew',
            changeRecNew: 'changeRecNew', //收到的分享目录下的new标识
            funcBtnChange: 'funcBtnChange', // 修改上传、新建文件夹功能按钮的隐藏和显示
            fileContentSwitch: 'fileContentSwitch', // 文件内容区切换
            selectAll: 'selectAll', // 发起全选命令
            unSelectAll: 'unSelectAll', // 取消全选命令
            mp3Player: 'mp3Player', //音乐播放事件
            mp3PlayerClose: 'mp3PlayerClose' //关闭音乐播放器事件
        };

        // 文件夹栈 用于保存当前位置
        var catalogStack = [];

        // 当前选中的文件/文件夹ID
        var selectedIDs = [];

        /**
         * 获取当前路径ID
         */
        var getCurrentPathId = function() {
            var last = catalogStack.length - 1;
            if (last >= 0) {
                return catalogStack[last].catalogID;
            }
        };

        /**
         * 获取当前路径
         */
        var getCurrentCatalog = function() {
            var last = catalogStack.length - 1;
            if (last >= 0) {
                return catalogStack[last];
            }
        };

        /**
         * 获取当前路径栈
         */
        var getCatalogStack = function() {
            return catalogStack;
        };

        var clearSetCatalogStack = function(Obj) {
            catalogStack = [];
            if (Obj) {
                catalogStack.push(Obj);
            }
        };

        var setCatalogStack = function(catalogStack) {
            catalogStack = catalogStack;
        };

        /** ************************对外暴露回调方法start*************************************** */
        /**
         * @param ids
         *            选中文件与文件夹的id数组
         * @param total
         *            当前列表总数
         */
        var selectHandler = function(ids, total) {
            selectedIDs = ids;
            trigger(keys.selectData, ids, total);
        };

        /**
         * 发起全选
         */
        var selectAll = function() {
            trigger(keys.selectAll);
        };

        /**
         * 取消全选
         */
        var unSelectAll = function() {
            trigger(keys.unSelectAll);
        };

        /**
         * @param params.type
         *            文件或是文件夹 params.id 文件或是文件夹的id
         *
         */
        var dbclickHandler = function(params) {
            setReceDirReadStatus(params);
            var catalogInfo = cache.getFileCache(constants.FILE_LIST_CACHEGROUP,
                params.id);
            if (!catalogInfo) {
                return;
            }
            var content = catalogInfo;
            if (catalogInfo.catalogID) {
                var catalogInfo = cache.getFileCache(constants.FILE_LIST_CACHEGROUP,
                    params.id);

                enterDir(params.id);
            } else {
                // 如果是音频视频则播放之
                if (!judgement.isSafeBox() && (judgement.isAudio(content) || judgement.isVideo(content))) {
                    if ((judgement.isEnterprisePath()) && ((enterpriseAuth == 4 ? false : true) && (enterpriseAuth == 7 ? false : true))) {
                        viewFile(params.id);
                    } else {
                        viewFile(params.id);
                    }
                }
                // 如果是图片
                else if (!judgement.isSafeBox() && judgement.isPicture(content)) {
                    if (judgement.isEnterprisePath() && ((enterpriseAuth == 4 ? true : false) || (enterpriseAuth == 7 ? true : false))) {

                    } else {
                        browseImage(params.id);
                    }
                }
                // 如果是文本
                else if (!judgement.isSafeBox() && judgement.isDocPrev(content.contentSuffix)) {
                    if (judgement.isEnterprisePath() && ((enterpriseAuth == 4 ? false : true) && (enterpriseAuth == 7 ? false : true))) {
                        prew(content);
                        //在线浏览提交pv统计
                        caiyun.pvlog('fileOper', 'viewDoc', content.contentID);
                    } else if (!judgement.isEnterprisePath()) {
                        prew(content);
                        //在线浏览提交pv统计
                        caiyun.pvlog('fileOper', 'viewDoc', content.contentID);
                    }
                }
                // 其他下载
                else {
                    if (judgement.isEnterprisePath() && ((enterpriseAuth == 4 ? true : false) || (enterpriseAuth == 7 ? true : false))) {

                    } else {
                        userDownload(params.id);
                    }
                }
            }
        };

        var download4TimelineParam = {}; //timeline下载文件功能传递参数用
        /**
         *timeline双击文件时预览文件方法，contentInfo不在cache中，故模仿dbclickHandler方法重写此方法
         *add by huangyonghao
         * @param params.type
         *            文件或是文件夹 params.id 文件或是文件夹的id
         *
         */
        var dbclickHandler4Timeline = function(params, eid) {
            var jsonData = {};
            var contents = [];
            contents.push(params.contentInfo);
            jsonData.contents = contents;
            if (params.id) jsonData.contents[0].contentID = params.id[0];
            cache.putFileCache(constants.FILE_LIST_CACHEGROUP, jsonData);
            var catalogInfo = params.contentInfo;
            if (!catalogInfo) {
                return;
            }
            var content = catalogInfo;
            if (catalogInfo.catalogID) {
                var catalogInfo = cache.getFileCache(constants.FILE_LIST_CACHEGROUP,
                    params.id);
                enterDir(params.id);
            } else {
                // 如果是音频视频则播放之
                if (!judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare) && !judgement.isSafeBox() && (judgement.isAudio(content) || judgement.isVideo(content))) {
                    var continfo = {
                        cataID: "",
                        contentID: params.id[0]
                    };
                    setTimeLineReadStatus(continfo);
                    viewFile(params.id);
                    // 统计播放视频和音乐
                    caiyun.pvlogforTimeline('fileOper', 'viewMusic', params.id, "", "", "", "", eid);
                }
                // 如果是图片
                else if (!judgement.isSafeBox() && judgement.isPicture(content)) {
                    var continfo = {
                        cataID: "",
                        contentID: params.id[0]
                    };
                    setTimeLineReadStatus(continfo);
                    browseImage(params.id);
                    // 统计打开
                    caiyun.pvlogforTimeline('fileOper', 'viewPic', params.id, "", "", "", "", eid);
                }
                // 如果是文本
                //else if(!judgement.isSafeBox() && judgement.isDocPrev(content.contentSuffix)&& !judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)){
                //  prew(content);
                //}
                else if (!judgement.isSafeBox() && judgement.isDocPrev(content.contentSuffix)) { //修改 给网达测试用
                    // 统计打开
                    caiyun.pvlogforTimeline('fileOper', 'viewDoc', params.contentInfo.contentID, "", "", "", "", eid);
                    var continfo = {
                        cataID: "",
                        contentID: params.contentInfo.contentID
                    };
                    setTimeLineReadStatus(continfo);
                    prew(content);
                }
                // 其他下载
                else {
                    if (eid && eid.indexOf("E") === 0) {
                        window.caiyun.ui.iMsgTip.tip('企业空间暂不提供文件下载');
                        return;
                    }
                    if (params.path) download4TimelineParam.path = params.path;
                    if (params.ownerMSISDN) download4TimelineParam.ownerMSISDN = params.ownerMSISDN;
                    if (params.timelineFlag) download4TimelineParam.timelineFlag = params.timelineFlag;
                    caiyun.pvlogforTimeline('fileOper', 'download', params.id, "", "", "", "", eid);
                    var continfo = {
                        cataID: "",
                        contentID: params.id[0]
                    };
                    setTimeLineReadStatus(continfo);
                    userDownload(params.id);
                }
            }
        };

        /**
         * @param params.sortField
         *            排序字段 params.sortType 排序类型
         */
        var sortHandler = function(params) {
            sortClear();

            for (sortField in sortFields) {
                if (sortField == params.sortField) {
                    queryParams['catalogSortType'] = params.sortField == 'name' ? 1 : 0;
                    queryParams['contentSortType'] = sortFields[params.sortField];
                    queryParams['sortDirection'] = sortType[params.sortType];
                    reLoad();
                    break;
                }
            }

        };

        /**
         * 对文件夹进行过滤
         *
         * @param params.contentType
         *            过滤文件类型
         *
         * 类型： 默认取值为0 0：全部类型 1：图片文件 2：音频文件 3：视频文件 4：其他文件 5：文档 7：表格 8：幻灯片
         */
        var filterHandler = function(params) {
            queryParams.contentType = params.contentType;
            if (params.contentType === 0) {
                queryParams.filtertype = 0;
            } else {
                queryParams.filtertype = 2;
            }
            reLoad();
        };

        /**
         * 创建文件夹回调
         *
         * @param params.catalogName
         *            新文件夹的名字 params.parentcatalogID 父目录ID params.catalogType
         *            文件夹类型
         */
        // 是否正在新建文件夹
        var createFoldering = false;
        var createFolder = function(params) {
            if (createFoldering) {
                return;
            }
            // 检查名字是否符合规范，检查失败弹出提示框
            var errorCode = judgement.isValidFolderName(params.catalogName);
            if (errorCode) {
                window.caiyun.tips.showErrorMsg(errorCode);
                return errorCode;
            }

            // 判断目录层级
            if (catalogStack >= 10) {
                window.caiyun.tips.showErrorMsg('FOLDER_DEPTH_EXCEEDED');
                return 'FOLDER_DEPTH_EXCEEDED';
            }

            params.catalogName = encodeURIComponent(params.catalogName);
            //如果参数中已经有path(用于移动复制框中的新建文件夹操作,非企业空间下没有传path)
            if (params.path) {

            } else { //管理员企业空间创建文件夹时,没有传入path
                if (judgement.isEnterprisePath()) {
                    params.path = judgement.getPathForEnterprise();
                }
            }
            createFoldering = true;
            fileManager.createCatalog(params,
                // 处理成功

                function(ajaxParams, result) {
                    createFoldering = false;
                    var msg = $.trim(result.message);
                    if (msg) {
                        window.caiyun.ui.iMsgTip.tip(msg, 'error');
                        if (params.failCallback) {
                            params.failCallback(result);
                        }
                    } else {
                        if (params.successCallback) {
                            params.successCallback(result);
                        }
                        if (ajaxParams.data.noEnterDir) {
                            return;
                        }
                        // 统计新建文件夹操作
                        caiyun.pvlog('fileOper', 'createFold', result.catalogInfo.catalogID);
                        // 进入新文件夹
                        if (result.path) {
                            result.catalogInfo.path = result.catalogInfo.path || (result.path + "/" + result.catalogInfo.catalogID);
                            enterDir(result.catalogInfo.catalogID, result.catalogInfo, result.path + "/" + result.catalogInfo.catalogID);
                        } else {
                            enterDir(result.catalogInfo.catalogID, result.catalogInfo);
                        }
                    }
                },
                // 处理失败

                function() {
                    createFoldering = false;
                    if (params.failCallback) {
                        params.failCallback(result);
                    }
                });

        };

        /**
         * 用户准备创建文件夹
         */
        var userCreateFolder = function() {
            trigger(keys.userCreateFolder);
        };

        // 对外滚动条数据加载回调函数
        var scrollBottomLoadData = function() {
            // 超出页数不做查询
            count = count || 0;
            var curPage = Math.ceil(count / constants.gridInitConfig.endNum);
            if (scrolling || startPage >= curPage) {
                return;
            }
            scrolling = true;
            isScrollLoad = true;
            var startNumber = startPage * constants.gridInitConfig.endNum + 1 - dropCount;
            var endNumber = (startPage + 1) * constants.gridInitConfig.endNum - dropCount;
            switch (queryType) {
                case 0:
                    enterFolder($.extend({
                        'startNumber': startNumber,
                        'endNumber': endNumber
                    }, queryParams));
                    break;
                case 1:
                    queryDataByType($.extend({
                        'startNumber': startNumber,
                        'endNumber': endNumber
                    }, queryParams));
                    break;
                case 2:
                    _queryBySuffix($.extend({
                        'startNumber': startNumber,
                        'endNumber': endNumber
                    }, queryParams));
                    break;
                case 3:
                    queryByKeyword($.extend({
                        'startNumber': startNumber,
                        'endNumber': endNumber,
                        'keyWord': keyWords,
                        'path': path,
                        'searchType': searchType,
                        'catalogStack': catalogStack
                    }, queryParams));
                    break;
            }
        };

        /**
         * 视图切换时方法调用
         *
         * @param currView
         *            要切换的视图模式（从常量配制文件中拿取）
         */
        var viewSwitch = function(currView) {
            if (currentView != currView) {
                currentView = currView;
                trigger(keys.viewSwitch, currentView);
            }
            return this;
        };

        // 判断当时视图是否是传入的参数视图
        var isCurrView = function(view) {
            return currentView === view;
        };

        // 获取当前视图
        var getCurrentView = function() {
            return currentView;
        };

        // 重新刷新数据(page为1)
        var reLoad = function() {
            queryClear();
            switch (queryType) {
                case 0:
                    enterFolder(queryParams);
                    break;
                case 1:
                    queryDataByType(queryParams);
                    break;
                case 2:
                    _queryBySuffix(queryParams);
                    break;
                case 3:
                    queryByKeyword(queryParams);
                    break;
            }
            trigger(keys.reload, queryParams);
            selectedIDs = [];
            trigger(keys.selectData, selectedIDs);
            return this;
        };

        // 判断操作是否能执行
        // 如果传入ids数组，则用这个数组中的元素进行判断，否则按照当前选中的元素判断
        var canExecute = function(operation, ids) {
            var idList = ids || selectedIDs;
            var catalogs = [];
            var contents = [];
            var gotPublisher = false;
            var gotDraftBox = false;
            var gotReceivedPublishDir = false;
            $(idList).each(function() {
                // 获得文件数据缓存组
                var data = cache.getFileCache(constants.FILE_LIST_CACHEGROUP,
                    this);
                if (data) {
                    // 如果是目录
                    if (data.catalogID) {
                        if (data.catalogID === constants.publisherAccountConstants.publisherDir) {
                            gotPublisher = true;
                        }
                        if(data.shareType === '5'){
                            gotReceivedPublishDir = true;
                        }
                        if(data.catalogID === constants.publisherAccountConstants.draftBox){
                            gotDraftBox = true;
                        }
                        catalogs.push(data);
                    }
                    // 如果是文件
                    else if (data.contentID) {
                        contents.push(data);
                    }
                }
            });
            var flag = false;
            var temp = false;
            // 如果是在公共公开目录下，先去judgement处理
            if (judgement.isInPublisherDir()) {
                temp = judgement.canExecuteInPublisherDir(operation,catalogs,contents);
                // 如果不能执行，就不判断以下动作了
                if (!temp) {
                    return temp;
                }
            }
            // 可以对公共账号（管理员和收到的分享）做什么操作
            if (gotPublisher || (gotReceivedPublishDir && judgement.isReceviteDir(getCatalogStack()))) {
                temp = judgement.canExecuteWithPublisherDir(operation);
                // 如果不能执行，就不判断以下动作了
                if (!temp) {
                    return temp;
                }
            }
            // 是否在收到分享项中的公开目录里
            if (judgement.isInReceivedPublishDir()) {
                temp = judgement.canExecuteInReceivedPublishDir(operation,catalogs,contents);
                // 如果不能执行，就不判断以下动作了
                if (!temp) {
                    return temp;
                }
            }
            // 是否在草稿箱下
            if (judgement.isInDraftBox()){
                temp = judgement.canExecuteInDraftBox(operation);
                // 如果不能执行，就不判断以下动作了
                if (!temp) {
                    return temp;
                }
            }
            if(gotDraftBox){
                 temp = judgement.canExecuteWithDraftBox(operation);
                // 如果不能执行，就不判断以下动作了
                if (!temp) {
                    return temp;
                }
            }
            switch (operation) {
                // 一个目录可以打开
                case 'open':
                    flag = idList.length == 1 && catalogs.length == 1;
                    break;
                    // 一个视频或音频可以播放
                case 'play':
                    /*flag = idList.length == 1 && contents.length == 1
                            && (judgement.isVideo(contents[0]) || judgement.isAudio(contents[0])) && !judgement.isSafeBox() && !judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare);*/
                    flag = idList.length == 1 && contents.length == 1 && (judgement.isVideo(contents[0]) || judgement.isAudio(contents[0])) && !judgement.isSafeBox();
                    if (judgement.isEnterprisePath()) {
                        flag = idList.length == 1 && contents.length == 1 && (judgement.isVideo(contents[0]) || judgement.isAudio(contents[0])) && ((enterpriseAuth == 4 ? false : true) && (enterpriseAuth == 7 ? false : true));
                    }
                    break;
                    // 一幅图片可以打开浏览
                case 'browse':
                    flag = idList.length == 1 && contents.length == 1 && (judgement.isPicture(contents[0])) && !judgement.isSafeBox();
                    if (judgement.isEnterprisePath()) {
                        flag = idList.length == 1 && contents.length == 1 && (judgement.isPicture(contents[0])) && ((enterpriseAuth == 4 ? false : true) && (enterpriseAuth == 7 ? false : true));
                    }
                    break;
                case 'link':
                    flag = idList.length == 1 && !judgement.isSafeBox() && !judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare);
                    if (judgement.isEnterprisePath()) {
                        flag = idList.length == 1 && ((enterpriseAuth == 0 ? true : false) || (enterpriseAuth == 8 ? true : false));
                    }
                    $(catalogs).each(function() {
                        if (judgement.notModify(this)) {
                            flag = false;
                        }
                    });

                    break;
                case 'beauty':
                    flag = idList.length == 1 && !judgement.isSafeBox() && !judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare);
                    if (judgement.isEnterprisePath()) {
                        flag = idList.length == 1 && ((enterpriseAuth == 0 ? true : false) || (enterpriseAuth == 8 ? true : false));
                    }
                    $(catalogs).each(function() {
                        if (judgement.notModify(this)) {
                            flag = false;
                        }
                    });

                    break;
                case 'share':
                    flag = idList.length == 1 && !judgement.isSafeBox() && !judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare) && !judgement.isEnterprisePath();
                    $(catalogs).each(function() {
                        if (judgement.notModify(this)) {
                            flag = false;
                        }
                    });
                    break;
                case 'download':
                    if (judgement.isEnterprisePath()) {
                        flag = idList.length > 0 && ((enterpriseAuth == 4 ? false : true) && (enterpriseAuth == 7 ? false : true));
                    } else if (!judgement.isReceviteDir(catalogStack) && !gotReceivedPublishDir) {
                        flag = idList.length > 0;
                    } else {
                        flag = idList.length == 1;
                    }
                    $(catalogs).each(function() {
                        if (this.catalogID === caiyun.constants.cannotModifyIDs.root_receiveShare || this.shareType == "4") {
                            flag = false;
                        }
                    });
                    break;
                case 'leaveShare':
                    if (judgement.isReceviteDir(catalogStack)) {
                        flag = true;
                        $(catalogs).each(function() {
                            if (judgement.notModify(this) || this.shareType === '5') {
                                flag = false;
                                return false;
                            } else {
                                flag = true;
                            }
                        });
                    } else {
                        flag = false;
                    }
                    break;
                case 'copy':
                    flag = !judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare);
                    if (judgement.isEnterprisePath()) {
                        flag = (enterpriseAuth == 0 ? true : false) || (enterpriseAuth == 8 ? true : false);
                    }
                    $(catalogs).each(function() {
                        if (judgement.notModify(this)) {
                            flag = false;
                        }
                    });
                    break;
                case 'reCopy':
                    if (judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)) {
                        if (judgement.isReceviteDir(catalogStack) && idList.length > 1 && !gotReceivedPublishDir) {
                            flag = false;
                        } else {
                            flag = true;
                        }
                    }
                    if (judgement.isEnterprisePath()) {
                        flag = false;
                    }
                    $(catalogs).each(function() {
                        if (judgement.notModify(this)) {
                            flag = false;
                        }
                    });
                    break;
                case 'move':
                    flag = !judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare);
                    if (judgement.isEnterprisePath()) {
                        flag = (enterpriseAuth == 0 ? true : false) || (enterpriseAuth == 8 ? true : false);
                    }
                    $(catalogs).each(function() {
                        if (judgement.notModify(this)) {
                            flag = false;
                        }
                    });
                    break;
                case 'rename':
                    flag = idList.length == 1 && !judgement.isReceviteDir(catalogStack);
                    if (judgement.isEnterprisePath()) {
                        flag = idList.length == 1 && ((enterpriseAuth == 0 ? true : false) || (enterpriseAuth == 8 ? true : false));
                    }
                    $(catalogs).each(function() {
                        if (judgement.notModify(this)) {
                            flag = false;
                        }
                    });
                    break;
                case 'delete':
                    if (judgement.isReceviteDir(catalogStack)) {
                        flag = false;
                    } else if (judgement.isEnterprisePath()) {
                        flag = (enterpriseAuth == 0 ? true : false) || (enterpriseAuth == 8 ? true : false);
                        if (flag) {
                            // 最多一次删除两百个
                            flag = idList.length > 0 && idList.length <= 200;
                            if (flag) {
                                $(catalogs).each(function() {
                                    if (judgement.notModify(this)) {
                                        flag = false;
                                    }
                                });
                            }
                        }
                    } else {
                        // 最多一次删除两百个
                        flag = idList.length > 0 && idList.length <= 200;
                        if (flag) {
                            $(catalogs).each(function() {
                                if (judgement.notModify(this)) {
                                    flag = false;
                                }
                            });
                        }
                    }
                    break;
                case 'showVersionList':
                    flag = contents.length == 1 && catalogs.length == 0;
                    if (judgement.isEnterprisePath()) {
                        flag = contents.length == 1 && catalogs.length == 0 && (enterpriseAuth == 0 ? true : false);
                    }
                    break;
                case 'cancelSync':
                    if (judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)) {
                        flag = false;
                    } else if (judgement.isEnterprisePath()) {
                        flag = false;
                    } else {
                        flag = idList.length == 1 && catalogs.length == 1 && judgement.isSyncCatalog(catalogs[0]) &&
                            (!judgement.isFixedCatalog(catalogs[0])) && !judgement.isSafeBox();
                    }
                    break;
                case 'edit':
                    if (judgement.isEnterprisePath()) {
                        flag = (idList.length == 1 && contents.length == 1 ? (judgement.isDocEdit(contents[0].contentSuffix)) : false) && ((enterpriseAuth == 8 ? true : false) || (enterpriseAuth == 0 ? true : false));
                    } else {
                        flag = !judgement.isSafeBox() &&
                            (idList.length == 1 && contents.length == 1 ? (judgement.isDocEdit(contents[0].contentSuffix)) : false);
                    }
                    break;
                case 'newFolder':
                    if (judgement.isEnterprisePath()) {
                        flag = (enterpriseAuth == 0 ? true : false) || (enterpriseAuth == 8 ? true : false);
                    } else if (!judgement.isReceviteDir(catalogStack)) {
                        flag = true;
                    }
                    break;
                case 'upload':
                    if (judgement.isEnterprisePath()) {
                        flag = (enterpriseAuth == 5 ? false : true) && (enterpriseAuth == 7 ? false : true);
                    } else if (!judgement.isReceviteDir(catalogStack)) {
                        flag = true;
                    }
                    break;
            }
            return flag;
        };

        // 用户发起重命名事件
        var userRename = function() {
            trigger(keys.userRename, selectedIDs);
        };

        // 重命名
        var rename = function(id, newName, successCallback, failCallback) {
            var id = id || selectedIDs[0];
            var item = cache.getFileCache(constants.FILE_LIST_CACHEGROUP, id);
            if (item && newName !== null && newName !== undefined) {
                newName = $.trim(newName);
                // 如果是文件夹调用更新文件夹信息接口
                if (item.catalogID) {
                    // 检查文件夹名称规则，等同于创建文件夹
                    var errorCode = judgement.isValidFolderName(newName);
                    if (errorCode) {
                        window.caiyun.tips.showErrorMsg(errorCode);
                        return errorCode;
                    }

                    newName = encodeURIComponent(newName);
                    var param = {
                        catalogID: id,
                        catalogName: newName
                    };
                    // 如果是修改"我接收到的文件"下的文件则需要加path路径
                    if (judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)) {
                        $.extend(param, {
                            path: item.path
                        });
                    }
                    //如果是修改企业空间（管理员）下的文件
                    if (judgement.isEnterprisePath()) {
                        $.extend(param, {
                            path: judgement.getPathForEnterprise() + "/" + id
                        });
                    }
                    fileManager.updateCatalogInfo(param, function(params, result) {
                        var msg = $.trim(result.message);
                        if (msg) {
                            window.caiyun.ui.iMsgTip.tip(msg, 'error');
                            if (failCallback) {
                                failCallback(params, result);
                            }
                        } else {
                            // 更新改文件项的缓存中的名字
                            var folder = cache.getFileCache(constants.FILE_LIST_CACHEGROUP, id);
                            if (result.result.retObj) {
                                folder.catalogName = result.result.retObj;
                            }
                            if (successCallback) {
                                successCallback(params, result);
                            }
                        }
                    }, function() {});
                } else {
                    // 检查文件名是否合法
                    var errorCode = judgement.isValidFileName(newName);
                    if (errorCode) {
                        window.caiyun.tips.showErrorMsg(errorCode);
                        return errorCode;
                    }

                    if (judgement.isSafeBox()) {
                        newName = encodeURIComponent(newName);
                    }

                    var modifyPar = {
                        contentID: id,
                        contentName: newName,
                        contentDesc: item.contentDesc,
                        tags: item.tags
                    };
                    // 如果是修改"我接收到的文件"下的文件则需要加path路径
                    if (judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)) {
                        var path = judgement.getPath(getCatalogStack()) + "/" + id;
                        $.extend(modifyPar, {
                            path: path
                        });
                    }
                    //如果是修改企业空间（管理员）下的文件
                    if (judgement.isEnterprisePath()) {
                        $.extend(modifyPar, {
                            path: judgement.getPathForEnterprise() + '/' + id
                        });
                    }
                    fileManager.updateContentInfo(modifyPar, function(params, result) {
                        var msg = $.trim(result.message);
                        if (msg) {
                            window.caiyun.ui.iMsgTip.tip(msg, 'error');
                            if (failCallback) {
                                failCallback(params, result);
                            }
                        } else {
                            // 更新改文件项的缓存中的名字
                            var file = cache.getFileCache(constants.FILE_LIST_CACHEGROUP, id);
                            if (result.result.retObj) {
                                file.contentName = result.result.retObj;
                            }
                            if (successCallback) {
                                successCallback(params, result);
                            }
                        }
                    }, function() {});
                }
                //统计修改文件名
                caiyun.pvlog('fileOper', 'rename', id);
            }
        };
        // 用户发起播放音乐
        var mp3Player = function(id) {
            trigger(keys.mp3Player, id ? id : selectedIDs);
        }

        // 用户关闭音乐播放器
        var mp3PlayerClose = function(id) {
            trigger(keys.mp3PlayerClose, id ? id : selectedIDs);
        }

        // 用户发起删除到回收站
        var userDelete = function(id) {
            trigger(keys.userDelete, id ? id : selectedIDs);
        };
        // 同步文件夹用户取消同步
        var syncCancel = function() {
            trigger(keys.syncCancel, selectedIDs);
        };

        // 删除到回收站
        var deleteFile = function(ids, successCallback, failCallback) {
            var _ids = ids || selectedIDs;
            var catalogList = [];
            var contentList = [];
            var account = ownerMSISDN;
            var path = judgement.getPath(getCatalogStack());
            $(_ids).each(function() {
                var item = cache.getFileCache(constants.FILE_LIST_CACHEGROUP,
                    this);
                //分页以后找不到先前图片，如果找不到就在图片缓存中去取
                if (!item) {
                    item = cache.getPictureCache(constants.PICTURE_LIST_CACHE_GROUP, this);
                }
                if (item.catalogID) {
                    // 如果是我接收到的文件下，id则变成全路径形式
                    if (caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)) {
                        catalogList.push(item.path);
                    } else if (caiyun.judgement.isEnterprisePath()) {
                        catalogList.push(caiyun.judgement.getPathForEnterprise() + "/" + item.catalogID);
                    } else {
                        catalogList.push(this);
                    }
                } else {
                    if (caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)) {
                        contentList.push(path + "/" + item.contentID);
                    } else if (caiyun.judgement.isEnterprisePath()) {
                        contentList.push(caiyun.judgement.getPathForEnterprise() + "/" + item.contentID);
                    } else {
                        contentList.push(this);
                    }
                }
            });

            // 在保险箱中则彻底删除
            if (judgement.isSafeBox()) {
                fileManager.drop({
                    catalogIDs: catalogList,
                    contentIDs: contentList
                }, function(params, result) {
                    if ($.trim(result.showMessage)) {
                        // 弹出error对话框
                        window.caiyun.ui.iMsgTip.tip(result.showMessage, 'error');
                        failCallback();
                        return;
                    }
                    dropCount += _ids.length;
                    count -= _ids.length;
                    // 清除缓存
                    $(_ids).each(function() {
                        cache.delFileCache(this);
                    });
                    trigger(keys.dropItems, _ids);
                    window.caiyun.ui.iMsgTip.tip('删除成功');
                    if (successCallback) {
                        successCallback(params, result);
                    }
                    if (needReload()) {
                        reLoad();
                    }
                    window.caiyun.initdata.setDiskSize();
                }, function() {});
                // 保险箱删除操作PV统计
                if (catalogList) {
                    for (var i = 0; i < catalogList.length; i++) {
                        caiyun.pvlog('safeBox', 'delete', catalogList[i]);
                    }
                }
                if (contentList) {
                    for (var i = 0; i < contentList.length; i++) {
                        caiyun.pvlog('safeBox', 'delete', contentList[i]);
                    }
                }
            } else {
                var stack = getCatalogStack();
                // 如果是在我接收到的文件夹一级目录下，则是退出共享操作。
                if (judgement.isReceviteDir(stack)) {
                    window.caiyun.biz.fileShare.leaveShare({
                        account: ownerMSISDN,
                        catalogIDList: catalogList.toString(),
                        contentIDList: contentList.toString()
                    }, function(params, result) {
                        if ($.trim(result.showMessage)) {
                            // 弹出error对话框
                            window.caiyun.ui.iMsgTip.tip(result.showMessage, 'error');
                            return;
                        }
                        window.caiyun.ui.iMsgTip.tip('删除分享成功');
                        dropCount += _ids.length;
                        count -= _ids.length;
                        // 清除缓存
                        $(_ids).each(function() {
                            cache.delFileCache(this);
                        });
                        trigger(keys.dropItems, _ids);
                        if (successCallback) {
                            successCallback(params, result);
                        }
                        if (needReload()) {
                            reLoad();
                        }
                    }, function() {});
                    // 退出共享pv统计
                    $(_ids).each(function() {
                        var leaveObj = cache.getFileCache(constants.FILE_LIST_CACHEGROUP, this);
                        caiyun.pvlog("fileShare", "exitShare", leaveObj.catalogID ? leaveObj.catalogID : leaveObj.contentID, leaveObj.contentType ? leaveObj.contentType : "0", leaveObj.contentSize ? leaveObj.contentSize : 0, leaveObj.contentSuffix ? leaveObj.contentSuffix : "");
                    });
                } else {
                    fileManager.removeToRecycleBin({
                        account: ownerMSISDN,
                        catalogIDs: catalogList,
                        contentIDs: contentList
                    }, function(params, result) {
                        if ($.trim(result.showMessage)) {
                            // 弹出error对话框
                            window.caiyun.ui.iMsgTip.tip(result.showMessage, 'error');
                            return;
                        }
                        window.caiyun.ui.iMsgTip.tip('删除成功');
                        dropCount += _ids.length;
                        count -= _ids.length;
                        // 清除缓存
                        $(_ids).each(function() {
                            cache.delFileCache(this);
                        });
                        trigger(keys.dropItems, _ids);
                        // 重新设置容量
                        window.caiyun.initdata.setDiskSize();
                        if (successCallback) {
                            successCallback(params, result);
                        }
                        if (needReload()) {
                            reLoad();
                        }
                    }, function() {});
                }
            }
        };

        function needReload() {
            if (catalogStack[catalogStack.length - 1].catalogID === constants.rootIds.myFolder) {
                var catalogs = cache.getGroupCache(constants.FILE_LIST_CACHEGROUP).getCache();
                var defaultCount = 0;
                for (var catalogId in catalogs) {
                    if (catalogId === constants.publisherAccountConstants.publisherDir || catalogId === constants.publisherAccountConstants.draftBox || judgement.notModify(catalogs[catalogId])) {
                        defaultCount++;
                    }
                }
                return startPage * constants.gridInitConfig.endNum - dropCount <= defaultCount;
            }
            return count <= 0 || startPage * constants.gridInitConfig.endNum - dropCount <= 0;
        }

        // 同步文件夹取消同步
        var syncCancelfunc = function(id, successCallback, failCallback) {
            // 统计取消同步操作
            caiyun.pvlog('syncFile', 'remvsync', selectedIDs[0]);
            var id = selectedIDs[0];
            var item = cache.getFileCache(constants.FILE_LIST_CACHEGROUP, id);
            var name = item.catalogName;
            fileManager.updateCatalogInfo({
                catalogID: id,
                catalogName: name,
                catalogType: "0"
            }, function(params, result) {
                var msg = $.trim(result.message);
                if (msg) {
                    window.caiyun.ui.iMsgTip.tip(msg, 'error');

                } else {
                    // reLoad();
                    window.caiyun.ui.iMsgTip.tip("取消同步成功!");
                    item.catalogType = "0";
                }
            }, function() {});

        };

        var getFileSrc = function(key) {
            var fileSrc = "";
            if (key.sharer) {
                if (key.sharer.indexOf("E") != -1) {
                    fileSrc = key.catalogName.substring(0, key.catalogName.length - 7);
                } else {
                    fileSrc = linkData.getNameForPhone(key.sharer);
                }
            }
            if(key.shareType === '5'){
                return '';
            }
            return fileSrc;
        };

        /** ************************对外暴露回调方法end*************************************** */

        /** ************************数据加载查询start*************************************** */

        // 判断目录在路径栈中的位置
        var indexInCatalogStack = function(catalogId) {
            for (var i in catalogStack) {
                if (catalogStack[i].catalogID == catalogId) {
                    return parseInt(i);
                }
            }
        };


        /** 文档在线编辑 * */
        var edit = function() {
            var data = cache.getFileCache(constants.FILE_LIST_CACHEGROUP, selectedIDs[0]);
            setReceDirReadStatus(data.contentID);
            if (judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)) {
                caiyun.fileOnlineEdit.edit($.extend({}, data, {
                    path: judgement.getPath() + "/" + data.contentID
                }));
            } else {
                caiyun.fileOnlineEdit.edit(data);
            }
            //在线编辑提交pv统计
            caiyun.pvlog('fileOper', 'editDoc', data.contentID);
        };

        // 收到分享文件夹查询
        var enterReceiveDir = function(params) {
            if (constants.abortAjaxs) {
                constants.abortAjaxs.abort();
            }
            var param = {
                account: ownerMSISDN,
                sndRcv: "1",
                orderField: params.contentSortType || params.catalogSortType,
                order: (params.sortDirection == '1') ? '0' : "1" || sortType.desc,
                startRange: params.startNumber || constants.gridInitConfig.startNum,
                endRange: params.endNumber || constants.gridInitConfig.endNum,
                readStatus: "0",
                retrievalItem: "0",
                status: "0"
            };
            constants.abortAjaxs = fileShareManager.getShareList(param, queryFileShareSuccCallBack, queryFileShareFailCallBack);
        };

        var queryFileShareSuccCallBack = function(param, data) {
            scrolling = false;
            $('#listLoading').fadeOut('slow');
            if (data.resultCode == "0") {
                scrollLoadSucc();
                // 过滤数据
                var dci = {};
                var cataInfos = [];
                var conInfos = [];
                var listRsp = data.getShareListRsp;
                var detailShareRspInfo = listRsp.detailShareRspInfoList.detailShareRspInfo;
                if (detailShareRspInfo) {
                    $.each(detailShareRspInfo, function(i, data) {
                        if (data.catalogInfo) {
                            data.catalogInfo.updateTime = data.shareTime; //将shareTime转换成updataTime用于前端展示
                            cataInfos.push($.extend({}, data.shareInfo, data.catalogInfo));
                        };
                        if (data.contentInfo) {
                            data.contentInfo.updateTime = data.shareTime; //将shareTime转换成updataTime用于前端展示
                            conInfos.push($.extend({}, data.shareInfo, data.contentInfo));
                        };
                    });
                    dci = {
                        cataloginfos: cataInfos,
                        contents: conInfos,
                        totalNums: listRsp.totalNums
                    };
                }
                // 数据放入缓存
                dci.nodeCount = listRsp.totalNums;
                cache.putFileCache(constants.FILE_LIST_CACHEGROUP, dci);
                count = listRsp.totalNums;
                // 列表添加数据
                trigger(keys.loadReceiveData, dci);
            } else {
                window.caiyun.ui.iMsgTip.tip("系统繁忙,请稍后再试!", 'error');
            }
        };


        var queryFileShareFailCallBack = function() {
            scrolling = false;
            $('#listLoading').fadeOut('slow');
            // 弹出error对话框
        };

        // 打开所在文件夹回调
        var enterDirLocateCallBack = function(params, json) {
            var resInfo = json.gotoParentCtlgRes;
            if (resInfo.resultcode == "0") {
                if (resInfo.prtCtlgPath[0].id == constants.rootIds.myFolderWithUserID && startPage == "1" && !resInfo.prtCtlgPath[1]) {
                    caiyun.ui.model.fileContent.switchToView(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW);
                    caiyun.operate.enterDir(caiyun.constants.rootIds.myFolder);
                    return;
                }
                scrollLoadSucc();
                catalogStack = [];
                $.each(resInfo.prtCtlgPath, function(index, item) {
                    var itemName = item.name;
                    // 如果返回的是我的文件，改掉文件名变成 我的文件
                    if (item.id === constants.rootIds.myFolderWithUserID) {
                        itemName = constants.rootIdsName[constants.rootIds.myFolder];
                        item.id = constants.rootIds.myFolder;
                    }
                    catalogStack.push({
                        catalogName: itemName,
                        catalogID: item.id
                    });
                });
                queryClear();
                queryParams.id = catalogStack[catalogStack.length - 1].catalogID;
                trigger(keys.enterDir, catalogStack);
                dci = {
                    cataloginfos: resInfo.ctlgList,
                    contents: resInfo.contList,
                    totalNums: resInfo.count
                };
                // 数据放入缓存
                dci.nodeCount = resInfo.count;
                cache.putFileCache(constants.FILE_LIST_CACHEGROUP, dci);
                count = resInfo.count;
                // 列表添加数据
                trigger(keys.loadData, dci);
            } else {
                window.caiyun.ui.iMsgTip.tip("系统繁忙,请稍后再试!", 'error');
            }
        };

        // 打开所在文件夹
        var enterDirLocate = function(param) {
            var contentId = param.id || param.contID || "";
            var cataID = param.cataID || "";
            var datas = {
                contID: contentId,
                cataID: cataID,
                endNumber: constants.gridInitConfig.endNum,
                path: param.path || '',
                isShare: param.isShare
            };

            queryType = 0;
            queryClear();
            var dateType = "json";
            if (caiyun.judgement.isSafeBox()) {
                dateType = "jsonp";
            }
            constants.abortAjaxs = ajax({
                type: "POST",
                url: "webdisk/Search!toContentCtlgDir.action",
                dataType: dateType,
                data: datas,
                succFun: enterDirLocateCallBack,
                errFun: function() {}
            });
        };


        // 外链\分享 转存成功后打开
        var enterCopyDirLocate = function(param) {
            var contentId = param.id || param.contID || "";
            var cataID = param.cataID || "";
            var datas = {
                contID: contentId,
                cataID: cataID,
                endNumber: constants.gridInitConfig.endNum,
                path: param.path || '',
                isShare: param.isShare
            };

            //如果在根目录下，直接打开文件
            if (cataID == constants.rootIds.myFolder) {
                enterDir(cataID);
                return;
            } else if (cataID == constants.rootIds.myFolderWithUserID) {
                enterDir(cataID.replace(wdUserId, ""));
                return;
            } else if (cataID === constants.cannotModifyIDs.root_receiveShare) {

            }

            queryType = 0;
            queryClear();
            var dateType = "json";
            if (caiyun.judgement.isSafeBox()) {
                dateType = "jsonp";
            }
            constants.abortAjaxs = ajax({
                type: "POST",
                url: "webdisk/Search!toContentCtlgDir.action",
                dataType: dateType,
                data: datas,
                succFun: enterCopyDirLocateCallBack,
                errFun: function() {}
            });
        };

        // 外链\分享 转存成功后打开 回调
        var enterCopyDirLocateCallBack = function(params, json) {
            var resInfo = json.gotoParentCtlgRes;
            if (resInfo.resultcode == "0") {
                scrollLoadSucc();
                catalogStack = [];
                // 先根据级别排序
                resInfo.prtCtlgPath.sort(function(a, b) {
                    return parseInt(a.level, 10) > parseInt(b.level, 10);
                });
                $.each(resInfo.prtCtlgPath, function(index, item) {
                    var itemName = item.name;
                    // 如果返回的是我的文件，改掉文件名变成彩云
                    if (item.id === constants.rootIds.myFolderWithUserID || item.id === constants.rootIds.myFolder) {
                        itemName = constants.rootIdsName[constants.rootIds.myFolder];
                        item.id = constants.rootIds.myFolder;
                    }
                    catalogStack.push({
                        catalogName: itemName,
                        catalogID: item.id
                    });
                    if (params.data.isShare && (item.id === constants.rootIds.myFolderWithUserID || item.id === constants.rootIds.myFolder)) {
                        catalogStack.push({
                            catalogID: constants.cannotModifyIDs.root_receiveShare,
                            catalogName: "收到的分享"
                        });
                    }
                });
                queryClear();
                queryParams.id = catalogStack[catalogStack.length - 1].catalogID;
                // 如果是进入文件夹，不需要触发两次enterDir
                if (!params.data.cataID) {
                    trigger(keys.enterDir, catalogStack);
                }
                dci = {
                    cataloginfos: resInfo.ctlgList,
                    contents: resInfo.contList,
                    totalNums: resInfo.count
                };
                // 数据放入缓存
                dci.nodeCount = resInfo.count;
                cache.putFileCache(constants.FILE_LIST_CACHEGROUP, dci);
                count = resInfo.count;

                if (params.data.cataID && params.data.cataID != constants.rootIds.myFolderWithUserID) {
                    // 如果包含当前目录信息则直接进入
                    if (cache.getFileCache(constants.FILE_LIST_CACHEGROUP, params.data.cataID)) {
                        if (params.data.isShare) {
                            caiyun.operate.enterDir(params.data.cataID, null, params.data.path);
                        } else {
                            caiyun.operate.enterDir(params.data.cataID);
                        }
                    } else {
                        // 继续查询目录信息
                        var dateType = "json";
                        if (caiyun.judgement.isSafeBox()) {
                            dateType = "jsonp";
                        }
                        constants.abortAjaxs = ajax({
                            type: "POST",
                            url: "webdisk2/multiGetInfosAction.action",
                            dataType: dateType,
                            data: {
                                isShare: params.data.isShare,
                                catalogIDs: params.data.cataID,
                                path: params.data.path // 这个参数不需要传递，只是用于回调时用
                            },
                            succFun: queryCatalogInfoSuccess
                        });
                    }

                    return;
                } else {
                    // 文件的话，直接添加数据
                    trigger(keys.loadData, dci);
                }

            } else {
                window.caiyun.ui.iMsgTip.tip("文件(夹)不存在或已被删除", 'error');
                // 找不到就回到彩云主目录
                caiyun.ui.model.fileContent.switchToView(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW);
                caiyun.operate.enterDir(caiyun.constants.rootIds.myFolder);
            }
        };

        function queryCatalogInfoSuccess(param, json) {
            var resultCode = json.result.resultcode;
            var message = json.message;
            var catalogInfoList = null;
            if (resultCode === '0') {
                catalogInfoList = json.result.multiGetCatalogInfosRes.catalogInfoList;
                if (!catalogInfoList || catalogInfoList.length === 0) {
                    window.caiyun.ui.iMsgTip.tip("文件(夹)不存在或已被删除", 'error');
                    // 找不到就回到彩云主目录
                    caiyun.ui.model.fileContent.switchToView(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW);
                    caiyun.operate.enterDir(caiyun.constants.rootIds.myFolder);
                } else {
                    var catalogInfo = catalogInfoList[0];
                    // 放入缓存中
                    cache.addCatalogCache(constants.FILE_LIST_CACHEGROUP, catalogInfo);
                    if (param.data.isShare) {
                        caiyun.operate.enterDir(catalogInfo.catalogID, null, param.data.path);
                    } else {
                        caiyun.operate.enterDir(catalogInfo.catalogID);
                    }
                }
            } else {
                if (message) {
                    window.caiyun.ui.iMsgTip.tip(message, 'error');
                }
            }
        }


        // timeline打开文件夹
        var enterDir4Timeline = function(param, dciObj, shareInfo, curPath) {
            var contentId = param.id || "";
            var cataID = param.cataID || "";
            var datas = {
                contID: contentId,
                cataID: cataID,
                endNumber: constants.gridInitConfig.endNum,
                path: curPath
            };
            queryType = 0;
            queryClear();
            var dateType = "json";
            if (caiyun.judgement.isSafeBox()) {
                dateType = "jsonp";
            }
            if (cataID == constants.rootIds.myFolder) { //已经在根目录了，不需要调用toContentCtlgDir.action拼接导航了
                scrollLoadSucc();
                catalogStack = [];
                catalogStack.push({
                    catalogName: "彩云",
                    catalogID: param.cataID
                });
                queryClear();
                queryParams.id = catalogStack[catalogStack.length - 1].catalogID;
                trigger(keys.enterDir, catalogStack);

                var vDir = {
                    catalogID: constants.cannotModifyIDs.root_receiveShare,
                    catalogType: "0",
                    catalogName: constants.receiveFolderName,
                    parentid: constants.rootIds.myFolder,
                    shareType: '0',
                    isFixedDir: 1,
                    updateTime: '---'
                };
                dciObj.cataloginfos.splice(0, 0, vDir);

                dci = {
                    cataloginfos: dciObj.cataloginfos,
                    contents: dciObj.contents,
                    totalNums: dciObj.nodeCount
                };
                // 数据放入缓存
                dci.nodeCount = dciObj.nodeCount;
                cache.putFileCache(constants.FILE_LIST_CACHEGROUP, dci);
                count = dciObj.nodeCount;
                // 列表添加数据
                trigger(keys.loadData, dci);
            } else {
                constants.abortAjaxs = ajax({
                    type: "POST",
                    url: "webdisk/Search!toContentCtlgDir.action",
                    dataType: dateType,
                    data: datas,
                    succFun: function(params, json) {
                        var resInfo = json.gotoParentCtlgRes;
                        if (resInfo.resultcode == "0") {
                            scrollLoadSucc();
                            catalogStack = [];
                            resInfo.prtCtlgPath.sort(function(a, b) {
                                return parseInt(a.level) > parseInt(b.level);
                            });
                            $.each(resInfo.prtCtlgPath, function(index, item) {
                                var itemName = item.name;
                                // 如果返回的是我的文件，改掉文件名变成 我的文件
                                if (item.id === constants.rootIds.myFolderWithUserID) {
                                    itemName = constants.rootIdsName[constants.rootIds.myFolder];
                                    item.id = constants.rootIds.myFolder;
                                }

                                catalogStack.push({
                                    catalogName: itemName,
                                    catalogID: item.id
                                });

                                if (shareInfo && item.id === constants.rootIds.myFolder) {
                                    catalogStack.push({
                                        catalogName: shareInfo.name,
                                        catalogID: shareInfo.cataID
                                    });
                                }
                            });
                            //增加自己的name,id到导航
                            //如果文件夹涉及改名操作，取最新文件夹名展示导航条
                            var catalgInfo = resInfo.ctlgList;
                            for (var i = 0; i < catalgInfo.length; i++) {
                                if (catalgInfo[i].catalogID === cataID)
                                    param.name = catalgInfo[i].catalogName;
                            };
                            var cur = {
                                catalogName: param.name,
                                catalogID: param.cataID
                            };
                            if (curPath) cur.path = curPath;
                            catalogStack.push(cur);
                            queryClear();
                            queryParams.id = catalogStack[catalogStack.length - 1].catalogID;
                            trigger(keys.enterDir, catalogStack);
                            dci = {
                                cataloginfos: dciObj.cataloginfos,
                                contents: dciObj.contents,
                                totalNums: dciObj.nodeCount
                            };
                            // 数据放入缓存
                            dci.nodeCount = dciObj.nodeCount;
                            cache.putFileCache(constants.FILE_LIST_CACHEGROUP, dci);
                            count = dciObj.nodeCount;
                            // 列表添加数据
                            trigger(keys.loadData, dci, 1); // 1表示是查询的第一页

                            //进入文件夹统计
                            caiyun.pvlogforTimeline('fileOper', 'openFold', param.id, "", "", "", "", "");
                            //var setParam = {account:ownerMSISDN,catalogIDList:param.cataID,contentIDList:'',readStatus:'1',replyAllFlag:'0'};
                            if (shareInfo) {
                                var params = {
                                    cataID: param.cataID,
                                    contentID: ""
                                };
                                setTimeLineReadStatus(params);
                            }

                        } else {
                            window.caiyun.ui.iMsgTip.tip("系统繁忙,请稍后再试!", 'error');
                        }
                    },
                    errFun: function() {}
                });
            };
        };


        //timeline通知后台已读
        var setTimeLineReadStatus = function(params) {
            var setParam = {
                account: ownerMSISDN,
                catList: params.cataID,
                conList: params.contentID,
                readStatus: '1',
                replyAllFlag: '0'
            };


            fileShareManager.replyShare(setParam, function() {}, function() {});
        }

        // 文件夹查询
        var enterDir = function(rootId, newPathItem, path) {
            var rootId = rootId || selectedIDs[0];
            setReceDirReadStatus(rootId);
            queryType = 0;
            // 如果存在根目录名字，则切换
            var pathName = constants.rootIdsName[rootId];
            var pathItem;
            if (pathName) {
                catalogStack = [];
                catalogStack.push({
                    catalogName: pathName,
                    catalogID: rootId
                });
            } else {
                var index = indexInCatalogStack(rootId);
                if (index >= 0) {
                    catalogStack.splice(index + 1, catalogStack.length);
                } else {
                    pathItem = cache.getFileCache(
                        constants.FILE_LIST_CACHEGROUP, rootId) || newPathItem;
                    catalogStack.push(pathItem);
                }
            }
            // 保留排序参数
            var catalogSortType = queryParams['catalogSortType'];
            var contentSortType = queryParams['contentSortType'];
            var sortDirection = queryParams['sortDirection'];
            queryParams = {
                id: rootId,
                catalogSortType: catalogSortType,
                contentSortType: contentSortType,
                sortDirection: sortDirection
            };
            trigger(keys.enterDir, catalogStack, queryParams);
            selectedIDs = [];
            trigger(keys.selectData, selectedIDs);
            queryClear();
            // setListViewInfo();
            if (pathItem) {
                $.extend(queryParams, {
                    path: pathItem.path
                });
            }
            if (path) {
                $.extend(queryParams, {
                    path: path
                });
            }
            enterFolder(queryParams);
        };

        // 获取拼装目录查询参数
        var getQueryToByFolderParams = function(param) {

            var hdhd = param.id || constants.rootIds.myFolder;
            var params = {
                contentID: param.id || constants.rootIds.myFolder,
                catalogSortType: param.catalogSortType || constants.gridInitConfig.catalogSortType,
                contentSortType: param.contentSortType || constants.gridInitConfig.contentSortType,
                filtertype: param.filtertype || 0,
                startNumber: param.startNumber || constants.gridInitConfig.startNum,
                endNumber: param.endNumber || constants.gridInitConfig.endNum,
                sortDirection: param.sortDirection || 1,
                // 文件类型
                contentType: param.contentType || 0
            };
            if (param.path) {
                $.extend(params, {
                    path: param.path
                });
            }

            return params;
        };

        // 是否存在新数据
        var hasNewData = function(json) {
            if (!json) {
                return false;
            }
            if (json.cataloginfos && json.cataloginfos.length > 0) {
                return true;
            }
            if (json.contents && json.contents.length > 0) {
                return true;
            }
            if (json.diskcataloginfo && json.diskcataloginfo.contents && json.diskcataloginfo.contents.length > 0) {
                return true;
            }
        };

        // 进入文件夹统一方法
        var enterFolder = function(param) {
            var params = getQueryToByFolderParams(param);
            // 判断是否进入"我收到的分享文件"目录
            if (param.id.indexOf(constants.cannotModifyIDs.root_receiveShare) != -1) {
                enterReceiveDir(params);
                // 通知后台修改成"已读状态"
                //setReadStatus();
            } else {
                queryToByFolder({
                    url: "webdisk2/queryContentAndCatalog!disk.action",
                    data: params,
                    success: queryCatalogSuccCallBack,
                    fail: queryCatalogFailCallBack
                });
            }
            // 显示加载更多的提示栏
            $('#listLoading').fadeIn('fast');
            // 统计进入文件夹
            caiyun.pvlog('fileOper', 'openFold', param.id, (param.contentType ? param.contentType : ''));
        };

        var queryCatalogSuccCallBack = function(params, json) {
            scrolling = false;
            $('#listLoading').fadeOut('slow');
            if ($.trim(json.showMessage)) {
                // 弹出error对话框
                window.caiyun.ui.iMsgTip.tip(json.showMessage, 'error');
            } else {
                scrollLoadSucc();
                // 数据放入缓存
                // 如果上级目录是root,则将虚拟目录"我收到的文件"加入返回json中
                if (json.dci.parentid == constants.rootIds.myFolder && startPage == "1" && json.dci.cataloginfos && json.dci.cataloginfos.length > 0) {
                    var vDir = {
                        catalogID: constants.cannotModifyIDs.root_receiveShare,
                        catalogType: "0",
                        catalogName: constants.receiveFolderName,
                        parentid: json.dci.parentid,
                        shareType: '0',
                        isFixedDir: 1,
                        updateTime: '---'
                    };
                    json.dci.cataloginfos.splice(0, 0, vDir);
                }
                cache.putFileCache(constants.FILE_LIST_CACHEGROUP, json.dci);
                count = json.dci.nodeCount;
                // 列表添加数据
                trigger(keys.loadData, json.dci, startPage);
                if (json.dci.parentid == constants.rootIds.myFolder && startPage == "1") {
                    // 通知修改"我收到的文件"状态
                    changReceDirStatus();
                }
            }
        };

        var queryCatalogFailCallBack = function(request, textStatus,
            errorThrown, params) {
            scrolling = false;
            $('#listLoading').fadeOut('slow');
            // 弹出error对话框
        };

        var getQueryToByTypeParams = function(param) {
            var params = {
                isSumnum: param.isSumnum || 1,
                contentType: param.type || 0,
                contentSortType: param.contentSortType || constants.gridInitConfig.contentSortType,
                startNumber: param.startNumber || constants.gridInitConfig.startNum,
                endNumber: param.endNumber || constants.gridInitConfig.endNum,
                sortDirection: param.sortDirection || 1
            };

            return params;
        };

        var queryByType = function(param) {
            // 清空当前目录栈
            catalogStack = [];
            // 特殊的目录地址
            var id = constants.catalogIDPrefix.byType + param.type;
            catalogStack.push({
                catalogID: id,
                catalogName: constants.fileTypesName[param.type]
            });

            // 虚拟目录-分类文件
            var typedCata = constants.catalogIDPrefix.byType + constants.fileTypes.typed;
            catalogStack.push({
                catalogID: typedCata,
                catalogName: constants.fileTypesName[param.type]
            });

            queryType = 1;
            trigger(keys.enterDir, id);
            selectedIDs = [];
            trigger(keys.selectData, selectedIDs);
            queryClear();
            isByType = true;
            queryParams = {
                type: param.type
            };
            queryDataByType(queryParams);
        };

        // 按文件类型查询
        var queryDataByType = function(param) {
            $('#listLoading').fadeIn('slow');
            var params = getQueryToByTypeParams(param);
            queryToByFolder({
                url: "webdisk2/getContentInfo!byType.action",
                data: params,
                success: queryByTypeSuccCallBack,
                fail: queryByTypeFailCallBack
            });
        };

        var queryByTypeSuccCallBack = function(params, json) {
            scrolling = false;
            $('#listLoading').fadeOut('slow');
            if ($.trim(json.showMessage)) {
                // 弹出error对话框
                window.caiyun.ui.iMsgTip.tip(json.showMessage, 'error');
            } else {
                scrollLoadSucc();
                // 数据放入缓存
                cache.putFileCache(constants.FILE_LIST_CACHEGROUP, json.diskcataloginfo);
                count = json.diskcataloginfo.nodeCount;
                // 列表添加数据
                trigger(keys.loadData, json.diskcataloginfo);
            }
        };

        var queryByTypeFailCallBack = function(request, textStatus,
            errorThrown, params) {
            scrolling = false;
            $('#listLoading').fadeOut('slow');
            // 弹出error对话框
        };

        // 获取后缀查询参数
        var getQueryToBySuffixParams = function(param) {
            return params = {
                catalogSortType: param.catalogSortType || constants.gridInitConfig.catalogSortType,
                contentSortType: param.contentSortType || constants.gridInitConfig.contentSortType,
                startNumber: param.startNumber || constants.gridInitConfig.startNum,
                endNumber: param.endNumber || constants.gridInitConfig.endNum,
                sortDirection: param.sortDirection || 1,
                isSumnum: param.isSumnum || 1,
                channelList: param.channelList,
                contentType: param.contentType,
                contentSuffix: param.contentSuffix
            };
        };

        // 根据文件后缀查询
        var _queryBySuffix = function(param) {
            var allParams = getQueryToBySuffixParams(param);
            $('#listLoading').fadeIn('slow');
            if (constants.abortAjaxs) {
                constants.abortAjaxs.abort();
            }

            constants.abortAjaxs = fileManager.queryContentInfosBySuffix(allParams, function(params, json) {
                $('#listLoading').fadeOut('slow');
                scrolling = false;
                if ($.trim(json.showMessage)) {
                    // 弹出error对话框
                    window.caiyun.ui.iMsgTip.tip(json.showMessage, 'error');
                } else {
                    scrollLoadSucc();
                    // 数据放入缓存
                    cache.putFileCache(constants.FILE_LIST_CACHEGROUP,
                        json.dci);
                    count = json.dci.nodeCount;
                    // 列表添加数据
                    trigger(keys.loadData, json.dci);
                }
            }, function() {
                scrolling = false;
                $('#listLoading').fadeOut('slow');
            }, true);
        };

        // 按照文件后缀查询
        var queryBySuffix = function(param) {
            catalogStack = [];
            var id = constants.catalogIDPrefix.byPhoneOS + param.os;
            var name = param.os;
            catalogStack.push({
                catalogID: id,
                catalogName: name
            });

            queryType = 2;
            trigger(keys.enterDir, id);
            selectedIDs = [];
            trigger(keys.selectData, selectedIDs);
            queryClear();
            queryParams = {
                contentSuffix: param.contentSuffix,
                contentType: param.contentType
            };
            _queryBySuffix(param);
        };

        // 按文件夹，即结点查询
        var queryToByFolder = function(param) {
            if (constants.abortAjaxs) {
                constants.abortAjaxs.abort();
            }
            constants.abortAjaxs = ajax({
                type: "POST",
                url: param.url,
                dataType: "json",
                data: param.data,
                succFun: param.success,
                errFun: param.fail,
                hideLoading: param.hideLoading
            });

        };

        // 搜索
        var queryByKeyword = function(param) {
            scrollLoadSucc();
            if (constants.abortAjaxs) {
                constants.abortAjaxs.abort();
            }
            $('#listLoading').fadeIn('slow');
            queryType = 3;
            selectedIDs = [];
            trigger(keys.selectData, selectedIDs);
            getQueryByKeywordParams(param);

            if (params.startNumber == 1) {
                //    trigger(keys.reload);
                queryClear();
            }

            if (param.catalogStack) {
                // 进入搜索结果，保留原本的导航目录栈
                catalogStack = param.catalogStack;
            }
            if (param.searchType) {
                searchType = param.searchType;
            }
            if (param.path) {
                path = param.path;
            }
            params.path = path;
            switch (searchType) {
                case 1:
                case 2:
                    url = "webdisk/Search!advanced.action";
                    params.searchScope = "0";
                    params.searchFileType = 1111111111111111;
                    break;
                case 3:
                    params.path = "";
                    url = "webdisk/Search!simple.action";
                    break;
            };

            queryToByFolder({
                url: url,
                data: params,
                success: queryByKeywordSuccCallBack,
                fail: queryByKeywordFailCallBack
            });
            $('#createFolderBtn').hide();
            $('#uploadBtn').css("visibility", "hidden").css('left', '-1000px');
        };

        var getQueryByKeywordParams = function(param) {
            keyWords = param.keyWord || $('#keyword').val();
            return params = {
                scope: "1000000000000000",
                keyWord: keyWords,
                startNumber: param.startNumber || constants.gridInitConfig.startNum,
                endNumber: param.endNumber || constants.gridInitConfig.endNum
            };
        };

        var queryByKeywordSuccCallBack = function(params, json) {
            scrolling = false;
            $('#listLoading').fadeOut('slow');
            if ($.trim(json.returnMsg)) {
                // 弹出error对话框
                window.caiyun.ui.iMsgTip.tip(json.returnMsg, 'error');
            } else {
                scrollLoadSucc();
                // 数据放入缓存
                var contents = [];
                count = json.count;
                if (count > 0) {
                    $.each(json.contentList, function(index, item) {
                        item.contentInfo.updateTime = window.caiyun.util.formateSearchTime(item.contentInfo.updateTime);
                        // 目前 其他页面都把上传时间改成更新时间了
                        item.contentInfo.uploadTime = window.caiyun.util.formateSearchTime(item.contentInfo.updateTime);
                        if (path && path != "") {
                            item.contentInfo.path = path;
                        }
                        contents.push(item.contentInfo);
                    });
                    cache.putFileCache(constants.FILE_LIST_CACHEGROUP, {
                        "contents": contents
                    });

                    /*   $.each(json.catalogList, function(index, item){
                      catalogs.push(item.catalogInfo);
                  });*/
                }
                json.contentList = contents;

                var keywordShort = keyWords.substringName(70);
                // 调整页面视图
                $("#searchResultCount").html(" > " + count + '条搜索结果 “<span style="color:#4c14a5;font-weight:bold" title="' + keyWords + '">' + keywordShort + '</span>”');

                // 列表添加数据
                trigger(keys.loadSearchData, json);
            }
        };

        var queryByKeywordFailCallBack = function(request, textStatus,
            errorThrown, params) {
            scrolling = false;
            $('#listLoading').fadeOut('slow');
            // 弹出error对话框
        };

        // 文件夹查询数据前的清理工作
        var queryClear = function() {
            // 文件缓存清空
            cache.clearFileCache(constants.FILE_LIST_CACHEGROUP);
            startPage = 1;
            dropCount = 0;
            count = 0;
            isScrollLoad = false;
            isByType = false;
        };

        // 排序查询数据前的清理工作
        var sortClear = function() {
            // 文件缓存清空
            cache.clearFileCache(constants.FILE_LIST_CACHEGROUP);
            startPage = 1;
            dropCount = 0;
            count = 0;
            isScrollLoad = false;
        };

        // 滚动数据查询中止或是失败时对于page的恢复
        var scrollLoadSucc = function() {
            if (isScrollLoad) {
                startPage++;
            }
        };

        // 中断查询
        var abortQuery = function() {
            if (constants.abortAjaxs) {
                constants.abortAjaxs.abort();
            }
        };

        // 打包下载
        var userDownload = function(id) {
            var params = id ? id : selectedIDs;
            setReceDirReadStatus(params);
            trigger(keys.userDownload, id ? id : selectedIDs);
        };

        // 下载
        var download = function(ids, successCallback, failCallback) {
            // 获取文件信息
            var _ids = ids || selectedIDs;

            if (!(ids instanceof Array)) {
                _ids = [_ids];
            }

            var catalogList = [];
            var contentList = [];
            var path = "";
            if (judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)) {
                path = judgement.getPath(caiyun.operate.getCatalogStack());
            }
            if (judgement.isEnterprisePath()) {
                path = judgement.getPathForEnterprise();
            }


            $(_ids).each(function() {
                var item = cache.getFileCache(constants.FILE_LIST_CACHEGROUP, this);
                //分页以后找不到先前图片，如果找不到就在图片缓存中去取
                if (!item) {
                    item = cache.getPictureCache(constants.PICTURE_LIST_CACHE_GROUP, this);
                }
                //视频播放从缓存中取
                if (!item) {
                    item = cache.getVideoCache(constants.VIDEO_LIST_CACHE_GROUP, this);
                }
                if (item.catalogID) {
                    catalogList.push({
                        catalogID: item.catalogID,
                        name: item.catalogName,
                        type: item.catalogType,
                        path : item.path,
                        parentCatalogId : item.parentCatalogId
                    });
                } else {
                    contentList.push({
                        contentID: item.contentID,
                        name: item.contentName,
                        contentSize: item.contentSize,
                        parentCatalogId : item.parentCatalogId
                    });
                }
            });

            if (catalogList.length === 0 && contentList.length == 0) {
                return;
            }

            // 如果只有一个文件则使用下载到PC
            if (contentList.length === 1 && catalogList.length == 0) {
                var downloadParm = {
                    contentID: _ids[0]
                };
                var path = "";
                if (judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare) || judgement.isInReceivedPublishDir()) {
                     // 如果是公共账号目录下的下载，path特殊处理
                    if (judgement.isInReceivedPublishDir()) {
                         path = judgement.getPathInPublishDir(contentList[0].parentCatalogId, _ids[0]);
                    }
                    else{
                        path = judgement.getPath(caiyun.operate.getCatalogStack()) + '/' + _ids[0];
                    }

                    var item = cache.getFileCache(constants.FILE_LIST_CACHEGROUP, _ids[0]);
                    $.extend(downloadParm, {
                        path: path ,
                        ownerMSISDN: item.sharer
                    });
                }
                if (judgement.isEnterprisePath()) {
                    path = judgement.getPathForEnterprise();
                    var item = cache.getFileCache(constants.FILE_LIST_CACHEGROUP, _ids[0]);
                    $.extend(downloadParm, {
                        path: path + '/' + _ids[0],
                        ownerMSISDN: item.sharer
                    });
                }
                //timeline下载别人共享给你的文件需要直接从页面传入path和ownerMSISDN参数，通过判断my_active标签的显示隐藏来判断是否在timeline视图下
                if ($('#tl_show_by_opType').css("display") == "block" || $('#tl_show_by_opType').css("display") == "inline") {
                    if (download4TimelineParam.path) downloadParm.path = download4TimelineParam.path;
                    if (download4TimelineParam.ownerMSISDN) downloadParm.ownerMSISDN = download4TimelineParam.ownerMSISDN;
                    if (download4TimelineParam.timelineFlag) downloadParm.timelineFlag = download4TimelineParam.timelineFlag;
                }
                if (!$.browser.msie) {
                    fileManager.downloadFile(downloadParm, successCallback, failCallback);
                    return 'downloadFile';
                } else {
                    // 如果是IE用另外一个链接下载之
                    var downloadFrame = $('#downloadFile');
                    var queryStr = '';
                    for (var pname in downloadParm) {
                        queryStr += pname + '=' + encodeURIComponent(downloadParm[pname]) + '&';
                        if (pname === 'contentID') {
                            queryStr += 'shareContentIDs=' + downloadParm[pname] + '&';
                        }
                    }
                    queryStr += 'redirect=t';
                    if (!judgement.isSafeBox()) {
                        downloadFrame.attr('src', '/webdisk2/downLoadAction!downloadToPC.action?' + queryStr);
                    } else {
                        downloadFrame.attr('src', address + 'safebox/downLoadAction!downloadToPC.action?' + queryStr);
                    }
                    return;
                }
            } else {

                // 统计下载文件的体积
                var totalSize = 0;
                var zipPath = "";
                $(contentList).each(function() {
                    totalSize += parseInt(this.contentSize);
                });
                if (totalSize > constants.maxDownloadsize) {
                    window.caiyun.ui.iMsgTip.tip('选中打包的文件和文件夹不能超过100M，请减少。', 'error');
                    return;
                }

                // 获取当前路径的名称
                var fileName = getCurrentCatalog().catalogName;

                // 如果只是一个文件夹打包使用文件夹名称
                if (catalogList.length == 1 && contentList.length == 0) {
                    fileName = '【批量下载】' + catalogList[0].name.substringName(50,true) + '-彩云';
                } else if (catalogList.length == 0 && contentList.length > 1) {
                    fileName = '【批量下载】' + contentList[0].name.substringName(50) + '等文件-彩云';
                } else if (catalogList.length > 0 && contentList.length >= 0) {
                    fileName = '【批量下载】' + catalogList[0].name.substringName(50,true) + '等文件-彩云';
                }

                if (judgement.isSafeBox()) {
                    fileName = encodeURI(fileName);
                }

                var zipDownParam = {
                    catalogList: catalogList,
                    contentList: contentList,
                    recursive: 1,
                    zipFileName: fileName
                };

                if (judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)) {
                    if (judgement.isReceviteDir(getCatalogStack())) {
                        var item = cache.getFileCache(constants.FILE_LIST_CACHEGROUP, _ids[0]);
                        if (item.catalogID) {
                            zipPath = item.path;
                        }
                        $.extend(zipDownParam, {
                            path: zipPath
                        });
                    } else {
                        path = judgement.getPath();
                        // 只支持单个文件夹的打包下载
                        $.extend(zipDownParam, {
                            path: path
                        });
                    }
                }

                if (judgement.isInReceivedPublishDir()){
                    var pId = null,targetId = null;
                    if(getCatalogStack().length > 3){
                        pId = getCatalogStack()[3].parentCatalogId;
                    }else{
                        if(contentList.length > 0){
                            pId = contentList[0].parentCatalogId;
                        }else{
                            pId = catalogList[0].parentCatalogId;
                        }
                    }
                    

                    // 指定分享需要传入目标文件夹ID
                    if(catalogList.length === 1 ){
                        targetId = catalogList[0].catalogID;
                    }

                    path = judgement.getPathInPublishDir(pId,targetId);
                    $.extend(zipDownParam, {
                            path: path
                    });
                }

                if (judgement.isEnterprisePath()) {
                    $.extend(zipDownParam, {
                        path: judgement.getPathForEnterprise()
                    });
                }

                // 打包下载
                fileManager.downloadZipPkg(zipDownParam,
                    function(params, result) {
                        if (result.message != "") {
                            window.caiyun.ui.iMsgTip.tip(result.message, 'error');
                            if (failCallback) {
                                failCallback(params, result);
                            }
                            return;
                        } else {
                            if (successCallback) {
                                successCallback(params, result);
                            }
                        }
                    }, function() {}
                );

                return 'downloadZip';
            }
        };

        // 复制或移动
        var moveOrCopy = function(op) {
            var _ids = selectedIDs;
            setReceDirReadStatus(_ids);
            if (op == 'move') {
                window.caiyun.ui.model.moveOrCopy({
                    ids: _ids,
                    type: 'move'
                });
            } else if (op == 'copy') {
                window.caiyun.ui.model.moveOrCopy({
                    ids: _ids,
                    type: 'copy'
                });
            }
        };

        /**
         * 拖拽移动云端文件处理函数 dragItemIds {catalogIds: [], contentIds: []}
         * 被拖拽的文件（夹）项的id destinationFolderId {String} 要放置到的文件夹的id
         */
        var dragMoveFiles = function(dragItemIds, destinationFolderId) {
            window.caiyun.ui.model.dragFile.dragMoveFiles({
                catalogIds: dragItemIds.catalogIds,
                contentIds: dragItemIds.contentIds
            }, destinationFolderId);
        };

        /**
         * 拖拽上传本地文件处理函数 files {event.dataTransfer.files} 被拖拽的本地文件
         * destinationFolderId {String} 要放置到的文件夹的id
         */
        var dragUploadFiles = function(files, destinationFolderId) {
            // 收到的分享的首层目录不支持拖拽上传
            if (judgement.isReceiveShareFolder(destinationFolderId)) {
                return;
            }

            var userAgent = navigator.userAgent.toLowerCase();
            // 傲游浏览器event.originalEvent.dataTransfer.files有bug，其返回的files没有清除过去上传过的文件
            if (userAgent.indexOf('maxthon') === -1) {
                window.caiyun.ui.model.dragFile.dragUploadFiles(files, destinationFolderId);
            }
        };

        // 用户触发浏览图片文件
        var browseImage = function(ids) {
            var _id = ids || selectedIDs;
            setReceDirReadStatus(_id);
            $("").lightbox({
                currentImge: {
                    id: _id
                },
                fitToScreen: true,
                scaleImages: true,
                xScale: 1.2,
                yScale: 1.2,
                displayDownloadLink: true
            });
        };

        // 文档预览
        var prew = function(date, shareFilePath) {
            setReceDirReadStatus(date.contentID);
            caiyun.fileOnlineEdit.prev(date, shareFilePath);

        };

        // 分享文件外链
        var creatFileLink = function(ids) {
            trigger(keys.getFileLink, ids ? ids : selectedIDs);
        };

        // 分享文件
        var createShareFile = function(ids) {
            trigger(keys.createShareFile, ids ? ids : selectedIDs);
        };

        //获取分享信息，用于文件分享弹出框.sharememberbox
        var getShareInfo = function(ids) {
            trigger(keys.getShareInfo, selectedIDs);
        };

        // 浏览文件
        var viewFile = function(id) {
            var id = id || selectedIDs[0];
            if (!id) {
                return;
            }
            var content = cache.getFileCache(constants.FILE_LIST_CACHEGROUP, id);
            if (!content) {
                return;
            }

            window.caiyun.viewFile.viewFile(content);

        };

        var setReadStatus = function() {
            var setParam = {
                account: ownerMSISDN,
                catalogIDList: '',
                contentIDList: '',
                readStatus: '1',
                replyAllFlag: '0'
            };
            fileShareManager.replyShare(setParam, function() {}, function() {});
        };

        var setReceDirReadStatus = function(params) {
            var stack = getCatalogStack();
            if (judgement.isReceviteDir(stack)) {
                var catalogInfo = cache.getFileCache(
                    constants.FILE_LIST_CACHEGROUP, params.id ? params.id : params);

                if (!catalogInfo) {
                    return;
                }
                var content = catalogInfo;
                if (catalogInfo.catalogID) {
                    if (catalogInfo.shareeInfoList) {
                        if (catalogInfo.shareeInfoList.shareeInfo[0].readStus == 2) {
                            var setParam = {
                                account: ownerMSISDN,
                                catList: catalogInfo.catalogID,
                                conList: '',
                                readStatus: '1',
                                replyAllFlag: '0'
                            };
                            fileShareManager.replyShare(setParam, function() {
                                trigger(keys.changeRecNew, catalogInfo.catalogID);
                            }, function() {});
                        }
                    }
                } else if (content.contentID) {
                    if (catalogInfo.shareeInfoList.shareeInfo[0].readStus == 2) {
                        var setParam = {
                            account: ownerMSISDN,
                            catList: '',
                            conList: content.contentID,
                            readStatus: '1',
                            replyAllFlag: '0'
                        };
                        fileShareManager
                            .replyShare(
                                setParam,
                                function() {
                                    trigger(keys.changeRecNew, content.contentID);
                                },
                                function() {});
                    }
                }

            }

        };



        // 通知修改"我收到的文件"状态
        var changReceDirStatus = function() {
            caiyun.biz.fileShare.getShareList({
                account: ownerMSISDN,
                sndRcv: "1",
                readStatus: "2",
                retrievalItem: "1",
                status: "0",
                orderField: "0",
                order: "0",
                startRange: "-1",
                endRange: "-1"
            }, function(req, jsonData) {
                // 如果成功修改接收到的文件状态
                if (jsonData.resultCode == "0") {
                    if (jsonData.getShareListRsp.totalNums > 0) {
                        // 修改为"new"状态
                        trigger(keys.changeNew, '');
                    }
                }
            }, function() {});
        };

        var triggerFileContentSwitch = function(oldView, newView) {
            trigger(keys.fileContentSwitch, {
                oldView: oldView,
                newView: newView
            });
        };
        /** ************************数据加载查询end*************************************** */

        /*
         * 监听注册，里面提供了三个监听 【 enterDir : 进入目录时触发，参数为当前进入的目录id selectData:
         * 选择文件，参数为当前所有选择的文件ids loadData ： 数据载入，参数为请求后台的json数据对象 】
         */

        function addListen(key, fun) {
            var ref, stack;
            key = $.trim(key);

            if (keys[key]) {
                stack = (ref = listens[key]) == null ? [] : ref;
                stack.push(fun);
                listens[key] = stack;
            }
            return this;
        };

        var removeListen = function(key) {
            delete listens[$.trim(key)];
            return this;
        };

        var trigger = function(key) {
            var events = listens[key] || {}, params = [],
                i = 1,
                length = arguments.length;
            if (length > 1) {
                for (; i < length; i++) {
                    params.push(arguments[i]);
                }
            }

            $.each(events, function() {
                this.apply(null, params);
            });
        };

        return {
            selectHandler: selectHandler, // 文件项选择处理器，处理被选中的文件
            dbclickHandler: dbclickHandler, // 文件项双击处理器，
            dbclickHandler4Timeline: dbclickHandler4Timeline, // 文件项双击处理器--timeline页面调用
            sortHandler: sortHandler, // 排序处理器
            filterHandler: filterHandler, // 过滤器处理器
            createFolder: createFolder, // 确认创建文件夹提交到后台
            userCreateFolder: userCreateFolder, // 用户发起创建文件夹
            getCurrentPathId: getCurrentPathId, // 获取当前目录ID
            enterDir: enterDir, // 进入文件夹
            enterDirLocate: enterDirLocate, // 打开所在文件夹
            enterCopyDirLocate: enterCopyDirLocate, //外链\分享 转存成功后打开 回调
            enterDir4Timeline: enterDir4Timeline, //timeline进入文件夹
            queryByType: queryByType, // 根据类型查询 ，废弃
            queryBySuffix: queryBySuffix, // 根据后缀查询，废弃
            queryByKeyword: queryByKeyword, // 搜索
            viewSwitch: viewSwitch, // 切换文件视图 web 列表模式 window 缩略图模式
            isCurrView: isCurrView, // 是否当前视图
            getCurrentView: getCurrentView, // 获取当前视图
            reLoad: reLoad, // 刷新
            scrollLoadData: scrollBottomLoadData, // 滚动加载更多数据
            onListen: addListen, // 增加监听器
            removeListen: removeListen, // 删除监听器
            canExecute: canExecute, // 操作是否可以执行
            userRename: userRename, // 用户发起重命名
            rename: rename, // 提交重命名到后台
            userDelete: userDelete, // 用户发起删除
            syncCancel: syncCancel, // 取消分享
            deleteFile: deleteFile, // 删除文件
            syncCancelfunc: syncCancelfunc, // 文件夹取消同步
            userDownload: userDownload, // 用户发起下载
            download: download, // 从后台下载
            creatFileLink: creatFileLink, // 创建文件外链事件
            createShareFile: createShareFile, //创建文件分享事件
            getCatalogStack: getCatalogStack, // 获取当前目录栈
            getCurrentCatalog: getCurrentCatalog, //获取当前目录
            clearSetCatalogStack: clearSetCatalogStack, // 清除当前目录栈
            getFileSrc: getFileSrc, // 获取文件来源
            moveOrCopy: moveOrCopy, // 用户发起移动复制
            changReceDirStatus: changReceDirStatus, // 修改我收到的文件状态
            browseImage: browseImage, // 浏览图片
            viewFile: viewFile, // 浏览文件，播放音频视频
            prew: prew, // 文档预览
            edit: edit, // 文档编辑
            setReceDirReadStatus: setReceDirReadStatus, // 修改我收到的文件为已读状态
            getShareInfo: getShareInfo, //获取分享文件详细信息
            triggerFileContentSwitch: triggerFileContentSwitch, // 触发文件内容区域变化
            dragMoveFiles: dragMoveFiles, // 拖拽文件（夹）
            dragUploadFiles: dragUploadFiles,
            selectAll: selectAll,
            unSelectAll: unSelectAll,
            setCatalogStack: setCatalogStack, // 设置目录栈
            abortQuery: abortQuery, // 中断当前查询
            mp3Player: mp3Player, //播放音乐
            mp3PlayerClose: mp3PlayerClose //关闭音乐播放器
        };
    })();
})();