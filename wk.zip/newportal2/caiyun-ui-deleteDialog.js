/**
 * 删除文件对话框
 */
(function(){
	var self = caiyun.ui.model.deleteDialog;
	var ui = caiyun.ui;
	
	// 初始化方法
	self.init = function(){
		var fileOperator = caiyun.operate;
		var judgement = caiyun.judgement;
		var cache = window.caiyun.util.cache;
		var constants = window.caiyun.constants;
		

		
		var html = 		'<div class="popContent">'+
									'<div class="system_main"></div>' + 
									'<div class="off_line_tips_YN">'+
            						'<div class="tips_img"></div>'+
            						'<div class="floatleft" style="width:420px;">' + 
            						'<p class="content" >确定要把此文件（夹）放入回收站?</p> ' +
            						'<p class="sub_content">你可以进入回收站彻底删除或恢复此文件(夹)</p> '+
            						'</div>' +
                                   '</div>'+
                                   '</div>';
		
		
		// 监听用户删除文件事件
		fileOperator.onListen('userDelete',function(selected){
			
			// 创建对话框
			var dialog;
			
			dialog = ui.msgBox({
					title : "系统提示",
					width :650,			
					leftBtn : false,     //左下角是否有按钮
					middleBtn : false,      //底部按钮是否居中
					html :html,
					btnName :["确定","取消"],
					okHandle :function(){
						fileOperator.deleteFile(null,function(){
						}
						);
						dialog.close();
					}
			});
			      	
			// 内部内容的HTML元素		
			var $innerHtml = dialog.getWinBody();
			// 提示内容
			var $content = $innerHtml.find('.content');
			var oneFileContent = '确定要把此文件（夹）放入回收站吗？';
			var $subContent = $innerHtml.find('.sub_content');
			
			var hasSyncCatalog = false;
			for(var i in selected){
				var item = cache.getFileCache(constants.FILE_LIST_CACHEGROUP,
						selected[i]);
				if(judgement.isSyncCatalog(item)){
					hasSyncCatalog = true;
					break;
				}
			}
			
			if(!selected || selected.length == 0){
				return
			}else if(hasSyncCatalog){
					$content.html('确定要删除同步吗？<BR/>删除后将导致其他终端无法继续同步。').css('width','360px');
					$subContent.text('');
			}
			else if(judgement.isReceviteDir(fileOperator.getCatalogStack())){
				    // 我收到的文件
					$content.html('确定要删除此分享吗？<BR/>删除后你将无法访问此文件。').css('line-height','44px;');
					$subContent.text('');
			}
			else if(judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)){
					// 我收到的文件二级目录下提示语
					$subContent.text('分享者可以进入回收站彻底删除或恢复此文件（夹）');
			}
			else if(selected.length == 1){
				// 如果是在保险箱中提示内容不一样
				if(judgement.isSafeBox()){
					$content.css('line-height','50px').text('确定要彻底删除所选文件（夹）吗?');
					$subContent.text('');
				}else{
					$subContent.text('您可以进入回收站彻底删除或恢复此文件（夹）');
					$content.text(oneFileContent);
				}				
			}
			else{
				if(judgement.isSafeBox()){
					$content.css('line-height','50px').text('确定要把这'+selected.length + '项彻底删除吗？');
					$subContent.text('');
				}
				else{
					$content.text('确定要把这'+ selected.length + '项放入回收站吗？');
					$subContent.text('您可以进入回收站彻底删除或恢复此文件（夹）');
				}
			}
			
			
			
			dialog.show();
		});
	};
	
	// 将自己的初始化方法加载到ui的initList中
	caiyun.ui.initList.push(self);
})();