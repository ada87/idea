/**
 * 登录记录管理
 */
;
(function() {

	var self = window.caiyun.ui.model.loginRecordManager;

	var get_dina_passwd_success = $('#get_dina_passwd_success');

	var fristLoadcount = 20;
	var addedLoadcount = 10;
	var itemCount = 0;
	var containerBoxHeight;
//	var scrolltool;
	var recordsArray = new Array();
	
	

	// 是否可以继续加载
	var loadFlag = (function() {
		var flag = true;
		return {
			lock : function() {
				flag = false
			},
			unlock : function() {
				flag = true
			},
			isAccess : function() {
				return flag
			}
		}
	})();

	// 缓存管理
	var cacheManager = (function() {
		var cache = {};

		var put = function(id, item) {
			id ? (cache[id] = item) : "";
		}

		var get = function(id) {
			return cache[id];
		}

		var show = function() {
			return cache;
		}

		return {
			put : put,
			get : get,
			show : show
		}
	})();
	/* 初始化 */
	var init = function() {
		 var showValue = $('#set_login').css('display');
		 /*if(showValue=="inline-block")
			 get_dina_passwd_success.find('p').html('加载更多... ...').end()
				.show();*/
		containerBoxHeight = caiyun.util.iGet.PageSize().WinH - 120;
		$("#set_login").css("height", containerBoxHeight);
		getLoginInfos({
			bNum : 1,
			eNum : fristLoadcount,
			bTime : '',
			eTime : ''
		}, initQuerySuccess);

		//删除
		$("#clearLoginRec").unbind().bind('click',function(){
		
		    //创建对话框
			dialog = window.caiyun.ui.msgBox({
			 			title : "系统提示",
				 		width :520,
				 		height:220,
			 			html :'<div class="popContent">'
		                      + '<div class="system_main"></div>'
                              + '<div class="off_line_tips_YN" style="padding: 16px 0px 0px 50px">'
                              + '<div class="tips_img"></div>'
                              + '<div class="floatleft" style="width:300px;height:50px;padding:13px 5px 0px 10px">'
                              + '<p>亲，你确定要清除所有操作记录吗？</p>'
                              + '</div></div></div>',
			 	        btnName :["确定","取消"],
			 	        okHandle :function(){
			 	        	deleteLoginInfos();
			 	        	 dialog.close();
			 	        }});
				dialog.show();			
		});

	}

	// 获取记录
	var getLoginInfos = function(param, querySuccess) {

		var data = param;

		loadFlag.lock();
		$.ajax({
			url : "getLoginInfos!queryUserLoginInfos.action?date="
					+ new Date().getTime(),
			type : "POST",
			data : data,
			dataType : "json",
			success : querySuccess,
			fail : function() {
				loadFlag.unlock();
				// $("#record_listLoading").hide();
				get_dina_passwd_success.find('p').html('加载更多... ...').end()
						.hide();
			}
		});

	}

	var initQuerySuccess = function(src) {
		// $("#record_listLoading").hide();
		get_dina_passwd_success.find('p').html('加载更多... ...').end().hide();
		// 登录超时，跳转到登录页面
		if ("timeout" == src.showMessage) {
			timeOutUrl();
			return;
		}
		if (src.retCode == 0) {
			var items = src.infos.loginRecs;
			var trs = "";
			itemCount = items.length;
			for ( var i in items) {

				if (pushRecord(items[i])) {
					trs += createHorizontalLine();
				}
				trs += createHtml(items[i]);
			}
			$("#records").append(trs);
			// 如果小于第一次加载的条数 则不会触发加载
			items.length < fristLoadcount ? loadFlag.lock() : loadFlag.unlock();
			var config = {
				id : "recordLists",
				className : "loginRecordScrollerWindow",
				srcollSpeed : 18,
				bindToGloalWheel : false,
				autoHidden : true
			};
			var callback = {
				onScrollToBottom : scroll2Bottom
			};
		//	scrolltool = $("#recordContainer").CyScroller(config, callback)[0];

			$("#recordLists").css("height", containerBoxHeight - 180);

			hideScrollBar();
		//	scrolltool.updateScroller();
		} else {
			tost('系统繁忙，请稍后再试！');
		}

	}

	var hideScrollBar = function() {
		if (itemCount == 0) {
			$("#recordLists").hide();
			$('#login_null').show();
			$("#recordLists .CyScrollerArea").hide();
		}
	};

	// 加载更多的回调方法
	var loadMoreSuccess = function(src) {
		// 登录超时，跳转到登录页面
		if ("timeout" == src.showMessage) {
			timeOutUrl();
			return;
		}

		// $("#record_listLoading").hide();
		get_dina_passwd_success.find('p').html('加载更多... ...').end().hide();
		var items = src.infos.loginRecs;
		var trs = "";
		itemCount += items.length;
		for ( var i in items) {

			if (pushRecord(items[i])) {
				trs += createHorizontalLine();
			}
			trs += createHtml(items[i]);
		}
		$("#records").append(trs);
		// 如果小于第一次加载的条数 则不会触发加载
		items.length < addedLoadcount ? loadFlag.lock() : loadFlag.unlock();
		//scrolltool.updateScroller();
	}

	var scroll2Bottom = function(position, $scroller) {
		if (loadFlag.isAccess()) {
			// $("#record_listLoading").show();
			get_dina_passwd_success.find('p').html('加载更多... ...').end().show();
			getLoginInfos({
				bNum : itemCount + 1,
				eNum : itemCount + addedLoadcount,
				bTime : '',
				eTime : ''
			}, loadMoreSuccess);
		}
	}

	// 是否需要水平线
	var pushRecord = function(item) {
		if (recordsArray.length == 0) {
			recordsArray.push(item);
			return false;
		}
		var prev = recordsArray[recordsArray.length - 1];
		var minus = parseInt(prev.loginTime.substr(0, 8), 10)
				- parseInt(item.loginTime.substr(0, 8), 10)
		if (minus != 0) {
			recordsArray.push(item);
			return true;
		} else {
			recordsArray.push(item);
			return false;
		}
	}

	var createHtml = function(item) {
		var _html = '<tr>' + '<td width="400"><span class="timeTxt">'
				+ getYMD(item.loginTime) + '</span><span>'
				+ getHMS(item.loginTime) + '</span></td>' + '<td width="300">'
				+ item.clientIP + '</td>' + '<td width="150">'
				+ ($.trim(item.clienType) ? $.trim(item.clienType) : "")
				+ '</td>' + '</tr>';
		return _html;
	}

	var createHorizontalLine = function() {
		return '<tr><td colspan="3" style="color:#999;height:10px;"><div style="height:1px; border-bottom:1px dotted #dbdbdb;width:100%;"></div></td></tr>';
	}

	// loginTime = yyyymmddh24MMSS
	var getYMD = function(loginTime) {
		if (loginTime) {
			return loginTime.substr(0, 4) + '/' + loginTime.substr(4, 2) + '/'
					+ loginTime.substr(6, 2);
		}
		return "";
	}
	// loginTime = yyyymmddh24MMSS
	var getHMS = function(loginTime) {
		if (loginTime) {
			return loginTime.substr(8, 2) + ':' + loginTime.substr(10, 2) + ':'
					+ loginTime.substr(12, 2);
		}
		return "";
	}

	var deleteLoginInfos = function() {

		if (recordsArray.length == 0) {
			return;
		}
		$.ajax({
			url : "getLoginInfos!deleteUserLoginInfos.action?data="
					+ new Date().getTime(),
			type : "POST",
			data : {},
			dataType : "json",
			success : deleteSuccessFunc,
			fail : function() {
			}
		});
	}

	// 成功删除回调
	var deleteSuccessFunc = function(res) {
		// 登录超时，跳转到登录页面
		if ("timeout" == res.showMessage) {
			timeOutUrl();
			return;
		}

		if (res.retCode == 0) {
			$("#records").empty();
			$("#recordLists").hide();
			$('#login_null').show();
			tost('删除成功');
			recordsArray = new Array();
		} else {
			tost('系统繁忙');

		}

	};
	// 弹出框
	var tost = function(res) {

		get_dina_passwd_success.find('p').html(res).end().show();
		setTimeout(function() {
			get_dina_passwd_success.hide();
		}, 2000);
	};
	var timeOutUrl = function() {
		window.caiyun.util.timeoutHref();
	}
	// 设置悬浮
//
//	$('#mySetup').hover(function() {
//		$('.userMenu').show();
//	}, function() {
//		$('.userMenu').hide();
//	});
	
	$("#toFile").click(function(){
	    window.location.href = "index.jsp";
	    return false;
	});
	$("#toMyphone").click(function(){
	    window.location.href = "index.jsp?menuStatus=2";
	    return false;
	});
	$("#toTimeLine").click(function(){
	    window.location.href = "index.jsp?menuStatus=3";
	    return false;
	});
	//设置切换
	
	$('#userMenu_his_loginman').hover(function(){
		$(this).addClass('hover');
	}, function() {
		$(this).removeClass('hover');
	});
	$('#userMenu_sms_loginman').hover(function(){
		$(this).addClass('hover');
	}, function() {
		$(this).removeClass('hover');
	});
	$('#userMenu_out_loginman').hover(function(){
		$(this).addClass('hover');
	}, function() {
		$(this).removeClass('hover');
	});
	// 显示更多列表
	var $moreMenu = $('#more_menu');
	$('#left_more,#more_menu').hover(function() {
		$moreMenu.show();
	}, function() {
		$moreMenu.hide();
	});
	
	//显示客户端下载更多
	$("#moreBtn,#moreAppDown").hover(function(){
	    $("#moreAppDown").show();
	},function(){
	    $("#moreAppDown").hide();
	});
	// 左边悬浮
	$('.set_left_tab').hover(function() {
		$(this).addClass('hover');
	}, function() {
		$(this).removeClass('hover');
	});
	// 点击切换
	$('#set_log_button').bind("click", function() {
		$('#set_login').show();
		$('#set_notifiacation').hide();
		$('.set_left_tab').removeClass('current');
		$('#set_log_button').addClass('current');
	});
	$('#set_notifi_button').bind("click", function() {

		$('#set_login').hide();
		$('#set_notifiacation').show();
		$('.set_left_tab').removeClass('current');
		$('#set_notifi_button').addClass('current');
	});
	// 磁盘容量
	var setDiskSize = function() {
		$.ajax({
			type : "post",
			url : "personInfoAction!queryDiskInfo.action" + "?date="
					+ new Date().getTime(),
			dataType : "json",
			success : diskSizeSucc,
			hideLoading : true
		});
	};

	var capacityBar = caiyun.ui.CyDiskCapability();

	var diskSizeSucc = function(json, parms) {
		if (!json.userDiskInfo) {
			return;
		}
		var disk = json.userDiskInfo;
		var diskSize = disk.diskSize;
		var userDiskSize = disk.userDiskSize;
		var percent;
		capacityBar.cysetDiskSize({
			renderTo : 'capacity_bar',
			diskSize : diskSize,
			userDiskSize : userDiskSize
		});
	};
	$(document).ready(function() {
		init();
		setDiskSize();

	});

	// 页尾
	window.onresize = function() {
		if ($.browser.msie && $.browser.version == '6.0') {
			var offsetH = document.documentElement.clientHeight;
			$("#sideBar_bottom").css("top", (offsetH - 77 - 85) + "px");
		}
	};

	window.onresize();

})();
