/**
 * 过滤器条、快捷排序列、以及工具条组成的文件title
 */
(function() {
	var self = caiyun.ui.model.fileTitle;

	self.init = function() {
		var $title = $('#filter_bar_and_title');
		var $filterBar = $('#filter_bar');
		var $sortColumns = $('.file_sort_col');
		var $selectAll = $('#select_all');
		var $toolbarColumn = $('#tool_bar_col');
		var $sortBySize = $('#sort_by_size');
		var $sortByTime = $('#sort_by_time');
		var $sortByTimeArrow = $sortByTime.find('.arrow');
		var $sortBySizeArrow = $sortBySize.find('.arrow');
		var disable = false;
		var sortDisable = false;
		var sortColumnVisible = true; // 排序列不可见
		var constants = caiyun.constants;
		var showMore = true;
		var judgement = window.caiyun.judgement;

		var fileOperate = caiyun.operate;
		var options = {
			appendToId: 'filter_bar', // 指定控件添加的dom元素id,必须 如：filterBar
			spans: [{
					id: 'all', // 元素id后缀，代表一种过滤类型
					title: '全部', // 元素名称
					click: function() {
						fileOperate.filterHandler({
							contentType: 0
						});
					} // 点击事件
				}, // 第一个默认为全部，该项默认显示
				{
					id: 'Img',
					title: '图片',
					click: function() {
						fileOperate.filterHandler({
							contentType: 1
						});
					}
				}, {
					id: 'video',
					title: '视频',
					click: function() {
						fileOperate.filterHandler({
							contentType: 3
						});
					}
				}, {
					id: 'music',
					title: '音乐',
					click: function() {
						fileOperate.filterHandler({
							contentType: 2
						});
					}
				}, {
					id: 'document',
					title: '文档',
					click: function() {
						fileOperate.filterHandler({
							contentType: 5
						});
					}
				}
			]
		};
		filterBar = window.caiyun.ui.CyFilterBar(options);

		// 全选按钮
		$selectAll.bind('click', function() {
			if ($selectAll.hasClass('input_first')) {
				$selectAll.removeClass('input_first');
				$selectAll.addClass('input_first_on');
				fileOperate.selectAll();
			} else {
				$selectAll.removeClass('input_first_on');
				$selectAll.addClass('input_first');
				fileOperate.unSelectAll();
			}
		});

		// 更多下拉菜单
		var moreDropDownMenu = $('body').CyDropDownMenu({
			id: 'moreDropDownMenu',
			items: [{
					id: 'edit',
					iconClass: 'ico-edit',
					name: '编辑',
					click: function() {
						fileOperate.edit();
					},
					hiddenBy: function() {
						return !fileOperate.canExecute('edit');
					}
				},

				{
					id: 'open',
					iconClass: 'ico-1',
					name: '打开',
					click: function() {
						fileOperate.enterDir();
					},
					hiddenBy: function() {
						return !fileOperate.canExecute('open');
					}
				},

				{
					id: 'browse',
					name: '打开',
					click: function() {
						fileOperate.browseImage();
					},
					hiddenBy: function() {
						return !fileOperate.canExecute('browse');
					}
				},

				{
					id: 'play',
					name: '打开',
					click: function() {
						fileOperate.viewFile();
					},
					hiddenBy: function() {
						return !fileOperate.canExecute('play');
					}
				},

				{
					id: 'move',
					name: '移动',
					iconClass: 'ico-move',
					click: function() {
						fileOperate.moveOrCopy('move');
					},
					hiddenBy: function() {
						return !fileOperate.canExecute('move');
					}
				},

				{
					id: 'copy',
					name: '复制',
					iconClass: 'ico-5',
					click: function() {
						fileOperate.moveOrCopy('copy');
					},
					hiddenBy: function() {
						return !fileOperate.canExecute('copy');
					}
				},

				{
					id: 'rename',
					name: '重命名',
					iconClass: 'ico-6',
					click: function() {
						fileOperate.userRename();
					},
					hiddenBy: function() {
						return !fileOperate.canExecute('rename');
					}
				},

				{
					id: 'delete',
					name: '删除',
					iconClass: 'ico-7',
					click: function() {
						fileOperate.userDelete();
					},
					hiddenBy: function() {
						return !fileOperate.canExecute('delete');
					}
				},

				{
					id: 'showVersionList',
					iconClass: 'ico-8',
					name: '历史版本管理',
					click: function() {
						caiyun.ui.model.versionList.show();
					},
					hiddenBy: function() {
						return !fileOperate.canExecute('showVersionList');
					}
				}, {
					id: 'reCopy',
					name: '转存',
					iconClass: 'ico-3-7',
					click: function() {
						fileOperate.moveOrCopy('copy');
					},
					hiddenBy: function() {
						return !fileOperate.canExecute('reCopy');
					}
				}, {
					id: 'leaveShare',
					name: '删除分享',
					iconClass: 'ico-3-6',
					click: function() {
						fileOperate.userDelete();
					},
					hiddenBy: function() {
						return !fileOperate.canExecute('leaveShare');
					}
				}, {
					id: 'cancelSync',
					name: '取消同步',
					iconClass: 'ico-cancelSync',
					click: function() {
						fileOperate.syncCancel();
					},
					hiddenBy: function() {
						return !fileOperate.canExecute('cancelSync');
					}
				}
			]
		})[0];

		moreDropDownMenu.hover(function() {}, function() {
			moreDropDownMenu.close();
		});

		$(window).bind('scroll', function() {
			moreDropDownMenu.close();
		});

		// 传入鼠标事件定位menu
		function openAndLocate(data) {
			var event = data.e;
			var offset = $(event.target).offset();
			var position = {
				top: offset.top + 21, // 偏移几个像素使鼠标能够悬浮在菜单区域内
				left: offset.left
			};
			moreDropDownMenu.open();
			moreDropDownMenu.locate(position, true);
		};

		// 命令列表
		var commandList = [{
			id: 'share_filelink',
			name: '分享文件链接',
			style: 'l_share_filelink',
			click: function() {
				fileOperate.creatFileLink();
			},
			isDisable: function() {
				return fileOperate.canExecute('link');
			}
		}, {
			id: 'share_to_other',
			name: '分享给其他用户',
			style: 'l_share_other',
			click: function() {
				fileOperate.createShareFile();
			},
			isDisable: function() {
				return fileOperate.canExecute('share');
			}
		}, {
			id: 'download',
			name: '下载',
			style: 'l_download',
			click: function() {
				fileOperate.userDownload();
			},
			isDisable: function() {
				return fileOperate.canExecute('download');
			}
		}, {
			id: 'more',
			name: '更多',
			style: 'l_more',
			isDisable: function() {
				return showMore && fileOperate.canExecute('move') || fileOperate.canExecute('copy') || fileOperate.canExecute('delete') || fileOperate.canExecute('showVersionList') || fileOperate.canExecute('reCopy') || fileOperate.canExecute('rename') || fileOperate.canExecute('leaveShare') || fileOperate.canExecute('cancelSync');
			},
			click: function(event) {
				// 显示内部下拉菜单
				if (moreDropDownMenu.is(':hidden')) {
					openAndLocate(event);
				} else {
					moreDropDownMenu.close();
				}
			}
		}];

		// 工具栏内部对象
		var toolBar = window.caiyun.ui.CyNavBar({
			renderTo: 'tool_bar',
			items: commandList
		});

		// 监听选择事件
		fileOperate.onListen('selectData', function(ids, total) {
			var i = 0,
				j, notModifiedCount,publisherConstants = caiyun.constants.publisherAccountConstants;
			if (disable) {
				return;
			}
			var idList = ids;
			var catalogs = [];
			$(idList).each(function() {
				// 获得文件数据缓存组
				var data = caiyun.util.cache.getFileCache(constants.FILE_LIST_CACHEGROUP, this);
				if (data) {
					// 如果是目录
					if (data.catalogID) {
						catalogs.push(data);
					}
				}
			});
			if (!ids || ids.length === 0) {
				$sortColumns.show();
				if (!sortColumnVisible) {
					$sortBySize.hide();
					$sortByTime.hide();
				}
				$selectAll.removeClass('input_first_on');
				$selectAll.addClass('input_first');
			} else {
				$sortColumns.hide();
				$toolbarColumn.show();

				showMore = true;
				$(catalogs).each(function() {
					if (judgement.notModify(this)) {
						showMore = false;
						notModifiedCount++;
					}else if(this.catalogID === publisherConstants.publisherDir || this.catalogID === publisherConstants.draftBox){

					}
				});
			}
			if (ids.length + notModifiedCount < total) {
				$selectAll.removeClass('input_first_on');
				$selectAll.addClass('input_first');
			}
			moreDropDownMenu.close();
			toolBar.nvaBarShow(ids);
		});

		$sortBySize.find('a,b').click(function() {
			if (sortDisable) {
				return;
			}
			var arrow = $sortBySizeArrow;
			// 如果是隐藏掉表示，不是按照大小排序，点一下就按照大小倒序排
			if (arrow.is(':hidden')) {
				fileOperate.sortHandler({
					sortField: 'size',
					sortType: 'desc'
				});
				return false;
			} else if (arrow.hasClass('m_time_down')) {
				fileOperate.sortHandler({
					sortField: 'size',
					sortType: 'asc'
				});
				return false;
			} else {
				fileOperate.sortHandler({
					sortField: 'size',
					sortType: 'desc'
				});
				return false;
			}
		});

		$sortByTime.find('a,b').click(function() {
			if (sortDisable) {
				return;
			}
			var arrow = $sortByTimeArrow;
			// 如果是隐藏掉表示，不是按照时间排序
			if (arrow.is(':hidden')) {
				fileOperate.sortHandler({
					sortField: 'time',
					sortType: 'desc'
				});
				return false;
			} else if (arrow.hasClass('m_time_down')) {
				fileOperate.sortHandler({
					sortField: 'time',
					sortType: 'asc'
				});
				return false;
			} else {
				fileOperate.sortHandler({
					sortField: 'time',
					sortType: 'desc'
				});
				return false;
			}
		});

		function changeSorter(params) {
			// 方向
			// 'asc' : '0',
			// 'desc' : '1'
			// 排序类型
			// 'time' : '0',
			// 'name' : '1',
			// 'type' : '2',
			// 'size' : '3'

			if (!params) {
				return;
			}

			var sortType = params.contentSortType;
			var sortDirection = parseInt(params.sortDirection, 10);

			if (sortType == 3) {
				$sortBySizeArrow.removeClass('m_time_up m_time_down').addClass(
					sortDirection === 1 ? 'm_time_down' : 'm_time_up');
				$sortByTimeArrow.hide();
				$sortBySizeArrow.show();
			} else if (sortType == 0) {
				$sortByTimeArrow.removeClass('m_time_up m_time_down').addClass(
					sortDirection === 1 ? 'm_time_down' : 'm_time_up');
				$sortBySizeArrow.hide();
				$sortByTimeArrow.show();
			} else {
				// 找不到就不显示
				$sortByTimeArrow.removeClass('m_time_up m_time_down').hide();
				$sortBySizeArrow.hide();
			}
		}

		// 监听reload事件，更改排序列状态
		fileOperate.onListen('reload', function(params) {
			if (disable) {
				return;
			}
			changeSorter(params);
		});

		// 监听enterDir事件，重置排序状态
		fileOperate.onListen('enterDir', function(catalogstack, params) {
			if (disable) {
				return;
			}
			//如果在收到的分享一级目录下，修改“上传时间”文案为“分享时间”.
			if (judgement.isReceviteDir(caiyun.operate.getCatalogStack())) {
				$sortByTime.children('a').text('分享时间');
				$('#title_col_2').css('visibility', 'hidden');
			} else {
				$sortByTime.children('a').text('上传时间');
				$('#title_col_2').css('visibility', 'visible');
			}

			changeSorter(params);
			// 重置过滤器
			filterBar.toDefault();
		});

		// 监听enterDir事件，重置排序状态
		fileOperate.onListen('fileContentSwitch', function(data) {
			if (data.newView.name === constants.SEARCH_CONTENT_VIEW) {
				sortDisable = true;
				$sortByTimeArrow.hide();
			} else {
				sortDisable = false;

			}
		});

		var col1 = $('#title_col_1');
		var col2 = $('#title_col_2');
		// 监听视图切换，判断是否显示文件拍序列
		fileOperate.onListen('viewSwitch', function(view) {
			if (constants.view.win === view) {
				sortColumnVisible = false;
				$sortBySize.hide();
				// 调整工具栏的宽度
				col2.css('width', '95%');
			} else {
				sortColumnVisible = true;
				// 调整工具栏的宽度
				col2.css('width', '');
			}
		});

		self.show = function() {
			$title.show();
			$filterBar.show();
		};

		self.hide = function() {
			$title.hide();
		};

		self.enter = function() {
			disable = false;
			// 初始化
			$selectAll.removeClass('input_first_on');
			$selectAll.addClass('input_first');
			$sortColumns.show();
			$toolbarColumn.hide();
			// 按照时间倒序排列
			$sortByTimeArrow.removeClass('m_time_up m_time_down').addClass(
				'm_time_down').show();
			$sortBySizeArrow.hide();
		};

		self.leave = function() {
			disable = true;
			self.hide();
		};
	};

	caiyun.ui.initList.push(self);
})();