/**
 * 文件分享对话框
 */
;(function(){
	
	var self =window.caiyun.ui.model.sharememberbox;
	
	self.init = function(){
		var constants = window.caiyun.constants;
		var ui = window.caiyun.ui;
        var fileShareOperate  = caiyun.myFileShareOperate;
        var fileOperate = caiyun.operate;
		var cache = window.caiyun.util.cache;
		var util = window.caiyun.util;
		var fileShareBiz = caiyun.biz.fileShare;
		var cytxl = window.caiyun.biz.cytxl;
		var title ='';
		var selectedData;
		var defVal = "输入手机号码或从下方选择分享对象";
		var blurVal = '';      //保存输入框失去焦点之后的值
//		var maxShareNum = parseInt(maxShareNumber) > 0 ? parseInt(maxShareNumber) : 20;
		var numCount = 0;
		
		var lastShareLinker = [];  //最后一次分享成员
		
		//从缓存数据中取文件(夹)名
		var getFileNameByObj = function(obj){
			var fileName ='';
			if(obj != undefined && typeof(obj)=="object")
			{
				if(obj.catalogName)
				{
					fileName = obj.catalogName.substringName(25,true);

				}
				else
				{
					fileName = obj.contentName.substringName(25);
				}
			}
			return fileName;
		};
		
		//从缓存数据中取文件(夹)名
		var getFileName = function(id){
			var cacheID = id;
			var fileName ='';
			$(selectedData).each(function(i){
				if(selectedData[i].catalogID==cacheID){
					fileName = selectedData[i].catalogName;
				}
				if(selectedData[i].contentID==cacheID){
					fileName =selectedData[i].contentName;
				}
			});
			return fileName;
		};
		
		//从右边选中手机号码
		var getMobiles = function(){
			var lis = $('#share_contact_box').children('li');
			var arr = [];
			if(lis){
				$.each(lis,function(index,element){
					var mobileNum = $(element).attr('title');
					arr.push(util.replace86(mobileNum));
				});
			}
			return arr;
		};
		
		//是否有格式不正确的号码()
		var hasUnValidPhone = function(){
			var $lis = $('#share_contact_box').children('li');
			var res = false;
			$.each($lis,function(index,element){
				if($(element).children('span').hasClass('sp_r')){
					res = true;
				}
			});
			return res;
		};
		
		//管理分享弹出框事件 
		var eventHandler = function(){
			
			$(".share_sms_checkbox").unbind().click(function(){
				if($(this).hasClass("share_sms_checked"))
				{
					$(this).removeClass("share_sms_checked");
				}
				else
				{
					$(this).addClass("share_sms_checked");
				}
				
			});
			
			//树的展开收起
			$('#contactGroupTree').delegate('li','click',function(){
				var $this = $(this);
				var $liChild = $this.children('.arrow');
				var $ulChild = $this.children('ul');
				if($liChild.hasClass('collapsed')){
					$liChild.removeClass('collapsed'); 
					$liChild.addClass('expanded');
					$ulChild.show();
				}else if($liChild.hasClass('expanded')){
					$liChild.removeClass('expanded');
					$liChild.addClass('collapsed');
					$ulChild.hide();
				}
				return false;
			});
			
			//li .checkbox选择事件
			$('#contactGroupTree').delegate('.group_li > .checkbox','click',function(){
				var arr = getMobiles();
				numCount = arr.length;
				var $this = $(this);
				var $ulChild = $this.next().next().next();
				if($this.hasClass('half_checked')){
					$this.removeClass('half_checked');
					var $lis = $ulChild.children('li');
					$.each($lis,function(index,element){
						var nickName = $(element).attr('nickname');
						var id = $(element).attr('name');
						var title =$(element).attr('title');
						var data = {name:id,nickname:nickName,mobile:title};
						$(element).children('.checkbox').removeClass('checked');
						deletFromHtml(data);
					})
				}else{
					if (numCount < maxShareNumber) {
						var $lis = $ulChild.children('li').slice(0,(maxShareNumber - numCount));
						$this.addClass('half_checked');
						$.each($lis, function(index, element){
							var nickName = $(element).attr('nickname');
							var id = $(element).attr('name');
							var title = $(element).attr('title');
							var data = {
								name: id,
								nickname: nickName,
								mobile: title
							};
							var mobile = util.replace86(title)
							if(mobile == ownerMSISDN)
							{
                                errorTip('不用分享给自己哦','error');
								return true;
							}
							if(hasDuplicateInArray(arr,mobile)){
                                errorTip('号码已存在','error');
								return true;
							}
							$(element).children('.checkbox').addClass('checked');
							appendConcactToHtml(data);
						});
					}
				}
				return false;
			});
			
			//每个联系人li绑定选择事件
			$('#contactGroupTree').delegate('.group_li > ul > li > .checkbox','click',function(){
				var arr = getMobiles();
				numCount = arr.length;
				var $this = $(this);
				var nickName = $this.parent('li').attr('nickname');
				var id = $this.parent('li').attr('name');
				var title = $this.parent('li').attr('title');
				var data = {name:id,nickname:nickName,mobile:title};
				var mobile = caiyun.util.replace86(title);
				
				if($this.hasClass('checked')){
					$this.removeClass('checked');
					var $ul_li=$this.parent().parent().children('li');
					if(!hasSelected($ul_li)){
						$this.parent().parent().parent().children('.checkbox').removeClass('half_checked');
					}
					deletFromHtml(data);
				}else{
					if(mobile == ownerMSISDN)
					{
                        errorTip('不用分享给自己哦','error');
						return false;
					}
					if(hasDuplicateInArray(arr,mobile)){
                        errorTip('号码已存在','error');
						return false;
					}
					if (numCount < maxShareNumber) {
						$this.addClass('checked');
						$this.parent().parent().parent().children('.checkbox').addClass('half_checked');
						appendConcactToHtml(data);
					}
				}
				return false;
			})
			
			//清空事件
			$('#share_right_clear').unbind().bind('click',function(){
				$('#share_contact_box').children('li').remove();
				var $checkbox = $('#contactGroupTree').children('.group_li').children('.checkbox');
				$.each($checkbox,function(index,element){
					if($(element).hasClass('half_checked')){
						$(element).click();
					}
				});
				var $search =$('#contactSearchTree').children('li').children('.checkbox');
				if($search){
					$.each($search,function(index,element){
						if($(element).hasClass('checked')){
							$(element).click();
						}
					});
				}
				updateSelectNum();
			});
			
			//每项清空
			$('#share_contact_box').delegate('li > span > em','click',function(){
				var $this = $(this);
				var $parent = $this.parent().parent();
				var name = $parent.attr('name');
				$parent.remove();
				updateSelectNum();
				deletFromTree({name:name});
			});
			
			
			//搜索框
			$('#share_seach').focus(function(e){
					var $this = $(this);
					$(this).parent().addClass("share_seach_focus");
					var txt = $this.val();
					if(txt==defVal){
						$this.val('');
						if(linkData._isOpenCytxl){
							//显示全部tree;
							showContactsTree();
						}
					}else if(txt == blurVal){
					}else{
						if(linkData._isOpenCytxl){
							//搜索联系人
							var searchConts = linkData.searchLinkers(txt);
							//显示搜索结果
							showSeachContact(searchConts);
						}
					}
					e.stopPropagation();
				}).blur(function(){
					var $this = $(this);
					$(this).parent().removeClass("share_seach_focus");
					var txt = $this.val();
					blurVal = txt;
					if(txt==''){
						$this.val(defVal);
						if(linkData._isOpenCytxl){
							showContactsTree();
						}else{
							showCytxl();
						}
					};
				}).keyup(function(){
					var $this = $(this);
					var txt = $this.val();
					if(txt==defVal||txt==''){
						$this.val('');
						if(linkData._isOpenCytxl){
							//显示全部tree;
							showContactsTree();
						}
					}else{
						if(linkData._isOpenCytxl){
							//搜索联系人
							var searchConts = linkData.searchLinkers(txt);
							//显示搜索结果
							showSeachContact(searchConts);
						}else{
							var $checklist = $('#contactSearchTree');
							var $checkTree = $('#contactGroupTree')
							$checkTree.hide();
							$checklist.children().remove();
							$checklist.append('<div class="share_font"><p>未找到相关联系人!</p><p class="p2"><a id="id_addContact"  href="javascript:void(0)" class="share_add_btn">添加</a></p></div>');
							$checklist.show();
						}
					}
				});
			
			//搜索结果Tree .checkbox选择事件
			$('#contactSearchTree').delegate('li .checkbox','click',function(){
				var arr = getMobiles();
				numCount = arr.length;
				var $this = $(this);
				var name = $this.parent().attr('name');
				var title = $this.parent().attr('title');
				var nickName = $this.parent().attr('nickname');
				var con = {name:name,nickname:nickName,mobile:title}
				var mobile = util.replace86(title);
				
				if($this.hasClass('checked')){
					$this.removeClass('checked');
					deletFromHtml(con);
				}else{
					if(mobile == ownerMSISDN)
					{
                        errorTip('不用分享给自己哦','error');
						return false;
					}
					if(hasDuplicateInArray(arr,mobile)){
                        errorTip('号码已存在','error');
						return false;
					}
					if (numCount < maxShareNumber) {
						$this.addClass('checked');
						appendConcactToHtml(con);
						selectToTree(con);
					}
				}
				return false;
			});
			
			//导入彩云通讯录
			$('#contactSearchTree').delegate('#active_user','click',function(e){
				activeUser();
				return false;
			});
			
			//添加联系人
			$('#contactSearchTree').delegate('#id_addContact','click',function(){
				var arr = getMobiles();
				numCount = arr.length;
				if (numCount < maxShareNumber) {
					var txt = util.replace86($.trim($('#share_seach').val()));
					if(txt == ownerMSISDN)
					{
                        errorTip('不用分享给自己哦','error');
						return false;
					}
					if (txt !== defVal) {
						if(hasDuplicateInArray(arr,txt)){
                            errorTip('号码已存在','error');
							return false;
						}
						var data = {
							name: txt,
							nickname: txt,
							mobile: util.replace86(txt)
						};
						appendConcactToHtml(data);
						//重置搜索框
						$("#share_seach").val(defVal);
						$("#contactSearchTree").hide();
						$("#contactGroupTree").show();
					}
				}
				return false;
			});
			
		};
		
		var activeUser = function(){
			cytxl.regAndSignIn(activeUserSuccCallBack,activeUserFailCallBack);
		};
		
		var activeUserSuccCallBack = function(res,resp){
			if(resp.message=="" && resp.st){
				initContactData();
			}else if(resp.message=='error'){
                errorTip('开通彩云通讯录失败!','error');
			}
		};
		
		var activeUserFailCallBack = function(r){
            errorTip('系统繁忙,请稍后再试!','error');
		};
		
		var hasSelected = function(obj){
			var result =false;
			$.each(obj,function(index,element){
				if($(element).children('.checkbox').hasClass('checked')){
					result = true;
				}
			});
			return result;
		};
		
		//未开通彩云通讯录
		var showCytxl = function(){
			var html ='<div class="share_font"><p><a  href="javascript:void(0)" id="active_user" class="share_a1">导入彩云通讯录</a>，分享更轻松！</p></div>';
			$('#contactGroupTree').hide();
			$('#contactSearchTree').html("").append(html);
			$('#contactSearchTree').show();
			
		};
		
		//显示联系人Tree
		var showContactsTree = function(){
			$('#contactSearchTree').hide();
			$('#contactGroupTree').show();
		}
		
		//显示搜索联系人Tree
		var showSeachContact = function(lists){
			var $checklist = $('#contactSearchTree');
			var $checkTree = $('#contactGroupTree')
			$checkTree.hide();
			$checklist.children().remove();
			if(lists.length == 0){
				$checklist.append('<div class="share_font"><p>未找到相关联系人!</p><p><a id="id_addContact"  href="javascript:void(0)" class="share_add_btn">添加</a></p></div>');
			}
			var conLists = getSeachContactHtml(lists);
			$(conLists).appendTo($checklist);
			$checklist.show();
		};
		
		//获取搜索联系人treeHTML 
		var getSeachContactHtml = function(lists){
			var html = new StringBuffer();
			$.each(lists,function(i,list){
				html.append('<li')
					.append(' name="')
					.append(list.contactId)
					.append('" alonetogroupid="" unselectable="on" title="')
					.append(list.mobile[0]?list.mobile[0]:'')
					.append('" nickname="')
					.append(util.formatHTMLEncode(list.name))
					.append('">')
					.append('<div class="arrow" unselectable="on"></div>')
					.append('<div class="checkbox" unselectable="on" flag="0"></div>')
					.append('<label style="cursor:default;" unselectable="on">')
					.append(util.subStringByLen(util.formatHTMLEncode(list.name),8))
					.append('</label>')
					.append('</li>');
			});
			return html.toString();			
		};
		
		var getBodyHtml  = function(){
			var html = new StringBuffer();
			html.append('<div class="msm_share msm_share_file">')
			    .append('<div class="share_left">')
				.append('<div id="left_share_title" class="share_left_title">')
				.append('<input id="share_seach" name="" class="txtBg_01" value="')
				.append(defVal)
				.append('">')
				.append('</div>')
				.append('<div class="share_left_m">')
				.append('<ul id="contactSearchTree" class="search_twoTree"></ul>')
				.append('<ul id="contactGroupTree" class="share_twoTree"></ul>')
				.append('</div></div>')
				.append('<div class="share_right">')
				.append('<div class="share_right_title">')
				.append('<h1 class>')
				.append('<span style="color:#999999;float:left;">选中的分享对象</span>')
				.append('<span id="selectShareNum" class="share_people_num">(0/'+maxShareNumber+')</span>')
				.append('</h1>')
				.append('<span id="share_right_clear" class="s_delete">清空</span>')
				.append('</div>')
				.append('<div class="share_right_m">')
				.append('<ul id="share_contact_box"></ul>')
				.append('<div class="share_empty" id="share_empty">清空分享对象后，该文件将取消分享</div>')
				.append('</div></div></div>');
                //.append('<div class="border_bottom"></div>');
			return html.toString();
			
		}
		//向右边框加入联系人
		var appendConcactToHtml = function(data){
			
			$("#share_empty").hide();
			
			var mobile = util.replace86(data.mobile);
			var html = new StringBuffer();
			
			if(data.type != undefined && data.type == 0)
			{
				html.append('<li class="select-cancel" name="');
			}
			else
			{
				html.append('<li class="select-cancel select-new" name="');
			}
			
				html.append(util.formatHTMLEncode(data.name))
				.append('" title="')
				.append(mobile);
				if(util.isChinaMobile(mobile))
				{
					html.append('"><span>');
					
				}else if(util.isCellPhone(mobile))
				{
					html.append('"><span>');
				}
				else{
					html.append('"><span class="sp_r">');
				}
				html.append(util.subStringByLen(data.nickname,11))
					.append('<em class="delMailAddr"></em>')
					.append('</span></li>');
			var contactHtml = html.toString(); 
			$(contactHtml).appendTo($('#share_contact_box'));
			
			updateSelectNum();
		};
		
		
		//匹配左边联系人添加到右边
		var switchContactAppendToRightWard = function(data){
			var $_lis  = $('#contactGroupTree').children('.group_li').children('ul').children('li');
			$.each(data,function(i,n){
				var num = util.replace86(n);
				var flag = false;
				$.each($_lis,function(i,data){
					var mobile = util.replace86($(data).attr('title'));
				    if(num == mobile){
						//$(data).children('.checkbox').click();
				    	
				    	var nickName = $(data).attr('nickname');
						var id = $(data).attr('name');
						var title = $(data).attr('title');
						var li_data = {name:id,nickname:nickName,mobile:title,type:0};
				    	$(data).children('.checkbox').addClass('checked');
						$(data).parent().parent().children('.checkbox').addClass('half_checked');
						appendConcactToHtml(li_data);
				    	
						flag = true;
						return false;
					}
				});
				if(!flag)
				{
					appendConcactToHtml({mobile:num,name:num,nickname:num,type:0});
				}
			});
		};
		
		var updateSelectNum = function(){
			var selectNum = $('#share_contact_box').find("li").length;
			$("#selectShareNum").text("(" + selectNum + "/" + maxShareNumber + ")");
			if(selectNum == 0 && lastShareLinker.length != 0 ){
				$("#share_empty").show();
			}
		} 
		
		
		//从联系人Tree中选中
		var selectToTree = function(data){
			var $lis = $('#contactGroupTree').children('.group_li').children('ul').children('li');
			$.each($lis,function(index,element){
				var name = $(element).attr('name');
				if(data.name==name){
					var $check = $(element).children('.checkbox');
					$check.addClass('checked');
					$check.parent().parent().parent().children('.checkbox').addClass('half_checked');
				}
			});
		};
		
		var deletFromHtml = function(data){
			var $lis = $('#share_contact_box').children('li');
			$.each($lis,function(index,element){
				var name = $(element).attr('name');
				if(data.name==name){
					$(element).remove();
					updateSelectNum();
				}
			});
		}
		
		var deletFromTree = function(data){
			var $lis = $('#contactGroupTree').children('li');
			var $searchli = $('#contactSearchTree').children('li');
			$.each($lis,function(index,element){
				var $ul_lis =$(element).children('ul').children('li');
				$.each($ul_lis,function(index,element){
					var name = $(element).attr('name');
					if(data.name==name){
						$(element).children('.checkbox').click();
					}
				});
			});
			if($searchli){
				$.each($searchli,function(index,element){
					var name = $(element).attr('name');
					if(data.name==name){
						$(element).children('.checkbox').click();
					}
				});				
			}
		};
		//获取分组html
		var getContactHtml = function(groups){
			var gHtml = new StringBuffer();
			$.each(groups,function(i,n){
				gHtml.append('<li class="group_li" name="')
				.append(util.formatHTMLEncode(n.groupId))
				.append('" flag="group" load="true">')
				.append('<div class="checkbox " flag="group"></div>')
				.append('<label flag="group">')
                .append(util.formatHTMLEncode(n.groupName))
                .append('</label>')
                .append('<b class="arrow expanded" flag="group"></b>')
				.append(getGroupItemHtml(n.groupId,n.list))
				.append('</li>');
			})
			return gHtml.toString();
		};
		
		//获取组下联系人html
		var getGroupItemHtml = function(groupId,lists){
			var itemHtml = new StringBuffer();
			if(lists.length>0){
				itemHtml.append('<ul unselectable="on" style="display:block" flag="group">');
				$.each(lists,function(i){
					var mobile = "";
					if(lists[i].mobile){
						mobile = lists[i].mobile[0]?lists[i].mobile[0]:'';
					}
					mobile = util.replace86(mobile);
					itemHtml.append('<li ')
						.append(' name="')
						.append(groupId).append('_').append(lists[i].contactId)
						.append('" nickname="')
						.append(lists[i].name? util.formatHTMLEncode(lists[i].name) : "")
						.append('" unselectable="on" title="')
						.append(mobile ? mobile : '')
						.append('">')
						.append('<div class="checkbox" unselectable="on" flag="0"></div>')
						.append('<label unselectable="on">')
                        .append('<div class="arrow" unselectable="on"></div>')
						.append(util.subStringByLen(util.formatHTMLEncode(lists[i].name),8))
						.append('</label></li>');
				});
				itemHtml.append('</ul>');
			}
			return itemHtml;
		};
		
		var hasDuplicateInArray = function(array,item){
			var flag = false;
			if(array){
				for(var i =0;i<array.length;i++){
					if(array[i]==item)
					{
						flag = true;
						break;
					}
				}
				return flag;
			}
		};
		
		var forNameType = function(na,len){
			var tempName = "";
			if(null == na || "" == na){
				return tempName;
			}
	
			if(na.length <= len){
				tempName = na;
			}else{
				var suffixIndex = na.lastIndexOf(".");
				var suffix = na.substring(suffixIndex);
				if(suffix.length > 4){
           			tempName = na.substr(0,len - 3) + "..";
        		}
        		else{
            		tempName = na.substr(0,len - 6) + ".." + suffix;
        		}
			}
			return tempName;
		};
		
		//显示共享、分享对话框
		var showShereMeberBox = function(type,ids){
            var shareHtml = getBodyHtml();
			var shareDialogBox =window.caiyun.ui.msgBox({
						title:'分享' + getFileNameByObj(selectedData[0])+'给其他用户',
						id:"shareMsgBox",
						type: "sharefile",
						width:710,
						btnName:["确定"],
						html:shareHtml,
						okHandle: function(){
							if(!hasUnValidNum()){
								var newContects  = getMobiles();
                            	if(newContects.length == 0 && lastShareLinker.length == 0){
                                    //修改为直接关闭分享框
                            		//errorTip("您还没有填写分享者");
                            		shareDialogBox.close();
									return;
								}
							
								var shareeInfos = getShareeInfos();
                           		var dirFileIDs = getDirFileIDs();
								var cytxlNum = getCytxlNum();
								var unCytxlNum = getUnCytxlNum(cytxlNum);
								var ntfType = "0";
								if(shareeInfos.length > 0 && newContects.length > 0)
								{
									if($(".share_sms_checkbox").hasClass("share_sms_checked"))
									{
										ntfType="1";
									}									
                            		var paramNew ={'sharer':ownerMSISDN,'shareeInfos':shareeInfos,'dirFileIDs':dirFileIDs,'ntfType':ntfType};
                                	fileShareOperate.inivteShareFile(parseParam(paramNew));
									//文件分享pv统计
									caiyun.pvlog("fileShare","addShare",dirFileIDs[0].objID,selectedData[0].contentType?selectedData[0].contentType:"0",selectedData[0].contentSize?selectedData[0].contentSize:0,selectedData[0].contentSuffix?selectedData[0].contentSuffix:"",cytxlNum,unCytxlNum);
								}else if(shareeInfos.length > 0 && newContects.length == 0){
									fileShareOperate.cancelFileShare(dirFileIDs[0].objID,selectedData[0].contentType?selectedData[0].contentType:"0");
								}
								shareDialogBox.close();
							}
							else
                            {
                                errorTip("请输入正确的手机号码", "error");
                            	return false;
                            }
							
						}});
			shareDialogBox.show();
			initContactData();//初始化通讯录数据
			initReceiveContact(type,ids);//初始化分享弹出框右边联系人数据
			eventHandler();//绑定短信分享弹出框事件
			
			$("#tb_1").unbind().click(function(){
				$("#tb_2").removeClass("hovertab");
				$(this).addClass("hovertab");
				$("#share_content_01").show();
				$("#share_content_02").hide();
				
				$("#shareMsgBox_ok").show();
				$(".share_bottom_text").show();
				
			});
			
			$("#tb_2").unbind().click(function(){
				$("#tb_1").removeClass("hovertab");
				$(this).addClass("hovertab");
				$("#share_content_02").show();
				$("#share_content_01").hide();
				
				$("#shareMsgBox_ok").hide();
				$(".share_bottom_text").hide();
			});
			
		};
		
		
		var initReceiveContact = function(type,ids){
			lastShareLinker = [];
            if(type == "member")
            {
                fileShareOperate.getShareInfo(ids);
            }else{
                initGetShareInfoList();
            }

		};
		
		
		var cancelFileShareSuccCallBack = function(data,response){
			if(null == response)
			{
				caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试...", "error");
				return false;
			}
			if(null != response.showMessage && "" != response.showMessage)
			{	
				caiyun.ui.iMsgTip.tip("取消分享失败","error");
				return false;
			}else {
				if(response.resultCode == "0")
				{
					caiyun.ui.iMsgTip.tip("取消分享成功！", "success",3);
					reload();
					trigger(keys.cancelFileShare,"");
					//排序样式重置
					var $sortBySize = $('#share_title1');
					var $sortByTime = $('#share_title3');
					var $sortByTimeArrow = $sortByTime.find('.arrow');
					var $sortBySizeArrow = $sortBySize.find('.arrow');
					$sortByTimeArrow.removeClass('m_time_up m_time_down').addClass('m_time_down').show();
					$sortBySizeArrow.removeClass('m_time_up m_time_down').addClass('m_time_down').hide();
				}
				else{
					caiyun.ui.iMsgTip.tip("取消分享失败","error");
				}
			}
		};
        
		var cancelFileShareFailCallBack = function(req,textStatus,errorThrown,params){
			
			caiyun.ui.iMsgTip.tip("系统繁忙,请稍后再试...","error");
		};
		
		
		
		
		//初始化通讯录列表
		var initContactData = function(){
			if(linkData._isOpenCytxl){
				var groups = linkData._all;
				var treeHtml = getContactHtml(groups);
				$('#contactGroupTree').append(treeHtml).show();
			}else{
				//显示未开通彩云通讯录
				showCytxl()
			}
		};
		
        //获取文件分享联系人
        var getShareeInfos = function(){
            var ShareeInfos = [];
            var mobiles = getMobiles();
            var lastmobiles = lastShareLinker;
            
            var addMobile = util.delRepeatArr(mobiles,lastmobiles);
            var delMobile = util.delRepeatArr(lastmobiles,mobiles);
            if(addMobile){
                $.each(addMobile,function(i){
					var shareeInfo = {};
                    shareeInfo.sharee = addMobile[i];
                    shareeInfo.role = "1";
                    shareeInfo.status = "0";
                    shareeInfo.readStus = "0";
                    shareeInfo.oprType = "1";
                    ShareeInfos.push(shareeInfo);
                });
            }
            if(delMobile){
                $.each(delMobile,function(i){
					var shareeInfo = {};
                    shareeInfo.sharee = delMobile[i];
                    shareeInfo.role = "1";
                    shareeInfo.status = "0";
                    shareeInfo.readStus = "0";
                    shareeInfo.oprType = "2";
                    ShareeInfos.push(shareeInfo);
                });
            }
            return ShareeInfos;
        };
		
		//获取统计信息--彩云通讯录联系人数量
		var getCytxlNum = function(){
			var mobiles = getMobiles();
			var num = 0;
			for(var i = 0,len = mobiles.length;i<len;i++){
				var moblie = util.replace86(mobiles[i]);
				if(linkData.isCytxlNum(moblie)){
					num++;
				}
			}
			return num;
		};
		
		//获取统计信息--非彩云通讯录联系人数量
		var getUnCytxlNum = function(num){
			var mobiles = getMobiles();
			return mobiles.length  - num;
		};
		
		//是否有格式不正确的号码(非手机号码)
		var hasUnValidNum = function(){
			var $lis = $('#share_contact_box').children('li');
			var res = false;
			$.each($lis,function(index,element){
				if($(element).children('span').hasClass('sp_r')){
					res = true;
				}
			});
			return res;
		};
		
		//没有添加联系人错误提示
		var errorTip = function(msg){
			$(".msg-noavail-tip-r").html(msg).show();
			setTimeout(function(){$(".msg-noavail-tip-r").hide();},3000);
		};
		
        //获取文件分享资源
        var getDirFileIDs = function(){
            var dirFileIDS = [];
            var dirFileID ={};
            $.each(selectedData,function(i){
				if(selectedData[i].catalogID)
				{
                	dirFileID.objID = selectedData[i].catalogID;
					dirFileID.objType = "2";
					dirFileID.name = getFileName(selectedData[i].catalogID);
				}
				if(selectedData[i].contentID)
				{
					dirFileID.objID = selectedData[i].contentID;
					dirFileID.objType = "1";
					dirFileID.name = getFileName(selectedData[i].contentID);
				}
				dirFileIDS.push(dirFileID);
            });
			return dirFileIDS;
        };
		
		//监听文件分享成员管理事件
		fileShareOperate.onListen('memberManager',function(ids){
			var dataSet = [];
			$(ids).each(function(i,id) {
				data = cache.getFileCache(constants.FILE_MY_FILE_SHARE_LIST_CACHEGROUP,id);
				if(data){
					dataSet.push(data);
				}
			})
			selectedData = dataSet;
			if(dataSet.length > 0){
				showShereMeberBox("member",ids);
			}
		});

        //监听文件分享事件
        fileOperate.onListen('createShareFile',function(ids){
            var dataSet = [];
            $(ids).each(function(i,id) {
                data = cache.getFileCache(constants.FILE_LIST_CACHEGROUP,id);
                //分页以后找不到先前图片，如果找不到就在图片缓存中去取
                if(!data){
                    data = cache.getPictureCache(constants.PICTURE_LIST_CACHE_GROUP,id);
                }
                //视频播放从缓存中取
                if(!data){
                    data = cache.getVideoCache(constants.VIDEO_LIST_CACHE_GROUP,id);
                }
                if(data){
                    dataSet.push(data);
                }
            })
            selectedData = dataSet;
            if(dataSet.length > 0){
                showShereMeberBox();
            }
        });


        //监听分享文件获取联系人事件
        var initGetShareInfoList = function(){
                var objType = "";
                var name = "";
                var objID = "";
                if(selectedData[0].catalogID){
                    objID = selectedData[0].catalogID;
                    objType = "2";
                    name = selectedData.catalogName;
                };
                if(selectedData[0].contentID){
                    objID = selectedData[0].contentID;
                    objType = "1";
                    name = selectedData[0].contentName;
                };
                var parms = {account:ownerMSISDN,objID:objID,objType:objType,name:name};
                fileShareBiz.getShareInfo(parms,getShareInfoSuccessCallback,getShareInfoErrorCallback);
        };
		
		//监听分享管理获取联系人事件
		fileShareOperate.onListen('getShareInfo',function(data){
			if(data){
				var obj  = window.caiyun.util.cache.getMyFileShareCache(caiyun.constants.FILE_MY_FILE_SHARE_LIST_CACHEGROUP,data[0]);
			 	var objType = "";
             	var name = "";
             	if(obj.catalogID){
                	objType = "2";
                	name = obj.catalogName;
             	};
             	if(obj.contentID){
                	objType = "1";
                	name = obj.contentName;
             	};
				var parm = {account:ownerMSISDN,objID:data[0],objType:objType,name:name};
				fileShareBiz.getShareInfo(parm,getShareInfoSuccessCallback,getShareInfoErrorCallback);
			}
		});
		
		var getShareInfoSuccessCallback = function(param,jsonData){
			if(jsonData.resultCode == "0"){
				var recevieContact = [];
				var shrInfos = jsonData.getShareInfoRes.shareInfoList.shrInfo;
                if(shrInfos)
                {
                    $.each(shrInfos,function(i,data){
                        var shareeInfos = data.shareeInfoList.shareeInfo;
                        $.each(shareeInfos,function(i,n){
                            var contact= util.replace86(n.sharee);
                            recevieContact.push(contact);
                        });
                    });
                    if(recevieContact.length > 0)
                    {
                        lastShareLinker = recevieContact;
                        switchContactAppendToRightWard(recevieContact);
                    }
                }
			}else{
                errorTip("获取共享联系人失败");
			}
		};
		
		var getShareInfoErrorCallback = function(){
            errorTip("系统繁忙，请稍后再试");
		};
			
	};

	// 注册到页面初始化方法中
	caiyun.ui.initList.push(self);

})();
