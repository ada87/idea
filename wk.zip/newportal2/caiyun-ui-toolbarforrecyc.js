/**
 * 回收站工具栏
 */
(function() {

	var self = caiyun.ui.model.toolbarforrecyc;
	var $recycleBar = $('#recycle_bar');
	var disable = false;

	self.init = function() {

		var operate = caiyun.recycleBinOperate;

		var commandList = [{
			id: 'revert',
			name: '还原',
			style: 'look_all_btn l_restore',
			click: function() {
				operate.revertFile();
			},
			isDisable: function() {
				return true;
			}
		}, {
			id: 'delete',
			name: '彻底删除',
			style: 'look_all_btn l_all_delete',
			click: function() {
				operate.deleteFile();
			},
			isDisable: function() {
				return true;
			}
		}];

		// 工具栏内部对象
		var toolBar = window.caiyun.ui.CyNavBar({
			renderTo: 'recycle_bar',
			items: commandList
		});

		// 监听选择事件
		operate.onListen('selectData', function(ids) {
			if (disable) {
				return;
			}
			if (!ids || ids.length == 0) {
				$recycleBar.hide();
			} else {
				$recycleBar.show();
			}
		});

		window.caiyun.recycleBinOperate.onListen('selectData', toolBar.nvaBarShow);
	};

	self.show = function() {
		$recycleBar.show();
	};

	self.hide = function() {
		$recycleBar.hide();
	};

	self.enter = function() {
		disable = false;
	};

	self.leave = function() {
		disable = true;
		self.hide();
	};
	caiyun.ui.initList.push(self);

})();