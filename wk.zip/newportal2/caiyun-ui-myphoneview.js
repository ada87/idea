/**
 * myphone的文件视图
 */
(function(){
		var view = {
				leave : function(){
					window.caiyun.myPhoneOperate.clearCurrentId();
				},
				name : caiyun.constants.MY_PHONE_CONTENT_VIEW ,//显示方式名字
				modelList :[ // 包含的UI对象
						{
								model:caiyun.ui.model.leftNav
						},
						{
								model:caiyun.ui.model.myphone
						},
						{
								model:caiyun.ui.model.myphonePath
						}
				],
				data : {},
				className : 'myphone'
		};
		// 注册到文件视图管理器下
		caiyun.ui.model.fileContent.addContentView(view);
})();
