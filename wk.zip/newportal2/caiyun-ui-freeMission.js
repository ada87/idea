/**
 * 免费扩容视图
 */
(function(){
		var view = {
				leave : function(){
					window.caiyun.operate.clearSetCatalogStack();
				},
				name : caiyun.constants.FREEMISSION_CONTENT_VIEW ,//显示方式名字
				modelList :[ // 包含的UI对象
						{
								model:caiyun.ui.model.leftNav
						},
						{
								model:caiyun.ui.model.freemission
						},
						
				],
				data : {},
				after: function(){
				},
				leave : function(){
				}
		};
		// 注册到文件视图管理器下
		caiyun.ui.model.fileContent.addContentView(view);
})();
