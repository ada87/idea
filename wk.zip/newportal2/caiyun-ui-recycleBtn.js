/**
 * 回收站按钮视图
 */
(function(){
	var self = caiyun.ui.model.recycleBtn;
	var $recycleBtn1 = $('#recyclebtn1');
	var $recycleBtn2 = $('#recyclebtn2');
	var $enterpriseNum = $('#enterpriseNum');
	var $enterpriseRole = $('#enterpriseRole');
	var disable = false;
	
	self.init = function(){
		var recycleOperate = caiyun.recycleBinOperate;

		$recycleBtn2.unbind().bind('click', function(){
			recycleOperate.clearRecyc();
		});
		
	};
	
		
	self.show = function(){
		$recycleBtn1.show();
		$recycleBtn2.show();
		$enterpriseNum.hide();
		$enterpriseRole.hide();
	};
	
	self.hide = function(){
		$recycleBtn1.hide();
		$recycleBtn2.hide();
		$enterpriseNum.hide();
		$enterpriseRole.hide();
	};
	
	self.enter = function(){
		disable = false;
	};
	
	self.leave = function(){
		disable = true;
		self.hide();
	};
	
	caiyun.ui.initList.push(self);
})();