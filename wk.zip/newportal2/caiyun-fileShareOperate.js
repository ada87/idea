/**
 * 文件分享视图
 */
(function(){
    window.caiyun.fileShareOperate = (function(){
        var util = caiyun.util;
		var constants = window.caiyun.constants;
        var fileShare = caiyun.biz.fileShare;
        //查询数据初始参数，用于保存状态之用
        var queryParams = {
			linkType:0
		};
        //查询数据初页数
        var startPage = 1;
        //是否是滚动加载数据请求
        var isScrollLoad = false;
        //是否是否滚动中
        var scrolling = false;
		
		//新创建的文件外链的集合
		var fileShareInfosSet = [];
		
		var listens = {};
		//文件总数
		var count = 0;
		//当前选中的Ids
		var selectedIDs =[];
		
		var search = 0;
		
		var sortType = {
			'asc' : '1',
			'desc' : '0'
		};
		var sortFields = {
			'time' : '1',
			'size' : '2'
		};
		
		var oneSize = 0;
		
		var twoSize = 0;
		
		//操作的key
		var keys = {
			enterFileShare : 'enterFileShare',  //进入分享链接
			loadData : 'loadData',              //成功加载分享链接数据事件
			cancelFileShare :'cancelFileShare', //取消分享链接
			creatFileShare:'creatFileShare',    //创建分享链接
			creatFileShareFail:'creatFileShareFail',   //创建分享链接失败事件
			selectData:'selectData'                    //当前选中项
		};

        /**
         * @param params
         * params,sortField 排序字段
         * params.sortType  排序类型
         *
         */
        var sortHandler = function(params){
			sortClear();
			queryParams["srt"]= sortFields[params.sortField];
			queryParams["srtDr"] = sortType[params.sortType];
			loadFileShareInfos();
		};
		
		var selectHandler = function(ids,total) {
			selectedIDs = ids;
			trigger(keys.selectData, ids,total);
		};
		
		
		 var getQueryParams = function(param){
	            var lkSrc = "";
	            var shrCtlgLst = "";
	            if((!entryPriseInfoData._isEnterpriseUser) && (!entryPriseInfoData._isAdmin)){//非企业彩云用户
	                lkSrc = "100";
	            }else{
	                if(entryPriseInfoData._isAdmin || (entryPriseInfoData._isAdmin && entryPriseInfoData._isEnterpriseUser)){//既是管理员又是普通成员
	                	//第一次查询AB
	                    lkSrc = "010";
	                    var cataIds = [];
	                    cataIds.push(entryPriseInfoData._enterpriseAdminCataIds);
	                    cataIds.push(entryPriseInfoData._enterpriseUserCataIds);
	                    shrCtlgLst = cataIds.toString();
	                    search = 1;
	                    
	                }
	                else{
	                	//只查询B
	                    lkSrc = "110";
	                    var cataIds = [];
	                    cataIds.push(entryPriseInfoData._enterpriseUserCataIds);
	                    shrCtlgLst = cataIds.toString();
	                }
	            }
	            return {
	                linkType: param.linkType || 0,//外链类型
	                srt: param.srt || constants.gridInitConfig.fileShareSrt,//外链排序方式
	                srtDr: param.srtDr || sortType.desc,//排序方向
	                bNum: param.bNum || constants.gridInitConfig.startNum,
	                eNum: param.eNum || constants.gridInitConfig.endNum ,
	                lkSrc:lkSrc,
	                shrCtlgLst:shrCtlgLst
	            };
	            
	        };
	        
	        var getQueryParams1 = function(param){
	            var lkSrc = "";
	            var shrCtlgLst = "";

	            //第二次查询A
	            lkSrc = "101";
	            var cataIds = [];
	            cataIds.push(entryPriseInfoData._enterpriseAdminCataIds);
	            shrCtlgLst = cataIds.toString();
	            
	            return {
	                linkType: param.linkType || 0,//外链类型
	                srt: param.srt || constants.gridInitConfig.fileShareSrt,//外链排序方式
	                srtDr: param.srtDr || sortType.desc,//排序方向
	                bNum: param.bNum || constants.gridInitConfig.startNum,
	                eNum: param.eNum || constants.gridInitConfig.endNum ,
	                lkSrc:lkSrc,
	                shrCtlgLst:shrCtlgLst
	            };
	        };
		
		var openFileShareInfo = function(){
			var dataurl
			var selectids = selectedIDs[0];
			//获取链接地址
			var data = window.caiyun.util.cache.getFileShareCache(constants.FILE_SHARE_LIST_CACHEGROUP,selectids);
			//dataurl = data.url;
			dataurl = centreLinkId == '' ? data.url : data.url + "&centreLinkId=" + centreLinkId;
			window.open(dataurl);
		};
		//复制链接地址
		var copyFileShareUrl = function(){
			var selectID = selectedIDs[0];
			//获取链接地址
			var data = window.caiyun.util.cache.getFileShareCache(constants.FILE_SHARE_LIST_CACHEGROUP,selectID);
			var selectMsg  = data.url;
			//window.clipboardData.clearData();
            //window.clipboardData.setData("Text", selectMsg);
		};
		
		var reload = function(){
			sortClear();
			loadFileShareInfos();
		}
		
		var loadFileShareInfos = function(){
			trigger(keys.enterFileShare,[]);
			window.caiyun.util.cache.clearFileCache(constants.FILE_SHARE_LIST_CACHEGROUP);
			getFileShareInfos(queryParams);
		};
        
		 //加载文件分享
        var getFileShareInfos = function(param){
        	 if(constants.abortAjaxs){
                 constants.abortAjaxs.abort();
             }
        	 
        	 if(constants.abortShareAjaxs){
        		 constants.abortShareAjaxs.abort();
             }
        
            var params = getQueryParams(param);
            
            constants.abortAjaxs = fileShare.getAllShare(params, queryFileLinkSuccCallBack, queryFileLinkFailCallBack,true);
            scrolling = true;
            // 显示加载更多的提示栏
			$('#listLoading').fadeIn('fast');
        };
        
        //加载文件分享
        var getFileShareInfos1 = function(param){
        	 if(constants.abortAjaxs){
                 constants.abortAjaxs.abort();
             }
        	 
        	 if(constants.abortShareAjaxs){
        		 constants.abortShareAjaxs.abort();
             }
            var params = getQueryParams1(param);
            constants.abortShareAjaxs = fileShare.getAllShare(params, queryFileLinkSuccCallBack1, queryFileLinkFailCallBack1,true);
            scrolling = true;
            // 显示加载更多的提示栏
			$('#listLoading').fadeIn('fast');
        };
        
        var queryFileLinkSuccCallBack = function(params, response){
			scrolling = false;
			$('#listLoading').fadeOut('slow');
			if(null == response){
				caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试！","error");
				return false;
			}
			if(null != response.showMessage && "" != response.showMessage)
			{
				caiyun.ui.iMsgTip.tip(formatReturnMsg(response.showMessage),"error");
			}else{
				var retCode = response.getOutLinkLstRes.retCode;
				if(retCode == "0"&& response.getOutLinkLstRes.outLinks != null){
					var listView = window.caiyun.ui.model.fileShareListView;
					count = response.getOutLinkLstRes.count;
					window.caiyun.util.cache.putShareFileCache(constants.FILE_SHARE_LIST_CACHEGROUP, response.getOutLinkLstRes);
					scrollLoadSucc();
					trigger(keys.loadData,response.getOutLinkLstRes);
					
					//第二次调用查询 
					oneSize = oneSize + response.getOutLinkLstRes.outLinks.length;
					if((response.getOutLinkLstRes.count <= oneSize) && (search == 1)){
						startPage =1;
						search = 2;
						oneSize = 0;
						getFileShareInfos1(queryParams);
					}
				}else{
					caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试！","error");
				}
			}
            
        };
        
        var queryFileLinkFailCallBack = function(request, textStatus, errorThrown, params){
            //弹出error对话框
			 scrolling = false;
			 if(!constants.abortAjaxs && !constants.abortShareAjaxs){
				 caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试...","error");
	         }
			 //caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试！","error");
			 $('#listLoading').fadeOut('slow');
			 
			 //失败以后也接着第二次调用
			 if(search == 1){
				 startPage =1;
				 search = 2;
				 oneSize = 0;
				 getFileShareInfos1(queryParams);
			 }
			 
        };
        
        var queryFileLinkSuccCallBack1 = function(params, response){
			scrolling = false;
			$('#listLoading').fadeOut('slow');
			if(null == response){
				caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试！","error");
				return false;
			}
			if(null != response.showMessage && "" != response.showMessage)
			{
				caiyun.ui.iMsgTip.tip(formatReturnMsg(response.showMessage),"error");
			}else{
				var retCode = response.getOutLinkLstRes.retCode;
				if(retCode == "0"&& response.getOutLinkLstRes.outLinks != null){
					var listView = window.caiyun.ui.model.fileShareListView;
					count = response.getOutLinkLstRes.count;
					window.caiyun.util.cache.putShareFileCache(constants.FILE_SHARE_LIST_CACHEGROUP, response.getOutLinkLstRes);
					scrollLoadSucc();
					trigger(keys.loadData,response.getOutLinkLstRes);
				}else{
					caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试！","error");
				}
			}
            
        };
        
        var queryFileLinkFailCallBack1 = function(request, textStatus, errorThrown, params){
            //弹出error对话框
			 scrolling = false;
			 caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试！","error");
			 $('#listLoading').fadeOut('slow');
			 
        };
        
		//取消分享
		var delOutLink = function(params,cancelFileShareSuccCallBack,cancelFileShareFailCallBack){
			fileShare.cancelFileShare(params,cancelFileShareSuccCallBack,cancelFileShareFailCallBack);
		};
		
		
		var triggerCancelFileShareSucc = function(objID){
			trigger(keys.cancelFileShare,objID);
		};
		
		//分享管理页的取消分享
		var delOutLinkForShare= function(ids){
			var workIds = ids || selectedIDs;
			var seleIds = workIds.toString();
			var params = {linkIDs:seleIds+','};
			var contentHtml = '<div class="system_main"></div><div class="off_line_tips_YN"><div class="tips_img"></div><div class="floatleft"><p>取消分享后，好友将无法再访问此文件（夹）。<BR/>是否确定取消？</p></div></div>';
			var dialog = caiyun.ui.msgBox({
				width : 580,
				title:"取消分享",
				html:contentHtml,
				okHandle:function(){
					fileShare.cancelFileShare(params,cancelFileShareSuccCallBack,cancelFileShareFailCallBack);
					dialog.close();
				}
			});
			dialog.show();
			//统计取消分享操作
			for(var i = 0;i<workIds.length;i++){
				caiyun.pvlog("fileLink",'unPublish',workIds[i]);
			}
		};
		
		var cancelFileShareSuccCallBack = function(data,response){
			if(null == response)
			{
				caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试！", "error");
				return false;
			}
			if(null != response.showMessage && "" != response.showMessage)
			{	
				caiyun.ui.iMsgTip.tip("取消分享失败","error");
				return false;
			}else {
				if(response.resultCode == "0")
				{
					caiyun.ui.iMsgTip.tip("取消分享成功！", "success",3);
					reload();
					var linkids = response.linkIDs.split(',');
					trigger(keys.cancelFileShare,linkids);
					//排序样式重置
					var $sortBySize = $('#links_title1');
					var $sortByTime = $('#links_title2');
					var $sortByTimeArrow = $sortByTime.find('.arrow');
					var $sortBySizeArrow = $sortBySize.find('.arrow');
					$sortByTimeArrow.removeClass('m_time_up m_time_down').addClass('m_time_down').show();
					$sortBySizeArrow.removeClass('m_time_up m_time_down').addClass('m_time_down').hide();
				}
				else{
					caiyun.ui.iMsgTip.tip("取消分享失败","error");
				}
			}
		};
        
		var cancelFileShareFailCallBack = function(req,textStatus,errorThrown,params){
			
			caiyun.ui.iMsgTip.tip("系统繁忙,请稍后再试.","error");
		};
		
        //对外滚动条数据加载回调函数
        var scrollBottomLoadData = function(){
			// 超出页数不做查询
			count = count || 0;
			var curPage = Math.ceil(count/constants.gridInitConfig.endNum);
            // 处理中，不操作
            if (scrolling || startPage >= curPage) {
            	 if(search == 2){
            		 search = 0;
            		 oneSize = 0;
            	 }
            	 return;
            	
            }
                     
            if(search == 2){
            		oneSize = 0;
                    scrolling = true;
                    isScrollLoad = true;
                    var startNumber = startPage * constants.gridInitConfig.endNum + 1;
                    var endNumber = (startPage + 1) * constants.gridInitConfig.endNum;
            	
        		 getFileShareInfos1($.extend(queryParams, {
                     bNum: startNumber,
                     eNum: endNumber
                 }));
            }else{
            	
                scrolling = true;
                isScrollLoad = true;
                var startNumber = startPage * constants.gridInitConfig.endNum + 1;
                var endNumber = (startPage + 1) * constants.gridInitConfig.endNum;
	            	if(!$("#linklistView").is(":hidden")){//只有当在分享文件链接的视图下才加载外链
	            		getFileShareInfos($.extend(queryParams, {
	                    bNum: startNumber,
	                    eNum: endNumber
	                }));
            	}
                
            }
            
        };
		
		// 是否存在新数据
        var hasNewData = function(json){
            if (!json) {
                return false;
            }
            if (json.count > 0) {
                return true;
            }
        };
		
		//滚动数据查询中止或是失败时对于page的恢复
        var scrollLoadSucc = function(){
            if (isScrollLoad) {
                startPage++;
            }
        };
		
		//排序查询数据前的清理工作
        var sortClear = function(){
            //文件缓存清空
            window.caiyun.util.cache.clearFileCache(constants.FILE_SHARE_LIST_CACHEGROUP);
            startPage = 1;
			count = 0;
            isScrollLoad = false;
			queryParams = {
				linkType: 0
			}
        };
		
		//分享文件
		var  creatShareFiles = function(params){
			fileShare.creatFileShare(params,creatFileShareSuccCallBack,creatFileShareFailCallBack);
		};
		
		var creatFileShareSuccCallBack = function(req,resp){
			//清空创建文件外链集合
			fileShareInfosSet = [];
			if(null != resp.showMessage && "" != resp.showMessage)
			{
				if("error_01" == resp.showMessage)
				{
					caiyun.ui.iMsgTip.tip("您尚未登录", "error");
				}
				else if("error_02" == resp.showMessage)
				{
					caiyun.ui.iMsgTip.tip("请求参数不正确", "error");
				}
				else if("error_03" == resp.showMessage)
				{
					caiyun.ui.iMsgTip.tip("系统异常，请稍后再试", "error");
				}
				else if("error_04" == resp.showMessage)
				{
					caiyun.ui.iMsgTip.tip("请求文件数不能超过20", "error");
				}
				else if("error_05" == resp.showMessage)
				{
					caiyun.ui.iMsgTip.tip("请求文件夹数不能超过20", "error");
				}
				else if("error_06" == resp.showMessage)
				{
					caiyun.ui.iMsgTip.tip("共享人数不能超过50", "error");
				}
				return false;
			}
			if (resp.getOutLinkRes && resp.getOutLinkRes.retCode == "0" && resp.getOutLinkRes.getOutLinkResSet) {
				//重新赋值
				fileShareInfosSet = resp.getOutLinkRes.getOutLinkResSet;
				trigger(keys.creatFileShare, fileShareInfosSet);
			}
			else if (resp.getOutLinkRes.retCode == "200000400") {
				caiyun.ui.iMsgTip.tip("文件分享失败，文件不存在或文件总数大于200!", "error");
			}
			else if (resp.getOutLinkRes.retCode == "9470") {
                caiyun.ui.iMsgTip.tip("文件名含有敏感词，请修改后重试", "error");
            }
			else {
				caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试", "error");
			}
		};
		
		var creatFileShareFailCallBack = function(req,textStatus,errorThrown,params){
			//清空创建文件外链集合
			fileShareInfosSet = [];
			caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试", "error");
		};
		
		var getFileShareInfosSet = function(){
			return fileShareInfosSet;
		};
		
		//判断操作能否执行
		var canExecute = function(operation, ids){
			var idList = ids || selectedIDs;
			var flag = true;
			switch(operation) {
				case 'openFileShare':
					if(idList.length>1){
						flag = false;
					}
					break;
				case 'copyFileShare':
					if(idList.length>1){
						flag = false;
					}
					break;
				case 'cancelFileShare':
					break;
			}
			return flag;
		};
		
		//短信分享
		var shareLinkByMsg = function(linkid,recvMSISDN,shareLinkByMsgSuccCallBack,shareLinkByMsgFailCallBack){
			var parms = new Object();
			parms["type"] = 1;
			parms["linkID"] = linkid;
			parms["recvMSISDN"] = recvMSISDN;
			fileShare.shareLinkByMsg(parms,shareLinkByMsgSuccCallBack,shareLinkByMsgFailCallBack);
		};
		
//		var shareLinkByMsgSuccCallBack = function(req,response){
//			if(null == response){
//				caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试！", "error");
//				return false;
//			}
//			if(null != response.showMessage && "" != response.showMessage){
//				caiyun.ui.iMsgTip.tip(formatReturnMsg(response.showMessage),"error");
//				return false;
//			}
//			else{
//				var resultCode = response.resultCode;
//				if(resultCode == "0"){
//					caiyun.ui.iMsgTip.tip("分享成功！", "success");
//					return false;
//				}
//				else if(resultCode == "208000402")
//				{
//					caiyun.ui.iMsgTip.tip("每天分享短信数量不可超过50条。", "error");
//					return false;
//				}
//				else{
//					caiyun.ui.iMsgTip.tip("分享失败，请稍后再试！", "error");
//					return false;
//				}
//			}
//		};
//		
//		var shareLinkByMsgFailCallBack = function(){
//			caiyun.ui.iMsgTip.tip("分享失败，请稍后再试！", "error");
//		};
		
		
		//邮件分享
		var shareLinkByMail = function(linkid,recvEmail,shareLinkByMailSuccCallBack,shareLinkByMailFailCallBack){
			var parms = new Object();
			parms["type"] = 1;
			parms["linkID"] = linkid;
			parms["recvEmail"] = recvEmail;
			
			
			fileShare.shareLinkByMail(parms,shareLinkByMailSuccCallBack,shareLinkByMailFailCallBack);
		};
		
//		var shareLinkByMailSuccCallBack = function(req,response){
//			if(null == response){
//				caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试！", "error");
//				return false;
//			}
//			if(null != response.showMessage && "" != response.showMessage){
//				caiyun.ui.iMsgTip.tip(formatReturnMsg(response.showMessage),"error");
//				return false;
//			}
//			else{
//				var resultCode = response.resultCode;
//				if(resultCode == "0"){
//					caiyun.ui.iMsgTip.tip("分享成功！", "success");
//					return false;
//				}
//				else if(resultCode == "208000402")
//				{
//					caiyun.ui.iMsgTip.tip("每天分享邮件数量不可超过5封。", "error");
//					return false;
//				}
//				else
//				{
//					caiyun.ui.iMsgTip.tip("分享失败，请稍后再试！", "error");
//					return false;
//				}
//			}
//		};
//		
//		var shareLinkByMailFailCallBack = function(){
//			caiyun.ui.iMsgTip.tip("分享失败，请稍后再试！", "error");
//		};
		
		
		//返回showMessage时，提示对应错误信息
		var formatReturnMsg = function(showMessage){
			var tipstr = "系统繁忙，请稍后再试";
			if(null == showMessage || "" == showMessage)
			{
				return tipstr;
			}
			else if("error_01" == showMessage)
			{
				tipstr = "您尚未登录";
			}
			else if("error_02" == showMessage)
			{
				tipstr = "请求参数不正确";
			}
			else if("error_03" == showMessage)
			{
				tipstr = "系统异常，请稍后再试";
			}
			else if("error_04" == showMessage)
			{
				tipstr = "请求文件数不能超过20";
			}
			else if("error_05" == showMessage)
			{
				tipstr = "请求文件夹数不能超过20";
			}
			else if("error_06" == showMessage)
			{
				tipstr = "共享人数不能超过50";
			}
				else if("error_07" == showMessage)
			{
				tipstr = "每次分享最多10个人";
			}
			else if("error_08" == showMessage)
			{
				tipstr = "分享次数过多";
			}
			return tipstr;
		};
		/*
		 * 监听注册，里面提供了3个监听
		 * 1.enterFileShare ：进入文件分享模块
		 * 2.选择文件，参数为当前所有选择的文件ids 
		 * 3.loadData ： 数据载入，参数为请求后台的json数据对象
		 * 4.cancelFileShare: 取消分享,参数为当前选择的文件coids或者是caids
		 */
		var addListen = function(key, fun) {
			var ref, stack;
			key = $.trim(key);

			if (keys[key]) {
				stack = (ref = listens[key]) == null ? [] : ref;
				stack.push(fun);
				listens[key] = stack;
			}
			return this;
		};
		
		var removeListen = function(key) {
			delete listens[$.trim(key)];
			return this;
		};

		var trigger = function(key) {
			var events = listens[key] || {} ,params = [],i = 1,length = arguments.length;
			if(length > 1){
				for(;i < length ; i ++){
					params.push(arguments[i]);
				}
			}
			
			$.each(events, function() {
				this.apply(null, params);
			});
		};
		
		return {
			selectedIDs : selectedIDs,
            loadFileShareInfos : loadFileShareInfos,
            scrollLoadData : scrollBottomLoadData,
			openFileShareInfo : openFileShareInfo,
			canExecute : canExecute,
			coypURL : copyFileShareUrl,
			getFileShareInfosSet: getFileShareInfosSet,
			creatShareFiles : creatShareFiles,
			sortHandler : sortHandler,
			reload   :  reload,
			shareLinkByMsg : shareLinkByMsg,
			shareLinkByMail : shareLinkByMail,
			selectHandler : selectHandler,
			delOutLink : delOutLink,
			triggerCancelFileShareSucc : triggerCancelFileShareSucc,
			onListen : addListen,
			delOutLinkForShare : delOutLinkForShare
        }
        
    })();
})()
