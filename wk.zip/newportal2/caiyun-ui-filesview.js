/**
 * 图片的文件视图
 */
(function(){
		var view = {
				name : caiyun.constants.FILES_CONTENT_VIEW ,//显示方式名字
				modelList :[ // 需要显示的对象列表，旧viewModel对象中的显示对象列表会被隐藏，调用hide方法
						{
								model:caiyun.ui.model.listView // 该显示类型下，会出现的对象，不管该对象是否显示，只要该对象有可能在该显示类型下出现都需要加到列表中
						},
						{
								model:caiyun.ui.model.fileCount // 该显示类型下，会出现的对象，不管该对象是否显示，只要该对象有可能在该显示类型下出现都需要加到列表中
						}
				],
				className : 'files',
				data : {}
		};
		// 注册到文件视图管理器下
		caiyun.ui.model.fileContent.addContentView(view);
})();
