//分享管理TAB栏
(function(){
	var self = caiyun.ui.model.shareTab;
	var $links_title0 = $('#links_title0');
	var $links_title1 = $('#links_title1');
	var $links_title2 = $('#links_title2');
	var $links_title3 = $('#links_title3');
	
	var $share_title0 = $('#share_title0');
	var $share_title1 = $('#share_title1');
	var $share_title2 = $('#share_title2');
	var $share_title3 = $('#share_title3');
	
	var $sortBySize = $('#share_title1');
	var $sortByTime = $('#share_title3');
	var $sortByTimeArrow = $sortByTime.find('.arrow');
	var $sortBySizeArrow = $sortBySize.find('.arrow');


	var $linkTime = $('#links_title2');
	var $linkTimeArrow = $linkTime.find('.arrow');
	var $linkSize = $('#links_title1');
	var $linkSizeArrow = $linkSize.find('.arrow');
	
	var constants = window.caiyun.constants;
	
	self.init = function(){
		// 文件操作对象
		var fileShareOperator = caiyun.fileShareOperate;
		var myFileShareOpt = caiyun.myFileShareOperate;
		
		var tabList = [{
				id  		: 'shareUrlTab',
				name		: '我分享的链接',
				click   	: function(){
					$("#sharelistView").hide();
					$("#linklistView").show();
					$("#share_title").hide();
					$("#links_title").show();
					$("#links_bar").hide();
					$("#share_bar").hide();
					$links_title0.show();
					$links_title1.show();
					$links_title2.show();
					$links_title3.show();
					$("#selectLinksAll").removeClass('input_first_on');
					$("#selectLinksAll").addClass('input_first');
					$linkTimeArrow.removeClass('m_time_up m_time_down').addClass('m_time_down').show();
					$linkSizeArrow.removeClass('m_time_up m_time_down').addClass('m_time_down').hide();
					window.caiyun.fileShareOperate.reload();
					caiyun.pvlog('feature','fileLink');
				}
		},{
				id  		: 'shareFileTab',
				name		: '我分享的文件',
				click   	: function(){
					$("#sharelistView").show();
					$("#linklistView").hide();
					$("#share_title").show();
					$("#links_title").hide();
					$("#links_bar").hide();
					$("#share_bar").hide();
					$share_title0.show();
					$share_title1.show();
					$share_title2.show();
					$share_title3.show();
					$("#selectShareAll").removeClass('input_first_on');
					$("#selectShareAll").addClass('input_first');
		    		$sortByTimeArrow.removeClass('m_time_up m_time_down').addClass('m_time_down').show();
		    		$sortBySizeArrow.removeClass('m_time_up m_time_down').addClass('m_time_down').hide();
					window.caiyun.myFileShareOperate.reload();
					caiyun.pvlog('feature','fileShare');
				}
		}];
		
		//分享管理tab对象
		var shareTab = window.caiyun.ui.CyTab({
			renderTo		:		'shareTab',
			items			:     	tabList
		});
		
		//监听进入我的文件分享
		fileShareOperator.onListen("enterFileShare",function(){
		    shareTab.cyTabReSet();
		    $("#sharelistView").hide();
			$("#linklistView").show();
			$("#share_title").hide();
			$("#links_title").show();
			$("#links_bar").hide();
			$("#share_bar").hide();
			$links_title0.show();
			$links_title1.show();
			$links_title2.show();
			$links_title3.show();
		});
		
		
		var shareUrlTabInit = function (){
		
		}
		
		self.hide = function(){
			shareTab.cyTabHide();
			$("#doc_path").show();
			$("#sharelistView").hide();
			$("#linklistView").hide();
            if(constants.abortAjaxs){
                constants.abortAjaxs.abort();
            }
            if(constants.abortShareAjaxs){
       		 	constants.abortShareAjaxs.abort();
            }
			
		};
		self.show = function(){
			shareTab.cyTabShow();
			$("#doc_path").hide();
			$("#share_title").show();
			$sortByTimeArrow.removeClass('m_time_up m_time_down').addClass('m_time_down').show();
			$sortBySizeArrow.removeClass('m_time_up m_time_down').addClass('m_time_down').hide();
		};
	};
	
	// 将自己的初始化方法加载到ui的initList中
	caiyun.ui.initList.push(self);
})();
