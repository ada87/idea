/**
 * 文档在线预览和编辑 
 */
;window.caiyun.fileOnlineEdit = window.caiyun.fileOnlineEdit || {};

(function(){
	var self = caiyun.fileOnlineEdit;
	
    var wangdaurl = editOnlineUrl,oseUrl = editOnlineOseUrl;
	
	/* 在线预览文档 */
	var prevDocument = function(obj){
				
        var id = (new Date()).getTime();
		var myStringBuffer = new StringBuffer();
    	var name = obj.contentName;
    	var fileId = obj.contentID;
    	var format = obj.contentSuffix;
    	var owner = ownerMSISDN;
    	//timeline预览企业里的文档，需要传入企业空间所有者帐号作为ownerMSISDN，下面的if是兼容作用
    	if(obj.spaceOwner4Timeline){
    		owner = obj.spaceOwner4Timeline;
    	}
    	var path = getFilePath(fileId);
    	if(obj.path){
    		path = obj.path;
    		//owner = obj.owner.replace("+86","");
    	}
    	
		    myStringBuffer.append('<form method="POST" id="form'+id+'" style="display:none;" target="_blank" action="">')
        				  .append('<input type="hidden" name="name" value="'+name+'" />')
        				  .append('<input type="hidden" name="fileId" value="'+fileId+'" />')
        				  .append('<input type="hidden" name="format" value="'+format+'" />')
						  //.append(obj.path?'<input type="hidden" name="path" value="'+path+'">':'')
						  .append('<input type="hidden" name="path" value="'+path+'">')
						  .append('<input type="hidden" name="Authorization" value="'+rcsToken+'" />')
                          .append('<input type="submit" name="Preview" value="submit" />')
        				  .append('</form>');
    	$("body").append(myStringBuffer.toString());
    	var br = new StringBuffer();
    		br.append(oseUrl + "/richlifeApp/devapp/IUploadAndDownload");
    		br.append("?MSISDN=" + owner);
    		br.append("&contentID=" + fileId);
    		br.append("&ownerMSISDN=" + owner);
    		br.append("&fileVersion=-1");
    	var form=document.getElementById('form'+id);
    	form.action=wangdaurl+'/files/filePreview.action?url='+ LittleUrl.encode(br.toString());
    	//提交表单参数
    	form.submit();
	}
	
	/* 在线编辑文档 */
	var editDocument = function(obj){
		var myStringBuffer = new StringBuffer();
		var id = (new Date()).getTime();
		var name = obj.contentName;
    	var fileId = obj.contentID;
    	var format = obj.contentSuffix;
    	
    	var owner = ownerMSISDN;
    	var path = getFilePath(fileId);
    	if(obj.path){
    		path = obj.path;
    		//owner = obj.owner.replace("+86","");
    	}
    	
    	var getUrl = new StringBuffer();
    		getUrl.append(oseUrl + "/richlifeApp/devapp/IUploadAndDownload");
    		getUrl.append("?MSISDN=" + owner);
    		getUrl.append("&contentID=" + fileId);
    		getUrl.append("&ownerMSISDN=" + owner);
    		getUrl.append("&fileVersion=-1");
        var saveUrl = new StringBuffer();
    		saveUrl.append(oseUrl + "/richlifeApp/devapp/IUploadAndDownload");
    		saveUrl.append("?ownerMSISDN=" + owner);
    		saveUrl.append("&newCatalogName=" + obj.contentName);
    		saveUrl.append("&parentCatalogID=" + obj.parentCatalogId);
    		saveUrl.append("&updateContentID=" + obj.contentID);
    	
		myStringBuffer.append('<form method="post" id="form'+id+'" style="display:none;" target="_blank" action="">')
        				.append('<input type="hidden" name="url" value="'+getUrl.toString()+'" />')
        				.append('<input type="hidden" name="name" value="'+name+'" />')
        				.append('<input type="hidden" name="fileId" value="'+fileId+'" />')
        				.append('<input type="hidden" name="format" value="'+format+'" />')
        				//.append(obj.path?'<input type="hidden" name="path" value="'+path+'">':'')
        				.append('<input type="hidden" name="path" value="'+path+'">')
        				.append('<input type="hidden" name="saveurl" value="'+saveUrl.toString()+'" />')
        				.append('<input type="hidden" name="Authorization" value="'+rcsToken+'" />')
        				.append('<input type="submit" name="Edit" value="submit" />')
        				.append('</form>');				
        $("body").append(myStringBuffer.toString());
    	var form = document.getElementById('form'+id);
    	form.action=wangdaurl+'/files/fileEdit.action';
    	form.submit();
	}
	
	//获取文件路径
	var getFilePath = function(id){
	    var path = '';
	    //判断是否在"我收到的分享"文件夹目录下或者在企业管理目录下都要传文件路径PATH
	    if (caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)) {
	        path = caiyun.judgement.getPath(caiyun.operate.getCatalogStack());
		}
        if(caiyun.judgement.isEnterprisePath()){
            path = caiyun.judgement.getPathForEnterprise();
        }
	    return path;
	}
	
	var LittleUrl = {  
        // public method for url encoding  
        encode : function (string) {  
            return escape(this._utf8_encode(string));  
        },  
        // public method for url decoding  
        decode : function (string) {  
            return this._utf8_decode(unescape(string));  
        },  
        // private method for UTF-8 encoding  
        _utf8_encode : function (string) {  
            string = string.replace(/\r\n/g,"\n");  
            var utftext = "";  
            for (var n = 0; n < string.length; n++) {  
       
                var c = string.charCodeAt(n);  
       
                if (c < 128) {  
                    utftext += String.fromCharCode(c);  
                }  
                else if((c > 127) && (c < 2048)) {  
                    utftext += String.fromCharCode((c >> 6) | 192);  
                    utftext += String.fromCharCode((c & 63) | 128);  
                }  
                else {  
                    utftext += String.fromCharCode((c >> 12) | 224);  
                    utftext += String.fromCharCode(((c >> 6) & 63) | 128);  
                    utftext += String.fromCharCode((c & 63) | 128);  
                }  
       
            }  
       
            return utftext;  
        },  
       
        // private method for UTF-8 decoding  
        _utf8_decode : function (utftext) {  
            var string = "";  
            var i = 0;  
            var c = c1 = c2 = 0;  
       
            while ( i < utftext.length ) {  
       
                c = utftext.charCodeAt(i);  
       
                if (c < 128) {  
                    string += String.fromCharCode(c);  
                    i++;  
                }  
                else if((c > 191) && (c < 224)) {  
                    c2 = utftext.charCodeAt(i+1);  
                    string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));  
                    i += 2;  
                }  
                else {  
                    c2 = utftext.charCodeAt(i+1);  
                    c3 = utftext.charCodeAt(i+2);  
                    string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));  
                    i += 3;  
                }  
            }  
            return string;  
        }  
    }  
	
	return window.caiyun.fileOnlineEdit = {
		prev : prevDocument,
		edit : editDocument
	}
})();
