(function() {
    var constants = window.caiyun.constants;
    var util = window.caiyun.util;
    var grids = {};
    var scrollerWrapper = {};
    var fileReader = {
        itemID: 'id',
        name: 'name',
        itemSize: 'size',
        virUpdateTime: 'time',
        type: 'type'
    };

    var self = window.caiyun.ui.model.recycleBinView;

    var genExtraHoverTool = template.compile(
        '<b title="还原" class="hover_tools_btn l_revert" id="gridrevertfile_<%=grid.getId()%>_<%=rowItem.id%>"></b>' +
        '<b title="彻底删除" class="hover_tools_btn l_remove" id="griddeletefile_<%=grid.getId()%>_<%=rowItem.id%>"></b>');



    self.init = function() {
        var operate = window.caiyun.recycleBinOperate;
        var visible = false;
        var $parent = $('#recycleBinView');

        var checkBoxCol = new caiyun.ui.CyGridColumns.SelectCheckBox();
        checkBoxCol.width = '5%';
        var fileInfoCol = new caiyun.ui.CyGridColumns.FileInfo();
        fileInfoCol.width = '60%';
        var sizeCol = new caiyun.ui.CyGridColumns.Words();
        sizeCol.width = '18%';
        var dateCol = new caiyun.ui.CyGridColumns.Words();
        dateCol.width = '17%';
        var fileGrid = window.caiyun.ui.CyDefaultGrid({
            renderId: 'recycleBinView',
            row: new caiyun.ui.CyGridRows.SelectedRow(),
            columns: [checkBoxCol, fileInfoCol, sizeCol, dateCol]
        });

        // 设置相关处理器 =============================================================

        fileGrid.setSelectedHandler(function(items, total) {
            var ids = [];
            $(items).each(function() {
                ids.push(this.id);
            });
            operate.selectHandler(ids, total);
        });

        fileGrid.setContextmenuHandler(function(e) {
            var menu = caiyun.ui.model.recycleBinRightClickMenu;
            menu.openAndLocate(e);
        });

        function extraHoverToolHandler(event) {
            var $this = $(this);
            var itemId = $this.attr('id').split('_')[2];
            if ($this.hasClass('l_revert')) {
                operate.revertFile([itemId]);
            }else if($this.hasClass('l_remove')){
                operate.deleteFile([itemId]);
            }
            event.stopPropagation();
            return false;
        }

        // 注册悬浮菜单处理器
        fileGrid.addEventListener('click', 'b.l_revert,b.l_remove', extraHoverToolHandler);

        // 设置相关处理器 =============================================================

        var addDatas = function(data) {
            var items = [];
            if (data && visible) {
                self.addFiles(data.vitem);
            }
        };


        // 注册文件操作监听事件======================================
        $(window).bind('scroll', function() {
            if (visible) {
                operate.scrollLoadData();
            }
        });

        // 监听视图切换
        operate.onListen('viewSwitch', function(viewMode) {
            if (viewMode == constants.view.web) {
                self.show();
            } else {
                self.hide();
                fileGrid.clear();
            }
        });

        // 监听加载文件列表事件
        operate.onListen('loadData', function(data) {
            if (visible) {
                // 记录当前窗口滚动条位置
                var scrollTop = util.getScrollTop();
                addDatas(data);

                if (data.nodeCount == "0") {
                    // 还原滚动条位置
                    window.scrollTo(0, 0);
                    //                  fileGrid.setEmptyStyle(util.getEmptyHtmlStr("此目录还没有任何东西哦，请选择上传按钮进行相关操作!"));
                    fileGrid.setEmptyStyle(util.getEmptyHtmlStr("您的回收站目前为空!"));
                    //                  fileGrid.setEmptyStyle(util.getEmptyHtmlStr(""));
                } else {
                    // 还原滚动条位置
                    window.scrollTo(0, scrollTop);
                    fileGrid.show();
                }
            }
        });


        // 监听全选命令
        operate.onListen('selectAll', function() {
            if (!visible) {
                return;
            }
            fileGrid.selectAll();
        });

        // 监听取消全选命令
        operate.onListen('unSelectAll', function() {
            if (!visible) {
                return;
            }
            fileGrid.unSelectAll();
        });

        operate.onListen('clearData', function() {
            fileGrid.clear();
        });

        // 添加文件夹，将彩云的文件夹信息转化为视图要显示的格式
        self.addFolders = function(folders, inFront) {
            var items = [];
            $(folders).each(function() {
                var data = new window.caiyun.ui.CyGridItem(this.catalogID);
                data.type = 'folder';
                // 第一列空对象
                data.colItems.push({});
                // 第二列文件信息
                data.colItems.push({
                    showName: window.caiyun.util.htmlEscape(this.catalogName.substringName(25,true)),
                    fileName: window.caiyun.util.htmlEscape(this.catalogName),
                    thumbnail: window.caiyun.util.Icon.getIcon({
                        id: this.catalogID,
                        shareType: this.shareType || '0',
                        suffix: 'folder'
                    }, true),
                    extraHoverTool: genExtraHoverTool({
                        grid: fileGrid,
                        rowItem: data
                    })
                });
                // 第三列文件大小
                data.colItems.push({
                    str: '---'
                });
                // 第四列文件时间
                data.colItems.push({
                    str: util.formateLifeTime(this.updateTime)
                });
                items.push(data);
            });
            if (items.length > 0) {
                if (inFront) {
                    fileGrid.unshiftItems(items);
                } else {
                    fileGrid.pushItems(items);
                }
            }
        };

        // 添加文件，将彩云的文件信息转化为视图要显示的格式
        self.addFiles = function(files, inFront) {
            var items = [];
            $(files).each(function() {
                var data = new window.caiyun.ui.CyGridItem(this.itemID);
                // 第一列空对象
                data.colItems.push({});
                // 第二列文件信息
                var thumbnail = window.caiyun.util.Icon.getRecycIcon(this, true);
                data.colItems.push({
                    showName: window.caiyun.util.htmlEscape(this.name.substringName(25,this.type === '-1')),
                    fileName: window.caiyun.util.htmlEscape(this.name),
                    thumbnail: thumbnail,
                    extraHoverTool: genExtraHoverTool({
                        grid: fileGrid,
                        rowItem: data
                    })
                });
                // 第三列文件大小
                data.colItems.push({
                    str: util.formateSize(this.itemSize)
                });
                // 第四列文件时间
                data.colItems.push({
                    str: util.formateLifeTime(this.virUpdateTime)
                });
                items.push(data);
            });
            if (items.length > 0) {
                if (inFront) {
                    fileGrid.unshiftItems(items);
                } else {
                    fileGrid.pushItems(items);
                }
            }
        };

        self.show = function() {
            visible = true;
            fileGrid.show();
            $parent.show();
        };

        self.hide = function() {
            visible = false;
            fileGrid.hide();
            operate.selectHandler([]);
            $parent.hide();
        };

        self.enter = function() {};

        self.leave = function() {
            fileGrid.clear();
        };

    };

    // 注册到页面初始化方法中
    caiyun.ui.initList.push(self);
})();