/**
 * myphone控制器
 */
(function(){
	caiyun.myPhoneOperate = (function(){
		
		var listens = {};
		var keys = {
			switchTo : 'switchTo',
			triggerSmsContent : 'triggerSmsContent'
		};
		var nameMap = {
			contact : '通讯录',
			calendar : '日历',
			sms : '短彩信',
			mms : '短彩信',
			apps : '手机应用',
			my_image : '手机图片',
			my_video : '手机视频'
		};
		
		var urlMap = {
			contact : 'http://caiyun.feixin.10086.cn/Mcloud/proxy/txl.jsp',
			calendar : 'http://mail.10086.cn/Login/CalendarLogin.ashx?loginName='+ownerMSISDN+'&token='+rcsToken+'&isRedirect=1',
			sms : 'index_newsms2.jsp',
			mms : 'index_newsms2.jsp',
			apps : 'myphoneApp.jsp'
		};

		var currentId = null;
		
		var getCurrentId = function(){
			return currentId;
		};

		var clearCurrentId = function(){
			currentId = null;
		};

		var addListen = function(key, fun) {
			var ref, stack;
			key = $.trim(key);

			if (keys[key]) {
				stack = (ref = listens[key]) == null ? [] : ref;
				stack.push(fun);
				listens[key] = stack;
			}
			return this;
		};
		
		var trigger = function(key, param) {
			var events = listens[key] || {};
			$.each(events, function() {
				this.call(null, param);
			});
		};
		
		/**
		 * 切换到栏目
		 * 
		 * @param id 栏目ID
		 */
		var switchTo = function(id){
			currentId = id;
			trigger(keys.switchTo,{id : id , name : nameMap[id] , url : urlMap[id]});
		};

		/**
		 * 通知短彩信栏目切换
		 */
		var triggerSmsContent = function(id){
			currentId = id;
			trigger(keys.triggerSmsContent,{id : id});
		};
	
		return {
			switchTo : switchTo,
			addListen : addListen,
			getCurrentId : getCurrentId,
			clearCurrentId: clearCurrentId,
			triggerSmsContent : triggerSmsContent
		};
	})();
	
}
)();