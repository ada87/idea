/**
 * 排序表头菜单
 * 
 */
var CySortTitle = {
	count : 0,

	// 初始化
	init : function() {
		$('#s_size').unbind().bind('click', function() {

			$("#s_size").CySortTable("c_size", function() {
			});
			CySortTitle.count = 1;
			$("#c_size").show();

		});
		$('#s_time').unbind().bind('click', function() {

			$("#s_time").CySortTable("c_time", function() {
			});
			CySortTitle.count = 1;
			$("#c_time").show();
		});

		$("#s_size").hover(function() {

			$("#c_size").show();
		}, function() {
			if ($("#c_time").is(":hidden")) {
				if (CySortTitle.count == 0) {
					$("#c_size").hide();
				}
			} else {
				$("#c_size").hide();
			}
		});

		$("#s_time").hover(function() {
			$("#c_time").show();
		}, function() {

			if ($("#c_size").is(":hidden")) {
				if (CySortTitle.count == 0) {
					$("#c_time").hide();
				}
			} else {
				$("#c_time").hide();
			}

		});

	}
};

$(function() {
	CySortTitle.init();
});