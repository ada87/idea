/**
 * 过滤器
 * options{
 * 			appendToId : '',//指定控件添加的dom元素id,必须 如：filterBar
 * 			spans       : [{
 *                            id:''  //元素id后缀，代表一种过滤类型
 *                            title  : ''//元素名称
 *                            style:''   //被选中样式(可选)，默认为'colum_name_all'
 *                            click : '' //点击事件
 *                       }]//tab的元素
 * }
 */
;(function(){
	window.caiyun.ui.CyFilterBar = function(options){
		var filterBar = $('#'+options.appendToId);
		$.each(options.spans,function(i,val){
			if(typeof(val.style)==='undefined' ){
				val.style = 'colum_name_all';
			}
		});
		var init = function(){
			if (!options) {
				return;
			}
			createFilter();
		};
		
		//创建过滤器体
		var createFilter = function(){
			$.each(options.spans,function(i,val){
				createSpan(val);
				addEventHandle(val);
				if(i==0){
					$('#'+options.appendToId + '_' + val.id).addClass(val.style);
				}
			});
			//收起和展开按钮
			createItem();
			
			//默认收起
			$.each(options.spans,function(i,val){
				if(i!=0){
					$('#'+options.appendToId +'_' +val.id).hide();
				}
			});
			$('#'+options.appendToId+'Pickup').hide();
		};
		
		//创建单个过滤选项
		var createSpan = function(span){
			var conHtml = '';
			conHtml += '<span class="colum_name" '
				   +'id="' + options.appendToId + '_' + span.id + '"' 
				   +'title="' + span.title + '">'+ span.title 
				   +'</span>' ;
			filterBar.append(conHtml.toString());
		};
		
		//选项绑定点击事件，点击改变样式
		var addEventHandle = function(val){
			if($.isFunction(val.click)){
				$('#'+options.appendToId +'_' +val.id).unbind('click')
					.bind('click', function(){
						$('[id^='+options.appendToId + '_]').removeClass(val.style);
						$('#'+options.appendToId + '_' + val.id).addClass(val.style);
						val.click();
					});
			}
		};
		
		//创建收起和展开图标并绑定事件
		var createItem = function(){
			var conHtml = '';
			conHtml += '<em><i class="look_sj_right" id="' +
					   options.appendToId + 'Pickup"></i>' +
					   '<i class="look_sj_left" id="' +
					   options.appendToId + 'Spread">' +
					   '</i></em>' ;
			filterBar.append(conHtml.toString());
			
			//绑定收起事件
			$('#'+options.appendToId +'Pickup')
				.unbind('click').bind('click',pickUp );
			//绑定展开事件
			$('#'+options.appendToId +'Spread')
				.unbind('click').bind('click',Spread );
		};
		
		//收起功能
		var pickUp = function(){
			//隐藏具体项
			$.each(options.spans,function(i,val){
				if(i!=0){
					$('#'+options.appendToId +'_' +val.id).fadeTo("slow", 0);
					$('#'+options.appendToId +'_' +val.id).hide();
				}
			});
			//收起改为展开
			$('#'+options.appendToId+'Pickup').hide();
			$('#'+options.appendToId+'Spread').show(500);
		};
		
		//展开功能
		var Spread = function(){
			//展开具体项
			$.each(options.spans,function(i,val){
				if(i!=0){
					$('#'+options.appendToId +'_' +val.id).fadeTo("slow", 1);
				}
			});
			//展开改为收起图标
			$('#'+options.appendToId+'Spread').hide();
			$('#'+options.appendToId+'Pickup').show(500);
		};
		 
		var toDefault = function(){
			var val = options.spans[0];
			$('[id^='+options.appendToId + '_]').removeClass(val.style);
			$('#'+options.appendToId + '_' + val.id).addClass(val.style);
			//val.click();
			pickUp();
		};
		
		var show = function(){
			filterBar.show();
		};
		var hide = function(){
			filterBar.hide();
		};
		
		init();
		
		return {
        	show : show,
			hide : hide,
			toDefault : toDefault
        };
	};
})();