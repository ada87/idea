/*
 * 垂直Tab控件,用于显示彩云各个功能模块
 * 
 * options{
 * 
 * 			appendToId : '',//指定控件添加的dom元素id,必须
 * 			tabId : '',//整个Tab插件ID
 * 			tabs       : [{
 *                            id:''  //元素id,代表一个模块
 *                            title  : ''//元素名称
 *                            style:''   //被选中样式(可选)
 *                            click : '' //点击事件
 *                            display: ''  //是否显示(默认显示)
 *                       }]//tab的元素
 * }
 * 
 */
;(function(){
	window.caiyun.ui.jVTab = function(options){
		var leftNavCss = caiyun.constants.leftNavCss;
		var para = {};
		var tabId = options.tabId;
		
		
		var init = function(){
			if (!options) {
				return;
			}
			p = {
				display:true
			}
			para = options;
			
			$.extend(p,para);
			
			//为每个tab的index属性赋值
			$.each(options.tabs,function(i,n){
				n.index = i+1;
			});
			creatTabs();
			initCss();//初始化按钮图标样式
			addEventHandles();
		}
		
		//主体HTML
		var creatTabs = function(){
			var conHtml = new StringBuffer();
			conHtml.append('<div id="')
				.append(tabId)
				.append('"style="height:500px;" class="side-nav">')
				.append('<div class="left_menu_top"></div>')
				.append(addTabs(para.tabs))
				//.append(addRecycleHtml(tab))
				.append('</div>');
			$('#'+options.appendToId).append(conHtml.toString());
		};
		
		var addTab = function(tab){
			var tabHtml = new StringBuffer();
			
			tabHtml.append('<li id="')
				.append(tabId)
				.append("_")
				.append(tab.id)
				.append('" class="')
				.append(tab.style)
				.append('" ')
				if(!tab.display){
					tabHtml.append('style="display:none"');
				}
				tabHtml.append('><a href="javascript:void(0);"><i class=""></i>')
					.append(tab.title)
					.append('</a></li>');
			
			return tabHtml.toString();
		};
		
		var addTabs = function(tabs){
			if (!tabs || tabs.length === 0) {
				return "";
			}
			var tabsHtml = new StringBuffer(), tab;
			tabsHtml.append('<ul>');
			for (var i = 0; i < tabs.length; i++) {
				tab = tabs[i];
				tabsHtml.append(addTab(tab));
			};
			tabsHtml.append('</ul>');
			
			return tabsHtml.toString();
		};
		
		//回收站HTML
		var addRecycleHtml = function(tab){
			var recycleHtml = new StringBuffer();
			recycleHtml
				.append('<ul class="recycle"><li id="')
				.append(tabId)
				.append("_")
				.append(tab.id)
				.append('" ')
				if(!tab.display){
					recycleHtml.append('style="display:none"');
				}
				recycleHtml.append('><a href="javascript:void(0);"><i class="i')
					.append(tab.index)
					.append('"></i>')
					.append(tab.title)
					.append('</a></li></ul>');
			return recycleHtml.toString();
		};
		
		var initCss = function(){
			$.each($('#' + tabId + " li"),function(i,n){
				$(this).find('i').addClass(leftNavCss[i]);
			});
			
		};
		
		var addEventHandle = function(tab){
			if (tab.click) {
				$('#' + tabId + '_' + tab.id).unbind('click').bind('click', function(e){
					$('#' + tabId + " li.current").removeClass('current');
					$(this).addClass('current');
					if (tab.click) {
						tab.click(e);
					}
				});
				$('#' + tabId).delegate('li', 'mouseover', function(){
					//            			var $a = $(this).find('a');
					//            			if(!$a.hasClass('focus')){
					//            				$a.addClass('selected');
					//            			}
				}).delegate('li', 'mouseout', function(){
					//            			$(this).find('a').removeClass('selected');
				});
				//中断<a>的click事件冒泡
				$('#' + tabId).delegate('a','click',function(){
					return false;
				});
			}
		};
		
		var addEventHandles = function(){
			var tabs = para.tabs;
			if (!tabs) {
				return;
			}
			for (var i = 0; i < tabs.length; i++) {
				addEventHandle(tabs[i]);
			};
		};
		
		var selectHandle = function(id){
			$('#' + tabId + " li.current").removeClass('current');
			$('#' + tabId + '_' + id).addClass('current');
		}
		//
		var clickByID = function(id){
			$('#' + tabId + '_' + id).click();
		}
		
		var selectByID = function(id){
			selectHandle(id);
		}
		
		var showByID = function(id){
			$('#' + tabId + '_' + id).show();
		}
		
		var hideByID = function(id){
			$('#' + tabId + '_' + id).hide();
		}
		init();
		
		return {
			clickByID :clickByID,
			hideByID : hideByID,
			showByID : showByID,
			selectByID : selectByID
		}
		
	};
	
/*
 * 水平Tab控件,用于显示彩云各个功能模块
 * 
 * options{
 * 
 * 			appendToId : '',//指定控件添加的dom元素id,必须
 * 			tabId : '',//整个Tab插件ID
 * 			tabs       : [{
 *                            title  : ''//元素名称
 *                            style:''   //被选中样式(可选)
 *                            btnStyle:''//按钮的样式(必填)
 *                            click : '' //点击事件
 *                       }]//tab的元素
 * }
 * 
 */
	
	window.caiyun.ui.jHTab = function(options){
		var para = {};
		var tabId = "";
		
		
		var init = function(){
			if (!options) {
				return;
			}
			para = options;
			tabId = options.tabId;
			
			//为每个tab的index属性赋值
			$.each(options.tabs,function(i,n){
				n.index = i;
			});
			creatTabs();
			addEventHandles();
		}
		
		//主体HTML
		var creatTabs = function(){
			var conHtml = new StringBuffer();
			var tab = para.tabs[para.tabs];
			conHtml.append(addTabs(para.tabs))
			$('#'+options.appendToId).append(conHtml.toString());
		};
		
		var addTab = function(tab){
			var tabHtml = new StringBuffer();
			
			tabHtml.append('<li id="')
				.append(tabId)
				.append("_")
				.append(tab.index)
				.append('"><a class ="')
				.append(tab.style)
				.append('" href="javascript:void(0);"><i class="')
				.append(tab.btnStyle)
				.append('"></i>')
				.append('<span>')
				.append(tab.title)
				.append('</span>')
				.append('</a></li>');
			
			return tabHtml.toString();
		};
		
		var addTabs = function(tabs){
			if (!tabs || tabs.length === 0) {
				return "";
			}
			var tabsHtml = new StringBuffer(), tab;
			tabsHtml.append('<ul id="')
				.append(tabId)
				.append('">');
			for (var i = 0; i < tabs.length; i++) {
				tab = tabs[i];
				tabsHtml.append(addTab(tab));
			};
			tabsHtml.append('</ul>');
			
			return tabsHtml.toString();
		};
		
		var addEventHandle = function(tab){
			if (tab.click) {
				$('#' + tabId + '_' + tab.index).unbind('click').bind('click', function(e){
					$('#' + tabId + ">li a.focus").removeClass('focus');
					$(this).find('a').addClass('focus');
					if (tab.click) {
						tab.click(e);
					}
					
				});
				$('#' + tabId).delegate('li', 'mouseover', function(){
					//            			var $a = $(this).find('a');
					//            			if(!$a.hasClass('focus')){
					//            				$a.addClass('selected');
					//            			}
				}).delegate('li', 'mouseout', function(){
					//            			$(this).find('a').removeClass('selected');
				});
			}
		};
		
		var addEventHandles = function(){
			var tabs = para.tabs;
			if (!tabs) {
				return;
			}
			for (var i = 0; i < tabs.length; i++) {
				addEventHandle(tabs[i]);
			};
		};
		
		init();
		
	}
})()
