/**
 * Tab栏
 */
;(function(){
	window.caiyun.ui.CyTab = function(params){
		var cfgs = params||{};
		var renderToDom  = $('#'+cfgs.renderTo);
		
		var init = function(){
			creatBody();
			addEventHandles();
			renderToDom.hide();
		};
		
		var creatBody = function(){
			if(!cfgs){
				return;
			}
			var items = cfgs.items;
			var $_div =$('<div class="share-thumb"></div>');
			var $_ul = $('<ul></ul>');
			for(var i = 0; i<items.length; i++){
				var $_span = $('<span></span>');
				var $_li = $('<li></li>').attr("id",items[i].id);
                $_span.text(items[i].name);
				if(i == 0){
                    $_ul.addClass('ul_1');
				}
                $_li.attr("index",i+1);
				$_li.append($_span);

				$_ul.append($_li);
			}
			$_div.append($_ul);
			renderToDom.append($_div);
		};
		
		var bindEventHandler = function(tab){
			if(tab.click){
				$('#'+tab.id).children('span').unbind('click').bind('click',function(e){
					var $_this = $(this);
					var $_li = $_this.parent('li');
                    var $_ul = $_this.parent('li').parent('ul');
                    $_ul.removeClass().addClass('ul_'+$_li.attr('index'));
					tab.click(e);
					return false;
				});
			}
		};
		
		var addEventHandles = function(){
			if (!cfgs) {
				return;
			}
			var items = cfgs.items;
			for (var i = 0; i < items.length; i++) {
				bindEventHandler(items[i]);
			};
		};
		var show = function(){
			renderToDom.show();
		};
		var hide = function(){
			renderToDom.hide();
		};
		
		var reSet = function(){
			var items = cfgs.items;
			$.each(items,function(i,data){
				if(i == 0){
					$('#'+data.id).parent('ul').removeClass().addClass('ul_1');
				}
			});
		};
		
		init();
		return {
        	cyTabShow : show,
			cyTabHide :hide,
			cyTabReSet: reSet
        };
	};
})();
