(function(){
    var searchDiv = $("#search_div");
    var keywords = $("#keyword");
    var searchTip = $("#search_text_tip");
    var searchBtn = $("#search_btn");
    var caiyun = window.caiyun;
    
    keywords.bind('keydown', {Event:caiyun.util.Event, searchBtn : searchBtn}, function(event){
        var eventUtil = event.data.eventUtil;                
        if (event.keyCode === 13) {
            eventUtil.stopEvent(event);
            searchBtn.trigger('click');
        }
    });

    $("#searchEnterBtn").bind('click', function(){
        caiyun.ui.model.fileContent.switchToView(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW);
        caiyun.operate.enterDir(caiyun.constants.rootIds.myFolder);
    });
    
    searchBtn.bind('click', function(){
        var keyword = $.trim($("#keyword").val());
        var regex = /^.*[\\\/\"\'<>\|#%\＜\＞\“\‘\＃\％\？]+.*$/
        var errMsg = "";
        var searchType = 0;
        var path = "";
        if (keyword == "" ){
            errMsg = "请输入搜索内容";
        }
        else if (regex.test(keyword)) {
            errMsg = "关键字不能包含 / \ < > | # % \" \'等字符";
        }
        
        if (errMsg != "") {
            $("#keyword").focus();
            $("#search_errMsg").find("p").html(errMsg).end().show();
            setTimeout(function(){
                    $("#search_errMsg").hide();
                }, 3000);
            return false;
        }
        else{
        	$("#search_errMsg").find("p").html(errMsg);
        }
        filterBar.toDefault();
        
        // 判断搜索范围，1：企业空间内搜索； 2：分享文件夹下搜索； 3：普通个人搜索
        if(caiyun.judgement.isEnterprisePath()) {
            searchType = 1;
            path = caiyun.judgement.getPathForEnterprise();
        }else{
        	searchType = 3;
        }
        //保持目录信息，以便企业空间内部搜索使用
        catalogStack = window.caiyun.operate.getCatalogStack();
        caiyun.ui.model.fileContent.switchToView(caiyun.constants.SEARCH_CONTENT_VIEW);
        $("#searchResultCount").html(" > ");
        $("#search_div").show();
        caiyun.operate.queryByKeyword({keyWord:keyword,searchType:searchType,path:path,catalogStack:catalogStack});
    });
    
    $().ready(function () {
        if (search_opening == 'true') {
            $("#search_div").append('<input type="text" name="search_name" id="keyword" autocomplete="off" rel="txt" value=""  maxlength="128">').show();
        }
        
        $("#keyword").bind("focus", function(){
	        if ($("#search_text_tip").is(":visible")){
	        	$("#search_text_tip").hide();
	        }     
	    }).bind("blur", function(){
	        if ($("#keyword").val() == ""){
	            $("#search_text_tip").show();
	        }
	    }).bind("keyup", function(e){
	        if (e.which == 13) {
	          $("#search_btn").click();
	        }
	    });
	    
	    $("#search_text_tip").bind("click",function(){
	    	$("#keyword").show();
	    	$("#keyword").focus();
	    });
        
        if (searchFlag == "true")
        {
            $("#keyword").focus();
        }
        var intervalProcess = setInterval(function(){$("#keyword").val("");}, 100);
        setTimeout(function(){clearInterval(intervalProcess)}, 1000);
    });
    
    // 监听视图切换事件
    caiyun.operate.onListen('fileContentSwitch',function(event){
    	var view = event.newView.name;
    	// 如果是在保险箱、分享管理、回收站下都不显示搜索框
    	if(view == caiyun.constants.SAFEBOX_CONTENT_VIEW || view == caiyun.constants.SAFEBOX_FILE_CONTENT_VIEW || view == caiyun.constants.SHARE_CONTENT_VIEW || view == caiyun.constants.RECYCLEBIN_CONTENT_VIEW){
    		 $("#search_div").hide();
    	}else{
    		 $("#search_div").show();
    	}
    });
    
    caiyun.operate.onListen('enterDir',function(event){
    	// 分享目录下
    	if( caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare) && !caiyun.judgement.isEnterprisePath()){
    		 $("#search_div").hide();
    	}else{
    		 $("#search_div").show();
    	}
    });
    
})();
