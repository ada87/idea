/**
 * 用于缩略图
 * 
 * 鼠标滑过文件(夹)时，改变样式
 */
ko.bindingHandlers.hoverClass = {
	init : function(element, valueAccessor) {
		var cssClassName = ko.utils.unwrapObservable(valueAccessor());
		$(element).hover(function() {
			$(this).addClass(cssClassName);
		}, function() {
			$(this).removeClass(cssClassName);
		});
	}
};

/**
 * 已经废除，不使用
 */
ko.bindingHandlers.jqDraggable = {
    init: function(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
    	var value = valueAccessor(), allBindings = allBindingsAccessor();
        var $element = $(element);
        var options = ko.utils.unwrapObservable(value); 
        if ($.browser.msie) {
        	/*
        	 * The draggable ui option is broken when either the "delay" or "distance" parameters
        	 * are set to great than 5 value. This is especially true when a div with an image
        	 * inside of it is being dragged. The dragging just wont happen or takes several 
        	 * tries of jamming the mouse back and forth in while clicking on the object to 
        	 * get it to recognize that it needs to be dragged. This is only happening in 
        	 * IE 6, 7, and 8. IE9, and Firefox are fine. Webkit sometimes has troubles with this        	
        	 */
        	options.distance = 5; 
        } 
        $element.draggable(options);
    }
};

/**
 * 已经废除，不使用
 */
ko.bindingHandlers.jqDroppable = {
    init: function(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
    	var value = valueAccessor(), allBindings = allBindingsAccessor();
        var $element = $(element);
        var options = ko.utils.unwrapObservable(value); 
        $element.droppable(options);
    }
};

/**
* 针对IE浏览器，缩略图新建文件夹时，弹出输入框中未选中“新建文件夹”字样的问题，添加该方法，
* 导致该问题的原因是knockout 2.2.1及2.3.0版本的hasfocus存在bug
*/
ko.bindingHandlers.focusable = {
    init: function(element, valueAccessor) {
        var value = valueAccessor();
        var $element = $(element);        
        if (value.isFocus == true) {        
            $element.focus();
            $element.val(value.folderName).select();            
        }
    }
};