/*
 *  名称：CyDropDownMenu
 *
 *  说明： 在一个父元素的内部生成一个浮起的下拉菜单， 该下拉菜单可以通过决定定位指定显示的位置
 *  用法：$(父元素).CyDropDownMenu(options);
 *
 *  方法列表：
 *  CyDropDownMenu(options)
 *  说明：生成一个下拉菜单对象
 *
 *  输入参数：
 *  options{
 *  		id    : '', 							 // 菜单ID号
 * 			items : [{ // 下拉菜单选项列表
 * 							id: 'copy', 	         //   选项的ID , 必须传，一个下拉菜单中的id不能重复
 * 							name: '复制',     		 //   选项显示名称
 * 							iconClass: '样式图标',	 //   选项显示图标 
 * 							click: function,  		 //   被点击时的回调函数
 * 							hiddenBy: function 		 //   当下拉列表显示popup时，会触发这个函数，如果这个函数返回true，则选项会被隐藏
 * 							disableBy: function 	 //    当下拉列表显示popup时，会触发这个函数，如果这个函数返回true，则选项会不可用
 * 				},
 * 				'sp'				     			 //   字符串sp，代表分隔线，如果两个分隔符连在一起只有一个分隔符会显示
 * 			]
 *  }
 *
 *  locate(position,isGloal)
 *  说明：在指定位置定位下拉菜单，定位是下拉菜单左上角的定位
 *
 *  输入参数：
 *  position{         //定位的像素
 * 			left : 100 ,
 * 			top : 100
 *  }
 *
 *  isGloal   			//布尔值，默认true，true表示相对于整个视窗的定位，false表示相对于父元素的定位（需要注意父元素的position值）
 *
 *  open()
 *  说明：打开下拉菜单
 *
 *  close()
 *  说明：关闭下拉菜单
 */
(function($) {

	var CYDROPDOWNMENU_COUNT = 0;
	
	$.fn.CyDropDownMenu = function(options) {
		var result = [];

		this.each(function() {
			var $parent = $(this);
			var id = options.id;
			var _position = {};
			CYDROPDOWNMENU_COUNT ++;
			if(!id){
				id = 'CyDropDownMenu_'+CYDROPDOWNMENU_COUNT;
			}
			$parent.append('<div id="' + id +'" style="z-index:999;" class="contextMenu clearfix"></div>');
			var $menu = $parent.find('#' + id);
			$menu.css({position:'absolute',top:'0px',left:'0px'});
			// 绝对定位之，使之从文档流中去除
			//$menu.css({position:'absolute',top:'0px',left:'0px'});
			var items = options.items;
			var itemsMap = {};
			

			$(items).each(function(index) {
				if (this == 'sp' && index < items.length - 1 && index != 0 ) {//第一项和最后一个选项是分隔符不处理
					// 不华丽的分隔符
					$menu.append('<div class="CyDropDownMenuSp"/>');
				}
				else if ( typeof (this) == 'object') {
					$menu.append('<a href="javascript:void(0);" id="' + this.id + '" class="CyDropDownMenuItem"' + '/>');
					var $item = $menu.find('#' + this.id);
					// 设置名称
					$item.append('<i class="' + this.iconClass + '"></i>' + this.name);
					itemsMap[this.id] = this;
					// 绑定鼠标悬浮事件
					$item.bind('mouseenter',function(){
						$item.addClass('itemHover');
					}).bind('mouseleave',function(){
						$item.removeClass('itemHover');
					});
					// 如果有鼠标点击处理函数，绑定点击事件
					if($.isFunction(this.click)){
						$item.bind('click',this.click);
						$item.bind('click',function(e){
							$menu.hide();
							e.preventDefault();
							return false;
						});
					}
				}
			});

			// 实现locate方法
			$menu.locate = function(position, isGloal) {
				if (!position) {
					return;
				}
				// 非全局定位使用css来控制位置
				if (isGloal == false) {
					var pos = {};
					if (position.left && typeof (position.left) == 'number') {
						pos.left = position.left;
					}
					if (position.top && typeof (position.top) == 'number') {
						pos.top = position.top;
					}
					$menu.css(pos);
					_position = pos;
				} else {// 全局使用offet来定位
					var pos = {};
					if (position.left && typeof (position.left) == 'number') {
						pos.left = position.left;
					}
					if (position.top && typeof (position.top) == 'number') {
						pos.top = position.top;
					}
					$menu.offset(pos);
					_position = pos;
				}
			};
			
			$menu.getPosition = function(){
				return _position;
			};

			// 打开下拉菜单
			$menu.open = function() {
				var $items = $menu.find('a');
				var empty = true;
				// 两个连续的分隔符只出现一个
				var sp2 =false;
				// 判断是不是所有菜单项都没有显示
				$items.each(function(index) {
					var $this = $(this);
					var id = $this.attr('id');
					var hide = false;
					// 菜单项
					if($this.hasClass('CyDropDownMenuItem')){
						var item = itemsMap[id];
						if(!item){
							return;
						}
						// 拥有隐藏判断函数并且返回需要隐藏
						if(item.hiddenBy && item.hiddenBy($this,item)){
							$this.hide();
							hide = true;
							// 这里不要设置取消连续分隔符
						}else{
							$this.show();
							sp2 = false;
							empty = false;
						}
						// 如果没有隐藏，再判断是否可用
						if(!hide){
							// 拥有不可用判断函数并且返回不可用
							if(item.disableBy && item.disableBy($this,item)){
								$this.addClass('itemDisable');
								// 清除所有绑定的事件
								$this.unbind();
								sp2 = false;
							}else{ // 需要显示的菜单项
								$this.removeClass('itemDisable');
								sp2 = false;
							}
						}
					}else{ // 分隔符
						if(sp2){
							$this.hide();
						}
						sp2 = true;
					}
				});
				// 如果菜单项一项都没有，就不显示菜单
				if(!empty){
					$menu.show();
				}
			};
			
			$menu.close = function(){
				$menu.hide();
			};

			// 获取菜单的高度
			$menu.getHeight = function(){
				return $menu.height();
			};

			// 默认菜单是不显示的
			$menu.hide();
			
			result.push($menu);
		});
		return $(result);
	};
}
)(jQuery);
