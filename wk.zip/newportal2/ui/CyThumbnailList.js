/**
 * 缩略图列表
 */
(function() {

	// 工具类
	var utils = caiyun.util;
	var ns = caiyun.ui;
	ns.CyThumbnailList = CyThumbnailList;
	ns.CyThumbnailItem = CyThumbnailItem;
	
	/**
	 * 创建缩略图列表
	 * 
	 * @param parent
	 *            {DOMElement} 要添加到DOM父元素
	 */
	function CyThumbnailList(parent) {
		// 重置变量
		this.id = ko.observable('View');
		this.visible = ko.observable(false);
		this.newFoldering = null;
		this.renamingItem = null;
		this.selectingItem = null; // 重命名时选中的单项视图
		this.selectedHandler = null;
		this.openHandler = null;
		this.contextmenuHandler = null;
		this.confirmCreateItemHandler = null;
		this.confirmRenameSelectedItemHandler = null;
		this.itemDropableHandler = null;
		this.itemDropHandler = null;
		this.parent = parent; // it is a element dom, binding current view
		this.thumbnailItems = ko.observableArray(); // model to this element dom
		this.dragItems = null; // 被拖拽的项
		this.emptyStyle = ko.observable(''); // 空文件夹显示的样式
		this.mp3PlayingItem = null;
	}
	
	/**
	 * drop事件处理函数
	 */
	CyThumbnailList.prototype.dropWinXPFiles = function(target, event){
		event.stopPropagation();
		event.preventDefault();
		var files = null;
		var originalEvent = event.originalEvent;
		if (originalEvent.dataTransfer) {
			files = originalEvent.dataTransfer.files;
		}
		if(files) {
			var targetDirID;
			if (typeof target.fileType === 'function' && target.fileType() === 'folder') {
				targetDirID = target.fileID;
			} else {
				targetDirID = window.caiyun.operate.getCurrentPathId();
			}
				
			window.caiyun.operate.dragUploadFiles(files, targetDirID);
		}
	};
	
	/**
	 * 本地文件夹中拖拽文件进来，默认的动作是显示这个文件的相关信息，
	 * 并不是真的执行drop，此时需要将document的ondragover事件的默认行为阻止
	 */
	/*CyThumbnailList.prototype.dragover = function(target, event){
		event.stopPropagation();
		event.preventDefault();
	};*/

	/**
	 * 隐藏重命名框和新建文件夹的命名框
	 * 
	 * @param selectingItem
	 *            {ThumbnailItem} 重命名时选中的一个文件（夹）
	 */
	CyThumbnailList.prototype.clearRenameAndNewFolder = function(selectingItem) {
		// 重置文件项的renaming属性
		if (this.renamingItem && this.renamingItem != selectingItem) {
			this.renamingItem.renaming(false);
			this.renamingItem = null;
		}
		if (this.newFoldering) {
			this.thumbnailItems.remove(this.newFoldering);
			this.newFoldering = null;
		}
	};

	CyThumbnailList.prototype.addThumbnailItems = function(items, isInFront) {
		var i, length;
		var thumbnailItem = null, item = null, thumbnailItemSet = [];
		for (i = 0, length = items.length; i < length; i++) {
			item = items[i];
			thumbnailItem = new CyThumbnailItem({
				fileID : item.fileID,
				fileName : item.fileName,
				keyWords : item.keyWords,
				fileType : item.fileType,
				catalogType : item.catalogType, // 判断同步目录要用到该属性
				isFixedDir : item.isFixedDir, // 判断系统固定目录要用到该属性
				imgPath : item.imgPath,
				virus : item.virus,
				share : item.share,
				linkedFile : item.linkedFile,
				isVideo : item.isVideo, // 视频文件，该值是true
				inReceviteShareDir : item.inReceviteShareDir,
				inEnterpriseDir : item.inEnterpriseDir,
				isRead: item.isRead
			}, this);
			if (isInFront) {
				thumbnailItemSet.unshift(thumbnailItem);
			} else {
				thumbnailItemSet.push(thumbnailItem);
			}
		}
		if (isInFront) {
			ko.utils.arrayPushAll(this.thumbnailItems(), thumbnailItemSet);
			this.thumbnailItems.valueHasMutated();
		} else {
			ko.utils.arrayPushAll(this.thumbnailItems(), thumbnailItemSet);
			this.thumbnailItems.valueHasMutated();
		}
	};

	/**
	 * 显示缩略图
	 */
	CyThumbnailList.prototype.show = function() {
		this.visible(true);
	};

	/**
	 * 隐藏缩略图
	 */
	CyThumbnailList.prototype.hide = function() {
		this.visible(false);
	};

	/**
	 * 在列表结尾添加列表项
	 * 
	 * @param items
	 *            {ThumbnailItem数组} 列表项
	 * 
	 * @return {Number} 当前列表项数量
	 */
	CyThumbnailList.prototype.pushItems = function(items) {
		this.addThumbnailItems(items, false);
	};

	/**
	 * 在列表开头添加列表项
	 * 
	 * @param items
	 *            {ThumbnailItem数组} 列表项
	 * 
	 * @return {Number} 当前列表项数量
	 */
	CyThumbnailList.prototype.unshiftItems = function(items) {
		this.addThumbnailItems(items, true);
	};

	/**
	 * 更新列表中的item
	 * 
	 * @param item
	 *            {Item} 列表项
	 * 
	 * @return {Boolean} 是否更新成功
	 */
	CyThumbnailList.prototype.updateItem = function(item) {
		var i, length, thumbnailItem = null;
		for (i = 0, length = this.thumbnailItems().length; i < length; i++) {
			thumbnailItem = this.thumbnailItems()[i];
			if (thumbnailItem.fileID === item.fileID) {
				this.thumbnailItems.splice(i, 1, item);
				break;
			}
		}
	};

	/**
	 * 清空列表
	 */
	CyThumbnailList.prototype.clear = function() {
		this.thumbnailItems([]);
	};

	/**
	 * 空列表时的显示的HTML
	 * 
	 * @param html
	 *            {String} 要显示的HTML
	 */
	CyThumbnailList.prototype.setEmptyStyle = function(html) {
		this.emptyStyle(html);
	};

	/**
	 * 全选
	 */
	CyThumbnailList.prototype.selectAll = function() {
		var i, length;
		for (i = 0, length = this.thumbnailItems().length; i < length; i++) {
			this.thumbnailItems()[i].selected(true);
		}
		this.selectedHandler(this.getSelectedItems());
	};

	/**
	 * 全部不选
	 */
	CyThumbnailList.prototype.unSelectAll = function() {
		var i, length;
		for (i = 0, length = this.thumbnailItems().length; i < length; i++) {
			this.thumbnailItems()[i].selected(false);
		}
		this.selectedHandler(this.getSelectedItems());
	};

	/**
	 * 获取当前选中的文件项
	 * 
	 * @return {ThumbnailItem数组} 当前被选中的列表数
	 */
	CyThumbnailList.prototype.getSelectedItems = function() {
		var thumbnailSelectedItems = [], thumbnailItem = null;
		var i, length;
		for (i = 0, length = this.thumbnailItems().length; i < length; i++) {
			thumbnailItem = this.thumbnailItems()[i];
			if (thumbnailItem.selected() === true) {
				thumbnailSelectedItems.push(thumbnailItem);
			}
		}
		return thumbnailSelectedItems;
	};

	/**
	 * 选择的文件项变化处理函数，在当前选中的文件发生变化时触发 选择事件和其他事件同时触发时，先调用选择事件再调用其他事件
	 * 
	 * 回调时传入选中的文件项数组，没有文件选中时传入null function handler (items){};
	 * 
	 * @params handler {Function} 文件项变化函数
	 */
	CyThumbnailList.prototype.setSelectedHandler = function(handler) {
		this.selectedHandler = handler;
	};

	/**
	 * 打开文件项时，触发的事件
	 * 
	 * 回调参数如下，item 打开的文件项 function handler(item){};
	 * 
	 * @params handler {Function} 回调函数
	 */
	CyThumbnailList.prototype.setOpenHandler = function(handler) {
		this.openHandler = handler;
	};

	/**
	 * 右键点击文件项时，触发的事件
	 * 
	 * 回调参数如下，items 被右键点击的元素（右键可以多选），event 右键事件用于获取鼠标位置作为定位 function
	 * handler(items,event){};
	 * 
	 * @params handler {Function} 回调函数
	 */
	CyThumbnailList.prototype.setContextmenuHandler = function(handler) {
		this.contextmenuHandler = handler;
	};

	/**
	 * 显示创建文件项
	 * 
	 * @param item
	 *            {Object} 要创建的文件项参数
	 */
	CyThumbnailList.prototype.createItem = function(item) {
		var self = this;
		if (this.newFoldering) {
			return;
		}
		this.clearRenameAndNewFolder();
		var folder = new CyThumbnailItem({
			fileType : 'newFolder',
			imgPath : '../images/newportal2/m_picture.gif'
		}, this);
		folder.folderName = ko.observable('新建文件夹');
		folder.editing = true;
		folder.renaming(true);
		folder.confirmCallback = function(target, event) {
			var remove = false;
			if (self.confirmCreateItemHandler) {
				remove = self.confirmCreateItemHandler(target.folderName());
			}
			if (remove) {
				self.thumbnailItems.remove(target);
			}
			self.folder = null;
			self.newFoldering = null;
			event.stopPropagation();
		};
		folder.cancelCallback = function(target, event) {
			self.thumbnailItems.remove(target);
			self.folder = null;
			self.newFoldering = null;
			event.stopPropagation();
		};
		this.thumbnailItems.unshift(folder);
		this.newFoldering = folder;
		return folder;
	};

	/**
	 * 确认创建文件项的回调函数
	 * 
	 * function handler(params){ return true ; //
	 * 返回true表示去除创建文件项，返回false表示不去除创建文件项 };
	 * 
	 * @param handler
	 *            {Function} 回调函数
	 */
	CyThumbnailList.prototype.setConfirmCreateItemHandler = function(handler) {
		this.confirmCreateItemHandler = handler;
	};

	/**
	 * 对选中的文件项进行重命名
	 */
	CyThumbnailList.prototype.renameSelectedItem = function() {
		var selectedItems = this.getSelectedItems();
		if (selectedItems.length > 0) {
			this.selectingItem = selectedItems[0];
		} else {
			return;
		}
		this.clearRenameAndNewFolder(this.selectingItem);	
		var fileOldName = this.selectingItem.fileName();
		var fileName = utils.removeSuffix(fileOldName);
		this.selectingItem.editName(fileName);
		this.selectingItem.fileOldName = fileOldName;
		this.selectingItem.selected(true);
		this.selectingItem.renaming(true);
		this.renamingItem = this.selectingItem;
		this.selectingItem = null; // selected属性设置为false值后，要重置该值
	};

	/**
	 * 确认重命名的回调函数
	 * 
	 * function handler(params){ return true ; //
	 * 返回true表示结束重命名，返回false表示不结束重命名，让用户继续输入 };
	 */
	CyThumbnailList.prototype.setConfirmRenameSelectedItemHandler = function(
			handler) {
		this.confirmRenameSelectedItemHandler = handler;
	};

	/**
	 * 设置判断列表项是否可以放置拖拽文件项
	 * 
	 * @param handler
	 *            回调函数 
	 * dragItems {CyThumbnailItem Array}被拖拽的文件项 dropItem {CyThumbnailItem} 要放置到的文件项            
	 * function handler(dragItems, dropItem){ return true ; //
	 * 返回true表示可以放置，false表示不可以放置，不可以放置的列表项不触发放置效果 };
	 */
	CyThumbnailList.prototype.setItemDropableHandler = function(handler) {
		this.itemDropableHandler = handler;
	};

	/**
	 * 设置拖拽项被放置到放置项时触发事件的回调函数
	 * 
	 * @param handler
	 *            回调函数
	 * 
	 * dragItems {CyThumbnailItem Array}被拖拽的文件项 
	 * dropItem {CyThumbnailItem}要放置到的文件项 
	 * outsideDrag {Boolean} true 从本地文件系统拖拽文件上传 false 在浏览器里拖拽移动文件（夹）
	 * function handler(dragItems, dropItem){ };
	 */
	CyThumbnailList.prototype.setItemDropHandler = function(handler) {
		this.itemDropHandler = handler;
	};

	/**
	 * 彩云缩略图单个文件(夹)项
	 * 
	 * @param data
	 *            创建文件项所需要的初始数据 {fileID : 文件或文件夹ID,imgPath : 图片地址,fileName :
	 *            文件名,fileType : 文件类型('file'|'folder'),size : 文件大小字符串 xxMB ,
	 *            date : 显示时间字符串 , virus : 是否有毒 true 有毒 false 没毒, share : 是否共享
	 *            true 已共享 false 未共享, keyWords: 在搜索视图中搜索的关键字(其他视图可以不需要) }
	 * @param parent
	 *            {CyThumbnailList} 被添加到的缩略图列表
	 */
	function CyThumbnailItem(data, parent) {
		var self = this;
		this.fileID = data.fileID;
		this.imgPath = ko.observable(data.imgPath);
		this.backgroundImgPath = ko.computed(function(){
			return "url(" + data.imgPath + ")";
		});		
		this.fileName = ko.observable(data.fileName);
		this.fileType = ko.observable(data.fileType || 'file'); // 创建新文件夹的样式
		this.catalogType = data.catalogType;
		this.virus = ko.observable(data.virus);
		this.share = ko.observable(data.share);
		this.linkedFile = ko.observable(data.linkedFile);
		this.isFixedDir = data.isFixedDir;
		this.canMove = window.caiyun.operate.canExecute('move', this.fileID); // "收到的分享"目录里不支持拖拽操移动作
		this.isVideo = data.isVideo;
		this.isNew = ko.observable(data.isRead); // "收到的分享"目录有新分享文件时，显示icon
		this.selected = ko.observable(false); // 用于控制选中文件（夹）时的样式
		this.renaming = ko.observable(false);
		this.editName = ko.observable('');
		this.playMusic = ko.observable('');
		this.pictureLoaded = ko.observable(false);
		this.fileOldName = null;
		this.inReceviteShareDir = data.inReceviteShareDir;
		this.inEnterpriseDir = data.inEnterpriseDir;
		this.visibleShareIcon = ko.computed(function(){
			return this.share() && !this.inReceviteShareDir;
		}, this);
		this.visibleLinkedFileIcon = ko.computed(function(){
			return this.linkedFile() && (!this.inReceviteShareDir || this.inEnterpriseDir); 
		}, this);
		this.showNameLength = ko.observable(10);
		this.showImg = ko.computed(function(){
			return !this.renaming()&&this.pictureLoaded();
		}, this);
		this.keyWords = data.keyWords;

		this.showFileName = ko.computed(function() {
			var name = self.fileName();
			var keyWords = data.keyWords;
			if (!name) {
				return '';
			}
			var showNameLength = 10;
			if (name.strLen() <= showNameLength + 2) {
				return keyWords ? utils.strBound(name, keyWords) : name;
			} else {
				return keyWords ? utils.strBound(name.subCHStr(0, showNameLength - 4), keyWords) + "..." + 
						utils.strBound(name.subCHStr(name.strLen() - 4), keyWords) : 
							name.subCHStr(0, showNameLength - 4) + "..." + name.subCHStr(name.strLen() - 4);
			}
		}, this);

		// 图片加载完后的操作
		this.pictureLoad = function(target,event) {
			// 加载完后替换src为s.gif(小白点)，才能显示background；不能用空字符串替换'../images/newportal2/s.gif'，否侧显示空白
			var $target = $(event.target);
			if($target.attr('src') !== '../images/newportal2/s.gif'){
				$target.attr('src','../images/newportal2/s.gif');
				self.pictureLoaded(true);
			}
		};

		// 左键单击文件(夹)名事件处理
		this.clickName = function(target, event) {
			event.stopPropagation();
			if ($.isFunction(parent.openHandler)) {
				parent.openHandler(target);
			}
		};

		// 左键单击事件处理
		this.click = function(target, event) {
			event.stopPropagation();			
			if (target.fileType() == 'newFolder' || target.renaming()) {
				return;
			}
			parent.clearRenameAndNewFolder(target);
			if ($.isFunction(parent.openHandler)) {
				parent.openHandler(target);
			}
		};
		
		// 左键单击非图片区域的事件处理
		this.clickImgOutside = function(target, event){
			self.clickCheckBox(target, event);
		};

		// 处理右键点击
		this.rightClick = function(target, event) {
			event.stopPropagation();
			parent.clearRenameAndNewFolder(target);
			var selectedFiles = null;
			// 忽略新建文件夹类型的点击
			if (target.fileType() == 'newFolder' || target.renaming()) {
				return;
			}
			// 对象未被选中之
			if (!target.selected()) {
				// 取消全部选择
				parent.unSelectAll();
				target.selected(true);
				// 回调处理函数
				parent.selectedHandler([target]);
				parent.contextmenuHandler(target, event);
			} else {
				selectedFiles = parent.getSelectedItems();
				// 回调处理函数
				parent.contextmenuHandler(selectedFiles, event);
			}
		};
		
		// 处理双击checkbox的事件
		this.dbclickCheckBox = function(target, event){
			event.stopPropagation();
			return false;
		};
		
		// 处理单击checkbox是事件
		this.clickCheckBox = function(target, event){
			event.stopPropagation();
			// 忽略新建文件夹类型的点击
			if (target.fileType() == 'newFolder' || target.renaming()) {
				return;
			}
			parent.clearRenameAndNewFolder(target);
			var files = parent.thumbnailItems();
			// 如果ctrl被按下的话增加被选中的文件
			if (event.ctrlKey) {
				target.selected(!target.selected());
			}
			// 如果shift被按下的话，选中第一个被选中的文件一直到最后一个被选中的文件
			else if (event.shiftKey) {
				// 如果已经有文件被选中，则选中之前被选中的文件一直到当前被点击的文件
				var startIndex = -1;
				for ( var i = 0, length = files.length; i < length; i++) {
					if (files[i].selected()) {
						startIndex = i;
						break;
					}
				}
				if (startIndex >= 0) {
					var endIndex = parent.thumbnailItems.indexOf(self);
					parent.unSelectAll(true);
					if (endIndex > startIndex) {
						for ( var i = startIndex; i <= endIndex; i++) {
							files[i].selected(true);
						}
					} else {
						for ( var i = startIndex; i >= endIndex; i--) {
							files[i].selected(true);
						}
					}
				} else {
					self.selected(true);
				}
			}
			// 如果什么都没有按下则只选中当前点击的文件
			else {
				self.selected(!self.selected());
			}
			// 回调单击处理函数.
			if ($.isFunction(parent.selectedHandler)) {
				var selectedFiles = parent.getSelectedItems();
				parent.selectedHandler(selectedFiles);
			}
			return false;
		},
		
		// 处理双击重命名输入框的事件
		this.dbclickInput = function(target, event){
			event.stopPropagation();
			return false;
		};

		// 重命名确认回调
		this.confirmRenameCallback = function(target, event) {
			var close = false;
			if (parent.confirmRenameSelectedItemHandler) {
				close = parent.confirmRenameSelectedItemHandler(target);
				self.renaming(!close);
				// 清空正在重命名的子元素
				if (close) {
					parent.renamingItem = null;
				}
			} else {
				self.renaming(false);
				parent.renamingItem = null;
			}
			event.stopPropagation();
		};

		// 重命名取消回调
		this.cancelRenameCallback = function(target, event) {
			target.renaming(false);
			target.fileName(target.fileOldName);
			parent.renamingItem = null;
			event.stopPropagation();
		};
		
		/**
		 * 拖拽事件的处理函数，展示拖拽过程的效果
		 * 
		 * @param event {HTML Event事件} 拖拽事件
		 */
		this.getHelper = function(event){			
			parent.dragItems = parent.getSelectedItems();
			var dragFilesNum = parent.getSelectedItems().length;
			var lastSelectedItem = null;
			var imgUrl = '';
			if (dragFilesNum === 0 || self.selected() === false) {
				parent.dragItems = [self];
				dragFilesNum = 1;
				self.pictureLoaded() ? imgUrl = self.backgroundImgPath() : imgUrl = 'url(../images/newportal2/config_img.gif)';
			} else {
				lastSelectedItem = parent.getSelectedItems()[dragFilesNum - 1];
				lastSelectedItem.pictureLoaded() ? 
						imgUrl = lastSelectedItem.backgroundImgPath() : 
							imgUrl = 'url(../images/newportal2/config_img.gif)';
			}
			var innerHtml = '<div class="dom_num">' + dragFilesNum + '</div>';
            var divDom = $('<div class="maxDrag" style="z-index: 99999;background:#d8cce8 ' + 
            				imgUrl +' no-repeat scroll 50% 50%;opacity: 1;margin: 0;padding: 0;"></div>').append(innerHtml);
            
			return divDom;
		};
		
		/**
		 * 拖拽页面的文件（夹）图标放置到放置项时触发drop事件的处理函数
		 * event {Event} drop事件
		 * ui {Object} {draggable: {
		 * Type: jQuery
		 * A jQuery object representing the draggable element.};
		 * helper: {
		 * Type: jQuery
		 * A jQuery object representing the helper that is being dragged.};
		 * position: {
		 * Type: Object
		 * Current CSS position of the draggable helper as { top, left } object.};
		 * offset: {
		 * Type: Object
		 * Current offset position of the draggable helper as { top, left } object.};
		 * }
		 */
		this.dropMcloudFiles = function(event, ui){
			event.stopPropagation();
			// 判断是否在页面的头部位置
			if (event.clientY < 215) {			
				return;
			}
			var dragItems = parent.dragItems;
			var dropable = parent.itemDropableHandler(dragItems, self);		
			if (dropable) {
				ui.helper.remove();
				//ui.draggable.remove();
				parent.itemDropHandler(dragItems, self);				
			}
		};
		
		/**
		 * 拖拽本地文件（夹）图标放置到放置项时触发drop事件的处理函数
		 */
		this.dropWinXPFiles = function(target, event){
			parent.dropWinXPFiles(target, event);
		};
		
		/**
		 * 显示病毒文件提示语
		 * target CyThumbnailItem 当前CyThumbnailItem对象
		 * event Event对象 鼠标移动事件
		 */
		this.handlerMouseMove = function(target, event) {
			event.stopPropagation();
			var type = event.type;
			var $virusTips = $('#thumbnail_virus_tips');
			var $virusTipsCSS = $('#thumbnail_virus_tipsCSS');
			if (type === 'mousemove') {
				$virusTips.css({
	                top: event.pageY - 26,
	                left: event.pageX - 204
	            });
				$virusTipsCSS.show();
			} else if (type === 'mouseout') {
				$virusTipsCSS.hide();
			}
		};
		
		/**
		 * 单击病毒文件提示icon的事件处理函数
		 * target CyThumbnailItem 当前CyThumbnailItem对象
		 * event Event对象 鼠标单击事件
		 */
		this.handlerClickVirusIcon = function(target, event){
			event.stopPropagation();
			return false;
		};
	}

})();