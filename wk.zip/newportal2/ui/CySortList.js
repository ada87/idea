/**
 * 排序下拉菜单操作js
 * 
 */
var CySortList = {

	// 初始化
	init : function() {
		//var handler = window.caiyun.operate;

		var menu = $('#fm_paixun').CySortDropMenu( {
			id : 'CySortDropMenu',
			items : [ {
				id : 'time_asc',
				name : '时间从新到旧',
				click : function(event) {
					menu.close();
					$("#c_time").show();
					$("#c_time").removeClass();
					$("#c_size").hide();
					$("#c_time").addClass("min_icon m_time_up");
					//handler.sortHandler({'sortField':0,'sortType':0});
				return false;
			}
			}, {
				id : 'time_desc',
				name : '时间从旧到新',
				click : function(event) {
					//handler.sortHandler({'sortField':0,'sortType':1});
				menu.close();
				$("#c_time").show();
				$("#c_time").removeClass();
				$("#c_size").hide();
				$("#c_time").addClass("min_icon m_time_down");
				return false;
			}
			}, {
				id : 'size_asc',
				name : '文件从小到大',
				click : function(event) {
					//handler.sortHandler({'sortField':3,'sortType':0});
				menu.close();
				$("#c_size").show();
				$("#c_time").hide();
				$("#c_size").removeClass();
				$("#c_size").addClass("min_icon m_time_up");
				return false;
			}
			}, {
				id : 'size_desc',
				name : '文件从大到小',
				click : function(event) {
					//handler.sortHandler({'sortField':3,'sortType':1});
				menu.close();
				$("#c_size").show();
				$("#c_time").hide();
				$("#c_size").removeClass();
				$("#c_size").addClass("min_icon m_time_down");
				return false;
			}
			}, {
				id : 'file_type',
				name : '按文件类型',
				click : function(event) {
					//handler.sortHandler({'sortField':2,'sortType':0});
				menu.close();
				$("#c_size").hide();
				$("#c_time").hide();
				return false;
			}
			}, {
				id : 'file_name',
				name : '按文件名称',
				click : function(event) {
					//handler.sortHandler({'sortField':1,'sortType':0});
				menu.close();
				$("#c_size").hide();
				$("#c_time").hide();
				return false;
			}
			} ]
		})[0];

		$('#fm_paixun').unbind().bind('click', function() {
			menu.open();
		});

		$("#fm_paixun").mouseleave(function() {
			menu.close();
		});

	}
};

$(function() {
	CySortList.init();
});