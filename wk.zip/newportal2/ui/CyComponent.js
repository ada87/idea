/*
 * maskDiv ：屏遮层的控制方法，控制屏遮层的显示，管理和开关
 *     |- html ： 屏遮层的html代码。
 *     |- hasMask ：屏遮层的开关，控制只允许页面上出现一个屏遮层。
 *     |- show ：屏遮层的显示方法，可以传入一个值str，在屏遮层上显示loading。
 *     |- close ：屏遮层的关闭方法。
 *
 * layerIndex ：窗体层级管理，用于管理多窗体共存时的层级调度
 *     |- Idx ： 当前文档的所有窗体z-index值的数组，用于管理窗体的层级关系
 *     |- layerStor ：当前所有窗体ID的数组，用于管理存在于页面中的窗体
 *     |- getIdx ：获取窗体z-index值，每调用一次就递增一次，理论上来说无限往上增加
 *
 */

(function(){

	var util = window.caiyun.util;
	var UI = window.caiyun.ui;
    window.caiyun.layershow = false;

	//获取页面参数
    util.iGet = {
        //获取页面滚动位置,返回object,水平位移:X和垂直位移:Y
        PageScroll : function(){
           var x,y;
           if(window.pageYOffset){
               y = window.pageYOffset;
               x = window.pageXOffset;
           }else if(document.documentElement && document.documentElement.scrollTop){
               y = document.documentElement.scrollTop;
               x = document.documentElement.scrollLeft;
           }else if(document.body){
               y = document.body.scrollTop;
               x = document.body.scrollLeft;
           }
           return {X:x,Y:y};
        },
        //获取页面尺寸，返回objectpageW(页面宽度)和pageH(页面高度)winW(窗口宽度)和winH(窗口高度)
        PageSize : function(){
            var scrW,scrH;
            if(window.innerHeight && window.scrollMaxY){
               scrW = window.innerWidth + window.scrollMaxX;
               scrH = window.innerHeight + window.scrollMaxY;
            }else if(document.body.scrollHeight>document.body.offsetHeight){
               scrW = document.body.scrollWidth;
               scrH = document.body.scrollHeight;
            }else if(document.body){
               scrW = document.body.offsetWidth;
               scrH = document.body.offsetHeight;
            }
            var winW,winH;
            if(window.innerHeight){
               winW = window.innerWidth;
               winH = window.innerHeight;
            }else if(document.documentElement&&document.documentElement.clientHeight){
               winW = document.documentElement.clientWidth;
               winH = document.documentElement.clientHeight;
            }else if(document.body){
               winW = document.body.clientWidth;
               winH = document.body.clientHeight;
            }
            //定义并获取有效高度，有效高度的规则为，滚动高度和window高度，谁大就取谁
            var pageW = (scrW < winW) ? winW : scrW;
            //定义并获取有效宽度，有效宽度的规则为，滚动宽度和window宽度，谁大就宽度
            var pageH = (scrH < winH) ? winH : scrH;
            //返回一个对象，存储了页面高度及宽度，window高度及宽度，
            return {PageW:pageW,PageH:pageH,WinW:winW,WinH:winH};
        }
    };

	    //屏蔽层对象
    util.maskDiv = {
        browser : (window.XMLHttpRequest === undefined),//判断浏览器是否为ie6，在ie6下要手动隐藏select和flash
        hasMask : true,//标识是否存在屏蔽层

        /**
         * 显示屏蔽层
         * @param id 当前显示窗体的id,可为空
         */
        show : function(id){
            if(id){
                //判断屏蔽层是否存在
                if($('#overlay').length > 0){
                    //判断显示的窗体是否已经存在于层数组util.layerIndex.layerStor
                    if($.inArray(id,util.layerIndex.layerStor) != -1){
                        //获取显示窗体的z-index属性值
                        var z_index = $('#' + id).css('z-index');
                        //设置屏蔽层的z-index属性值为当前显示窗体的z-index值小1
                        $('#overlay').css('z-index',parseInt(z_index,10) - 1);
                    }
                    $('#overlay').show();
                }else{
                    util.maskDiv.hasMask = true;
                    util.maskDiv.set();
					$(window).bind('resize',util.maskDiv.resizeOverlayToWindow).bind('scroll',util.maskDiv.scroll);
					var $uploadBox = $(".download");
					if($uploadBox.is(':visible')){
						var z_index = $uploadBox.css('z-index');
                    	$('#overlay').css('z-index',parseInt(z_index,10));
						$('#'+id).css('z-index',parseInt(z_index,10) + 1);
					}
                    $('#overlay').show();
                }
                caiyun.layershow = true;
            }else{
                if(util.maskDiv.hasMask){
                    return;
                }else{
                    util.maskDiv.hasMask=true;
                    util.maskDiv.set();
					$(window).bind('resize',util.maskDiv.resizeOverlayToWindow).bind('scroll',util.maskDiv.scroll);
                    $('#overlay').show();
                    caiyun.layershow = true;
                }
            }
        },

        /**
         * 隐藏屏蔽层
         * @param id 当前显示窗体的id,可为空
         */
        hide : function(id){
            if(id){
				var z_index;
                //判断上传窗体是否存在
                //注:上传窗体比较特殊,将它关闭,其实并没有把它销毁,而是将它隐藏
                //这将导致,显示其他窗体时,屏蔽层会显示出现问题,所以需要特殊处理一下
                var $uploadBox = $(".download");
				var $myLightBox = $('.myLightbox');
				var $myVideoBox = $('.myVideobox')
                if ($uploadBox.length > 0) {

					var isUploadBoxVisible = false;
					if ($uploadBox.is(':visible')) {
						isUploadBoxVisible = true;
					}
					//判断上传窗体是否显示
					if (isUploadBoxVisible) {
						$('#overlay').css('z-index', parseInt($uploadBox.css('z-index'), 10) + 1);
					}
					//判断是否还存在其他的窗体
					if (util.layerIndex.layerStor.length > 0) {
						//如果存在,则需要获取最近弹出的窗体z-index值.
						z_index = $('#' + util.layerIndex.layerStor[util.layerIndex.layerStor.length - 1]).css('z-index');
						//将屏蔽层的z-index值设置为最近弹出的窗体z-index值减一
						$('#overlay').css('z-index', parseInt(z_index, 10) - 1);
						if ($myLightBox.length > 0) {
							$('#overlay').css('z-index', parseInt($myLightBox.css('z-index'), 10) - 1);
						}
						if (($myVideoBox.length > 0) && !($myLightBox.length)) {
							$('#overlay').remove();
						}
					}
					else {
						if ($myLightBox.length > 0) {
							$('#overlay').css('z-index', parseInt($myLightBox.css('z-index'), 10) - 1);
						}else{
							$('#overlay').remove();
                            caiyun.layershow = false;
						}
					}
				}
				else
				{
                    if (util.layerIndex.layerStor.length > 0) {
                        //如果存在,则需要获取最近弹出的窗体z-index值.
                        z_index = $('#' + util.layerIndex.layerStor[util.layerIndex.layerStor.length - 1]).css('z-index');
                        //将屏蔽层的z-index值设置为最近弹出的窗体z-index值减一
                        $('#overlay').css('z-index', parseInt(z_index, 10) - 1);
                    }else{
                        $('#overlay').remove();
                        caiyun.layershow = false;
                    }
				}
            }else{
                $('#overlay').remove();
                $('span.overlay_window').remove();
                util.maskDiv.hasMask = false;
                caiyun.layershow = false;
            }
        },
        close : function(){
			$('#overlay').remove();
		},
        //设置遮罩层
        set : function(){
            var $div = $("<div id='overlay' class='overlay'></div>");
            $('#overlay').get(0)||$('body').append($div);
            var $window = $(window);
            var $document = $(document);
            var w, l;
            if ($document.scrollLeft() === 0){
                w = $window.width();
                l = w;
            }else{
                w = $document.width();
                l = $window.width() + $document.scrollLeft() * 2;
            }
            var h, t;
            if ($document.scrollTop() === 0){
                h = $window.height();
                t = h;
            }else{
                h = $document.height();
                t = $window.height() + $document.scrollTop() * 2;
            }
            util.maskDiv.position(null, h, t, l);
        },

		resizeOverlayToWindow : function(){
			$('#overlay').css({width: $(document).width(), height: $(document).height()});
		},

        /**
         * scroll事件的处理函数
         */
        scroll : function(){
            var $window = $(window);
            var $document = $(document);
            var w = $window.width() + $document.scrollLeft();
            var h = $window.height() + $document.scrollTop();
            var l = w - $document.scrollLeft();
            var t = h + $document.scrollTop();
            util.maskDiv.position(w, h, t, l);
        },

        /**
         * 设置屏蔽层的坐标
         */
        position : function(w, h, t, l){
            if (!w){
                if(util.maskDiv.browser){
                  $('#overlay').css({width:$(window).width()+"px", height: h + "px"});
                }
                else{
	              $('#overlay').css({width:"100%", height: h + "px"});
                }
            }
            else{
                $('#overlay').css({width: w+"px", height: h + "px"});
            }
            var temp = $('.overlay_window');
            t = (t - temp.height())/2;
            l = (l - temp.width())/2;
            temp.css({top: t + "px", left: l + "px"});
        }
    };

	//窗体层级管理对象
    util.layerIndex = {
        //定义窗体z-index值的数组，用于管理窗体的层级关系
        Idx : [900],
        //定义窗体ID的数组，用于管理存在于页面中的窗体
        layerStor : [],

        /**
         *判断是否存在指定id窗体
         *@param {string} L_id 窗体id
         *L_id为空时,则判断是否存在窗体
         *L_id不为空,则判断是否存在于数组中,若不存在,则将它存入数组
         */
        hasLayer : function(L_id){
            if (!L_id) {
                if (util.layerIndex.layerStor.length === 0) {
                   return false;
                }
                else {
                    return true;
                }
            }
            else if($.inArray(L_id,util.layerIndex.layerStor) != -1){
                  return true;
            }
            else {
                  util.layerIndex.layerStor.push(L_id);
            }
        },

        /**
         *获取窗体的z-index值,每调用一次,z-index递增
         */
        getIdx : function(){
            var zId = this.Idx[this.Idx.length-1];
            zId = parseInt(zId,10) + 1;
            this.Idx.push(zId);
            return zId;
        },
        //add by chenpeng
        //用于支持多层遮罩,隐藏最后一层之后进行窗体id的回收
        deleteLayer : function(L_id){
        	if (!L_id) {
        		return true;
            }else if($.inArray(L_id,util.layerIndex.layerStor) != -1){
        		var i = $.inArray(L_id,util.layerIndex.layerStor);
           		//在数组wda.layerIndex.layerStor中删除ID名为b的元素。这里用于回收数组存储空间。
          		util.layerIndex.layerStor.splice(i,1);
        	}
        }
    };

    //弹出窗体基础BOX
    UI.msgBox = function(para){

        var $html  = '';
        var msgBoxTop = null;//窗体的纵坐标
        var msgBoxLeft = null;//窗体的横坐标
        var p = {};

        var init = function(){
			p = {
				id:'msgBox_',
				type:"",              //判断弹出框类型,默认弹出框类型"",如果是上传窗体传值:uploadBox,历史版本管理:history,分享窗体:fileshare,分享外链窗体sharelink,添加企业成员adduser
				title : "系统消息",
				width :704,
				leftBtn : false,     //左下角是否有按钮
				middleBtn : false,   //底部按钮是否居中
				masked : true,       //默认显示遮罩层
				minBtn : false,      //是否有最小化按钮,默认无
				closeBtn : true,     //是否有关闭按钮,默认有
				html :"",
                iconType:"normal",   //弹出框左上角图标类型支持{normal(无图标),copy,move,ZiPdownload,history}
				appendTo:"body",     //默认添加窗体到body
				leftBtnName : "新建文件夹",
				btnName :["确定","取消"],
				okOnly : false,       //如果只显示确定按钮,配合当btnName.length==1时来使用
				cancelOnly : false,   //如果只显示取消按钮,配合当btnName.length==1时使用
                hasBottomHtml : false,//弹出框是否存在底部html
				okHandle: function(){},
				cancelHandle: function(){destroy();},
				closeBox:function(){destroy();},   //关闭回调方法,默认执行销毁操作
				miniMize:function(){minimize();},   //最小化回调方法,默认执行最小化操作
                clearUploadListHandle:function(){}, //清除上传列表事件回调
				creatHandle:function(){},           //新建文件夹事件回调
				historyClear:function(){},          //文件历史管理清除版本回调
				historyDown:function(){},           //文件历史管理下载回调
				historyRecover:function(){},        //文件历史管理恢复按钮回调
                uploadListClear:function(){}        //清空上传任务列表按钮回调
		    };
			$.extend(p,para);//用传入参数覆盖默认值
			//判断参数里面是否已经有zIdx，如果没有，就重新获取下
            if (!para.hasOwnProperty("zIdx")) {
            	p.zIdx = util.layerIndex.getIdx();
                //判断参数里是否有传入id值，如果没有，就给p.id添加个zIdx作为区别
                if (!para.hasOwnProperty("id")) {
                	p.id += p.zIdx;
              }
            }
		    $html = getHtml();//存储主窗体对象
        };

        var getHtml = function(){
			//主窗体
			var $_Box = $('<div class="popBox" style="position:absolute;overflow:hidden;"></div>').css('width',p.width).attr('id',p.id);
			//内容框
			//var $_content = $(p.html);
            var $_content = $('<div class="popContent"></div>').append(p.html);
			//标题框
			var $_headDiv01 = $('<div class="floatleft t_01"></div>');
            if(p.iconType != "normal")
            {
                $_headDiv01.append('<i class="'+switchIconClass(p.iconType)+'"></i>');
            }
            $_headDiv01.append('<span>'+ p.title+'</span>');
			var $_headDiv02 = $('<div class="floatright t_02"></div>');
            var $_headDivSpan01 = $('<span class="minBtn"></span>').attr('id',p.id+'_minimize');
            var $_headDivSpan02 = $('<span class="cloBtn"></span>').attr('id',p.id+'_close');
            if(p.minBtn)
            {
                $_headDiv02.append($_headDivSpan01);
            }
            if(p.closeBtn)
            {
                $_headDiv02.append($_headDivSpan02);
            }
			var $_headHtml = $('<div class="popTitle"></div>');
            //底部
            var $_BottomHtml = $('<div class="popBottom"></div>');
            var $_BottomLeft = $('<div class="BtnLeft"></div>');
            var $_BottomRightOrCenter = $('<div class="BtnRight"></div>');
            if (p.middleBtn) {
            	$_BottomRightOrCenter = $('<div class="BtnCenter"></div>');
            }
            var $_newFolderSpan = $('<span class="creatnewBtn"><i class="i-new"></i><span>'+ p.leftBtnName+'</span></span>').attr('id',p.id+'_newFolder');
            var $_addUserSpan = $('<span class="creatnewBtn"><i class="i-add"></i><span>'+ p.leftBtnName+'</span></span>').attr('id',p.id+'_newFolder');
            if(p.okOnly)
            {
                var $_bottomBtnOk = $('<span class="okBtn"></span>').attr('id',p.id+'_ok').text(p.btnName[0]);
            }else if(p.cancelOnly)
            {
                var $_bottomBtnCancel = $('<span class="cancelBtn"></span>').attr('id',p.id+'_cancel').text(p.btnName[0]);
            }else
            {
                var $_bottomBtnOk = $('<span class="okBtn"></span>').attr('id',p.id+'_ok').text(p.btnName[0]);
                var $_bottomBtnCancel = $('<span class="cancelBtn"></span>').attr('id',p.id+'_cancel').text(p.btnName[1]);
            }
			if(p.type=="uploadBox")
			{
                var $_clearBottom  = $('<span class="passBtn_ie" title="清除已完成的任务记录"></span>').attr('id',p.id + '_clear').text('清空已上传记录');
                var $_uploadBody = $(p.html);
				//头部
                $_headHtml.append($_headDiv01).append($_headDiv02);

                //底部
                $_BottomRightOrCenter.append($_clearBottom);
                $_BottomHtml.append($_BottomRightOrCenter);
				//组合
				$_Box.append($_headHtml).append($_uploadBody).append($_BottomHtml).addClass('download');
			}
//			if(p.type=='safeBox')
//			{
//				//头部
//				$_headHtml.append($_headDiv01).append($_headDiv02);
//				//底部
//				$_BottomHtml.append($_bottomBtnOk).append($_bottomBtnCancel).addClass('pop_footer2');
//				//组合
//				$_Box.append($_headHtml).append($_content).append($_BottomHtml);
//			}
			if(p.type=="history")
			{
				//历史记录
				var $_clearBottom  = $('<span class="passBtn"></span>').attr('id',p.id + '_clear').text('清除版本信息');
				var $_downBottom  = $('<span class="passBtn"></span>').attr('id',p.id + '_down').text('下载到本地');
				var $_recoverBottom  = $('<span class="passBtn"></span>').attr('id',p.id + '_recover').text('恢复选中版本');

				$_headHtml.append($_headDiv01).append($_headDiv02);
				$_BottomRightOrCenter.append($_clearBottom).append($_downBottom).append($_recoverBottom);
                $_BottomHtml.append($_BottomRightOrCenter);
				$_Box.append($_headHtml).append($_content).append($_BottomHtml);

			}
			if(p.type == "sharefile")
			{
				//头部
				$_headHtml.append($_headDiv01).append($_headDiv02);
				//底部
                var $_sharemsgleftBar1 = $('<div class="share_span">收到分享的用户可对文件进行编辑和删除</div>');
                var $_sharemsgleftBar2 = $('<div class="share_sms_checkbox share_sms_checked"></div><div class="share_sms_notice">免费短信通知</div>');
                var $_sharemsgleftBar3 = $('<div class="msg-noavail-tip-r"></div>');
				$_BottomRightOrCenter.append($_bottomBtnOk);
				$_BottomHtml.append($_sharemsgleftBar1).append($_sharemsgleftBar2).append($_sharemsgleftBar3).append($_BottomRightOrCenter).css("padding-right","42px");
				//组合
				$_Box.append($_headHtml).append($_content).append($_BottomHtml);

			}
            if(p.type == 'sharelink')
            {
                //头部
                $_headHtml.append($_headDiv01).append($_headDiv02);
                //底部
                //var $_shareleftBar = $('<div class="share-style-box"><span>分享方式:</span><a href="javascript:void(0);" class="share_to_sms" title="短信分享"></a><a href="javascript:void(0);" class="share_to_mail" title="邮件分享"></a><a href="javascript:void(0);" class="share_to_139" title="分享到移动微博"></a><a href="javascript:void(0);" class="share_to_qq" title="分享到腾讯微博"></a><a href="javascript:void(0);" class="share_to_sina" title="分享到新浪微博"></a></div>');
                var $_shareleftBar = $('');
                $_BottomRightOrCenter.append($_bottomBtnOk).append($_bottomBtnCancel);
                $_BottomHtml.append($_shareleftBar).append($_BottomRightOrCenter).addClass("sharelink_bottom");
                //组合
                $_Box.append($_headHtml).append($_content).append($_BottomHtml);
            }
            if(p.type == 'sharelink_msg')
            {
                //头部
                $_headHtml.append($_headDiv01).append($_headDiv02);
                //底部
                var $_sharebymsgleftBar = $('<div class="msg-noavail-tip"></div>');
                $_BottomRightOrCenter.append($_bottomBtnOk).append($_bottomBtnCancel);
                $_BottomHtml.append($_sharebymsgleftBar).append($_BottomRightOrCenter);
                //组合
                $_Box.append($_headHtml).append($_content).append($_BottomHtml);
            }
            if(p.type == 'filelink_report' || p.type == 'filelink_desc')
            {
                //头部
                $_headHtml.append($_headDiv01).append($_headDiv02);
                //底部
                var $_sharebymsgleftBar = $('<div class="msg-noavail-tip-linkpop"></div>');
                $_BottomRightOrCenter.append($_bottomBtnOk).append($_bottomBtnCancel);
                $_BottomHtml.append($_sharebymsgleftBar).append($_BottomRightOrCenter);
                //组合
                $_Box.append($_headHtml).append($_content).append($_BottomHtml);
            }
            if(p.type == "adduser")
            {
                //头部
                $_headHtml.append($_headDiv01).append($_headDiv02);

                $_BottomRightOrCenter.append($_bottomBtnOk).append($_bottomBtnCancel);
                if(p.leftBtn)
                {
                    $_BottomHtml.append($_addUserSpan);
                }
                $_BottomHtml.append($_BottomRightOrCenter);
                //组合
                $_Box.append($_headHtml).append($_content).append($_BottomHtml);
            }
			if(p.type=="")//如果是普通弹出框
			{
				var $_tip = $('<div class="msg-noavail-tip2"></div>');
				//头部
				$_headHtml.append($_headDiv01).append($_headDiv02);
				//底部
				if(p.leftBtn)
				{
                 $_BottomLeft.append($_newFolderSpan);
					$_BottomHtml.append($_BottomLeft).append($_tip);
				}
				if (p.btnName.length == 1)
				{
					if (p.okOnly)
					{
                        $_BottomRightOrCenter.append($_bottomBtnOk);
						$_BottomHtml.append($_BottomRightOrCenter);
					}
				}
				if(p.btnName.length == 2)
				{
                    $_BottomRightOrCenter.append($_bottomBtnOk).append($_bottomBtnCancel).addClass("BtnRight_2");
					$_BottomHtml.append($_BottomRightOrCenter);
				}
				//组合
                if(p.hasBottomHtml)
                {
                    $_Box.append($_headHtml).append($_content);
                }else
                {
                    $_Box.append($_headHtml).append($_content).append($_BottomHtml);
                }
			}
			return $_Box;
        };

		var appendToBody = function(){
		    var $h = $html;
            //$h.appendTo("body");
		    $('body').append($h);
			$h.css(sty($h));
			if(p.type=="uploadBox"){//如果是上传窗体
				setUploadLocation();
			}else{
				util.layerIndex.hasLayer(p.id);
			}
		}

		//给保险箱使用
		var appendToId = function(divId){
			var $h = $html;
			$h.css({top:65,left:100});//保险箱默认样式
			$h.appendTo($('#'+divId));

		}

		var handle = function(){
		var ar=[];
			ar.push(
			//关闭
			{
				objSelector : "#" + p.id + "_close",
                action      : "click",
                handle      : function(){
					p.closeBox();
					//阻止冒泡事件
                    return false;
				}
			},
			{
				objSelector : "#" + p.id + "_close",
                action      : "mouseover",
                handle      : function(){

				}
			},
			{
				objSelector : "#" + p.id + "_close",
                action      : "mouseout",
                handle      : function(){

				}
			},
			//确定
			{
				objSelector: "#" + p.id + "_ok",
				action: "click",
				handle: function(){
					p.okHandle();
					return false;
				}
			},{
				objSelector : "#" + p.id + "_ok",
                action      : "mouseover",
                handle      : function(){

				}
			},
			{
				objSelector : "#" + p.id + "_ok",
                action      : "mouseout",
                handle      : function(){

				}
			});
			//如果只有1个按钮
			if (p.btnName.length == 1 && p.cancelOnly) {
				var cancelBtnObj = {
					objSelector: "#" + p.id + "_cancel",
					action: "click",
					handle: function(){
					    p.cancelHandle();
					    //阻止冒泡事件
						return false;
					}
				};
				ar.push(cancelBtnObj,
				{
					objSelector : "#" + p.id + "_cancel",
                	action      : "mouseover",
                	handle      : function(){

				    }
				},
				{
					objSelector : "#" + p.id + "_cancel",
                	action      : "mouseout",
                	handle      : function(){

				    }
				});

			}
			//如果有2个按钮，则把另一个按钮事件绑定
			if (p.btnName.length == 2) {
				var cancelBtnObj = {
					objSelector: "#" + p.id + "_cancel",
					action: "click",
					handle: function(){
					    p.cancelHandle();
						return false;
					}
				};
				ar.push(cancelBtnObj,
				{
					objSelector : "#" + p.id + "_cancel",
                	action      : "mouseover",
                	handle      : function(){
                        
				    }
				},
				{
					objSelector : "#" + p.id + "_cancel",
                	action      : "mouseout",
                	handle      : function(){

				    }
				});

			}
			//如果有新建文件夹按钮,则绑定事件
			if(p.leftBtn){
			   var newFoldObj = {
			       objSelector : "#" + p.id + "_newFolder",
                   action      : "click",
                   handle      : function(){
				       p.creatHandle();
					   return false;
				   }
			   }
			   ar.push(newFoldObj,
				{
					objSelector : "#" + p.id + "_newFolder",
                	action      : "mouseover",
                	handle      : function(){

				    }
				},
				{
					objSelector : "#" + p.id + "_newFolder",
                	action      : "mouseout",
                	handle      : function(){

				    }
				});
			}
			//如果有最小化按钮，则绑定事件
			if(p.minBtn){

				var minBtnObj = {
					objSelector : "#" + p.id + "_minimize",
                	action      : "click",
                	handle      : function(){
						p.miniMize();
					}
				}
				ar.push(minBtnObj,
					{
						objSelector : "#" + p.id + "_minimize",
                		action      : "mouseover",
                		handle      : function(){
						}
					},
					{
						objSelector : "#" + p.id + "_minimize",
                		action      : "mouseout",
                		handle      : function(){

						}
					}
				);

			}
            if(p.type="uploadBox"){
                var clearBtnObj = {
                    objSelector : "#" + p.id + "_clear",
                    action      : "click",
                    handle      : function(){
                        p.clearUploadListHandle();
                    }
                };
                ar.push(clearBtnObj);
            }
			//如果是历史版本管理
			if(p.type=='history'){
				var clearBtnObj = {
					objSelector : "#" + p.id + "_clear",
                	action      : "click",
                	handle      : function(){
						p.historyClear();
					}
				};
				var downBtnObj = {
					objSelector : "#" + p.id + "_down",
                	action      : "click",
                	handle      : function(){
						p.historyDown();
					}
				};
				var recoverBtnObj = {
					objSelector : "#" + p.id + "_recover",
                	action      : "click",
                	handle      : function(){
						p.historyRecover();
					}
				};
				ar.push(clearBtnObj,downBtnObj,recoverBtnObj);
			}

			bindFun(ar);
		}

        /**
         *获取弹出框左上角图标class
         * @param Ar 弹出框icon类型
         */
        var switchIconClass = function(icon){
            var iconClass = "";
            switch (icon){
                case 'normal':
                    iconClass ='';
                    break;
                case 'move':
                    iconClass = 'ta-2';
                    break;
                case 'copy':
                    iconClass = '';
                    break;
                case 'ZiPdownload':
                    iconClass = 'ta-1';
                    break;
                case 'history':
                    iconClass = 'ta-3';
                    break;
                case 'sharelink':
                    iconClass = 'ta-4';
                    break;
                case 'adduser':
                    iconClass = 'ta-5';
                    break;
                case 'edituser':
                    iconClass = 'ta-6';
                    break;
            }
            return  iconClass;
        }

		/**
     	* 绑定事件
     	* @param {Array} Ar 存储跟事件相关信息的数组
     	* Ar数组存储的元素包含的属性具体描述如下:
     	* objSelector:需要绑定事件的jquery对象
     	* action:事件名称
     	* handle:事件处理函数
     	* 例如
     	* Ar = [{objSelector:"#b",action:"click",handle:function(){}}]
     	*/
    	var bindFun = function(Ar){
        	for (var i = 0; i < Ar.length; i++) {
            	$(Ar[i].objSelector).bind(Ar[i].action,Ar[i].handle);
        	}
    	};

    	/**
     	* 取消绑定
     	* Ar = [{objSelector:"#b",action:"click"}]
     	*/
    	var unbindFun = function(Ar){
        	for (var i = 0; i < Ar.length; i++) {
            	$(Ar[i].objSelector).unbind(Ar[i].action);
        	}
    	};

		//显示窗体
        var show = function(){
            //$('body').css('overflow',"hidden");
            $('html').css('overflow',"hidden");
        	if($('#' + p.id).length){
                resetLocation();
				$('#' + p.id).show();
          	}
        	else{
				if(p.appendTo=='body'){
            		appendToBody();
				}else{
					appendToId(p.appendTo);
				}
				handle();//添加事件
				resetLocation();
         	}
          	if(p.masked){
             	util.maskDiv.show(p.id);
          	}
            
        };

		//隐藏窗体
		var hide = function(){
			if($('#' + p.id).length){
            	$('#' + p.id).hide();
            }
			if(p.masked){
				util.maskDiv.hide();
				//$('body').css('overflow',"auto");
                $('html').css('overflow',"auto");
			}
            
		};
		// 最小化窗体
		var minimize = function(){
			if(p.minBtn){
			    hide();
			}

		};
		var minimizeUploadBox = function(){
			if(p.type=="uploadBox"){
				$html.addClass('lessen');
				setUploadLocation();
			}
		};

	    //无条件销毁窗体的方法
        var destroy = function(){
        	$html.remove();
           	//获取ID名为b的元素在数组wda.layerIndex.layerStor中的位置，从0开始
          	var i = $.inArray(p.id,util.layerIndex.layerStor);
           	//在数组wda.layerIndex.layerStor中删除ID名为b的元素。这里用于回收数组存储空间。
          	util.layerIndex.layerStor.splice(i,1);
           	//判断是否需要屏遮层，不要就关闭。
		  	if(p.masked){
		  		util.maskDiv.hide(p.id);
		  		//图片浏览时退出操作仍不需要加载滚动条
		  		if($('.myLightbox').length == 0){
		  		  //$('body').css('overflow',"auto");
                  $('html').css('overflow',"auto");
		  		}	  		
		  	}
        };

		//获取窗体的相关css属性
       	var sty = function($h){
       	    var util = window.caiyun.util;
            var h,w,bottom,right,zIndex;
            w = p.width;
            h = p.height||$html.height();

           	msgBoxTop = bottom = (util.iGet.PageSize().WinH-h) / 2 - util.iGet.PageScroll().Y;
            msgBoxLeft = right = (util.iGet.PageSize().WinW-w) / 2 - util.iGet.PageScroll().X;

            zIndex = p.zIdx;
            $('#' + p.id).css({width:p.width,height:p.height});
            return {bottom:bottom,right:right,zIndex:p.zIdx};
       	};

		var setTitle = function(title){
          var $title = $('div#' + p.id + ' span:eq(0)');
          if($title.length){
            $title.text(title);
          }
       };

	   var setTitles = function(title){
	     var $title1 = $('#'+p.id +' .popTitle .floatleft span');
		 $title1.text(title);
	   }

		var resetLocation = function(){
          	var h,w,bottom,right;
          	w = p.width;
          	h = p.height||$html.height();
          	if($.browser.msie && $.browser.version == '6.0')
          	{
          		msgBoxTop = bottom = (util.iGet.PageSize().WinH-h) / 2;  //去掉滚动条后不计算滚动条高度
          	}
          	else
          	{
          		msgBoxTop = bottom = (util.iGet.PageSize().WinH-h) / 2 - util.iGet.PageScroll().Y;
          	}
          	
          	msgBoxLeft = right = (util.iGet.PageSize().WinW-w) / 2 - util.iGet.PageScroll().X;
          	$html.css({bottom:bottom,right:right,zIndex:p.zIdx});
       };

	   //上传窗体最小化定位
	   var setUploadLocation = function(){
	   		//$html.css({bottom:46,right:5});
	   };

		init();

		return {
			show: function(){
				show();
			},
			hide:function(){
				hide();
			},
			getWinBody:function(){
				return $html;
			},
			close: function(){
                destroy();
			},
			minimize: function(){
				minimize();
			},
			minimizeUploadBox :function(){
				minimizeUploadBox();
			},
			setUploadTitles: function(title){
				setTitles(title);
			},
			setTitle: setTitle
		};
    };
})();
