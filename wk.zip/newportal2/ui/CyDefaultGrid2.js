﻿/**
 * 彩云默认的列表实现
 * 依赖CyGrid2.js
 */
(function() {

    // 扩展事件
    var Events = window.caiyun.ui.CyGridEvents;
    Events.itemSelected = 'itemSelected';


    // 数组操作
    var _push = [].push;

    // 扩展行和列

    // 可选中的行
    window.caiyun.ui.CyGridRows.SelectedRow = function(className) {
        window.caiyun.ui.CyGridRows.DefaultRow.apply(this, arguments);
    };
    // 继承默认行
    window.caiyun.ui.CyGridRows.SelectedRow.prototype = new window.caiyun.ui.CyGridRows.DefaultRow();

    // 覆盖模板
    window.caiyun.ui.CyGridRows.SelectedRow.prototype.template = template.compile(
        '<table width="100%" cellspacing="0" cellpadding="0" border="0" <%if(!item.update){%> unselectable="on" onselectstart="return false;" style="-moz-user-select:none;-webkit-user-select:none;" <%}%>' +
        '<tbody>' +
        '<tr> <% for(var i=0 ; i < columns.length ; i++){%>' +
        '<th width="<%=columns[i].width%>"></th>' +
        '<%}%>' +
        '</tr>' +
        '<tr id="gridrow_tr_<%=grid.getId()%>_<%=item.id%>" class="<%=item.type%> gridRowTr gridrow_tr_<%=grid.getId()%> ' +
        '<%if(item.selected){%><%=row.getSelectedClassName(grid)%> current<%}%>"><%==columnsHTML%>' +
        '</tr>' +
        '</tbody>' +
        '</table>');

    window.caiyun.ui.CyGridRows.SelectedRow.dragHelperTemplate = template.compile(
        '<div class="minDrag" style="z-index: 99999;background:#d8cce8;opacity: 1;margin: 0;padding: 0;">' +
        '<img src="<%=imageForDrag%>" border="0" />' +
        '<div class="dom_num"><%=selectedNumber%></div>' +
        '</div>');

    // 获取拖拽时的样式元素，回调方法，this是被拖动的元素
    window.caiyun.ui.CyGridRows.SelectedRow.getDragHelper = function(event) {
        var $this = $(this);
        var ids = $this.attr('id').split('_');
        var gridId = ids[1];
        var itemId = ids[2];

        var grid = window.caiyun.ui.CyGridBase.grids[gridId];
        var row = grid.getRow();
        var selectedItems = grid.getSelectedItems();

        // 如果当前元素没有被选中，则选中当前元素
        if (!selectedItems[itemId]) {
            grid.selectItems(itemId);
        }
        var selectedNumber = 0;
        selectedItems = grid.getSelectedItems();
        for (var id in selectedItems) {
            selectedNumber++;
        }

        var selectedRange = grid.getFirstAndLastSelectedRow();
        var max = selectedRange.max;
        var maxItemId = $(max).attr('id').split('_')[2];
        var img = document.getElementById('fileThumbnail_' + gridId + '_' + maxItemId);
        var imgUrl = null;
        if (img) {
            imgUrl = $(img).attr('src');
        }
        var t = window.caiyun.ui.CyGridRows.SelectedRow.dragHelperTemplate;
        var helper = t({
            imageForDrag: imgUrl,
            selectedNumber: selectedNumber
        });

        return helper;
    };

    window.caiyun.ui.CyGridRows.SelectedRow.dropHandler = function(event) {
        var $this = $(this);
        var ids = $this.attr('id').split('_');
        var gridId = ids[1];
        var itemId = ids[2];

        // 写死一个不响应的距离，头部的高度
        if (event.clientY < 181) {
            return false;
        }

        var grid = window.caiyun.ui.CyGridBase.grids[gridId];
        var row = grid.getRow();
        var selectedItems = grid.getSelectedItems();
        var selectedList = [];
        for (var id in selectedItems) {
            selectedList.push(selectedItems[id].id);
        }

        var droppableHanlder = grid.getItemDroppableHandler();
        var dropHandler = grid.getItemDropHandler();
        if (droppableHanlder(selectedList, itemId)) {
            dropHandler(selectedList, itemId);
        }
    };

    window.caiyun.ui.CyGridRows.SelectedRow.prototype.getSelectedClassName = function(grid) {
        return grid.getId() + '_row_selected';
    };
    if (!window.caiyun.ui.CyGridRows.SelectedRow.prototype.ons) {
        window.caiyun.ui.CyGridRows.SelectedRow.prototype.ons = [];
    }
    _push.apply(
        window.caiyun.ui.CyGridRows.SelectedRow.prototype.ons, [{
                events: 'mouseenter mouseleave',
                selector: 'div.gridRow',
                handler: function(event) {
                    var type = event.type;
                    var grid = event.data.grid;
                    var row = grid.getRow();
                    var $tr = $(document.getElementById(row.getRowTrId(grid, this)));
                    var rowId = row.getItemId(this);
                    var hoverTool = document.getElementById('hoverTools_' + grid.getId() + '_' + rowId);
                    var selectedItems = null,
                        selectedCount = 0,
                        itemId;
                    // 如果这一行是正在重命名或者新建文件夹，跳过之
                    if (rowId === 'newItem' || grid.getItemById(rowId).update) {
                        $tr.removeClass('hover');
                        return;
                    }
                    if (type === 'mouseenter') {
                        $tr.removeClass('hover').addClass('hover');
                        // 如果有悬浮菜单，并且只选中一行时改行显示悬浮菜单，或者没有选择时显示悬浮菜单
                        if (hoverTool) {
                            selectedItems = grid.getSelectedItems();
                            for (itemId in selectedItems) {
                                selectedCount++;
                                if (selectedCount > 1) {
                                    break;
                                }
                            }
                            if (selectedCount === 0) {
                                $(hoverTool).show();
                            } else if (selectedCount === 1 && selectedItems[rowId]) {
                                $(hoverTool).show();
                            }
                        }
                    } else {
                        $tr.removeClass('hover');
                        if (hoverTool) {
                            $(hoverTool).hide();
                        }
                    }

                }
            }, {
                events: Events.itemSelected,
                selector: null,
                handler: function(event, otherData) {
                    var data = event.data;
                    var grid = data.grid;
                    var items = otherData.items;
                    var row = grid.getRow();
                    var className = row.getSelectedClassName(grid);
                    if (!items || items.length === 0) {
                        // IE不支持通过className查找元素，因此增加tr通过getElementsByTagName可以避免查找所有DOM节点
                        $('tr.' + className).removeClass(className + ' current');
                        $('div.' + className).removeClass(className);
                    } else if (items.length === grid.getItems().length) {
                        $('tr.gridrow_tr_' + grid.getId()).addClass(className + ' current');
                        $('div.gridRow_' + grid.getId()).addClass(className);
                    } else {
                        $('tr.' + className).removeClass(className + ' current');
                        $('div.' + className).removeClass(className);
                        // 遍历选中的元素数组，添加选中效果
                        var i = 0,
                            length = items.length,
                            item;
                        // 以下这批操作较慢
                        if (length > 100) {
                            var selected = [];
                            for (; i < length; i++) {
                                item = items[i];
                                selected.push(document.getElementById(row.generateRowTrId(grid, item.id)));
                                $(row.findElementByItemId(grid, item.id)).addClass(className);
                            }
                            $(selected).addClass(className + ' current');
                            selected = null;
                        } else {
                            for (; i < length; i++) {
                                item = items[i];
                                $(document.getElementById(row.generateRowTrId(grid, item.id))).addClass(className + ' current');
                                $(row.findElementByItemId(grid, item.id)).addClass(className);
                            }
                        }
                    }
                }
            }, {
                events: 'click',
                selector: 'div.gridRow',
                handler: function(event) {
                    // 这里的click事件是用于处理选择的！
                    var data = event.data;
                    var grid = data.grid;
                    var row = grid.getRow();
                    var selectedItems = grid.getSelectedItems();
                    var newSelectedIds;
                    var i, length, items = grid.getItems();
                    var thisId = row.getItemId(this),
                        $selectedRow, $firstSelectedRow, $lastSelectedRow, firstId, lastId, thisIndex, firstIndex, lastIndex, newSelectedItems;
                    var className = row.getSelectedClassName(grid);

                    // 如果这一行是新建文件夹或者正在重命名不处理
                    if (thisId === 'newItem' || grid.getItemById(thisId).update) {
                        return;
                    }

                    // 如果按下了shift键，需要从第一个选中元素开始，或者从最后一个选中的元素开始选中元素
                    if (event.shiftKey) {
                        $selectedRow = $('tr.' + className);
                        // 如果没有之前选中
                        if ($selectedRow.length === 0) {
                            grid.selectItems(thisId);
                            return;
                        }
                        $firstSelectedRow = $selectedRow.get(0);
                        $lastSelectedRow = $selectedRow.get(-1);
                        firstId = row.getItemId($firstSelectedRow);
                        lastId = row.getItemId($lastSelectedRow);
                        for (i = 0, length = items.length; i < length; i++) {
                            if (items[i].id === firstId) {
                                firstIndex = i;
                            }
                            if (items[i].id === lastId) {
                                lastIndex = i;
                            }
                            if (items[i].id === thisId) {
                                thisIndex = i;
                            }
                        }

                        // 比第一个选中的元素小，从当前元素选择到最后一个元素
                        if (thisIndex <= firstIndex) {
                            newSelectedItems = items.slice(thisIndex, lastIndex + 1);
                        } else if (thisIndex > firstIndex && thisIndex <= lastIndex) {
                            newSelectedItems = items.slice(firstIndex, thisIndex + 1);
                        } else {
                            newSelectedItems = items.slice(firstIndex, thisIndex + 1);
                        }
                        newSelectedIds = [];
                        for (i = 0, length = newSelectedItems.length; i < length; i++) {
                            newSelectedIds.push(newSelectedItems[i].id);
                        }
                        grid.selectItems(newSelectedIds);
                    } else if (event.ctrlKey) {
                        // 如果被选中,取消选择
                        if (selectedItems[thisId]) {
                            grid.unSelectItems(thisId);
                        } else {
                            newSelectedIds = [];
                            for (var id in selectedItems) {
                                newSelectedIds.push(selectedItems[id].id);
                            }
                            newSelectedIds.push(thisId);
                            grid.selectItems(newSelectedIds);
                        }
                    } else {
                        thisId = row.getItemId(this);
                        if (!selectedItems[thisId]) {
                            grid.selectItems(thisId);
                        } else {
                            grid.unSelectItems(thisId);
                        }
                    }
                    event.preventDefault();
                }
            }, {
                events: 'dblclick',
                selector: 'div.gridRow',
                handler: function(event) {
                    var data = event.data;
                    var grid = data.grid;
                    var row = grid.getRow();
                    var id = row.getItemId(this);
                    grid.openItem(id);
                }
            }, {
                events: 'contextmenu',
                selector: 'div.gridRow',
                handler: function(event) {
                    var data = event.data;
                    var grid = data.grid;
                    var row = grid.getRow();
                    var thisId = row.getItemId(this);
                    // 如果这一行是新建文件夹或者正在重命名不处理
                    if (thisId === 'newItem' || grid.getItemById(thisId).update) {
                        return;
                    }
                    // 如果没选中则选中当前元素
                    if (!grid.getSelectedItems()[thisId]) {
                        grid.selectItems(thisId);
                    }
                    grid.openContextmenu(event);
                    event.preventDefault();
                }
            }, { // 添加新增项目事件
                events: 'addItems',
                selector: null,
                handler: function(event, otherData) {
                    var callback = function() {
                        var data = event.data;
                        var grid = data.grid;
                        var row = grid.getRow();
                        var items = otherData.items;
                        var i = 0;
                        var item = null;
                        var length = items.length;
                        var $dom = null;
                        for (; i < length; i++) {
                            item = items[i];
                            $dom = $(row.findElementByItemId(grid, item.id));
                            if (item.draggable) {
                                $dom.draggable({
                                    revert: true,
                                    delay: 100,
                                    cursorAt: {
                                        left: -50
                                    },
                                    helper: window.caiyun.ui.CyGridRows.SelectedRow.getDragHelper,
                                    containment: 'parent'
                                });
                            }
                            $dom.droppable({
                                drop: window.caiyun.ui.CyGridRows.SelectedRow.dropHandler
                            });
                        }
                        $dom = null;
                        event = null;
                        otherData = null;
                        callback = null;
                    };
                    // 由于IE下执行比较慢，因此改成异步
                    setTimeout(callback,0);
                }
            },
           { // 添加拖拽上传事件
            events : 'dragenter dragleave',
            selector : 'div.gridRow',
            handler : function(event){
                var data = event.data;
                var grid = data.grid;
                var row = grid.getRow();
                var itemId = row.getItemId(this);
                var trId = row.getRowTrId(grid,this);

                var $tr = $(document.getElementById(trId));
                if(event.type === 'dragenter'){
                    $tr.addClass('hover');
                    caiyun.ui.webnd.listViewdragEvent(event,itemId);
                }else{
                    $tr.removeClass('hover');
                }
            }
        },{
            events : 'dragover',
            selector : 'div.gridRow',
            handler : function(event){
                event.stopPropagation();
                event.preventDefault();
                //插件上传 拖拽图标感应
                caiyun.ui.webnd.mouseoverListen(event);
                return false;
            }
        },
            {
                events: 'drop',
                selector: 'div.gridRow',
                handler: function(event) {
                    var data = event.data;
                    var grid = data.grid;
                    var row = grid.getRow();
                    var itemId = row.getItemId(this);
                    var originalEvent = event.originalEvent;
                    if (!(originalEvent.dataTransfer) || !(originalEvent.dataTransfer.files)) {
                        event.stopPropagation();
                        return false;
                    }
                    var files = originalEvent.dataTransfer.files;
                    grid.uploadFiles(files, itemId);
                    //插件上传 拖拽图标还原
                    caiyun.ui.webnd.modifyDragArea();
                    event.stopPropagation();
                    return false;
                }
            }, {
                events: 'drop',
                handler: function(event) {
                    var data = event.data;
                    var grid = data.grid;
                    var originalEvent = event.originalEvent;
                    if (!(originalEvent.dataTransfer) || !(originalEvent.dataTransfer.files)) {
                        event.stopPropagation();
                        return false;
                    }
                    var files = originalEvent.dataTransfer.files;
                    grid.uploadFiles(files);
                    //插件上传 拖拽图标还原
                    caiyun.ui.webnd.modifyDragArea();
                    event.stopPropagation();
                    return false;
                }
            }
        ]);

    // 复选框列
    window.caiyun.ui.CyGridColumns.SelectCheckBox = function(columnType, valign, align, width) {
        var args = [];
        args[0] = 'SelectCheckBox';
        args[1] = valign;
        args[2] = align;
        args[3] = width ? width : '5%';
        window.caiyun.ui.CyGridColumns.BaseColumn.apply(this, args);
    };
    window.caiyun.ui.CyGridColumns.SelectCheckBox.prototype = new window.caiyun.ui.CyGridColumns.BaseColumn();
    window.caiyun.ui.CyGridColumns.SelectCheckBox.prototype.template = template.compile(
        '<td valign="<%=valign%>" align="<%=align%>" class="p5 gridCheckBox"' +
        'id="selectOpt_<%=grid.getId()%>_<%=rowItem.id%>">' +
        '<span class="input_on"></span>' +
        '</td>');
    window.caiyun.ui.CyGridColumns.SelectCheckBox.prototype.render = function(grid, item, rowItem) {
        var context = {
            valign: this.valign,
            align: this.align,
            grid: grid,
            item: item,
            rowItem: rowItem
        };
        return this.template(context);
    };
    window.caiyun.ui.CyGridColumns.SelectCheckBox.prototype.ons = [{
        events: 'dblclick click',
        selector: '.gridCheckBox',
        handler: function(event) {
            if (event.type === 'click') {
                if (event.shiftKey) {
                    return;
                }
                var data = event.data;
                var grid = data.grid;
                var id = $(this).attr('id').split('_')[2];

                // 如果这一行正在重命名或者新建文件夹,关闭重命名和新建文件夹
                if (id === 'newItem' || grid.getItemById(id).update) {
                    grid.clearRenameAndNewFolder();
                    return;
                }
                // 关闭其他行可能也有的重命名或者新建文件夹操作
                grid.clearRenameAndNewFolder();
                var selectedItems = grid.getSelectedItems();
                if (selectedItems[id]) {
                    grid.unSelectItems(id);
                } else {
                    var newSelectedIds = [];
                    for (var sid in selectedItems) {
                        newSelectedIds.push(selectedItems[sid].id);
                    }
                    newSelectedIds.push(id);
                    grid.selectItems(newSelectedIds);
                }
                event.stopPropagation();
            } else if (event.type === 'dblclick') {
                // 屏蔽事件冒泡
                event.stopPropagation();
            }
        }
    }];

    // 复选框列 end

    // 文件信息列
    window.caiyun.ui.CyGridColumns.FileInfo = function(columnType, valign, align, width) {
        var args = [];
        args[0] = 'FileInfo';
        args[1] = valign;
        args[2] = align;
        args[3] = width ? width : '75%';
        window.caiyun.ui.CyGridColumns.BaseColumn.apply(this, args);
    };
    window.caiyun.ui.CyGridColumns.FileInfo.prototype = new window.caiyun.ui.CyGridColumns.BaseColumn();

    window.caiyun.ui.CyGridColumns.FileInfo.handleImgError = function(img) {
        var $this = $(img);
        $this.attr('src', '../images/newportal2/config_img.gif');
        var ids = $this.attr('id').split('_');
        var grid = window.caiyun.ui.CyGridBase.grids[ids[1]];
        var item = grid.getItemById(ids[2]);
        // 如果页面元素已经不存在，但是事件被触发
        if (item) {
            item.bigThumbnail = null;
        }
    };
    
        

    window.caiyun.ui.CyGridColumns.FileInfo.prototype.template = template.compile(
        '<td valign="middle" align="center"' +
        'id="fileInfo_<%=grid.getId()%>_<%=rowItem.id%>" class="gridRowFileInfo">' +
        '<div class="doc_nr_box clearfix  <%if(item.fromPath){%>recycle_txt_box<%}%>">' +
        '<%if(rowItem.hasShare){%>' +
        '<b class="min_icon m_people" title="分享给其他用户"></b>' +
        '<%}%>' +
        '<%if(rowItem.hasReciveNew){%>' +
        '<b class="min_icon m_minNew" title="有新收到的文件"></b>' +
        '<%}%>' +
        '<img onerror="window.caiyun.ui.CyGridColumns.FileInfo.handleImgError(this);" width="32" height="32" src="<%=item.thumbnail%>"' +
        'style="cursor: pointer" class="fileThumbnail" id="fileThumbnail_<%=grid.getId()%>_<%=rowItem.id%>" ondragstart="event.returnValue = false;">' +
        '<div class="doc_nr_r" class="file">' +
        '<div class="clear"><h2 title="<%=item.fileName%>"' +
        'id="fileInfo_<%=grid.getId()%>_<%=rowItem.id%>"' +
        'style="cursor: pointer" class="floatleft <%if(rowItem.playing){%>music_color<%}%> gridFileName">' +
        '<%=item.showName%>' + '<%==item.htmlName%>' +
        '</h2>' +
        '<%if(rowItem.playing){%><div id="playMusicIco" class="music_ico2"></div><%}%></div>' +
        '<%if(item.fromPath){%>' +
        '<div class="come_from clear">分享者：<%=item.fromPath%></div>' +
        '<%}%>' +
        '<%if(rowItem.hasVirus){%>' +
        '<div class="virus_ico"></div>' +
        '<%}%>' +
        '</div>' +
         '<%if(item.extraHoverTool){%>' +
                     '<p class="hover_tools" id="hoverTools_<%=grid.getId()%>_<%=rowItem.id%>" style="display: none;">' +
                        '<%==item.extraHoverTool%>'+
                     '</p>' +
        '<%}%>' +
        '<%if(item.hasHoverTool){%>' +
        '<p class="hover_tools" id="hoverTools_<%=grid.getId()%>_<%=rowItem.id%>" style="display: none;">' +
        '<b title="分享文件链接" class="hover_tools_btn l_share" id="gridoutlink_<%=grid.getId()%>_<%=rowItem.id%>"></b>' +
        '<b title="分享给其他用户" class="hover_tools_btn l_Tshare" id="gridshare_<%=grid.getId()%>_<%=rowItem.id%>"></b>' +
        '<b title="下载" class="hover_tools_btn l_download" id="griddownload_<%=grid.getId()%>_<%=rowItem.id%>"></b>' +
        '</p>' +
        '<%}%>' +
        '</div>' +
        '</td>'
    );
    window.caiyun.ui.CyGridColumns.FileInfo.prototype.templateForUpdate = template.compile(
        '<td id="updateName_<%=grid.getId()%>_<%=rowItem.id%>" class="<%=rowItem.updateType%>">' +
                '<div class="floatleft">' +
                '<img onerror="javascript:this.src=\'http://caiyun.feixin.10086.cn/Mcloud/images/newportal2/config_img.gif\';" src="<%=item.thumbnail%>" width="34" height="34">'+
                '</div>' +
                '<div class="newfile">' +
                    '<ul>' +
                        '<li class="nli_1">' +
                            '<input type="text" value="<%=rowItem.newName%>" maxlength="32" class="newfolder" id="updateNameValue_<%=grid.getId()%>_<%=rowItem.id%>">' +
                        '</li>' +
                        '<li class="nli_2">' +
                            '<a id="confirm_<%=grid.getId()%>_<%=rowItem.id%>" href="javascript:void(0)" title="确定" class="newf-ok <%=rowItem.updateType%>"></a>' +
                        '</li>' +
                        '<li class="nli_3">' +
                            '<a id="cancel_<%=grid.getId()%>_<%=rowItem.id%>" href="javascript:void(0)" title="取消" class="newf-no <%=rowItem.updateType%>"></a>' +
                        '</li>' +
                    '</ul>' +
                '</div>'+
        '</td>'
    );
    window.caiyun.ui.CyGridColumns.FileInfo.prototype.templateForThumbnail = template.compile(
        '<div class="img_max_look" id="bigThumbnail_<%=grid.getId()%>_<%=item.id%>">' +
        '<img src="../images/newportal2/s.gif" style="width:120px;height:120px;background:url(<%=item.bigThumbnail%>);background-position:center center;background-repeat:no-repeat;"></img>' +
        '</div>'
    );
    window.caiyun.ui.CyGridColumns.FileInfo.prototype.render = function(grid, item, rowItem) {
        var context = {
            valign: this.valign,
            align: this.align,
            grid: grid,
            item: item,
            rowItem: rowItem
        };
        if (rowItem.update) {
            return this.templateForUpdate(context);
        } else {
            return this.template(context);
        }
    };
    window.caiyun.ui.CyGridColumns.FileInfo.prototype.ons = [{
        events: 'click',
        selector: 'a.newf-ok',
        handler: function(event) {
            var data = event.data;
            var grid = data.grid;
            var index = data.colIndex;
            var column = grid.getColumns()[index];
            var id = $(this).attr('id').split('_')[2];
            var newFolderName = $('#updateNameValue_' + grid.getId() + '_' + id).val();
            if (id === 'newItem') {
                var close = grid.confirmCreateItem({
                    newFolderName: newFolderName
                });
                // 如果新建成功，就消失掉
                if (close) {
                    grid.cancelCreateItem();
                }
            } else {
                var item = grid.getItemById(id);
                grid.confirmRename(item, newFolderName);
                grid.cancelRename();
            }
            event.stopPropagation();
            // a标签默认返回false，避免IE触发离开页面
            return false;
        }
    }, {
        events: 'click',
        selector: 'a.newf-no',
        handler: function(event) {
            var data = event.data;
            var grid = data.grid;
            grid.clearRenameAndNewFolder();
            event.stopPropagation();
            // a标签默认返回false，避免IE触发离开页面
            return false;
        }
    }, {
        events: 'keydown',
        selector: 'input.newfolder',
        handler: function(event) {
            var data = event.data;
            var grid = data.grid;
            if (event.keyCode === 13) {
                var id = $(this).attr('id').split('_')[2];
                var newFolderName = $(this).val();
                if (id === 'newItem') {
                    var close = grid.confirmCreateItem({
                        newFolderName: newFolderName
                    });
                    // 如果新建成功，就消失掉
                    if (close) {
                        grid.cancelCreateItem();
                    }
                } else {
                    var item = grid.getItemById(id);
                    grid.confirmRename(item, newFolderName);
                    grid.cancelRename();
                }
                event.preventDefault();
                event.stopPropagation();
                return false;
            } else if (event.keyCode === 27) {
                grid.clearRenameAndNewFolder();
            }
        }
    }, {
        events: 'click dblclick',
        selector: 'input.newfolder',
        handler: function(event) {
            event.stopPropagation();
            return false;
        }
    }, {
        events: 'mouseenter mouseleave',
        selector: 'img.fileThumbnail',
        handler: function(event) {
            var data = event.data;
            var grid = data.grid;
            var type = event.type;
            var id = $(this).attr('id').split('_')[2];
            var item = grid.getItemById(id);
            var parent, pHeight, pHeightOld, bottom;
            if (!item.bigThumbnail || item.id === 'newItem' || grid.getRenameItem === item) {
                return;
            }
            var $column = document.getElementById('fileInfo_' + grid.getId() + '_' + id);
            // 如果鼠标进入，则添加缩略图
            if (type === 'mouseenter') {
                var thumbnail = window.caiyun.ui.CyGridColumns.FileInfo.prototype.templateForThumbnail;
                var context = {
                    grid: grid,
                    item: item
                };
                var temp = document.createElement('div');
                temp.innerHTML = thumbnail(context);
                var floatImg = temp.firstChild;
                $column.firstChild.appendChild(floatImg);
                temp = null;
                var $floatImg = $(floatImg);
                var offset = $floatImg.offset();
                var height = $floatImg.height();
                // 如果超出窗口范围
                if (offset.top + height * 2 + 20 > $(window).height() + $(document).scrollTop()) {

                } else {
                    // 为了防止页面拉伸导致出现瞬间的滚动条，因此图片时先向上显示，再变为向下显示
                    $floatImg.css('top', '8px');
                    parent = $(grid.getGridElement());
                    pHeight = parent.height();
                    pHeightOld = parent.css('height');
                    bottom = parent.offset().top + pHeight;
                    // 如果超出列表显示范围，拉伸一下父框的高度
                    if (offset.top + height > bottom) {
                        if (pHeightOld !== null && pHeightOld !== undefined) {
                            parent.attr('pHeightOld', pHeightOld);
                        }
                        parent.css('height', pHeight + ($floatImg.height() + 10) + 'px');
                    }
                }
            } else {
                parent = $(grid.getGridElement());
                pHeight = parent.height();
                pHeightOld = parent.css('height');
                bottom = parent.offset().top + pHeight;
                var $thumbnail = $('#' + 'bigThumbnail_' + grid.getId() + '_' + id);
                $thumbnail.remove();
                pHeightOld = parent.attr('pHeightOld');
                if (pHeightOld !== null && pHeightOld !== undefined) {
                    parent.css('height', pHeightOld);
                } else {
                    parent.css('height', '');
                }
            }
        }
    }, {
        events: 'mouseover mouseout mousemove',
        selector: 'div.virus_ico',
        handler: function(e) {
            if (e.type === 'mouseover' || e.type === 'mousemove') {
                $("#virusTipDiv").css({
                    top: e.pageY - 20,
                    left: e.pageX - 473
                });
            }
            if (e.type === 'mouseover') {
                $("#virusTipDiv").css("z-index", "50").show();
            }
            if (e.type === 'mouseout') {
                $("#virusTipDiv").css("z-index", "").hide();
            }
        }
    }, {
        events: 'click',
        selector: 'b.l_share,b.l_Tshare,b.l_download',
        handler: function(e) {
            var data = e.data;
            var grid = data.grid;
            var $this = $(this);
            var itemId = $this.attr('id').split('_')[2];
            var item = grid.getItemById(itemId);
            if ($this.hasClass('l_share')) {
                grid.createLink(item);
            } else if ($this.hasClass('l_Tshare')) {
                grid.createShare(item);
            } else if ($this.hasClass('l_download')) {
                grid.download(item);
            }
            e.stopPropagation();
            return false;
        }
    }, {
        events: 'click',
        selector: 'img.fileThumbnail,h2.gridFileName',
        handler: function(e) {
            var data = e.data;
            var grid = data.grid;
            var $this = $(this);
            var itemId = $this.attr('id').split('_')[2];
            var canOpen = grid.openItem(itemId);
            if (canOpen) {
                e.stopPropagation();
                return false;
            }
        }
    }, {
        events: 'mouseenter mouseleave',
        selector: 'h2.gridFileName',
        handler: function(e) {
            var $this = $(this);
            var data = e.data;
            var grid = data.grid;
            if (!grid.hasOpenHandler()) {
                return;
            }
            if (e.type === 'mouseenter') {
                $this.css('text-decoration', 'underline');
            } else {
                $this.css('text-decoration', 'none');
            }
        }
    }];
    // 文件信息列 end

    // 文字列
    window.caiyun.ui.CyGridColumns.Words = function(columnType, valign, align, width) {
        var args = [];
        args[0] = 'Words';
        args[1] = valign;
        args[2] = align;
        args[3] = width ? width : '20%';
        window.caiyun.ui.CyGridColumns.BaseColumn.apply(this, args);
    };
    window.caiyun.ui.CyGridColumns.Words.prototype = new window.caiyun.ui.CyGridColumns.BaseColumn();
    window.caiyun.ui.CyGridColumns.Words.prototype.template = template.compile(
        '<td valign="<%=valign %>" align="<%=align %>" class="gridRowWors"><h2></h2>' +
        '<%if(item.isEnterprisePath){%>' +
        '<b class="min_icon m_share_p"></b>' +
        '<%}%>' +
        '<span style="float: left; _margin-top: 3px"><%=item.str%></span>' +
        '<%if(item.hasLink){%>' +
        '<b class="min_icon m_share" title="分享文件链接"></b>' +
        '<%}%>' +
        '</td>'
    );
    window.caiyun.ui.CyGridColumns.Words.prototype.render = function(grid, item, rowItem) {
        var context = {
            valign: this.valign,
            align: this.align,
            grid: grid,
            item: item,
            rowItem: rowItem
        };
        return this.template(context);
    };

    // 文字列 end

    // 可点击的文件列
    // 可点击的文件列 end

    // 扩展默认的列表模型，用于实现彩云需要用到的接口方法
    window.caiyun.ui.CyDefaultGrid = function(config) {
        // 定义变量
        config.row = new window.caiyun.ui.CyGridRows.SelectedRow();
        if (config.dropable) {
            var $body = $(document.body);
            $body.on('dragover', '#' + config.renderId + ' tr', function(event) {
                caiyun.util.Event.stopPropagation(event);
                caiyun.util.Event.preventDefault(event);
                var $tr = $(caiyun.util.Event.getTarget(event)).parents('tr');
                if ($tr.hasClass('folder')) {
                    $tr.addClass('hover');
                }
            });

            $body.on('dragleave', '#' + config.renderId + ' tr', function(event, b) {
                caiyun.util.Event.stopPropagation(event);
                caiyun.util.Event.preventDefault(event);
                var target = caiyun.util.Event.getTarget(event);
                if (target.tagName.toLowerCase() == 'tr') {
                    $(target).removeClass('hover');
                } else {
                    $(target).parents('tr').removeClass('hover');
                }
            });
        }
        // 引入base方法
        var base = window.caiyun.ui.CyGridBase;
        var self = window.caiyun.ui.CyGrid2(config);
        // 记录父类销毁函数
        var _destory = self.destory;
        // 记录父类清除函数
        var _clear = self.clear;
        if (!self) {
            return null;
        }
        var targetElement = self.getGridElement();
        var target = $(targetElement);
        var gridId = self.getId();
        var selectedItems = {};
        var selectedHandler;
        var openHandler;
        var contextmenuHandler;
        var confirmCreateItemHandler;
        var createIteming = false;
        var updatingItem = null;
        var confirmRenameSelectedItemHandler = null;
        var itemDropableHandler = null;
        var itemDropHandler = null;
        var localFileDropHandler = null;
        var linkHandler = null;
        var downloadHander = null;
        var shareHandler = null;
        var viewHeight = config.viewHeight;
        var showEmptyStyle = false;
        // 定义变量END

        // 创建公用的病毒提示
        if (!document.getElementById('virusTipDiv')) {
            var tips = '<div id="virusTipDiv" style="position: absolute;width:505px;-moz-user-selec:none;display:none;">' +
                '<div id="virus_tipsCSS" class="virus_tipsCSS">' +
                '<b></b>' +
                '<div class="ing_up_txt">此文件可能存在病毒，请谨慎下载与分享。</div>' +
                '</div>' +
                '</div>';
            var div = document.createElement('div');
            div.innerHTML = tips;
            $('body').prepend(div.firstChild);
            div = null;
        }
        // 创建公用的病毒提示end

        // 绑定键盘操作
        var getFirstAndLastSelectedRow = function() {
            var rows = targetElement.childNodes;
            var i = 0,
                length = rows.length;
            var min = null;
            var max = null;
            var last = null;
            var first = null;
            var row = self.getRow();
            var rowDiv = null;
            var className = row.getSelectedClassName(self);
            for (; i < length; i++) {
                rowDiv = rows[i];
                if (rowDiv.nodeType === 1) {
                    if (!first) {
                        first = rowDiv;
                    }
                    if ($(rowDiv).hasClass(className)) {
                        if (!min) {
                            min = rowDiv;
                        }
                        max = rowDiv;
                    }
                    last = rowDiv;
                }
            }
            return {
                min: min,
                max: max,
                first: first,
                last: last
            };
        };

        // 如果键盘事件超出范围，则滚动到新选择的元素位置
        var scrollToNewSelectedItemPosition = function(isLast) {
            // 计算上下可显示的范围，查看当前选择元素是否超出了此范围，如果超出就上下或者向下滚动一行
            // css中的行高加上外边距
            var rowHeight = 51;
            var innerHeigth = $(window).height();
            var scrollTop = $(document).scrollTop();
            var scrollButtom = scrollTop + viewHeight;
            var selectedRange = getFirstAndLastSelectedRow();
            var newPosition = $(selectedRange.min).offset().top;
            var shift = 0;
            // 如果已经是最后一个元素，滚动多一点，触发滚动到最底的事件
            var more = isLast ? 51 : 0;
            // 每一行上下移动要与边界对齐！
            // 如果行的顶部超出显示范围
            if (newPosition < scrollTop + $(targetElement).offset().top) {
                // 计算超出部分
                shift = scrollTop + $(targetElement).offset().top - newPosition;
                window.scrollTo(0, scrollTop - shift);
            }
            // 如果行超出底部显示范围
            else if (newPosition + rowHeight > scrollButtom) {
                // 计算超出部分
                shift = newPosition + rowHeight - scrollButtom;
                window.scrollTo(0, scrollTop + shift + more);
            } else {
                // 最后一个元素，就滚多一点
                if (isLast) {
                    window.scrollTo(0, scrollTop + more);
                }
            }
        };

        // 键盘事件响应
        var keyHandler = function(event) {
            //当有弹出层时不做任何操作
            if (window.caiyun.layershow || self.getItems().length === 0) {
                return;
            }
            // 窗口高度
            var innerHeight = $(window).height();
            var key = event.keyCode;
            var itemList = [];
            var row = self.getRow();
            var result = null,
                min, itemId, prev, max, next, isLast;

            if (key === 13) {
                for (var id in selectedItems) {
                    itemList.push(selectedItems[id]);
                }
                //获取当前选择的items
                if (itemList.length == 1) {
                    self.openItem(itemList[0].id);
                }
                event.preventDefault();
                event.stopPropagation();
                return false;
            }
            // 上箭头
            else if (key === 38) {
                //取得当前选中的第一行
                result = getFirstAndLastSelectedRow();
                min = result.min;
                itemId = null;
                prev = null;
                // 没有最小选中第一个
                if (!min) {
                    min = result.first;
                    itemId = row.getItemId(min);
                    self.selectItems(itemId);
                } else {
                    prev = min.previousSibling;
                    while (prev) {
                        if (prev.nodeType === 1) {
                            break;
                        }
                        prev = prev.previousSibling;
                    }
                    // 有上一个选中
                    if (prev) {
                        itemId = row.getItemId(prev);
                        self.selectItems(itemId);
                    } else {
                        itemId = row.getItemId(min);
                        self.selectItems(itemId);
                    }
                }
                scrollToNewSelectedItemPosition();
                event.preventDefault();
                event.stopPropagation();
                return false;
            }
            // 下箭头
            else if (key === 40) {
                result = getFirstAndLastSelectedRow();
                max = result.max;
                itemId = null;
                next = null;
                if (!max) {
                    max = result.last;
                    itemId = row.getItemId(max);
                    self.selectItems(itemId);
                    isLast = true;
                } else {
                    next = max.nextSibling;
                    while (next) {
                        if (next.nodeType === 1) {
                            break;
                        }
                        next = next.nextSibling;
                    }
                    // 有下一个选中
                    if (next) {
                        itemId = row.getItemId(next);
                        self.selectItems(itemId);
                    } else {
                        itemId = row.getItemId(max);
                        self.selectItems(itemId);
                        isLast = true;
                    }
                }
                scrollToNewSelectedItemPosition(isLast);
                event.preventDefault();
                event.stopPropagation();
                return false;
            }
        };
        $(document).bind('keydown', keyHandler);
        // 绑定键盘操作 end

        // 监听删除事件
        base.on(self, self.getGridElement(), self.getId(), {
            events: window.caiyun.ui.CyGridEvents.removeItems,
            handler: function(event, otherData) {
                var data = event.data;
                var grid = data.grid;
                var removedItems = otherData.removedItems;
                var ids = [];
                var i = 0,
                    length = removedItems.length;
                if (length === 0) {
                    return;
                }
                for (; i < length; i++) {
                    ids.push(removedItems[i].id);
                }
                grid.unSelectItems(ids);
            }
        });
        // 监听删除事件 end

        // 定义公共方法
        // 销毁方法
        self.destory = function() {
            self.addEventListener = null;
            scrollToNewSelectedItemPosition = null;
            getFirstAndLastSelectedRow = null;
            $(document).unbind('keydown', keyHandler);
            keyHanlder = null;
            shareHandler = null;
            downloadHander = null;
            linkHandler = null;
            localFileDropHandler = null;
            itemDropHandler = null;
            itemDropableHandler = null;
            confirmRenameSelectedItemHandler = null;
            updatingItem = null;
            createIteming = null;
            confirmCreateItemHandler = null;
            contextmenuHandler = null;
            selectedHandler = null;
            selectedItems = null;
            gridId = null;
            target = null;
            targetElement = null;
            viewHeight = null;
            showEmptyStyle = null;
            _destory.apply(this);
            _clear = null;
            _destory = null;
            self = null;
        };
        self.setEmptyStyle = function(html) {
            self.clear();
            showEmptyStyle = true;
            // 替换成空样式
            target.append(html);
        };
        self.clearEmptyStyle = function() {
            if (showEmptyStyle) {
                self.clear();
                targetElement.innerHTML = '';
                showEmptyStyle = false;
            }
        };
        self.setViewHeight = function(height) {
            viewHeight = height;
        };
        self.clearRenameAndNewFolder = function() {
            self.cancelCreateItem();
            self.cancelRename();
        };
        self.clear = function() {
            self.clearRenameAndNewFolder();
            _clear.apply(this);
        };
        self.selectItems = function(ids) {
            var items = self.getItems();
            if (ids === null || ids === undefined) {
                base.trigger(self, Events.itemSelected, {
                    items: []
                });
                if (selectedHandler) {
                    selectedHandler([],items.length);
                }
            }
            var i = 0,
                length, item,
                result = [];
            if (!(ids instanceof Array)) {
                var tempids = [];
                tempids.push(ids);
                ids = tempids;
            }

            length = ids.length;
            selectedItems = {};
            for (; i < length; i++) {
                item = self.getItemById(ids[i]);
                if (item) {
                    selectedItems[item.id] = item;
                    item.selected = true;
                    result.push(item);
                }
            }
            base.trigger(self, Events.itemSelected, {
                items: result
            });
            if (selectedHandler) {
                selectedHandler(result,items.length);
            }
        };
        self.unSelectItems = function(ids) {
            if (ids === null || ids === undefined) {
                return;
            }
            if (!(ids instanceof Array)) {
                var tempids = [];
                tempids.push(ids);
                ids = tempids;
            }
            var i = 0,
                length = ids.length,
                newIds = [],
                item, removed = false;
            // 筛选出已选中，然后需要取消选择元素
            for (var id in selectedItems) {
                removed = false;
                item = selectedItems[id];
                for (i = 0; i < length; i++) {
                    if (ids[i] === item.id) {
                        removed = true;
                        item.selected = false;
                        break;
                    }
                }
                if (!removed) {
                    newIds.push(id);
                }
            }
            self.selectItems(newIds);
        };
        
        self.selectAll = function() {
            var ids = [],
                items = self.getItems(),
                length = items.length;
            for (var i = 0; i < length; i++) {
                if (!items[i].unselectable) {
                    ids.push(items[i].id);
                }
            }
            self.selectItems(ids);
        };
        self.unSelectAll = function() {
            self.selectItems([]);
        };
        self.getSelectedItems = function() {
            return selectedItems;
        };
        self.setSelectedHandler = function(handler) {
            selectedHandler = handler;
        };
        self.openItem = function(id) {
            if (openHandler) {
                openHandler(id);
                return true;
            }
            return false;
        };
        self.setOpenHandler = function(handler) {
            openHandler = handler;
        };
        self.hasOpenHandler = function() {
            return openHandler !== null && openHandler !== undefined;
        };
        self.openContextmenu = function(event) {
            if (contextmenuHandler) {
                contextmenuHandler(event);
            }
        };
        self.setContextmenuHandler = function(handler) {
            contextmenuHandler = handler;
        };
        self.createItem = function(defaultName) {
            if (!createIteming) {
                self.cancelRename();
                var newItem = new window.caiyun.ui.CyGridItem('newItem');
                newItem.update = true;
                newItem.updateType = 'newItem';
                newItem.newName = defaultName ? defaultName : '';
                newItem.colItems.push({}, {
                    thumbnail: '/Mcloud/images/newportal2/web_small/folder.gif'
                }, {});
                self.unshiftItems(newItem);
                // 选中输入框获取焦点
                var input = document.getElementById('updateNameValue_' + self.getId() + '_newItem');
                $(input).focus().select();
                createIteming = true;
            }
        };
        self.confirmCreateItem = function(params) {
            var flag = false;
            if (confirmCreateItemHandler) {
                flag = confirmCreateItemHandler(params);
            } else {
                flag = true;
            }
            return flag;
        };
        self.cancelCreateItem = function() {
            if (createIteming) {
                self.removeItems('newItem');
                createIteming = false;
            }
        };
        self.setConfirmCreateItemHandler = function(handler) {
            confirmCreateItemHandler = handler;
        };
        self.renameSelectedItem = function(getDefaultName) {
            // 先隐藏已显示重命名输入框
            self.cancelRename();
            if (!updatingItem) {
                self.cancelCreateItem();
                var selectedItemsList = [];
                var id;
                for (id in selectedItems) {
                    selectedItemsList.push(selectedItems[id]);
                }
                if (selectedItemsList.length !== 1) {
                    return;
                }
                var item = selectedItemsList[0];
                self.unSelectItems(item.id);
                updatingItem = item;
                updatingItem.update = true;
                updatingItem.newName = getDefaultName ? getDefaultName(updatingItem) : '';
                self.updateItem(item);

                // 选中输入框获取焦点
                var input = document.getElementById('updateNameValue_' + self.getId() + '_' + item.id);
                $(input).focus().select();
            }
        };
        self.cancelRename = function() {
            if (updatingItem) {
                updatingItem.update = null;
                updatingItem.newName = null;
                self.updateItem(updatingItem);
                updatingItem = null;
            }
        };
        self.confirmRename = function(item, newName) {
            if (updatingItem && confirmRenameSelectedItemHandler) {
                confirmRenameSelectedItemHandler({
                    item: item,
                    newName: newName
                });
            }
        };
        self.getRenameItem = function() {
            return updatingItem;
        };
        self.setConfirmRenameSelectedItemHandler = function(handler) {
            confirmRenameSelectedItemHandler = handler;
        };
        self.setItemDropableHandler = function(handler) {
            itemDropableHandler = handler;
        };
        self.setItemDropHandler = function(handler) {
            itemDropHandler = handler;
        };
        self.setLocalFileDropHandler = function(handler) {
            localFileDropHandler = handler;
        };
        self.setLinkHandler = function(handler) {
            linkHandler = handler;
        };
        self.createLink = function(item) {
            linkHandler(item);
        };
        self.setDownLoadHandler = function(handler) {
            downloadHander = handler;
        };
        self.download = function(item) {
            downloadHander(item);
        };
        self.setShareHandler = function(handler) {
            shareHandler = handler;
        };
        self.createShare = function(item) {
            shareHandler(item);
        };
        self.getFirstAndLastSelectedRow = getFirstAndLastSelectedRow;

        self.getItemDropHandler = function() {
            return itemDropHandler;
        };

        self.getItemDroppableHandler = function() {
            return itemDropableHandler;
        };
        self.uploadFiles = function(files, id) {
            if (localFileDropHandler) {
                localFileDropHandler(files, id);
            }
        };

        // 添加事件监听程序，用于和可扩展的HTML部分进行联动
        self.addEventListener = function(events,selector,handler){
            base.on(self, self.getGridElement(), self.getId(),{
                events : events,
                selector : selector,
                handler : handler
            });
        };

        // 定义公共方法 END

        return self;
    };
})();
