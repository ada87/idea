/**
 * 视屏播放
 * 
 */
;(function() {
	window.caiyun.lightbox4Video = (function() {
		
		var tools = window.caiyun.util;
		var ui = window.caiyun.ui;
		var fileOperator = window.caiyun.operate;
		var constants = window.caiyun.constants;
		var judgement = window.caiyun.judgement;
		var fileShareOperate = window.caiyun.fileShareOperate;
		var zIndex , lightBoxId;
		var currentLightbox4Video;
		var opts = {};
		var id;
		var flag = "isVedio"; //统计标示
		
		var defaults = {
			fileLoadingImage: '../images/wda6/lightbox_loading.gif',
			fileBottomNavCloseImage: '../images/wda6/lightbox_closebtn.gif',
			//当前播放DIV的宽
			widthCurrent: 960,
			containerHeight: 660
		};
		
		//获取box的z-index
		var getVideoBoxID = function(){
			zIndex = 88;//tools.layerIndex.getIdx();
			lightBoxId = 'videobox_' + zIndex;
		}
		
		var init = function(param){	
			opts = $.extend({}, defaults, param);
			// 如果屏幕比680小，将html和body的overflow属性改为auto
			//if($(window).height() < 680){
				//$('html,body').addClass('autoOverflow');
			//}
			caiyun.util.cache.clearVideoCache(caiyun.constants.Video_LIST_CACHE_GROUP);
			caiyun.util.cache.putPictureCache(caiyun.constants.Video_LIST_CACHE_GROUP,opts);
			$(window).resize(resizeOverlayToFitWindow).scroll(function(e){
				var scrollY = tools.iGet.PageScroll().Y;
				var top;
			
			});
			initialize();		
		};	
		
		var initialize = function(){
			getVideoBoxID();		
			initLightboxHtml();
			resizeContainer();
			initVideoInfo();
			addEventHandlers(opts.contentID);
			//播放器
			window.newPlayer.initPlayer(opts,loadOverFunc);
		    id = opts.contentID;
		};
		
		var loadOverFunc = function(){
			currentLightbox4Video.find("#loadingVideo").hide();
		}
		
		var initLightboxHtml= function (){
			var outerImage = new StringBuffer();
			outerImage.append('<div id="outerImageContainer" style="width:590px;height:425px;overflow:visible;">')
			          .append('  <div id="videoheadName" style="color: rgb(255, 255, 255); text-align: left; margin: 0px auto; width: 580px; padding-left: 10px; line-height: 40px; height: 35px;"></div>')
			          .append('  <div id="videoContainer" style="width:590px;height:390px;">')
			          .append('      <img id="bottomNavCloseTip" src="../images/wda6/close_view_img.gif" alt="" style="display:none;position:absolute;left:516px;top:7px;"/>')
			          .append('      <img id="bottomNavClose" src="' + opts.fileBottomNavCloseImage + '" alt=""/>')
			          .append('      <div id="loadingVideo">')
			          .append('          <a href="javascript:void(0);" id="loadingLinkVideo" onclick="return false;"><img src="' + opts.fileLoadingImage + '" onclick="return false;"></a>')
			          .append('      </div>')
			          /** 播放器嵌套区域添加安装flash插件提示 */
			          .append('      <div id="vplayer_area" style="">')
			          .append('       	<p style="position: absolute; top: 213px; left: 447px;"><a href="http://www.adobe.com/go/getflashplayer">')
                 	  .append('       	<img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" />')
                 	  .append('      	</a></p>')
			          .append('      </div>')
			          .append('   </div>')
			          .append('  </div>');
			$('.myVideobox').remove();
			$("body").append('<div id="' + lightBoxId + '" class="myVideobox myVideoPopCss">' + outerImage.toString() + '</div>').find('#'+lightBoxId).css('z-index',zIndex);
			$('#image_tools_publis_li').hide();
			//添加进入弹出框缓存
			tools.layerIndex.hasLayer(lightBoxId);
			//展示遮罩层
			//tools.maskDiv.show(lightBoxId);
			$('#imageDataContainer').width(opts.widthCurrent);
			currentLightbox4Video = $("#"+lightBoxId);
		};
		
		//初始化视频信息
		var initVideoInfo = function(info){
			var videoName = info?info.name : opts.contentName,
			    size = info?info.size : opts.contentSize,
			    uploadTime = info?info.uploadTime : opts.uploadTime;
			currentLightbox4Video.find('#videoheadName').text(tools.splitName({type:'1',maxLen:32,name:videoName})).attr('title',videoName);
			currentLightbox4Video.find('#video_zise').text(tools.formateSize(size));
			currentLightbox4Video.find('#video_time').text(tools.newFormateTime(uploadTime));
		}

		//调整播放器容器大小
		var resizeContainer = function() {
			var winH = tools.iGet.PageSize().WinH;
			if(winH < opts.containerHeight){
				return;
			}
        };
        
        var resizeOverlayToFitWindow = function(){
			$('#overlay').css({width: $(document).width(), height: $(document).height()});
		};
		
        
        var getPageScroll = function(){
			var xScroll, yScroll;
			var documentElement = document.documentElement;
			var body = document.body;
			if (self.pageYOffset){
				yScroll = self.pageYOffset;
				xScroll = self.pageXOffset;
			} else if (documentElement && documentElement.scrollTop){
				yScroll = documentElement.scrollTop;
				xScroll = documentElement.scrollLeft;
			} else if (body) {
				yScroll = body.scrollTop;
				xScroll = body.scrollLeft;
			}
			var arrayPageScroll = [xScroll,yScroll];
			return arrayPageScroll;
		};
		
		//绑定事件
		var addEventHandlers = function(contentID){
			
			$("#bottomNavClose").unbind().bind('click',end).hover(function(){
				$("#bottomNavCloseTip").show();
			},function(){
				$("#bottomNavCloseTip").hide();
			});
		}
		
		//播放器按钮事件
		//外链  
		var link = function(){
		    caiyun.operate.creatFileLink([opts.contentID]);
		    caiyun.pvlog('fileLink','publish',[opts.contentID],"",flag);
		}
		//分享
		var share = function(){
		    caiyun.operate.createShareFile([opts.contentID]);
		    caiyun.pvlog("fileShare","addShare",[opts.contentID],opts.contentType?opts.contentType:"0",opts.contentSize?opts.contentSize:0,opts.contentSuffix?opts.contentSuffix:"","","",flag);
		}
		//下载
		var download = function(){
		    window.caiyun.operate.userDownload(opts.contentID);
		    caiyun.pvlog('fileOper','download',[opts.contentID],opts.contentType,opts.contentSize,opts.contentSuffix,flag);
		}
		
		var end = function(contentID){
			$('html,body').removeClass('autoOverflow');
			$('#'+lightBoxId).remove();
			//最后一层 清除所有的遮罩
			tools.layerIndex.deleteLayer(lightBoxId);
			tools.maskDiv.hide(lightBoxId);
			//清除缓存中的数据,reload方法不会清除缓存
			if(contentID){
				caiyun.util.cache.delFileCache(window.caiyun.constants.FILE_LIST_CACHEGROUP,contentID);
			}
		}
		
		var updataVideoInfo = function(vidoeInfo){
			initVideoInfo({name:vidoeInfo.contentName,size:vidoeInfo.contentSize,uploadTime:vidoeInfo.uploadTime});
			addEventHandlers(vidoeInfo.contentID);
		}
		
       	return {
       		init            : init,
       		updataVideoInfo : updataVideoInfo,
       		link            : link,
       		share           : share,
       		download        : download
       	}
	})();
})();

var CY={
    link:function(){
	    window.caiyun.lightbox4Video.link();
	},
	share:function(){
	    window.caiyun.lightbox4Video.share();
	},
	download:function(){
	    window.caiyun.lightbox4Video.download();
	}
}
        
