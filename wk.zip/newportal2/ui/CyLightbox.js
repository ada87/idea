/**
 * 图片浏览控件(新版本)
 */
 
;(function($) {
	$.fn.lightbox = function(options) {
		var caiyun = window.caiyun;
		var Validate = caiyun.util.Validate;
		var tools = caiyun.util;
		var wdaAjax = tools.caiyunAjax;
		var iMsgTip = caiyun.ui.iMsgTip;
		var judgement = caiyun.judgement;
		var constants = caiyun.constants;
		var cache = tools.cache;
		var opts = null;
		var that = this;
		var zIndex = 902;//907
		var lightBoxId = 'lightbox_' + zIndex;
		var dialog;
		//旋转角度
        var turn = 0;
        var turning;
		
		
		var operation = {
			getObjById:function(id,type){
				return cache.getFileCache(constants.FILE_LIST_CACHEGROUP, id);
			},
			getFileSrc:function(key) {
				return caiyun.operate.getFileSrc(key);
			},
			getCaches:function() {
				return caiyun.util.cache.getInstanceCache(caiyun.constants.FILE_LIST_CACHEGROUP).getCache();
			},
			getPictrueCaches:function(){
			    return caiyun.util.cache.getInstanceCache(caiyun.constants.PICTURE_LIST_CACHE_GROUP).getCache();
			}
		}
		
		var defaults = {
			allSet: false,
			fileLoadingImage: '../images/wda6/lightbox_loading.gif',
			fileBottomNavCloseImage: '../images/wda6/lightbox_closebtn.gif',
			overlayOpacity: 0.8,
			borderSize: 10,
			imageArray: [],
			cssArray: [], //样式记录
			currentImge: null,
			activeImage: null,
			inprogress: false,
			needsearch: true, //是否需要查询
			isrest: false, //是否需要重置图片
			imgNumber: 0, //图片数量
			resizeSpeed: 350,
			widthCurrent: 960,
			heightCurrent: 510,
			picheight: 0,
			picwidth:0,
			displayTitle: true,
			strings: {
				prevLinkTitle: '点击跳到上一张',
				nextLinkTitle: '点击跳到下一张'
			},	
			loopImages: false
		};
		var isDescBtnCanClick = true,isNameBtnCanClick = true,isTagBtnCanClick = true;
		var imgPreloader,IE6Img;
        
		var init = function(){
			opts = $.extend({}, defaults, options);
			$(window).resize(resizeOverlayToFitWindow).scroll(function(e){
				var scrollY = tools.iGet.PageScroll().Y;
				var top;
				if($('.myLightbox').css('top')){
					top = parseInt($('.myLightbox').css('top').replace('px'));
				}
				else{
					top = 0;
				}
				var $myLightbox = $('.myLightbox');
				if(scrollY <= top){
                	$myLightbox.css({top:scrollY});
                }
			});
			initialize();
			$('.myLightbox').css({top:tools.iGet.PageScroll().Y});
			//#modified
			var images = operation.getCaches();
			//清空图片缓存
			cache.clearPictureCache(constants.PICTURE_LIST_CACHE_GROUP);
			if(images) {
				for (i in images) {
					var n = images[i];
					if(n.contentID && n.contentType == '1') {
						var info = operation.getObjById(n.contentID,2);
			            opts.imageArray.push([info.bigthumbnailURL, opts.displayTitle ? info.contentName : '', n.contentID, info.thumbnailURL]);
			            //存入图片缓存，分页时取不到分页后的图片信息
			            opts.cssArray.push([n.contentID, 0, ""]);//样式记录
			            cache.putPictureCache(constants.PICTURE_LIST_CACHE_GROUP,info);
					}
				}
			}			
			
			showLightbox();
			//加载缩略图
			//timeline不加载
			if(!($('#tl_show_by_opType').css("display")=="block"||$('#tl_show_by_opType').css("display")=="inline")){
			    addSmallPicList();
			    $("#" + (opts.imageArray[opts.activeImage][2])).parent().addClass('picselected');
			    $("#picul").css("width",(1280 + Math.abs(6 - opts.activeImage) * 88));
			    $("#picul").css("left",((6 - opts.activeImage) * 88));
			    
			}
			//统计
            caiyun.pvlog('fileOper','viewPic',getCurrentImageInfo().contentID);
            //快捷关闭事件
            if(($('.myLightbox').length)){
		        easyClose();
		    }
		    updateNav();
		    
		    //添加滚轮事件
            mousewheel.on(document, wheelHandle);
            document.ondragstart = function() {
                return false;
            };
			return $(that);	
		};	
		
		var initialize = function(){
		    opts.needsearch = true;   //是否需要查询下40张图片
			opts.inprogress = false;
			opts.imageArray = [];			
			initLightboxHtml();
			addEventHandlers();
			$(window).bind('resize',function(){
			    $('.alertPhoto_Boxs').css('height',caiyun.util.iGet.PageSize().WinH);
			    $('.img_shows').css('height',caiyun.util.iGet.PageSize().WinH - 215);
			    $('.prev_Abtn').css('height',caiyun.util.iGet.PageSize().WinH -215);
			    $('.next_Abtn').css('height',caiyun.util.iGet.PageSize().WinH -215);
			});
			return true;
		};

		var initLightboxHtml= function (){
			var outerImage = new StringBuffer();
			outerImage.append('<div class="alertPhoto_Boxs" style="height:' +caiyun.util.iGet.PageSize().WinH+ 'px;">')
	                  .append('<a href="javascript:void(0);" class="close_PhotoBoxs" title="关闭">关闭</a>')
	                  .append('<div class="img_boxs">')
	                  .append('<div class="img_title" style="margin-left:0px;">图片标题.jpg</div>')
	                  .append('<div class="prev_Abtn">')
	                  .append('<a href="javascript:void(0);" onclick="javascript:return false;"></a>')
	                  .append('</div>')
	                  .append('<div id="img_showArea" class="img_shows">')
	                  .append('<table width="100%" height="100%">')
	     	          .append('<tr>')
	     		      .append('<td id="imageContainer" algin="middle" valign="middle" style="text-align:center;">')
	     		      .append('<img id="lightboxImage" src="" alt=""/>')
	     		      .append('<div id="loading">')
			          .append('<a href="javascript:void(0);" id="loadingLink" onclick="return false;"><img src="' + opts.fileLoadingImage + '" onclick="return false;"></a>')
			          .append('</div></td>')
	     	          .append('</tr>')
	                  .append('</table>')
	                  .append('</div>')
	                  
	                  .append('<div class="next_Abtn"><a href="javascript:void(0);" onclick="javascript:return false;"></a></div>')
	                  .append('</div>')
	                  .append('<ul class="imgControl-btn">')
	                  .append('<li id="li1"><a href="javascript:void(0);" onclick="javascript:return false;" class="photo_icons0" title="左旋">左旋</a></li>')
	                  .append('<li><a href="javascript:void(0);" onclick="javascript:return false;" class="photo_icons1" title="右旋">右旋</a></li>')
	   	              .append('<li><a href="javascript:void(0);" onclick="javascript:return false;" class="photo_icons2" title="分享文件链接">分享</a></li>')
	   	              .append('<li><a href="javascript:void(0);" onclick="javascript:return false;" class="photo_icons3" title="分享给其他用户">喜欢</a></li>')
	   	              .append('<li><a href="javascript:void(0);" onclick="javascript:return false;" class="photo_icons4" title="下载">下载</a></li>')
	   	              .append('<li><a href="javascript:void(0);" onclick="javascript:return false;" class="photo_icons5" title="删除">删除</a></li>')
	   	              .append('<li style="margin-right:6px;"><a href="javascript:void(0);" onclick="javascript:return false;" class="photo_icons6" title="美化">美化</a></li>')
	                  .append('</ul>')
	                  
	                  //<!---缩略图预览-->
                      .append('<div class="small_pic_show" style="display:block;">')
                      .append('<a href="javascript:void(0);" class="pre-icon"></a>')
                      .append('<a href="javascript:void(0);" class="next-icon"></a>')
                      .append('<div class="mod_focus_list">')
                      .append('<ul id="picul" style="left:0px;">')
                      .append('<li><img id="id1" src="" /></li>')
                      .append('<li><img id="id2" src="" /></li>')
                      .append('<li><img id="id3" src="" /></li>')
                      .append('<li><img id="id4" src="" /></li>')
                      .append('<li><img id="id5" src="" /></li>')            
                      .append('<li><img id="id6" src="" /></li>')
                      .append('<li id="picselected" class="picselected"><img id="id7" src="../images/newportal2/config_img.png" /></li>')
                      .append('<li><img id="id8" src="" /></li>')
                      .append('<li><img id="id9" src="" /></li>')
                      .append('<li><img id="id10" src="" /></li>')
                      .append('<li><img id="id11" src="" /></li>')
                      .append('<li><img id="id12" src="" /></li>')
                      .append('<li><img id="id13" src="" /></li>')
                      .append('</ul>')
                      .append('</div>')
                      .append('</div>') 
                      //<!---缩略图预览 END-->
	                  
			$("body").append('<div id="' + lightBoxId + '" class="myLightbox">' + outerImage.toString() + '</div>').find('#'+lightBoxId).css('z-index',zIndex);
			$('html').css('overflow',"hidden");
            $('body').css('overflow',"hidden");
			
			//屏蔽掉主页面中的键盘事件
			window.caiyun.layershow = true;
			//添加进入弹出框缓存
			tools.layerIndex.hasLayer(lightBoxId);
			tools.maskDiv.show(lightBoxId);
			$('#imageDataContainer').width(opts.widthCurrent);
			//如果是timeline模块调用则隐藏上一张下一张按钮以及各种快捷操作按钮
		    if($('#tl_show_by_opType').css("display")=="block"||$('#tl_show_by_opType').css("display")=="inline"){ 				    
			    $(".prev_Abtn,.next_Abtn").hide();
			    $('.photo_icons2,.photo_icons3,.photo_icons4,.photo_icons5,.photo_icons6').hide();
			    $("#li1").css('margin-left','143px');
			    $(".mod_focus_list").hide();		    
			} 
			
			//如果是在"我收到的分享"目录下不显示功能键 或者 公共账号
            if (caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare) || caiyun.judgement.isInPublisherDir() || caiyun.judgement.isInDraftBox() || caiyun.judgement.isEnterprisePath()) {
                $('.photo_icons2,.photo_icons3,.photo_icons4,.photo_icons5,.photo_icons6').hide(); 
                $("#li1").css('margin-left','143px');
		    }
			
			//工具栏高亮显示
			$(".imgControl-btn li").hover(
				function(){
					$(this).addClass("click");
				},
				function(){
					$(this).removeClass("click");
			    }
			);
			
			//缩略图效果仅HTML5支持
			if($.browser.msie && $.browser.version <= 9){
		        $(".mod_focus_list li").hover(
		            function(){
					    $(this).addClass("hover-ie");
					    $("#picselected").removeClass().addClass("picselected");
				    },
				    function(){
					    $(this).removeClass("hover-ie");
					    $("#picselected").removeClass().addClass("picselected");
				    }
		        );
		    }else{
		        $(".mod_focus_list li").hover(
		            function(){
					    $(this).addClass("hover");
					    $("#picselected").removeClass().addClass("picselected");
				    },
				    function(){
					    $(this).removeClass("hover");
					    $("#picselected").removeClass().addClass("picselected");
				    }
		        );
		    }	
			
			// 去掉IE6下a标签框框
		    $(".alertPhoto_Boxs a").focus(function() {
			    $(this).blur();
		    });
		};
   
		//快速关闭事件
		var easyClose = function(){
	        $('.myLightbox').click(function(){
	            end();
	        });
	        //阻止事件冒泡
	        $('.img_boxs,.small_pic_show,.img_boxs,.imgControl-btn').click(function(event){
		        event.stopPropagation();
	        });
        };
		
		//绑定事件
		var addEventHandlers = function(){
			var ulTimer = null;
			$(".close_PhotoBoxs").click(function(){end(); return false;});
			//上一张，下一张事件
			$('.prev_Abtn,.pre-icon').unbind('click').bind('click',function(){
			    if(opts.activeImage != 0){
			        $('#lightboxImage').removeAttr("style")
			        $('#lightboxImage').removeClass("margin-top,margin-left");
			        $('#lightboxImage').removeClass();
			        turn = 0;
			        changeImage(opts.activeImage - 1);
			        $('.next_Abtn a').removeAttr("style");
			        $('.next-icon').removeAttr("style");
			        
			        $(".picselected").removeClass();
			        $("#" + (opts.imageArray[opts.activeImage][2])).parent().addClass('picselected');
			        $("#picul").css("width",(1280 + Math.abs(6 - opts.activeImage) * 88));
			        $("#picul").css("left",((6 - opts.activeImage) * 88));
			    }
			    if(opts.activeImage == 0){
			        $('.prev_Abtn a').removeClass();
			        $('.prev_Abtn a').css("cursor","default");
			        $('.pre-icon').css("cursor","default");
			    }  
			});
			$('.next_Abtn,.next-icon').unbind('click').bind('click',function(){
			    if(opts.activeImage != (opts.imageArray.length - 1)) {
			        $('#lightboxImage').removeAttr("style")
			        $('#lightboxImage').removeClass();
			        $('#lightboxImage').removeClass("margin-top,margin-left");
			        turn = 0;
			        changeImage(opts.activeImage + 1);
			        $('.prev_Abtn a').removeAttr("style");
			        $('.pre-icon').removeAttr("style");
			        
			        $(".picselected").removeClass();
			        $("#" + opts.imageArray[opts.activeImage][2]).parent().addClass('picselected');
			        $("#picul").css("width",(1280 + Math.abs(6 - opts.activeImage) * 88));
			        $("#picul").css("left",((6 - opts.activeImage) * 88));
			    }
			    if(opts.activeImage == (opts.imageArray.length - 1)) {
			        $('.next_Abtn a').removeClass();
			        $('.next_Abtn a').css("cursor","default");
			        $('.next-icon').css("cursor","default");
			    }
			});
			
			$(document).bind('keydown',escCallBack);
		};
		
		//删除系统缓存被删除的数据项
		var imageArrayDelete = function(imageNum){
		    return opts.imageArray.slice(0,imageNum).concat(opts.imageArray.slice(imageNum + 1));
		};
	    
		var getPageScroll = function(){
			var xScroll, yScroll;
			var documentElement = document.documentElement;
			var body = document.body;
			if (self.pageYOffset){
				yScroll = self.pageYOffset;
				xScroll = self.pageXOffset;
			} else if (documentElement && documentElement.scrollTop){
				yScroll = documentElement.scrollTop;
				xScroll = documentElement.scrollLeft;
			} else if (body) {
				yScroll = body.scrollTop;
				xScroll = body.scrollLeft;
			}
			var arrayPageScroll = [xScroll,yScroll];
			return arrayPageScroll;
		};

		
        var showLightbox = function() {
            resizeOverlayToFitWindow();
            var imageNum = 0;
            var imagesCount = opts.imageArray.length;

            if (opts.currentImge.id && imagesCount > 1) {
                $(opts.imageArray).each(function(i,n){
                	if(opts.imageArray[i][2] == opts.currentImge.id) {
                		imageNum = i;
                		return false;
                	}
                });
            }
            var lightboxTop = 0;
            var lightboxLeft = getPageScroll()[0];
            $('#lightbox').css({top : lightboxTop + 'px', left : lightboxLeft + 'px'}).show();

            //設定圖片位置 
            $('.img_shows').css('width',800);
            $('.img_shows').css('height',caiyun.util.iGet.PageSize().WinH - 215);
            $('.prev_Abtn').css('height',caiyun.util.iGet.PageSize().WinH - 215);
            $('.next_Abtn').css('height',caiyun.util.iGet.PageSize().WinH - 215);
            changeImage(imageNum);
        };		
	    //更换图片
		var changeImage = function(imageNum) {
		    //如果有弹出框事件则不允许使用上一张下一张功能
		    if(!$('#overlay').css('z-index') || $('#overlay').css('z-index') < $('#' + lightBoxId).css('z-index')){
			    if(opts.inprogress){return;}
			    opts.inprogress = true;
			    opts.activeImage = imageNum;
			    $('#loading').show();
			    $('#lightboxImage').attr("src","").hide();
			    doChangeImage();
			    if(opts.activeImage == 0){
			        $('.prev_Abtn a').removeClass();
			        $('.prev_Abtn a').css("cursor","default");
			        $('.pre-icon').css("cursor","default");
			    }else if(opts.activeImage == (opts.imageArray.length - 1)){
			        $('.next_Abtn a').removeClass();
			        $('.next_Abtn a').css("cursor","default");
			        $('.next-icon').css("cursor","default");
			    }else{
			        $('.prev_Abtn a').removeAttr("style");
			        $('.pre-icon').removeAttr("style");
			        $('.next_Abtn a').removeAttr("style");
			        $('.next-icon').removeAttr("style");
			    }
			}
			//enableKeyboardNav();
			//是否需要查询下一批图片
            if(opts.activeImage + 6 >= opts.imageArray.length){
                var pathid = caiyun.operate.getCurrentPathId();
                var catlogpath = caiyun.operate.getCurrentCatalog();
                //查询下一批40张图片并加入图片缓存
                if(opts.needsearch){
                    var queryParams = {}; 
                    var catalogSortType = queryParams['catalogSortType'] ;
                    var contentSortType = queryParams['contentSortType'];
                    var sortDirection = queryParams['sortDirection'];
                    queryParams = {
                        id : pathid,
                        catalogSortType: catalogSortType,
                        contentSortType : contentSortType,
                        sortDirection: sortDirection,
                        contentType : 1,
                        startNumber : opts.imageArray.length + 1,
                        endNumber : (opts.imageArray.length + 41),
                        filtertype : 2,
                        path : catlogpath.path
                    };
                    opts.imgNumber = opts.imageArray.length;
                        
                    //在收到的分享文件夹下不予自动加载，其他文件夹自动加载
                    if(!caiyun.judgement.isReceiveShareFolder(pathid)){
                        queryPic(queryParams);
                    }
                        
                    //如果没有后续图片，增加标示，不再查询
				    if(opts.imageArray.length - opts.imgNumber < 40){
				        opts.needsearch = false;
				    }else{
				        opts.needsearch = true;
				    }
                }
            }
		};
		
		//获取记录样式
		var readCss = function(){
		    var conner = 0;
		    var css = "";
		    $(opts.cssArray).each(function(i,n){
                if(opts.cssArray[i][0] == opts.imageArray[opts.activeImage][2]) {
                    conner = opts.cssArray[i][1];
                    css = opts.cssArray[i][2];
                }
            });
            return {turn:conner, css:css};
		}

		//判断是否正常加载
		var doChangeImage = function() {
		    //如果是IE6的情况
			if($.browser.msie && $.browser.version <= 6){
                var onImageLoad = function(img){
                	var param = getBigPicSize(img);
                	opts.picheight = param.height;
                    opts.picwidth = param.width;
                    $('#lightboxImage').attr('src',img.src).css({width:param.width,height:param.height});
                    showImage();
                    toolController.insertTool();
                };
                var onErrored = function(){
                    $('#lightboxImage').attr('src',"../images/wda6/images_delete.png").css({width:"321px",height:"126px"});        	
                    showImage();               	
                };
                IE6Img = new tools.newEnhancedImage(opts.imageArray[opts.activeImage][0], onImageLoad, onErrored);
                IE6Img.load();
                //如果是在"我收到的分享"目录下不显示功能键 或者 公共账号
                if (caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare) || caiyun.judgement.isInPublisherDir() || caiyun.judgement.isInDraftBox() || caiyun.judgement.isEnterprisePath()) {
                    $('.photo_icons2,.photo_icons3,.photo_icons4,.photo_icons5,.photo_icons6').hide(); 
                    $("#li1").css('margin-left','143px');
		        }
		        
			}else{
				imgPreloader = new Image();
                imgPreloader.onload = function() {
                    var param = getBigPicSize(imgPreloader);
                    opts.picheight = param.height;
                    opts.picwidth = param.width;
                    $('#lightboxImage').attr('src', opts.imageArray[opts.activeImage][0]).width(param.width).height(param.height);
                    if(!($.browser.msie&&$.browser.version<=9)){
                        var cssnote = readCss();
                        if(cssnote.turn != 0){
                            turn = cssnote.turn;
                            doTurn(turn);
                        }
                    }
                    showImage();
                    toolController.insertTool();
                };
                imgPreloader.onerror = function(){
                	$('#lightboxImage').attr('src', '../images/wda6/images_delete.png').width(321).height(126);
                	showImage();
                };
                imgPreloader.src = opts.imageArray[opts.activeImage][0];
                
			}
			
			resetImageInfo();
            //如果是在"我收到的分享"目录下不显示功能键 或者 公共账号 或者企业中
            if (caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare) || caiyun.judgement.isInPublisherDir() || caiyun.judgement.isInDraftBox() || caiyun.judgement.isEnterprisePath()) {
                $('.photo_icons2,.photo_icons3,.photo_icons4,.photo_icons5,.photo_icons6').hide();
                $("#li1").css('margin-left','143px');   
		    }  
		};
		
		//图片做转换时的样式更改
		var changeCss = function(){
		    $('#lightboxImage').removeAttr("style");
			$('#lightboxImage').removeClass("margin-top,margin-left");
			$('#lightboxImage').removeClass();
			turn = 0;   
		}
		
		//获取该ID图片在数组中的位置
		var getPicIndex = function(id){
		    var index = 0;
		    $(opts.imageArray).each(function(i,n){
                if(opts.imageArray[i][2] == id) {
                    index = i;
                }
            });
            return index;
		}
		
		//绑定缩略图事件
		var bindSmallPicAct = function(obj,id){
		    obj.unbind('click').bind('click',function(){
		        var num = getPicIndex(id);
                changeCss();
			    changeImage(num);
			    $(".picselected").removeClass();
			    $("#" + id).parent().addClass('picselected');
			    $("#picul").css("width",(1280 + Math.abs(6 - opts.activeImage) * 88));
			    $("#picul").css("left",((6 - num) * 88));
            });
		}
		
		//加载缩略图
		var addSmallPicList = function(){
		    $("#picul li").remove();
		    for(var i=0 ;i<opts.imageArray.length;i++){
		        $('#picul').append("<li><img id='" + opts.imageArray[i][2] + "' src='../images/newportal2/config_img.png'/></li>");
		        var imgobj = $("#" + opts.imageArray[i][2]);
		        loadSmallPic(opts.imageArray[i][0],imgobj);
		        bindSmallPicAct(imgobj,opts.imageArray[i][2]);
		    }
		}
		
		
		//加载小图，失败则显示底图
		var loadSmallPic = function(src,obj){
		    //如果是IE6的情况
			if($.browser.version === '6.0'){
                var onImageLoad = function(img){
                    obj.attr('src',img.src);
                };
                var onErrored = function(){
                    obj.attr('src', '../images/newportal2/config_img.png');            	
                };
                IE6Img = new tools.newEnhancedImage(src, onImageLoad, onErrored);
                IE6Img.load();
           }else{
				var img = new Image();
                img.onload = function() {
                    obj.attr('src', src);
                };
                img.onerror = function(){
                	obj.attr('src', '../images/newportal2/config_img.png');
                };
                img.src = src;
			}
		}	
	
		// 获取拼装目录查询参数
        var getQueryToByFolderParams = function(param) {
            
            var hdhd = param.id || constants.rootIds.myFolder;
            var params = {
                contentID : param.id || constants.rootIds.myFolder,
                catalogSortType : param.catalogSortType
                        || constants.gridInitConfig.catalogSortType,
                contentSortType : param.contentSortType
                        || constants.gridInitConfig.contentSortType,
                filtertype : param.filtertype || 0,
                startNumber : param.startNumber
                        || constants.gridInitConfig.startNum,
                endNumber : param.endNumber || constants.gridInitConfig.endNum,
                sortDirection : param.sortDirection || 1,
                // 文件类型
                contentType :  1
            };
            if(param.path){
                $.extend(params,{path:param.path});
            }
            
            return params;
        };
		
		//查询该文件夹下指定个数的图片文件
		var queryPic = function(param){
		    var data = getQueryToByFolderParams(param); 
		    var query_url = "webdisk2/queryContentAndCatalog!disk.action";
			$.ajax({
			    url:query_url, 
			    data:data, 
			    //async:false,
			    dataType:"json", 
			    type:"POST", 
			    success:function (res) {
				    if ($.trim(res.showMessage)) {
				        // 弹出error对话框
				        window.caiyun.ui.iMsgTip.tip(res.showMessage,'error');
			        } else {
			            if(res.dci.contents) {
				            for (i in res.dci.contents) {
					            var n = res.dci.contents[i];
					            if(n.contentID && n.contentType == '1') {
			                        opts.imageArray.push([n.bigthumbnailURL, opts.displayTitle ? n.contentName : '', n.contentID, n.thumbnailURL]);
			                        //存入图片缓存，分页时取不到分页后的图片信息
			                        opts.cssArray.push([n.contentID, 0, ""]);//样式记录
			                        cache.putPictureCache(constants.PICTURE_LIST_CACHE_GROUP,n);
			                        addSmallPicList();
			                        $("#" + (opts.imageArray[opts.activeImage][2])).parent().addClass('picselected');
			                        $("#picul").css("width",(1280 + Math.abs(6 - opts.activeImage) * 88));
			                        $("#picul").css("left",((6 - opts.activeImage) * 88));
					            }
				            }
			            }
			        }
			    },
			    error : function(){
			        opts.needsearch = false;
			    }
			});
		}
        	
		/*
		*加载图片进行压缩
		*/
		var getBigPicSize = function(param){
			var height = param.height;
			var width = param.width;
			// 75-固定间隙
			var maxheight = caiyun.util.iGet.PageSize().WinH - 215;
			if(height > maxheight){
                width = maxheight/height*width;
                height = maxheight;					
			}
			var maxwidth = 800;
			if(width > maxwidth){
			    width = maxwidth;
			    height = maxwidth/width*height;
			}
			return {width:width,height:height};
		};
		
		/*
		*图片旋转再缩放
		*/
		var getSmallPicSize = function(param){
			var height = param.height;
			var width = param.width;
			// 75-固定间隙
			var maxheight = caiyun.util.iGet.PageSize().WinH - 215;
			if(width > maxheight){
                height = maxheight/width*height;
                width = maxheight;					
			}
			return {width:width,height:height};
		};	
			
		//重设图片信息
		var resetImageInfo = function(){
			var currentImageId = opts.imageArray[opts.activeImage][2];
			var currentImageInfo = $.trim(operation.getObjById(currentImageId,2)) || '' ;
			var currentImageName = opts.imageArray[opts.activeImage][1];
			var currentImageDesc = $.trim(currentImageInfo.contentDesc) || '';
			var currentImageTags = currentImageInfo.tags || [];			
			
			/*********************** 添加图片名称 *************************/
			$('.img_title').text(tools.splitName({type:'1',maxLen:32,name:currentImageName})).attr('title',currentImageName);
			
		};
		
		/**
		 * 获取当前图片的信息
		 */
		var getCurrentImageInfo = function(){
			var imageID = opts.imageArray[opts.activeImage][2];
			if(!operation.getCaches()[imageID]){
			    return operation.getPictrueCaches()[imageID];
			}else{
			    return operation.getCaches()[imageID];
			}
		}
		
		//将旋转样式记录到记录表中
		var recordCss = function(id,num,css){
			$(opts.cssArray).each(function(i,n){
                if(opts.cssArray[i][0] == id) {
                    opts.cssArray[i][1] = num;
                	opts.cssArray[i][2] = css;
                }
               });
		}

	    //实现旋转
		var doTurn = function(num){
			if(num == 0){
			    $('#lightboxImage').removeClass();
			    var width = opts.picwidth;
			    var height = opts.picheight;
			    //IE设置滤镜
			    if($.browser.msie && $.browser.version <= 9){
			        $('#lightboxImage').removeAttr("style").attr("style","width:" + width + "px;height:" + height + "px;filter:progid:DXImageTransform.Microsoft.BasicImage(rotation=0);");
			    }else{
			        $('#lightboxImage').css({width:width,height:height});
			        $('#lightboxImage').addClass("rot0");
			    }
			    recordCss(opts.imageArray[opts.activeImage][2],num,"rot0");
			}else if(num == 90 || num == -270 ){
			    var width = opts.picwidth;
			    var height = opts.picheight;
			    $('#lightboxImage').removeClass();
			    //IE设置滤镜
			    if($.browser.msie && $.browser.version <= 9){
			        if(opts.picwidth > caiyun.util.iGet.PageSize().WinH - 215){
			            width = (caiyun.util.iGet.PageSize().WinH - 215);
			            height = opts.picheight * ((caiyun.util.iGet.PageSize().WinH - 215)/opts.picwidth);
			        }
			        var hh = Math.abs(Math.sin(Math.PI/2) * opts.picwidth) + Math.abs(Math.cos(Math.PI/2) * opts.picheight);
			        var ww = Math.abs(Math.sin(Math.PI/2) * opts.picheight) + Math.abs(Math.cos(Math.PI/2) * opts.picwidth);
			        
			        var style = "filter:progid:DXImageTransform.Microsoft.Matrix(M11=" + Math.cos(Math.PI/2) + ",M12= "+ -Math.sin(Math.PI/2) +",M21="+ Math.sin(Math.PI/2) +",M22="+Math.cos(Math.PI/2)+",SizingMethod='auto expand');";
			        $('#lightboxImage').removeAttr("style").attr("style","width:"+width+"px;height:"+height+"px;" + style);
					$('#lightboxImage').css({"margin-top":(opts.picheight-hh)/2+"px","margin-left":(opts.picwidth-ww)/2+"px"});
			    }else{
			        if(opts.picwidth > (caiyun.util.iGet.PageSize().WinH - 215)){
			            width = (caiyun.util.iGet.PageSize().WinH - 215);
			            height = opts.picheight * ((caiyun.util.iGet.PageSize().WinH - 215)/opts.picwidth);
			        }
			        $('#lightboxImage').css({width:width,height:height});
			        $("#lightboxImage").addClass("rot1");
			    }
			    recordCss(opts.imageArray[opts.activeImage][2],num,"rot1");
			}else if(num == 180 || num == -180 ){
			    var width = opts.picwidth;
			    var height = opts.picheight;
			    $('#lightboxImage').removeClass();
			    //IE设置滤镜
			    if($.browser.msie && $.browser.version <= 9){
			        $('#lightboxImage').removeAttr("style").attr("style","width:" + width + "px;height:" + height + "px;filter:progid:DXImageTransform.Microsoft.BasicImage(rotation=2);");
			    }else{
			        $('#lightboxImage').css({width:width,height:height});
			        $('#lightboxImage').addClass("rot2");
			    }
			    recordCss(opts.imageArray[opts.activeImage][2],num,"rot2");
			}else if(num == 270 || num == -90 ){
			    var width = opts.picwidth;
			    var height = opts.picheight;
			    $('#lightboxImage').removeClass();
			    //IE设置滤镜
			    if($.browser.msie && $.browser.version <= 9){
			        if(opts.picwidth > (caiyun.util.iGet.PageSize().WinH - 215)){
			            width = (caiyun.util.iGet.PageSize().WinH - 215);
			            height = opts.picheight * ((caiyun.util.iGet.PageSize().WinH - 215)/opts.picwidth);
			        }
			        var hh = Math.abs(Math.sin(Math.PI/2) * opts.picwidth) + Math.abs(Math.cos(Math.PI/2) * opts.picheight);
			        var ww = Math.abs(Math.sin(Math.PI/2) * opts.picheight) + Math.abs(Math.cos(Math.PI/2) * opts.picwidth);
			        var style = "filter:progid:DXImageTransform.Microsoft.Matrix(M11=" + -Math.cos(Math.PI/2) + ",M12= "+ Math.sin(Math.PI/2) +",M21="+ -Math.sin(Math.PI/2) +",M22="+ -Math.cos(Math.PI/2)+",SizingMethod='auto expand');";
			        $('#lightboxImage').removeAttr("style").attr("style","width:"+width+"px;height:"+height+"px;" + style);
				    $('#lightboxImage').css({"margin-top":(opts.picheight-hh)/2+"px","margin-left":(opts.picwidth-ww)/2+"px"});
			    }else{
			        if(opts.picwidth > (caiyun.util.iGet.PageSize().WinH - 215)){
			            width = (caiyun.util.iGet.PageSize().WinH - 215);
			            height = opts.picheight * ((caiyun.util.iGet.PageSize().WinH - 215)/opts.picwidth);
			        }
			        $('#lightboxImage').css({width:width,height:height});
			        $('#lightboxImage').addClass("rot3");
			    }
			    recordCss(opts.imageArray[opts.activeImage][2],num,"rot3");
			}
	    }
		
		//加载工具
		var toolController =  (function(){
			
			var insertTool = function(){
				
				//绑定事件
				bindAct();
			}
			
			var isCanPrint = function(){
				var suffix = getCurrentImageInfo().contentSuffix;
				if(suffix.toUpperCase() == 'JPG'){
					return true;
				}
				return false;
			}
		
			//给按钮绑定事件1.外链 2.共享 3.下载 4.删除 5.美图秀秀 6.冲印
			var bindAct = function(){
				var container = $(".image_tools");	
				//功能键 左旋
				$(".photo_icons0").unbind().bind('click',function(){
				    turn -= 90;
				    if(turn == -360){
				        turn = 0;
				    }
				    doTurn(turn);
				}); 
				//右旋
				$(".photo_icons1").unbind().bind('click',function(){
			        turn += 90;
				    if(turn == +360){
				        turn = 0;
				    }
				    doTurn(turn);
				});  
				//功能键 外链
				$(".photo_icons2").unbind().bind('click',function(){
				    if($.browser.msie){
				        document.detachEvent('keydown', stopDefoult);
				    }else{
				        document.removeEventListener('keydown', stopDefoult, false);
				    }
					caiyun.operate.creatFileLink([opts.imageArray[opts.activeImage][2]]);	
				});
				//分享
				$(".photo_icons3").unbind().bind('click',function(){
				    if($.browser.msie){
				        document.detachEvent('keydown', stopDefoult);
				    }else{
				        document.removeEventListener('keydown', stopDefoult, false);
				    }
					caiyun.operate.createShareFile([opts.imageArray[opts.activeImage][2]]);
				});
				//下载
				$(".photo_icons4").unbind().bind('click',function(){
					window.caiyun.operate.userDownload([opts.imageArray[opts.activeImage][2]]);
				});
				//删除
				$(".photo_icons5").unbind().bind('click',function(){
				    //创建对话框
					dialog = caiyun.ui.msgBox({
					 			title : "系统提示",
						 		width :650,
					 			html :'<div class="popContent">'
				                      + '<div class="system_main"></div>'
                                      + '<div class="off_line_tips_YN">'
                                      + '<div class="tips_img"></div>'
                                      + '<div class="floatleft" style="width:420px;">'
                                      + '<p>确定要把此文件（夹）放入回收站?</p>'
                                      + '<p>你可以进入回收站彻底删除或恢复此文件(夹)</p>'
                                      + '</div></div></div>',
					 	        btnName :["确定","取消"],
					 	        okHandle :function(){
				         	    caiyun.operate.deleteFile([opts.imageArray[opts.activeImage][2]],function(){
				             	    //如果当前删除的图片不是最后一张则自动替换下一张图片，否则将退出图片浏览
				         	        $("#" + opts.imageArray[opts.activeImage][2]).parent().remove();
				         	        opts.imageArray = imageArrayDelete(opts.activeImage);
				         	        cache.delFileCache(constants.FILE_LIST_CACHEGROUP, opts.imageArray[opts.activeImage][2]);
				             	    if(opts.activeImage < opts.imageArray.length){
				                        //删除系统缓存相应数据
				                 	    changeImage(opts.activeImage);
				                 	    $(".picselected").removeClass();
			                            $("#" + opts.imageArray[opts.activeImage][2]).parent().addClass('picselected');
			                            $("#picul").css("width",(1280 + Math.abs(6 - opts.activeImage) * 88));
			                            $("#picul").css("left",((6 - opts.activeImage) * 88));
				                 	    if(opts.activeImage == (opts.imageArray.length - 1)) {
			                                $('.next_Abtn a').removeClass();
			                            }
				             	    }else{
				                 	    end();
				             	    }					    
						 	    });
						 	dialog.close();
						}});
						dialog.show();			
				});
				
			    //美图秀秀
				$(".photo_icons6").unbind().bind('click',function(){
					beautifyImage.removeLink().initXiuxiu();
					disableKeyboardNav();
					$('ul').hide();
                    //一键美化pv统计
                    caiyun.pvlog('fileOper','picembellish',[opts.imageArray[opts.activeImage][2]]);
				});
				//冲印
				$(".photo_icons7").unbind().bind('click',function(){
					var imageInfo = getCurrentImageInfo();
					var opts = {
						contentID : imageInfo.contentID,
						thumbnailURL : imageInfo.thumbnailURL
					}
					//关闭当前的浏览界面
					end();
					caiyun.ui.model.printImage.getLightBox(opts);
				});
			}
			
			return {
				insertTool : insertTool
			}
		})();
		
		
		
		/**
		 * 一键美化
		 */
		var beautifyImage = {
			//流程标记 是否需要刷新页面
			flowFlag : false,
			
			//移除上下点击层
			removeLink : function(){
				$(".prev_Abtn,.next_Abtn").hide();
				return this;
			},
			//重新添加上下点击层
			addLink : function(){
			    if($('#tl_show_by_opType').css("display")=="none"){
				    updateNav();
				    $('.photo_icons0,.photo_icons1,.photo_icons2,.photo_icons3,.photo_icons4,.photo_icons5,.photo_icons6,.img_boxs > ul').show();
			    }
				return this;
			},
			
			//将png保存为jpg格式的url
			pngToJpgUrl : "", 
			//将png保存为jpg格式的uploadCode
			pngToJpgUploadCode : "",
			
			/**
			 * 缓存文件命名
			 * newName : 新文件名
			 * nameWithoutSuffix ： 不带后缀的文件名
			 * oldSuffix : 旧的文件名
			 * newSuffix : 新的文件名
			 */
			fileNameCache : {},
			
			/**
			 * 重命名规则
			 * 以时间yyyymmdd24Hmmss结尾 则去除加上当前的时间
			 * 没有则直接加上时间
			 */
			rename : function(imageName ,suffix){
				var nameWithoutSuffix = tools.removeSuffix(imageName);
				var regexp = new RegExp("_20\\d{12}$");
				/** 文件后缀规则 png图片则不变,其他格式jpg */
				var newSuffix = suffix == "png"?"png":"jpg";
				var nameObj = {};
				
				if(regexp.test(nameWithoutSuffix)){
					nameWithoutSuffix = nameWithoutSuffix.replace(regexp ,"_"+window.caiyun.util.simpleDateformat());
				}else{
					nameWithoutSuffix += "_"+window.caiyun.util.simpleDateformat();
				}			
				nameObj = {
					newName : nameWithoutSuffix + "." +newSuffix,
			 	    nameNoSuffix : nameWithoutSuffix ,
			        oldSuffix : suffix ,
			        newSuffix : newSuffix
				}
				beautifyImage.fileNameCache = nameObj;
				return nameObj;
			},
			
			//初始化插件		
			initXiuxiu : function(){
				var _self = beautifyImage;
				var imageCtx = getCurrentImageInfo();
				var imageSrc = opts.imageArray[opts.activeImage][0],
					imageName = opts.imageArray[opts.activeImage][1],
					imageID = opts.imageArray[opts.activeImage][2];
				    
				$("#imageContainer").append("<div id='objectBox'></div>");
				$("#lightboxImage").hide();
				$(".image_tools").fadeOut("fast");
				
				var contentName =  imageCtx.contentName;
				var suffix = imageCtx.contentSuffix;
				//文件别名
				var cache = _self.rename(imageName,suffix);
				
				var nameWithoutSuffix = cache.nameNoSuffix || "";
								
				var box = $("#imageContainer"),
				    boxHeight = box.height();
				
				//设置文件上传的filename参数
				xiuxiu.setLaunchVars("file_name", nameWithoutSuffix);
				xiuxiu.embedSWF("objectBox",1,750,boxHeight,"myXiuXiu");
				
				
				xiuxiu.onInit = function(){
					
					xiuxiu.loadPhoto(imageSrc);
					xiuxiu.setUploadType(2);

					//回调方法			
					var callback = function(res){
						var uploadUrl , uploadTaskID , Uploadcode , $xml;
						
						uploadUrl = beautifyImage.parseXML(res , "redirectionUrl");
						uploadTaskID = beautifyImage.parseXML(res , "uploadTaskID");
						//添加渠道信息
						uploadUrl = uploadUrl.replace('&oprChannel=10000025','&oprChannel=9');
						Uploadcode = beautifyImage.base64encode(ownerMSISDN+':'+uploadTaskID);
						xiuxiu.setUploadDataFieldName("file");
						xiuxiu.setUploadArgs({"uploadCode":Uploadcode});
						xiuxiu.setUploadURL(uploadUrl);
					}
					
					
					//预处理图片上传
					beautifyImage.beforeUploadAct({
						parentCatalogId    : imageCtx.parentCatalogId,
						nameWithoutSuffix  : nameWithoutSuffix,
						contentSize        : imageCtx.contentSize,
						suffix             : cache.newSuffix
					} , callback);
					
					//关闭按钮
					xiuxiu.onClose = function(id) {
						beautifyImage.cancelBeautify();
					}
					
					//上传之前
					xiuxiu.onBeforeUpload = function(data, id) {
						if(getCurrentImageInfo().contentSuffix == 'png' && data.type == "jpg"){
							xiuxiu.setUploadURL(beautifyImage.pngToJpgUrl);
							xiuxiu.setUploadArgs({"uploadCode":beautifyImage.pngToJpgUploadCode});
						}
					}
					
					//上传完毕
					xiuxiu.onUploadResponse = function(){
						beautifyImage.cancelBeautify();
						beautifyImage.flowFlag = true;
						beautifyImage.fileNameCache = {};
					}
					
					xiuxiu.onDebug = function (data){
						alert("错误响应" + data);
					}
					
				}
				return this;
			},
			
			//结束一键美化
			cancelBeautify : function(){
				$("#myXiuXiu").remove();
				$("#lightboxImage").show();
				$(".image_tools").fadeIn("fast");
				beautifyImage.addLink();
				enableKeyboardNav();
				$('ul').show();
			},
			
			/**
			 * 上传之前获取uploadurl处理
			 * data = {
			 * 		  parentCatalogId : 父目录ID
			 * 		  newName : 新文件文件名(不包括后缀)
			 * 		  suffix  : 文件后缀
			 * 		  contentSize : 文件大小
			 * 		  }
			 * 	
			 */
			beforeUploadAct : function(data,callback){
				
				beautifyImage.pngToJpgUrl = "";
				beautifyImage.pngToJpgUploadCode = "";
				if(data){
					beautifyImage.beforeHand({
						catalogId : data.parentCatalogId,
						name 	  : data.nameWithoutSuffix + "." + data.suffix,
						size      : data.contentSize,
						tag		  : "",
						desc 	  : ""
					} , callback);
					
					//对于.png的图片发送两次请求,分别后缀为jpg和png,防止png图片不能保存,默认png图片保存格式是png
					if('png' == data.suffix){
						beautifyImage.beforeHand({
							catalogId : data.parentCatalogId,
							name 	  : data.nameWithoutSuffix + ".jpg",
							size      : data.contentSize,
							tag		  : "",
							desc 	  : ""
						},beautifyImage.savePngUrl);
					}
				}
			},
			
			//保存png保存为jpg格式的URL
			savePngUrl : function(res){
				var uploadUrl , uploadTaskID , Uploadcode , $xml;
				
				uploadUrl = beautifyImage.parseXML(res , "redirectionUrl");
				uploadTaskID = beautifyImage.parseXML(res , "uploadTaskID");
				//添加渠道信息
				uploadUrl = uploadUrl.replace('&oprChannel=10000025','&oprChannel=9');
				Uploadcode = beautifyImage.base64encode(ownerMSISDN+':'+uploadTaskID);
				
				beautifyImage.pngToJpgUploadCode = Uploadcode;
				beautifyImage.pngToJpgUrl = beautifyImage.parseXML(res ,"redirectionUrl");
			},
			
			//获取XML字符串中节点
			parseXML : function(xmlStr,key){
				if(!xmlStr || !key){
					return "";
				}
				var $xml = $(beautifyImage.loadXML(xmlStr));
				return $xml.find(key).text();
			},
			

			/**
			 * 上传第一步请求
			 * @ignore
			 * @param {object} obj
			 * 					contentName : 新图片名
			 * 					contentSize : 图片大小
			 * 					contentTAG  ：
			 * 					contentDescription : 
			 * @param {string} number
			 */
			beforeHand : function(obj,callback){
				var _url = "webdiskjsonp!webUploadFileRequest.action" ,
				  _jsonp = "jsoncallback";
				
				var data = new Object();
				data.param1 = obj.catalogId ;
				data.date = new Date().getTime();
				if(caiyun.judgement.isEnterprisePath()){
                    data.path = caiyun.judgement.getPathForEnterprise();
                }
				data['up[0].contentName'] = encodeURI(obj.name);
				data['up[0].contentSize'] = obj.size;
				data['up[0].contentTAG'] = obj.tag;
				data['up[0].contentDescription'] = obj.desc;
				
				$.ajax({
					url: _url,
					data: data,
					jsonp:_jsonp,
					dataType: "jsonp",
					type: "post",
					success: function(json){
						var r = json.result || json;
						if($.trim(r.message) == "" && r.resultXml && $.isFunction(callback)){
							callback(r.resultXml);
						}
					},
					error: function(r){
					}
				});
			},
			//base64编码
			base64encode : function(str) {
			    var out, i, len;
			    var c1, c2, c3;
			    var base64encodechars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
			    len = str.length;
			    i = 0;
			    out = "";
			    while (i < len) {
			        c1 = str.charCodeAt(i++) & 0xff;
			        if (i == len) {
			            out += base64encodechars.charAt(c1 >> 2);
			            out += base64encodechars.charAt((c1 & 0x3) << 4);
			            out += "==";
			            break;
			        }
			        c2 = str.charCodeAt(i++);
			        if (i == len) {
			            out += base64encodechars.charAt(c1 >> 2);
			            out += base64encodechars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xf0) >> 4));
			            out += base64encodechars.charAt((c2 & 0xf) << 2);
			            out += "=";
			            break;
			        }
			        c3 = str.charCodeAt(i++);
			        out += base64encodechars.charAt(c1 >> 2);
			        out += base64encodechars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xf0) >> 4));
			        out += base64encodechars.charAt(((c2 & 0xf) << 2) | ((c3 & 0xc0) >> 6));
			        out += base64encodechars.charAt(c3 & 0x3f);
			    }
			    return out;
			},
			
			//支持IE的XML解析方式
			loadXML : function(xmlString){
		        var xmlDoc=null;
		        //判断浏览器的类型
		        //支持IE浏览器 
		        if(!window.DOMParser && window.ActiveXObject){   //window.DOMParser 判断是否是非ie浏览器
		            var xmlDomVersions = ['MSXML.2.DOMDocument.6.0','MSXML.2.DOMDocument.3.0','Microsoft.XMLDOM'];
		            for(var i=0;i<xmlDomVersions.length;i++){
		                try{
		                    xmlDoc = new ActiveXObject(xmlDomVersions[i]);
		                    xmlDoc.async = false;
		                    xmlDoc.loadXML(xmlString); //loadXML方法载入xml字符串
		                    break;
		                }catch(e){
		                }
		            }
		        }
		        //支持Mozilla浏览器
		        else if(window.DOMParser && document.implementation && document.implementation.createDocument){
		            try{
		                /* DOMParser 对象解析 XML 文本并返回一个 XML Document 对象。
		                 * 要使用 DOMParser，使用不带参数的构造函数来实例化它，然后调用其 parseFromString() 方法
		                 * parseFromString(text, contentType) 参数text:要解析的 XML 标记 参数contentType文本的内容类型
		                 * 可能是 "text/xml" 、"application/xml" 或 "application/xhtml+xml" 中的一个。注意，不支持 "text/html"。
		                 */
		                domParser = new  DOMParser();
		                xmlDoc = domParser.parseFromString(xmlString, 'text/xml');
		            }catch(e){
		            }
		        }else{
		            return null;
		        }
		
		        return xmlDoc;
		    }
		};
		
		/***************************************关闭按钮************************************************/

		var end = function(){
		    //判断是否还存在其他的窗体
		    if(tools.layerIndex.layerStor.length > 0){ 
		        //如果存在,则需要获取最近弹出的窗体z-index值.
			    var z_index = $('#' + tools.layerIndex.layerStor[tools.layerIndex.layerStor.length - 1]).css('z-index');
			    //如果有窗体在图片上
			    if(z_index > zIndex){
			        return;
			    } 
		    }
		    if(!($('.myLightbox').length)){
		        return;
		    }
			disableAllKeyboardNav();
			var isIE6 = ($.browser.msie && $.browser.version == '6.0');
			var imgLoad = isIE6 ? {} : null;
			var imgOnerr = isIE6 ? function(){
				$('#lightboxImage').remove();
				$('#'+lightBoxId).remove();
				tools.maskDiv.hide(lightBoxId);
				$("select, embed, object").css("visibility","visible")
			} : null;
			if(imgPreloader){
				imgPreloader.onload = imgLoad;
				imgPreloader.onerror = imgOnerr;
			}
			else{
				var imgDOM = document.getElementById('lightboxImage');
				imgDOM.onload = imgLoad;
				imgDOM.onerror = imgOnerr;
			}
			$('#lightboxImage').remove();
			$('#'+lightBoxId).remove();
			tools.layerIndex.deleteLayer(lightBoxId);
			tools.maskDiv.hide(lightBoxId);
			if(beautifyImage.flowFlag){
				caiyun.operate.reLoad();
				beautifyImage.flowFlag = false;
			}
			$("select, embed, object").css("visibility","visible")
			$('body').css({"overflow":""});
			$('html').css({"overflow":"auto"});
			//屏蔽掉主页面中的键盘事件
			window.caiyun.layershow = false;
			//删除滚轮事件
            mousewheel.un(document, wheelHandle);
		    if($.browser.msie){
		        document.detachEvent('keydown', stopDefoult);
		    }else{
				document.removeEventListener('keydown', stopDefoult, false);
		    }
		    document.ondragstart = function() {
                return true;
            };
			return false;
		};
        //预读上一张图片和下一张图片
		var preloadNeighborImages = function(){
			if ((opts.imageArray.length - 1) > opts.activeImage) {
				preloadNextImage = new Image();
				preloadNextImage.src = opts.imageArray[opts.activeImage + 1][0];
			}
			if (opts.activeImage > 0) {
				preloadPrevImage = new Image();
				preloadPrevImage.src = opts.imageArray[opts.activeImage - 1][0];
			}
		};
        //显示图片
		var showImage = function(){
		    $('#loading').hide();
			$('#lightboxImage').fadeIn("fast");
			updateDetails();
		    preloadNeighborImages();
			opts.inprogress = false;
			$('.image_tools').show();
		};
		

		var updateDetails = function() {
			resizeOverlayToFitWindow();
			//updateNav();
			enableKeyboardNav();
		};

		var resizeOverlayToFitWindow = function(){
			$('#overlay').css({width: $(document).width(), height: $(document).height()}).addClass("overlay_photo");
			
		};

        // 去掉IE6下a标签框框
		$('.prev_Abtn','.next_Abtn').find("a").focus(function() {
			$(this).blur();
		});
		
		var updateNav = function() {
			if (opts.imageArray.length > 1) {
			    $('.prev_Abtn a').removeClass();
				    if($('#tl_show_by_opType').css("display")=="none"){
					    $('.prev_Abtn').show().hover(function(){
					        if(opts.activeImage != 0) {
					            $('.prev_Abtn a').removeClass().addClass("hover"); 
					            $('.prev_Abtn a').removeAttr("style");
					        }
					    },function(){
					        //取消
					        $('.prev_Abtn a').removeClass();
					        $('.prev_Abtn a').css("cursor","default");
					    });
			        }
				$('.next_Abtn a').removeClass();
					if($('#tl_show_by_opType').css("display")=="none"){
					    $('.next_Abtn').show().hover(function(){
					        if(opts.activeImage != (opts.imageArray.length - 1)) {
					            $('.next_Abtn a').removeClass().addClass("hover");
					            $('.next_Abtn a').removeAttr("style");
					        }
					    },function(){
					        $('.next_Abtn a').removeClass();
					        $('.next_Abtn a').css("cursor","default");
					    });
			        }
				//enableKeyboardNav();
			}
		};
		
		var stopBubble = function(e){ 
           ///阻止默认浏览器动作(W3C)  
           if ( e && e.preventDefault ){ 
               e.preventDefault(); 
           //IE中阻止函数器默认动作的方式 
           }else{ 
               window.event.returnValue = false;
           } 
           return false;    
        }   
        /*
        //阻止浏览器默认事件
        var bindStopDefaultAct = function(e){
            stopBubble(e);
            nextAndPreCallBack(e);
        }
        */
        
        var stopDefoult = function (e) { e.preventDefault(); }
        
		var nextAndPreCallBack = function(e){
			var o = e.data.opts;
			var keycode = e.keyCode;
			var escapeKey = 27;
			var key = String.fromCharCode(keycode).toLowerCase();
			
			//如果在timeline中则取消掉键盘上一张下一张事件
			if($('#tl_show_by_opType').css("display")=="none"){ 				   		    
                if (keycode == 37 || keycode == 38 || keycode == 33) { 
				    if(o.activeImage != 0){
				        $('#lightboxImage').removeAttr("style");
				        $('#lightboxImage').removeClass();
					    disableKeyboardNav();
					    turn = 0;
					    changeImage(o.activeImage - 1);
					    
					    $(".picselected").removeClass();
			            $("#" + (opts.imageArray[opts.activeImage][2])).parent().addClass('picselected');
			            $("#picul").css("width",(1280 + Math.abs(6 - opts.activeImage) * 88));
			            $("#picul").css("left",((6 - opts.activeImage) * 88));
					    if(opts.activeImage == 0){
			                $('.prev_Abtn a').removeClass();
			            }
				    }
			    } else if (keycode == 39 || keycode == 40 || keycode == 34) { 
				    if(o.activeImage != (o.imageArray.length - 1)){
				        $('#lightboxImage').removeAttr("style");
				        $('#lightboxImage').removeClass();
					    disableKeyboardNav();
					    turn = 0;
					    changeImage(o.activeImage + 1);
					    $(".picselected").removeClass();
			            $("#" + (opts.imageArray[opts.activeImage][2])).parent().addClass('picselected');
			            $("#picul").css("width",(1280 + Math.abs(6 - opts.activeImage) * 88));
			            $("#picul").css("left",((6 - opts.activeImage) * 88));
					    if(opts.activeImage == (opts.imageArray.length - 1)) {
			                $('.next_Abtn a').removeClass();
			            }
				    }
			    }
			}
			//return false;
		};
		
		
		var escCallBack = function(e){
            var keycode = e.keyCode;
            var escapeKey = 27;
            if (keycode == escapeKey) { 
                end();
            }          
		};	
        //绑键盘上一张下一张事件
		var enableKeyboardNav = function(e) {
			$(document).bind('keydown', {opts: opts}, nextAndPreCallBack);
			if($.browser.msie){
			    document.attachEvent("keydown", stopDefoult);
			}else{
			    document.addEventListener('keydown', stopDefoult, false);
			}
		};
        //解绑键盘上一张下一张事件
		var disableKeyboardNav = function() {
			$(document).unbind('keydown',nextAndPreCallBack);
		};
		//解绑全部键盘事件
		var disableAllKeyboardNav = function(){
            $(document).unbind('keydown',nextAndPreCallBack).unbind('keydown',escCallBack);			
		};
		
		/**************************************************************鼠标滚轮事件******************************************************/
		var mousewheel = (function(){
            var types =['DOMMouseScroll','mousewheel'];
  
            fixedEvent = function(e){
                e.wheel = (e.wheelDelta? e.wheelDelta : -e.detail) > 0? 1 : -1;// 通过事件判断鼠标滚轮反向，1是向上，-1是向下
                e.wheelDir = e.wheel > 0? 1 : -1;    //这个只是描述 e.wheel的值和滚轮方向的关系
                return e;
            };
  
            return{//返回mousewheel的方法
                on: function(el, fn, preventDefault){ //mousewheel对象的on方法， el触发mousewheel事件对象，fn触发后执行函数，preventDefault是否阻止默认行为：滚轮的网页滚动效果
                    if(typeof preventDefault != 'boolean'){ //如果传入的实参preventDefault不是布尔值 
                        preventDefault = true; //初始化为true
                    }    
 
                    var fixedFn = function(e){ //阻止默认行为函数
                        e = fixedEvent(e || window.event); // 兼容写法， 返回的e用来判断滚轮方向
                        if(preventDefault){ // 如果需要阻止默认行为
                            if(e.preventDefault){    //firefox
                                e.preventDefault();
                            }else{
                                e.returnValue = false; //ie
                            }
                        };
                        fn.call(el, e); //el事件对象调用fn函数，参数为e; 注意fn中使用e.wheel去判断鼠标滚轮事件
                    },
                    wheelHash = el.wheelHash; //把包含fixedFn函数的 el.wheelHash属性 赋值给 wheelHash
 
                    if(!wheelHash){  //判断函数是否存在 wheelHash 对象
                        wheelHash = {};
                        wheelHash[fn] = fixedFn;  //wheelHash对象的属性fn为阻止默认行为函数
                        el.wheelHash = wheelHash;  //把wheelHash对象赋值给el的wheelHash属性  wheelHash[fn] == el.wheelHash[fn]
                    }else{
                        if(wheelHash[fn]) return; //如果存在 wheelHash 且 wheelHash中有 fixedFn 那么返回
                        wheelHash[fn] = fixedFn;  //如果没有， 就把fixedFn赋值给wheelHash.fn
                    };
 
                    if(document.addEventListener){  //firefox
                        var i = types.length;  
                        while(i--){  //循环滚轮事件 数组
                            el.addEventListener(types[i], fixedFn, false);    //firefox el监听滚轮事件，执行取消默认行为
                        }
                    }else{  //ie
                        el.attachEvent('onmousewheel', fixedFn);     // ie 监听事件， 处理函数fixedFn
                    }
                },  
 
                //mousewheel中的on方法作用: 让元素监听事件，且处理是否执行默认行为。并且保存事件的阻止默认行为函数fixedFn到对象el.wheelHash属性中，
                un: function(el, fn){
                    if(!el.wheelHash) return;  //如果对象不存在wheelHash, 直接跳出(没效果了)；
                    var wheelHash = el.wheelHash;
                    if(document.removeEventListener){  //firefox
                        var i = types.length;
                        while(i--){
                            el.removeEventListener(types[i],wheelHash[fn], false);  //删除监听事件，执行取消默认行为
                        }
                    }else{ //ie
                        el.detachEvent('onmousewheel', wheelHash[fn]);
                    }
                    delete wheelHash[fn]; //删除 默认行为函数
                }
            }
        })();
		
		//鼠标滚轮事件 1向上滚动是上一张事件，2向下滚动是下一张事件
		var wheelHandle = function(e){
		    var delta = e.wheelDir;
		    //如果在timeline中则取消掉键盘上一张下一张事件
			if($('#tl_show_by_opType').css("display")=="none"){
	            if(delta>0){
	                if(opts.activeImage != 0){
	                    $('#lightboxImage').removeAttr("style");
	                    $('#lightboxImage').removeClass();
	                    turn = 0;
	                    changeImage(opts.activeImage - 1);
	                    $(".picselected").removeClass();
			            $("#" + (opts.imageArray[opts.activeImage][2])).parent().addClass('picselected');
			            $("#picul").css("width",(1280 + Math.abs(6 - opts.activeImage) * 88));
			            $("#picul").css("left",((6 - opts.activeImage) * 88)); 
			            if(opts.activeImage == 0){
			                $('.prev_Abtn a').removeClass();
			            }
			        }
	            }else{
	                if(opts.activeImage != (opts.imageArray.length - 1)){
	                    $('#lightboxImage').removeAttr("style");
	                    $('#lightboxImage').removeClass();
	                    turn = 0;
	                    changeImage(opts.activeImage + 1);
	                    $(".picselected").removeClass();
			            $("#" + (opts.imageArray[opts.activeImage][2])).parent().addClass('picselected');
			            $("#picul").css("width",(1280 + Math.abs(6 - opts.activeImage) * 88));
			            $("#picul").css("left",((6 - opts.activeImage) * 88));
				        if(opts.activeImage == (opts.imageArray.length - 1)) {
			                $('.next_Abtn a').removeClass();
			            }
			        }
	            }
	        }
		}

		
		
		
		init();
	};	
})(jQuery);
