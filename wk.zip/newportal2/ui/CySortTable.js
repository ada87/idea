/**
 * 排序表头
 */
(function($) {

	$.fn.CySortTable = function(option, callback) {
		var id = option;
		if (id == "c_size") {
			//大小排序向上箭头时
			$("#c_size").show();
			if ($("#c_size").hasClass("min_icon m_time_up")) {
				$("#c_size").removeClass("min_icon m_time_up");
				$("#c_size").addClass("min_icon m_time_down");
			} else {
				//大小排序向下箭头时
				$("#c_size").removeClass("min_icon m_time_down");
				$("#c_size").addClass("min_icon m_time_up");
			}
			$("#c_time").hide();

		}
		//时间排序向上箭头时
		if (id == "c_time") {
			$("#c_time").show();
			if ($("#c_time").hasClass("min_icon m_time_up")) {
				$("#c_time").removeClass("min_icon m_time_up");
				$("#c_time").addClass("min_icon m_time_down");
			} else {
				//时间排序向下箭头时
				$("#c_time").removeClass("min_icon m_time_down");
				$("#c_time").addClass("min_icon m_time_up");
			}
			$("#c_size").hide();
		}

		//回调函数
		callback();
	}

})(jQuery)
