/**
/**
 * 缩略图列表
 */
(function() {

	// 工具类
	var utils = caiyun.util;
	var ns = caiyun.ui;
	ns.CyThumbnailList = CyThumbnailList;
	ns.CyThumbnailItem = CyThumbnailItem;
	
	/**
     * 定义会使用到的公共方法
     */
    window.caiyun.ui.CyThumbnailBase = {
        /**
         * 绑定事件函数，需要考虑兼容自定义事件(eventName_gridId)
         */
        on: function(thumbnailList, $element, ons) {
            var array;
            if(ons && !(ons instanceof Array)){
                array = [];
                array.push(ons);
            }else{
                array = ons;
            }
            var i = 0,
                len = array.length,
                temp, events, j, newEvents = [],
                eventName, evensLength;
            for (; i < len; i++) {
                temp = array[i];
                events = temp.events.split(' ');
                evensLength = events.length;
                for (j = 0; j < evensLength; j++) {
                    eventName = events[j];
                    if (window.caiyun.ui.CyThumbnailEvents[eventName]) {
                        newEvents.push(eventName);
                    } else {
                        newEvents.push(eventName);
                    }
                }
                $element.on(newEvents.join(' '), temp.selector, {
                    thumbnailList: thumbnailList,
                    eventUtil: utils.Event
                }, temp.handler);
                newEvents = [];
            }
        },

        /**
         * 触发一个列表事件
         *
         * @param thumbnailList {thumbnailList} 彩云缩略图列表对象，这个对象可以通过event.thumbnailList获取
         * @param eventName {String} 事件名称
         * @param otherdata {Object} 自定义数据，这些数据会被传到事件处理函数的第二个参数开始的参数
         */
        trigger: function(thumbnailList, eventName, otherdata) {
            var event = $.Event(eventName);
            event.eventName = eventName;
            thumbnailList.$target.trigger(event, otherdata);
        }
    };
	
	/**
     * 自定义缩略图事件
     * 自定义事件的类型通过event.eventName来获取
     */
    window.caiyun.ui.CyThumbnailEvents = {
        // 新项目被添加
        addItems: 'addItems',
        removeItems: 'removeItems',
        dropItems: 'dropItems'
    };
	
	/**
	 * 创建缩略图列表
	 * 
	 * @param parent
	 *            {DOMElement} 要添加到DOM父元素
	 */
	function CyThumbnailList(config) {
	    var self = this;
	    var $emptyTarget = $(document.getElementById(config.emptyTargetId));
	    this.$target = $(document.getElementById(config.targetId));
	    this.renderTargetId = config.renderTargetId;
	    this.base = window.caiyun.ui.CyThumbnailBase;
		this.visible = false;
		this.newFoldering = null;
		this.renamingItem = null;
		this.selectingItem = null; // 重命名时选中的单项视图
		this.selectedHandler = null;
		this.openHandler = null;
		this.contextmenuHandler = null;
		this.confirmCreateItemHandler = null;
		this.confirmRenameSelectedItemHandler = null;
		this.itemDropableHandler = null;
		this.itemDropHandler = null;
		this.thumbnailItems = []; // 记录所有已经创建的缩略图对象
		this.tempThumbnailItems = []; // 临时保存滚动加载的数据
		this.dragItems = null; // 被拖拽的项
		this.emptyStyle = ''; // 空文件夹显示的样式
		this.mp3PlayingItem = null;
		this.fileIdPrefix = config.fileIdPrefix;
		
		this.getThumbnailItem = function(itemId){
			var thumbnailItem = null;
			for(var i = 0, length = this.thumbnailItems.length; i < length; i++){
				if (itemId === this.thumbnailItems[i].fileID) {
					thumbnailItem = this.thumbnailItems[i];
					thumbnailItem.arrayIndex = i;
					break;
				}
			}
			
			return thumbnailItem;
		};
		
		var ons = [
		  {
		      events : 'mouseenter',
		      selector : 'li',
		      handler : function(event){
                $(this).addClass("hover");
		      }
		  },
		  {
              events : 'mouseleave',
              selector : 'li',
              handler : function(event){
                $(this).removeClass("hover");
              }
          },
          {
              events : 'click',
              selector : 'li > div > div.secFolderIcons, li > div > div > b.m_share, li > div > div > b.m_people',
              handler : function(event){
                var data = event.data;
                var eventUtil = data.eventUtil;
                eventUtil.stopEvent(event);
                var e = jQuery.Event('click', {ctrlKey: event.ctrlKey, shiftKey:event.shiftKey});
                $(this).parents('li').trigger(e);
                return false;
              }
          },
          {
              events : 'click',
              selector : '.checkBox',
              handler : function(event){
                var data = event.data;
                var eventUtil = data.eventUtil;
                eventUtil.stopEvent(event);
                var e = jQuery.Event('click', {ctrlKey: event.ctrlKey, shiftKey:event.shiftKey});
                $(this).parents('li').trigger(e);
                return false;
              }
          },
          {
            events : 'dblclick',
            selector : '.checkBox',
            handler : function(event){
                var data = event.data;
                var thumbnailList = data.thumbnailList;
                var eventUtil = data.eventUtil;
                eventUtil.stopEvent(event);
                var targetDom = eventUtil.getTarget(event);
                var domId = $(targetDom).parents('li').get(0).id;
                var itemId = domId.split('_')[1];
                var thumbnailItem = thumbnailList.getThumbnailItem(itemId);
                thumbnailItem.selected = !thumbnailItem.selected;
                thumbnailItem.selected === true ? $('#' + domId).addClass('selected') : $('#' + domId).removeClass('selected');
                // 回调单击处理函数.
                if ($.isFunction(thumbnailList.selectedHandler)) {
                    var selectedFiles = thumbnailList.getSelectedItems();
                    thumbnailList.selectedHandler(selectedFiles);
                }
                return false;
            }
          },
          {
              events : 'click',
              selector : 'li',
              handler : function(event){
                var data = event.data;
                var thumbnailList = data.thumbnailList;
                var eventUtil = data.eventUtil;
                eventUtil.stopEvent(event);
                var domId = this.id;
                var itemId = domId.split('_')[1];
                thumbnailList.selectItem(itemId, event.ctrlKey, event.shiftKey);
                return false;
              }
          },
          {
              events : 'click',
              selector : 'li > div.img-link, li > div > a',
              handler : function(event){
                var data = event.data;
                var thumbnailList = data.thumbnailList;
                var eventUtil = data.eventUtil;
                if (event.ctrlKey || event.shiftKey) {
                    return;
                }
                eventUtil.stopEvent(event);
                var targetDom = eventUtil.getTarget(event);
                var domId = $(targetDom).parents('li').get(0).id;
                var itemId = domId.split('_')[1];
                thumbnailList.leftMouseClick(itemId);
                return false;
              }
          },
          {
              events : 'contextmenu',
              selector : 'li',
              handler : function(event){
                var data = event.data;
                var thumbnailList = data.thumbnailList;
                var eventUtil = data.eventUtil;
                eventUtil.stopEvent(event);
                var domId = this.id;
                var itemId = domId.split('_')[1];
                var thumbnailItem = thumbnailList.getThumbnailItem(itemId);
                thumbnailList.clearRenameAndNewFolder(thumbnailItem);          
                var selectedFiles = null;
                // 忽略新建文件夹类型的点击
                if (!thumbnailItem || thumbnailItem.fileType == 'newFolder' || thumbnailItem.renaming) {
                    return;
                }
                // 对象未被选中之
                if (!thumbnailItem.selected) {
                    // 取消全部选择
                    thumbnailList.unSelectAll();
                    thumbnailItem.selected = true;
                    $('#' + domId).addClass('selected');
                    // 回调处理函数
                    thumbnailList.selectedHandler([thumbnailItem]);
                    thumbnailList.contextmenuHandler(thumbnailItem, event);
                } else {
                    selectedFiles = thumbnailList.getSelectedItems();
                    // 回调处理函数
                    thumbnailList.contextmenuHandler(selectedFiles, event);
                }
                return false;
              }
          },
          {
              events : 'click',
              selector : 'a.newf-ok',
              handler : function(event){
                var data = event.data;
                var thumbnailList = data.thumbnailList;
                var eventUtil = data.eventUtil;
                eventUtil.stopEvent(event);
                var domId = this.id;
                var itemId = domId.split('_')[1];
                thumbnailList.confirmRenameCallback(itemId);
              }
          },
          {
              events : 'click',
              selector : 'a.newf-no',
              handler : function(event){
                var data = event.data;
                var thumbnailList = data.thumbnailList;
                var eventUtil = data.eventUtil;
                eventUtil.stopEvent(event);
                var domId = this.id;
                var itemId = domId.split('_')[1];
                thumbnailList.cancelRenameCallback(itemId);
                return false;
              }
          },
          {
              events : 'keydown',
              selector : 'input',
              handler : function(event){
                var eventUtil = event.data.eventUtil;                
                if (event.keyCode === 13) {
                    eventUtil.stopEvent(event);
                    $(this).parents('li').find('a.newf-ok').trigger('click');
                }
              }
          },
          {
              events : 'mousemove mouseout',
              selector : 'a.virus_ico',
              handler : function(event){
                var data = event.data;
                var thumbnailList = data.thumbnailList;
                var eventUtil = data.eventUtil;
                eventUtil.stopEvent(event);
                var type = event.type;
                var position = {pageX : event.pageX, pageY : event.pageY};
                thumbnailList.handlerMouseMove(type, position);
                return false;
              }
          },
          {
	          events : 'dragenter',
	          selector : 'li',
	          handler : function(event){
                var data = event.data;
                var thumbnailList = data.thumbnailList;
                var eventUtil = data.eventUtil;
                eventUtil.stopEvent(event);
                var fileID = this.id.split('_')[1];
                caiyun.ui.webnd.listViewdragEvent(event, fileID);//插件上传
	          }
          },
          {
            events : 'dragover',
            selector : 'li',
            handler : function(event){
                //插件上传 拖拽图标感应
                caiyun.ui.webnd.mouseoverListen(event);
            }
          },
          {
              events : 'drop',
              selector : 'div, li',
              handler : function(event){
                var data = event.data;
                var thumbnailList = data.thumbnailList;
                var eventUtil = data.eventUtil;
                eventUtil.stopEvent(event);
                var files = null;
                var targetDom = null;
                var domId = '';
                var itemId = '';
                var originalEvent = event.originalEvent;
                if (originalEvent.dataTransfer) {
                    files = originalEvent.dataTransfer.files;
                }
                targetDom = event.target;
                domId = $(targetDom).is('li') ? $(targetDom).attr('id') : $(targetDom).parents('li').get(0).id;
                itemId = domId.split('_')[1];
                //插件上传 拖拽图标还原
                caiyun.ui.webnd.modifyDragArea();
                thumbnailList.dropWinXPFiles(itemId, files);
                return false;
              }
          },
          {
            events : window.caiyun.ui.CyThumbnailEvents.addItems,
            selector : null,
            handler : function(event, otherData){
                var data = event.data;
                var thumbnailList = data.thumbnailList;
                var tempThumbnailItems = thumbnailList.tempThumbnailItems;
                var length = tempThumbnailItems.length;
                var html = '';
                for (var i = 0; i < length; i++) {
                    html += thumbnailList.render({thumbnailItem : tempThumbnailItems[i]});
                }
		        $(html).appendTo('#' + thumbnailList.renderTargetId);
            }
          },
          {
            events : window.caiyun.ui.CyThumbnailEvents.removeItems,
            selector : null,
            handler : function(event, otherData){
                var data = event.data;
                var thumbnailList = data.thumbnailList;
                // 重新计算显示选中的item数
                thumbnailList.selectedHandler(thumbnailList.getSelectedItems());
            }
          },
          {
            events : window.caiyun.ui.CyThumbnailEvents.dropItems,
            selector : null,
            handler : function(event, otherData){
                var data = event.data;
                var thumbnailList = data.thumbnailList;
                var tempThumbnailItems = thumbnailList.tempThumbnailItems;
                var length = tempThumbnailItems.length;
                var fileIdPrefix = thumbnailList.fileIdPrefix;
                for (var j = 0; j < length; j++) {
                    (function(j){
                        var fileID = tempThumbnailItems[j].fileID;
	                    $('#' + fileIdPrefix + fileID).draggable({
	                        containment : '.cy_container',
	                        scroll : true,
	                        disabled : !tempThumbnailItems[j].canMove,
	                        revert : true,
	                        helper : function(event){
	                            var self = thumbnailList;
	                            var fileID = this.id.split('_')[1];
	                            var thumbnailItem = self.getThumbnailItem(fileID);
	                            self.dragItems = self.getSelectedItems();
	                            var dragFilesNum = self.dragItems.length;
	                            if (dragFilesNum === 0 || thumbnailItem.selected === false) {
	                                self.dragItems = [thumbnailItem];
	                            }
	                            return self.getHelper(self);
	                        },
	                        distance : 20
	                    });
	                    $('#' + fileIdPrefix + fileID).droppable({
	                        drop : function(event, ui){
	                            var self = thumbnailList;
	                            var fileID = this.id.split('_')[1];
	                            var thumbnailItem = self.getThumbnailItem(fileID);
	                            event.data.thumbnailItem = thumbnailItem;
	                            fileID = null;
	                            self.dropMcloudFiles(event, ui);
	                        },
	                        disabled : !tempThumbnailItems[j].canMove,
	                        hoverClass : 'hover'
	                    });
                    })(j);
                }
            }
          }
		];
		
		if (ons && ons.length > 0) {
		    this.base.on(self, this.$target, ons);
		}
		
		/**
		 * 显示或隐藏空文件夹的提示
		 * emptyStyle {String} 提示语
		 * display {String} 取block or none值
		 */
		this.displayEmptyFolderStyle = function(emptyStyle, display){
			$emptyTarget.html(emptyStyle).css('display', display);
		};
		
		this.templateSource = '<%if (thumbnailItem.selected == true) {%>' +
		              '<li id="' + this.fileIdPrefix + '<%=thumbnailItem.fileID%>" type="<%=thumbnailItem.fileType%>" class="selected">' +
		          '<%} else {%>' +
		              '<li id="' + this.fileIdPrefix + '<%=thumbnailItem.fileID%>" type="<%=thumbnailItem.fileType%>">' +
		          '<%}%>' +
					'<div class="img-link">' +
						'<img src="<%=thumbnailItem.imgPath%>" onerror="this.src=\'../images/newportal2/config_img.gif\';' +
						'this.nextSibling.style.display=\'none\';this.style.display=\'block\';" class="imgM" style="display:none;"/>' +
						'<img src="../images/newportal2/s.gif" style="display:block;background-image: url(<%=thumbnailItem.imgPath%>);" class="imgM"/>' +
						'<%if (thumbnailItem.isVideo) {%>' +
						'<div class="' + this.fileIdPrefix + '_video_play_icon"></div>' +
						'<%}%>' +
						'<%if (thumbnailItem.isNew == true) {%>' +
						'<div class="max_icon m_maxNew" title="有新收到的文件"></div>' +
						'<%}%>' +
						//缩略图分享标识
						'<%if (thumbnailItem.fileType == "folder") {%>'+
	          	 		'<div id="thumbnailShare_<%=thumbnailItem.fileID%>" class="secFolderIcons">' +
	          	 		'<%} else {%>' +
	          	 		'<div id="thumbnailShare_<%=thumbnailItem.fileID%>" class="secFileIcons">' +
	          	 		'<%}%>' +
                            '<%if (thumbnailItem.share == true) {%>' +
	                 		'<b class="m_people" title="分享给其他用户"></b>' +
                            '<%}%>' +
                            '<%if (thumbnailItem.linkedFile == true) {%>' +
	                 		'<b class="m_share" title="分享文件外链"></b>' +
	                 		'<%}%>' +
	             		'</div>' +
	             		//END 缩略图分享标识
					'</div>' +
					'<div class="checkBox"><b class="check-select"></b></div>' +
					'<%if (thumbnailItem.fileType==="file") {%>' +
					'<div class="file-name">' +
							//显示搜索结果，名字会加粗，所以用html binding 文件名
							'<a id="thumbnailFileName_<%=thumbnailItem.fileID%>" title="<%=thumbnailItem.fileName%>" href="javascript:void(0);"><%=thumbnailItem.showFileName()%></a>' +
							//病毒标识
							'<%if (thumbnailItem.virus == true) {%>' +
							'<a id="thumbnailVirus_<%=thumbnailItem.fileID%>" class="virus_ico" style="display:none;"></a>' +
							'<%}%>' +
							//END 病毒标识
							'<input id="thumbnailRename_<%=thumbnailItem.fileID%>" class="newfolder_s" type="text" maxlength="32" onfocus="this.select()" style="display:none;">' +
					'</div>' +
					'<%} else if (thumbnailItem.fileType==="folder") {%>' +
					'<div class="file-name">' +
							'<a id="thumbnailFileName_<%=thumbnailItem.fileID%>" title="<%=thumbnailItem.fileName%>" href="javascript:void(0);"><%=thumbnailItem.showFileName()%></a>' +
							'<input id="thumbnailRename_<%=thumbnailItem.fileID%>" type="text" maxlength="32" onfocus="this.select()" style="display:none;" style="display:none;">' +
					'</div>' +
					'<%} else if (thumbnailItem.fileType==="newFolder") {%>' +
					'<div class="file-name">' +
							'<input class="newfolder_s" type="text" maxlength="32">' +
					'</div>' +
					'<%}%>' +
					'<p class="file-info">' +
						'<a id="thumbnailConfirm_<%=thumbnailItem.fileID%>" class="newf-ok" style="margin-right:15px;" href="javascript:void(0)" style="display:none;"></a>' +
						'<a id="thumbnailCancel_<%=thumbnailItem.fileID%>" class="newf-no" href="javascript:void(0)" style="display:none;"></a>' +
					'</p>' +
				'</li>';
		this.render = template.compile(this.templateSource);
	};
	
	/**
	 * 拖拽上传
	 * drop事件处理函数
	 * 
	 * 拖拽本地文件（夹）图标放置到放置项时触发drop事件的处理函数
	 * 
	 * @param targetFolderID {String} 要上传到的文件夹id
	 * @param files {Array} 本地文件信息
	 */
	CyThumbnailList.prototype.dropWinXPFiles = function(targetFolderID, files){	
		if(files) {
			var targetDirID;
			if (targetFolderID) {
				targetDirID = targetFolderID;
			} else {
				targetDirID = window.caiyun.operate.getCurrentPathId();
			}
				
			window.caiyun.operate.dragUploadFiles(files, targetDirID);
		}
	};
	
	/**
	 * 拖拽事件的处理函数，展示拖拽过程的效果
	 * 
	 */
	CyThumbnailList.prototype.getHelper = function(thumbnailList){
	    var self = thumbnailList;
		var dragFilesNum = self.dragItems.length;
		var lastSelectedItem = self.dragItems[dragFilesNum - 1];
		var imgUrl = lastSelectedItem.imgPath;
		if (lastSelectedItem.isLoadImageError === true) {
		  imgUrl = '../images/newportal2/config_img.gif';
		}
		var innerHtml = '<div class="dom_num">' + dragFilesNum + '</div>';
        var divDom = $('<div class="maxDrag" style="z-index: 99999;background:#d8cce8 url(' + 
        				imgUrl + ') no-repeat scroll 50% 50%;opacity: 1;margin: 0;padding: 0;"></div>').append(innerHtml);
        
		return divDom;
	};
	
	/**
	 * 拖拽页面的文件（夹）图标放置到放置项时触发drop事件的处理函数
	 * event {Event} drop事件
	 * ui {Object} {draggable: {
	 * Type: jQuery
	 * A jQuery object representing the draggable element.};
	 * helper: {
	 * Type: jQuery
	 * A jQuery object representing the helper that is being dragged.};
	 * position: {
	 * Type: Object
	 * Current CSS position of the draggable helper as { top, left } object.};
	 * offset: {
	 * Type: Object
	 * Current offset position of the draggable helper as { top, left } object.};
	 * }
	 */
	CyThumbnailList.prototype.dropMcloudFiles = function(event, ui){
		event.stopPropagation();
		// 判断是否在页面的头部位置
		if (event.clientY < 215) {
			return;
		}
		var dragItems = this.dragItems;
		var dropItem = event.data.thumbnailItem;
		var dropable = this.itemDropableHandler(dragItems, dropItem);
		if (dropable) {
			ui.helper.remove();
			//ui.draggable.remove();
			this.itemDropHandler(dragItems, dropItem);
		}
	};

	/**
	 * 
	 * @param items
	 * @param isInFront
	 */
	CyThumbnailList.prototype.addThumbnailItems = function(items, isInFront) {
		var i, length;
		var thumbnailItem = null, item = null;
		this.tempThumbnailItems = [];
		for (i = 0, length = items.length; i < length; i++) {
			item = items[i];
			thumbnailItem = new CyThumbnailItem({
				fileID : item.fileID,
				fileName : item.fileName,
				keyWords : item.keyWords,
				fileType : item.fileType,
				isFixedDir : item.isFixedDir, // 判断系统固定目录要用到该属性
				isNew : item.isRead,
				imgPath : item.imgPath,
				virus : item.virus,
				share : item.share,
				linkedFile : item.linkedFile,
				isVideo : item.isVideo, // 视频文件，该值是true
				inReceviteShareDir : item.inReceviteShareDir,
				inEnterpriseDir : item.inEnterpriseDir,
				unselectAllable : item.unselectAllable
			}, this);
			
			this.tempThumbnailItems.push(thumbnailItem);
		}
		
		this.thumbnailItems = this.thumbnailItems.concat(this.tempThumbnailItems);
		
		window.caiyun.ui.CyThumbnailBase.trigger(this, window.caiyun.ui.CyThumbnailEvents.addItems);
		window.caiyun.ui.CyThumbnailBase.trigger(this, window.caiyun.ui.CyThumbnailEvents.dropItems);
		this.tempThumbnailItems = null;
	};

	// 左键单击事件处理
	CyThumbnailList.prototype.leftMouseClick = function(itemId) {
		var thumbnailItem = this.getThumbnailItem(itemId);
		// 忽略新建文件夹类型的点击
		if (!thumbnailItem || thumbnailItem.fileType == 'newFolder' || thumbnailItem.renaming) {
			return;
		}
		this.clearRenameAndNewFolder(thumbnailItem);
		this.unSelectAll();
		if ($.isFunction(this.openHandler)) {
			this.openHandler(thumbnailItem);
		}
	};
	
	/**
	 * 选中一个文件(夹)项的处理函数
	 * @param itemId {String} 文件(夹)ID
	 */
	CyThumbnailList.prototype.selectItem = function(itemId, ctrlKey, shiftKey){
		var thumbnailItem = this.getThumbnailItem(itemId);
		// 忽略新建文件夹类型的点击
		if (!thumbnailItem || thumbnailItem.fileType == 'newFolder' || thumbnailItem.renaming) {
			return;
		}
		this.clearRenameAndNewFolder(thumbnailItem);
		var files = this.thumbnailItems;
		// 如果ctrl被按下的话增加被选中的文件
		if (ctrlKey) {
			thumbnailItem.selected = !thumbnailItem.selected;
		}
		// 如果shift被按下的话，选中第一个被选中的文件一直到最后一个被选中的文件
		else if (shiftKey) {
			// 如果已经有文件被选中，则选中之前被选中的文件一直到当前被点击的文件
			var startIndex = -1;
			for ( var i = 0, length = files.length; i < length; i++) {
				if (files[i].selected) {
					startIndex = i;
					break;
				}
			}
			if (startIndex >= 0) {
				var endIndex = thumbnailItem.arrayIndex;
				this.unSelectAll(true);
				if (endIndex > startIndex) {
					for ( var i = startIndex; i <= endIndex; i++) {
						files[i].selected = true;
					}
				} else {
					for ( var i = startIndex; i >= endIndex; i--) {
						files[i].selected = true;
					}
				}
			} else {
				thumbnailItem.selected = true;
			}
		}
		// 如果什么都没有按下则只选中当前点击的文件
		else {
			thumbnailItem.selected = !thumbnailItem.selected;
		}
		for (var i = 0, length = files.length; i < length; i++) {
			if (files[i].selected) {
				$('#' + this.fileIdPrefix + files[i].fileID).addClass('selected');
			} else {
				$('#' + this.fileIdPrefix + files[i].fileID).removeClass('selected');
			}
		}
		// 回调单击处理函数.
		if ($.isFunction(this.selectedHandler)) {
			var selectedFiles = this.getSelectedItems();
			this.selectedHandler(selectedFiles);
		}
	};
	
	/**
	 * 显示缩略图
	 */
	CyThumbnailList.prototype.show = function() {
		this.visible(true);
	};

	/**
	 * 隐藏缩略图
	 */
	CyThumbnailList.prototype.hide = function() {
		this.visible(false);
	};

	/**
	 * 在列表结尾添加列表项
	 * 
	 * @param items
	 *            {ThumbnailItem数组} 列表项
	 * 
	 * @return {Number} 当前列表项数量
	 */
	CyThumbnailList.prototype.pushItems = function(items) {
		this.addThumbnailItems(items, false);
	};

	/**
	 * 在列表开头添加列表项
	 * 
	 * @param items
	 *            {ThumbnailItem数组} 列表项
	 * 
	 * @return {Number} 当前列表项数量
	 */
	CyThumbnailList.prototype.unshiftItems = function(items) {
		this.addThumbnailItems(items, true);
	};

	/**
	 * 更新列表中的item
	 * 
	 * @param item
	 *            {Item} 列表项
	 * 
	 * @return {Boolean} 是否更新成功
	 */
	CyThumbnailList.prototype.updateItem = function(item) {
		var i, length, thumbnailItem = null, newItem = null, oldItem = null;
		for (i = 0, length = this.thumbnailItems.length; i < length; i++) {
			thumbnailItem = this.thumbnailItems[i];
			if (thumbnailItem.fileID === item.fileID) {
				this.thumbnailItems.splice(i, 1, item);
				newItem = this.render({thumbnailItem:item});
				$('#' + this.fileIdPrefix + item.fileID).replaceWith(newItem);
				this.tempThumbnailItems = [item];
				window.caiyun.ui.CyThumbnailBase.trigger(this, window.caiyun.ui.CyThumbnailEvents.dropItems);
                this.tempThumbnailItems = null;
				break;
			}
		}
	};
	
	/**
	* 删除列表中的item
	*
	* @param {Array}
    *            itemIds 列表项id
	*/
	CyThumbnailList.prototype.removeItems = function(itemIds){
		var i = 0, idsLength = 0;
		var j = 0, itemsLength = 0;
		var fileID;
		if (!jQuery.isArray(itemIds)) {
		    return;
		}
		for (idsLength = itemIds.length; i < idsLength; i++) {
		    for (itemsLength = this.thumbnailItems.length; j < itemsLength; j++) {
		        fileID = this.thumbnailItems[j].fileID;
		        if (itemIds[i] === fileID) {
		            this.thumbnailItems.splice(j, 1);
		            $('#' + this.fileIdPrefix + fileID).remove();
		            break;
		        }
		    }
		}
		
		// 触发事件
        this.base.trigger(this, window.caiyun.ui.CyThumbnailEvents.removeItems);
	};
	
	/**
	* 获取第一个选中和最后一个选中的缩略图
	* 
	*/
	CyThumbnailList.prototype.getFirstAndLastSelectedItem = function(){
        var thumbnailItem = null;
        var i, length;
        var min = null; // 多选时，第一个选中的缩略图的下标
        var max = null; // 多选时，最后一个选中的缩略图的下标
        var firstItem = null; // 多选时，第一个选中的缩略图
        var lastItem = null; // 多选时，最后一个选中的缩略图
        for (i = 0, length = this.thumbnailItems.length; i < length; i++) {
            thumbnailItem = this.thumbnailItems[i];
            if (thumbnailItem.selected === true) {
                if (!firstItem) {
                    firstItem = thumbnailItem;
                    min = i;
                }
                lastItem = thumbnailItem;
                max = i;
            }
        }
       return {
            min: min,
            max: max,
            firstItem : firstItem,
            lastItem : lastItem
       };
	};
	
	/**
	* 设置选中文件后的滚动条位置
	* @parameter {String} 
	*          oldFileID "收到的分享"的文件夹的id
	* @parameter {String}
	*          newFileID 新选中的文件(夹)的id
	*/
	CyThumbnailList.prototype.setScrollPosition = function(oldFileID, newFileID){
		var $oldThumbnailItem = $('#' + this.fileIdPrefix + oldFileID);
		var $newThumbnailItem = $('#' + this.fileIdPrefix + newFileID);
		var oldTop = $oldThumbnailItem.offset().top;
		var newTop = $newThumbnailItem.offset().top;
		var itemHeight = $oldThumbnailItem.height();
		var windowHeigth = $(window).height();		
		
		if (oldTop === newTop) {
		  window.scrollTo(0, 0);
		} else if (newTop + itemHeight <= windowHeigth){
		  window.scrollTo(0, 0);
		} else {
		  window.scrollTo(0, newTop - (windowHeigth/2));
		}
		
	/*	
        var shift = newTop - oldTop;
        // 记录当前窗口滚动条位置
        var  scrollTop = utils.getScrollTop();
        
        if (scrollTop === 0) {
          scrollTop = windowHeigth + itemHeight;
        }
        if (newTop > windowHeigth && shift >= 0) {
		  // 滚动条位置
		  window.scrollTo(0, scrollTop + shift);
		  //console.log('向下滚动 1');
		} else if (newTop > windowHeigth && shift < 0) {
		  // 滚动条位置
          window.scrollTo(0, scrollTop + shift);
          //console.log('向上滚动 1');
		} else if (newTop < windowHeigth && shift > 0) {
		  // 滚动条位置
		  window.scrollTo(0, scrollTop + shift);
		  //console.log('向下滚动 2');
		} else if (newTop < windowHeigth && shift < 0) {
		  // 滚动条位置
          window.scrollTo(0, scrollTop + shift);
          //console.log('向上滚动 2');
		} else if (newTop === windowHeigth) {
		  // 滚动条位置
		  window.scrollTo(0, scrollTop + shift);
		}*/
	};
	
	/**
	* 键盘事件响应
	*
	* @parameter {Event} 
	*      event 键盘key码
	*
	*/
	CyThumbnailList.prototype.keyHandler = function(event){
	    var keyCode = event.keyCode;
        var eventUtil = event.data.util.Event;        
        //当有弹出层时不做任何操作
        if(window.caiyun.layershow || this.thumbnailItems.length === 0){
            return;
        }
        var firstAndLastSelectedItem = this.getFirstAndLastSelectedItem();
        var min = firstAndLastSelectedItem.min;
        var max = firstAndLastSelectedItem.max;
        var firstItem = firstAndLastSelectedItem.firstItem;
        var lastItem = firstAndLastSelectedItem.lastItem;
        var currentSelectItems = null;
        var distance = 5;
        var newMin = 0;
        var newMax = 0;         
        if (keyCode === 13) {// 回车键
            currentSelectItems = this.getSelectedItems();
            if (currentSelectItems.length == 1) {
                this.leftMouseClick(currentSelectItems[0].fileID); // 打开文件(夹)                
            }
            eventUtil.stopEvent(event);
        } else if (keyCode === 38 || keyCode === 37) {// 38是上箭头keyCode  37是左箭头keyCode
            if (min === null) {
                this.unSelectAll();
                min = 0;
                firstItem = this.thumbnailItems[min];
                firstItem.selected = true;
                this.updateItem(firstItem);
            } else {
                if (keyCode === 38) {
                    newMin = min - distance;
                } else {
                    newMin = min - 1;
                }
                if (newMin < 0) {
                    return;
                } else {
                    this.unSelectAll();
                    firstItem = this.thumbnailItems[newMin];
                    firstItem.selected = true;
                    this.updateItem(firstItem);
                }
            }
            this.setScrollPosition(this.thumbnailItems[0].fileID, firstItem.fileID);
            eventUtil.stopEvent(event);
        } else if(keyCode === 40 || keyCode === 39) {// 40是下箭头keyCode  39是右箭头keyCode
            if (max === null) {
                this.unSelectAll();
                max = this.thumbnailItems.length - 1;
                lastItem = this.thumbnailItems[max];
                lastItem.selected = true;
                this.updateItem(lastItem);
            } else {
                if (keyCode === 40) {
                    newMax = max + distance;
                } else {
                    newMax = max + 1;
                }
                if (newMax >= this.thumbnailItems.length) {
                    return;
                } else {
                    this.unSelectAll();
                    lastItem = this.thumbnailItems[newMax];
                    lastItem.selected = true;
                    this.updateItem(lastItem);
                }
            }
            this.setScrollPosition(this.thumbnailItems[0].fileID, lastItem.fileID);
            eventUtil.stopEvent(event);
        }
	};

	/**
	 * 清空列表
	 */
	CyThumbnailList.prototype.clear = function() {
		$('#' + this.renderTargetId).empty();
		this.thumbnailItems = [];
	};
	
	CyThumbnailList.prototype.destory = function() {
        // 解绑事件
        this.$target.off();
        $(document).unbind('keydown');
    };

	/**
	 * 空列表时的显示的HTML
	 * 
	 * @param html
	 *            {String} 要显示的HTML
	 */
	CyThumbnailList.prototype.setEmptyStyle = function(html) {
		this.emptyStyle = html;
	};
	
	/**
	*  判断是否是系统默认文件夹
	*   @param {String}
	*      id 文件夹id
	*/
    CyThumbnailList.prototype.isSystemItem = function(id){
        var cannotModifyIDs = caiyun.constants.cannotModifyIDs;
        var result = false;
        switch (id) {
            // 图片
            case cannotModifyIDs.root_phonePhoto:
                result = true;
                break;
            case cannotModifyIDs.root_syncGalary:
                result = true;
                break;
            // 视频
            case cannotModifyIDs.root_phoneVideo:
                result = true;
                break;
            case cannotModifyIDs.root_syncVideo:
                result = true;
                break;
            // 文档
            case cannotModifyIDs.root_phoneDoc:
                result = true;
                break;
            case cannotModifyIDs.root_syncMobile:
                result = true;
                break;
            // 收到的分享
            case cannotModifyIDs.root_receiveShare:
                result = true;
                break;
        }
        return result;
                
    };

	/**
	 * 全选
	 */
	CyThumbnailList.prototype.selectAll = function() {
		var i, length, fileID;
		for (i = 0, length = this.thumbnailItems.length; i < length; i++) {
            fileID = this.thumbnailItems[i].fileID;
		    if (this.thumbnailItems[i].unselectAllable === false) {
                this.thumbnailItems[i].selected = true;
                $('#' + this.fileIdPrefix + fileID).addClass('selected');
			}
		}
		this.selectedHandler(this.getSelectedItems());
	};

	/**
	 * 全部不选
	 */
	CyThumbnailList.prototype.unSelectAll = function() {
		var i, length;
		for (i = 0, length = this.thumbnailItems.length; i < length; i++) {
			this.thumbnailItems[i].selected = false;
		}
		$('li').removeClass('selected');
		this.selectedHandler(this.getSelectedItems());
	};

	/**
	 * 获取当前选中的文件项
	 * 
	 * @return {ThumbnailItem数组} 当前被选中的列表数
	 */
	CyThumbnailList.prototype.getSelectedItems = function() {
		var thumbnailSelectedItems = [], thumbnailItem = null;
		var i, length;
		for (i = 0, length = this.thumbnailItems.length; i < length; i++) {
			thumbnailItem = this.thumbnailItems[i];
			if (thumbnailItem.selected === true) {
				thumbnailSelectedItems.push(thumbnailItem);
			}
		}
		return thumbnailSelectedItems;
	};

	/**
	 * 选择的文件项变化处理函数，在当前选中的文件发生变化时触发 选择事件和其他事件同时触发时，先调用选择事件再调用其他事件
	 * 
	 * 回调时传入选中的文件项数组，没有文件选中时传入null function handler (items){};
	 * 
	 * @params handler {Function} 文件项变化函数
	 */
	CyThumbnailList.prototype.setSelectedHandler = function(handler) {
		this.selectedHandler = handler;
	};

	/**
	 * 打开文件项时，触发的事件
	 * 
	 * 回调参数如下，item 打开的文件项 function handler(item){};
	 * 
	 * @params handler {Function} 回调函数
	 */
	CyThumbnailList.prototype.setOpenHandler = function(handler) {
		this.openHandler = handler;
	};

	/**
	 * 右键点击文件项时，触发的事件
	 * 
	 * 回调参数如下，items 被右键点击的元素（右键可以多选），event 右键事件用于获取鼠标位置作为定位 function
	 * handler(items,event){};
	 * 
	 * @params handler {Function} 回调函数
	 */
	CyThumbnailList.prototype.setContextmenuHandler = function(handler) {
		this.contextmenuHandler = handler;
	};

	/**
	 * 显示创建文件项
	 * 
	 * @param item
	 *            {Object} 要创建的文件项参数
	 */
	CyThumbnailList.prototype.createItem = function(item) {
		var self = this;
		if (this.newFoldering) {
			return;
		}
		this.clearRenameAndNewFolder();
		var folder = new CyThumbnailItem({
			fileType : 'newFolder',
			imgPath : '../images/newportal2/m_picture.gif',
			fileID : 'thumbnail_createNewFolder'
		});
		folder.folderName = '新建文件夹';
		this.newFoldering = folder;
		var html = '<li id="' + folder.fileID + '">' +
				'<div class="img-link" style="width:75px;height:75px;">' +
					'<img src="../images/newportal2/m_picture.gif" style="width:85px;height:85px;">' +
				'</div>' +
				'<div class="checkBox"><b class="check-select"></b></div>' +
				'<div class="file-name">' +
					'<input class="newfolder_s" type="text" maxlength="32" value="新建文件夹">' +
				'</div>' +
				'<p class="file-info">' +
					'<a id="thumbnailConfirm_createNewFolder" class="newf-ok" style="margin-right:15px;" href="javascript:void(0)"></a>' +
					'<a id="thumbnailCancel_createNewFolder" class="newf-no" href="javascript:void(0)"></a>' +
				'</p>' +
			'</li>';
		
		var $newFolderItem = $(html).prependTo('#' + this.renderTargetId);
		$newFolderItem.find('input').focus(function(){
			$(this).select();
		});
		$newFolderItem.find('input').trigger('focus');
		$newFolderItem.on('click', 'a.newf-ok', {folder:folder, parent:self}, function(event){
			utils.Event.stopEvent(event);
			var remove = false;
			if (event.data.parent.confirmCreateItemHandler) {
				remove = event.data.parent.confirmCreateItemHandler(event.data.folder.folderName);
			}
			if (remove) {
				$('#thumbnail_createNewFolder').remove();
			}
			event.data.parent.newFoldering = null;
			return false;
		}).on('click', 'a.newf-no', {parent:self}, function(event){
			utils.Event.stopEvent(event);
			$('#thumbnail_createNewFolder').remove();
			event.data.parent.newFoldering = null;
			if (event.data.parent.thumbnailItems.length === 0) {
                // 隐藏空文件夹提示
                event.data.parent.displayEmptyFolderStyle(event.data.parent.emptyStyle, 'block');
            }
			return false;
		}).on('keydown', 'input', {eventUtil: utils.Event}, function(event){
            var eventUtil = event.data.eventUtil;                
            if (event.keyCode === 13) {
                eventUtil.stopEvent(event);
                $(this).parents('li').find('a.newf-ok').trigger('click');
            }
		});
	};

	/**
	 * 确认创建文件项的回调函数
	 * 
	 * function handler(params){ return true ; //
	 * 返回true表示去除创建文件项，返回false表示不去除创建文件项 };
	 * 
	 * @param handler
	 *            {Function} 回调函数
	 */
	CyThumbnailList.prototype.setConfirmCreateItemHandler = function(handler) {
		this.confirmCreateItemHandler = handler;
	};

	/**
	 * 对选中的文件项进行重命名
	 */
	CyThumbnailList.prototype.renameSelectedItem = function() {
		var selectedItems = this.getSelectedItems();
		if (selectedItems.length > 0) {
			this.selectingItem = selectedItems[0];
		} else {
			return;
		}
		this.clearRenameAndNewFolder(this.selectingItem);
		var fileOldName = this.selectingItem.fileName;
		var fileName = utils.removeSuffix(fileOldName);
		this.selectingItem.fileOldName = fileOldName; // 可以删除
		this.selectingItem.selected = true;
		this.selectingItem.renaming = true;
		this.renamingItem = this.selectingItem;
		this.selectingItem = null; // selected属性设置为false值后，要重置该值  // 可以删除
		// 重命名时隐藏或显示某些元素
		this.setRenameItemDisplay({itemId:this.renamingItem.fileID, fileName:fileName, display:'block'});
	};
	
	/**
	 * 重命名时隐藏或显示某些元素
	 * @param obj {Json} {itemId:文件(夹)id, fileName：文件(夹)名, display：可取block或none值}
	 */
	CyThumbnailList.prototype.setRenameItemDisplay = function(obj){
		var nondisplay = (obj.display === 'block' ? 'none' : 'block');
		var renameDisplay = (obj.display === 'block' ? '' : 'none');
		$('#thumbnailShare_' + obj.itemId).css('display', nondisplay);
		$('#thumbnailFileName_' + obj.itemId).css('display', nondisplay);
		$('#thumbnailVirus_' + obj.itemId).css('display', nondisplay);
		$('#thumbnailRename_' + obj.itemId).css('display', renameDisplay);
		$('#thumbnailConfirm_' + obj.itemId).css('display', renameDisplay);
		$('#thumbnailCancel_' + obj.itemId).css('display', renameDisplay);
		if (obj.display === 'block') {
			$('#' + this.fileIdPrefix + obj.itemId + ' > div.img-link').css({width:'75px', height:'75px'});
			$('#' + this.fileIdPrefix + obj.itemId + ' > div.img-link > img.imgM:eq(0)').css({width:'80px', height:'80px', display: 'block'});
			$('#' + this.fileIdPrefix + obj.itemId + ' > div.img-link > img.imgM:eq(1)').css({display: 'none'});
			$('#thumbnailRename_' + obj.itemId).attr('value', obj.fileName);
			$('#thumbnailRename_' + obj.itemId).focus();
		} else {
			$('#' + this.fileIdPrefix + obj.itemId + ' > div.img-link').css({width:'', height:''});
			if (obj.isLoadImageError) {
                $('#' + this.fileIdPrefix + obj.itemId + ' > div.img-link > img.imgM:eq(0)').css({width:'', height:'', display: 'block'});
			} else {
				$('#' + this.fileIdPrefix + obj.itemId + ' > div.img-link > img.imgM:eq(0)').css({width:'', height:'', display: 'none'});
				$('#' + this.fileIdPrefix + obj.itemId + ' > div.img-link > img.imgM:eq(1)').css({display: 'block'});
			}
			$('#thumbnailRename_' + obj.itemId).attr('value','');
		}
	};
	
	/**
	 * 重命名确认回调
	 * 
	 * @param itemId {String} 文件(夹)id
	 */ 
	CyThumbnailList.prototype.confirmRenameCallback = function(itemId) {
		var close = false;
		var thumbnailItem = this.getThumbnailItem(itemId);
		thumbnailItem.newName = $('#thumbnailRename_' + itemId).attr('value');
		if (this.confirmRenameSelectedItemHandler) {
			close = this.confirmRenameSelectedItemHandler(thumbnailItem);
			thumbnailItem.renaming = !close;
			// 清空正在重命名的子元素
			if (close) {
				this.renamingItem = null;
				this.setRenameItemDisplay({itemId:itemId, fileName:'', display:'none'});
			}
		} else {
			thumbnailItem.renaming = false;
			this.renamingItem = null;
			this.setRenameItemDisplay({itemId:itemId, fileName:'', display:'none'});
		}
	};

	/**
	 * 重命名取消回调
	 * 
	 * @param itemId {String} 文件(夹)id
	 */ 
	CyThumbnailList.prototype.cancelRenameCallback = function(itemId) {
		this.renamingItem.renaming = false;		
		this.setRenameItemDisplay({itemId:itemId, fileName:'', display:'none', isLoadImageError:this.renamingItem.isLoadImageError});
		this.renamingItem = null;
	};
	
	/**
	 * 隐藏重命名框和新建文件夹的命名框
	 * 
	 * @param selectingItem
	 *            {ThumbnailItem} 重命名时选中的一个文件（夹）
	 */
	CyThumbnailList.prototype.clearRenameAndNewFolder = function(selectingItem) {
		// 重置文件项的renaming属性
		if (this.renamingItem && this.renamingItem != selectingItem) {
			this.renamingItem.renaming = false;
			this.setRenameItemDisplay({itemId:this.renamingItem.fileID, fileName:'', display:'none'});
			this.renamingItem = null;
		}
		if (this.newFoldering) {
			$('#' + this.newFoldering.fileID).remove();
			this.newFoldering = null;
		}
	};

	/**
	 * 确认重命名的回调函数
	 * 
	 * function handler(params){ return true ; //
	 * 返回true表示结束重命名，返回false表示不结束重命名，让用户继续输入 };
	 */
	CyThumbnailList.prototype.setConfirmRenameSelectedItemHandler = function(
			handler) {
		this.confirmRenameSelectedItemHandler = handler;
	};

	/**
	 * 设置判断列表项是否可以放置拖拽文件项
	 * 
	 * @param handler
	 *            回调函数 
	 * dragItems {CyThumbnailItem Array}被拖拽的文件项 dropItem {CyThumbnailItem} 要放置到的文件项            
	 * function handler(dragItems, dropItem){ return true ; //
	 * 返回true表示可以放置，false表示不可以放置，不可以放置的列表项不触发放置效果 };
	 */
	CyThumbnailList.prototype.setItemDropableHandler = function(handler) {
		this.itemDropableHandler = handler;
	};

	/**
	 * 设置拖拽项被放置到放置项时触发事件的回调函数
	 * 
	 * @param handler
	 *            回调函数
	 * 
	 * dragItems {CyThumbnailItem Array}被拖拽的文件项 
	 * dropItem {CyThumbnailItem}要放置到的文件项 
	 * outsideDrag {Boolean} true 从本地文件系统拖拽文件上传 false 在浏览器里拖拽移动文件（夹）
	 * function handler(dragItems, dropItem){ };
	 */
	CyThumbnailList.prototype.setItemDropHandler = function(handler) {
		this.itemDropHandler = handler;
	};
	
	/**
	 * 显示病毒文件提示语
	 * eventType {String}对象 鼠标移动事件名
	 *
	 * position {pageX : event.pageX, pageY : event.pageY}
	 */
	CyThumbnailList.prototype.handlerMouseMove = function(eventType, position) {		
		var $virusTips = $('#thumbnail_virus_tips');
		var $virusTipsCSS = $('#thumbnail_virus_tipsCSS');
		if (type === 'mousemove') {
			$virusTips.css({
                top: position.pageY - 26,
                left: position.pageX - 204
            });
			$virusTipsCSS.show();
		} else if (type === 'mouseout') {
			$virusTipsCSS.hide();
		}
	};

	/**
	 * 彩云缩略图单个文件(夹)项
	 * 
	 * @param data
	 *            创建文件项所需要的初始数据 {fileID : 文件或文件夹ID,imgPath : 图片地址,fileName :
	 *            文件名,fileType : 文件类型('file'|'folder'),size : 文件大小字符串 xxMB ,
	 *            date : 显示时间字符串 , virus : 是否有毒 true 有毒 false 没毒, share : 是否共享
	 *            true 已共享 false 未共享, keyWords: 在搜索视图中搜索的关键字(其他视图可以不需要) }
	 * @param parent
	 *            {CyThumbnailList} 被添加到的缩略图列表
	 */
	function CyThumbnailItem(data) {
		var self = this;
		this.fileID = data.fileID;
		this.imgPath = data.imgPath;
		this.fileName = window.caiyun.util.htmlEscape(data.fileName);
		this.fileType = data.fileType || 'file'; // 创建新文件夹的样式
		this.virus = data.virus;
		this.share = data.share;
		this.selected = false;
		this.unselectAllable = data.unselectAllable;
		this.linkedFile = data.linkedFile;
		this.isFixedDir = data.isFixedDir;
		this.canMove = window.caiyun.operate.canExecute('move', this.fileID); // "收到的分享"目录里不支持拖拽操移动作
		this.isVideo = data.isVideo || false;
		this.isNew = data.isNew || false; // "收到的分享"目录有新分享文件时，显示icon
		this.inReceviteShareDir = data.inReceviteShareDir;
		this.inEnterpriseDir = data.inEnterpriseDir;
		this.showNameLength = 10;
		this.showFileName = function(){
			var name = self.fileName;
			var keyWords = data.keyWords;
			if (!name) {
				return '';
			}
			var showNameLength = 10;
			if (name.strLen() <= showNameLength + 2) {
				return keyWords ? utils.strBound(name, keyWords) : name;
			} else {
				return keyWords ? utils.strBound(name.subCHStr(0, showNameLength - 4), keyWords) + "..." + 
						utils.strBound(name.subCHStr(name.strLen() - 4), keyWords) : 
							name.subCHStr(0, showNameLength - 4) + "..." + name.subCHStr(name.strLen() - 4);
			}
		};
		this.isLoadImageError = false;
		var image = new Image();
		image.src = this.imgPath;
		image.onerror = function(){
		  self.isLoadImageError = true; 
		  this.onerror = null;
		};
	}

})();