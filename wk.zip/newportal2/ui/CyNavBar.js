/**
 * 导航工具栏组件
 * 
 */
(function(){
	window.caiyun.ui.CyNavBar = function(param){
		var time = new Date().getTime();
		var renderToDom ;
		var timeoutFun = {};
		var cfgs = param || {};
		var canClose = false;
		var _ids = [];
        
        var init = function(){
        	renderToDom = $('#'+cfgs.renderTo);
        	renderToDom.hide();
        };
        
        var createBarBut = function(ids){
        	_ids = ids;
        	
//        	renderToDom.html('<table class="doc_t_h" width="100%" border="0" cellspacing="0" cellpadding="0"><tbody>'
//        			+'<tr></tr></tbody></table>');
//
//        	renderToDom.find('tr').append('<th style="width:30px"><span class="input_first"></span></th>');
//        	renderToDom.find('tr').append('<th class="p5" colspan="3"><div class="doc_list_name"><div id="' + getId('fileCount') + '" class="look_all"></div></div></th>');
        	renderToDom.html('<div class="doc_list_name"><div id="' + getId('fileCount') + '" class="look_all"></div></div>');
        	var $list = renderToDom.find('#'+ getId('fileCount'));
        	$list.append('<span class="look_all_txt">已经选中'+ids.length+'个文件或文件夹</span>')
        	$.each(cfgs.items, function(i, item){
        		if(item.isDisable()){
        			$list.append('<a id="'+getId(item.id)+'" href="javascript:void(0);">' +
        				'<span class="look_all_btn ' + item.style + '">'+item.name+'</span></a>');
        			bindButHandle(item);
        		}
        	});
        };
        
        var createSubmenu = function(items,parantId){
           if($('#'+getId(parantId) + '_subMenu').length > 0){
           	  return ;
           }
		   
           var parant = $('#'+getId(parantId)).append('<div class="barSubMenu" id="'+getId(parantId)+'_subMenu" >');
           var subMenu = $('#'+getId(parantId) + '_subMenu');
           
	       $.each(items, function(i, item){
	            if(item.isDisable()){
	        		subMenu.append('<a id="'+getId(parantId + '_' +item.id)+'" href="javascript:void(0);">' +
	        			'<span class="look_all_btn '+ item.style + '">'+item.name+'</span></a>');
	        		bindSubmenuButHandle(item,subMenu,parantId);
	        	}
	        });
                    
           parant.append('</div>');    
           
           bindSubMenuClose(subMenu);   
        };
        
        var bindSubMenuClose = function(subMenu){
        	$("body").unbind('mousedown').bind("mousedown",function(){
                canClose = true;
                setTimeout(function(){beforeClose(subMenu);},200);
            });
            subMenu.unbind('mouseout').bind("mouseout", function(){
                canClose = true;
                setTimeout(function(){beforeClose(subMenu);},1000);
            }).unbind('mouseover').bind("mouseover", function(){
                canClose = false;
            });  
        };
        
        var bindSubmenuButHandle = function(item,subMenu,parantId){
        	$('#'+getId(parantId + '_' +item.id)).unbind('click').bind('click',function(e){
        		run(item.click,{ids:_ids,e:e});
        		subMenu.remove();
        		$('#'+getId(parantId)).removeClass("hover");
        		return stopDefault(e);
        	}).hover(
				  function () {
				    $(this).addClass("hover");
				  },
				  function () {
				    $(this).removeClass("hover");
				  }
			);
        };
        
        var bindButHandle = function(item){
        	$('#'+getId(item.id)).unbind('click').bind('click',function(e){
        		if(item.items){
		            createSubmenu(item.items,item.id);
        		}else{
        			run(item.click,{ids:_ids,e:e});
        		}
        		
        		return stopDefault(e);
        	}).hover(
				  function () {
				    $(this).addClass("hover");
				  },
				  function () {
				    $(this).removeClass("hover");
				  }
			);
        };
        
        
        var beforeClose = function(subMenu){
        	if(canClose){
        		subMenu.remove();
        	}
        }
         
        //传入方法统一回调
        var run = function(obj,e){
        	if(!obj){
        		return;
        	}
        	
            var type = typeof(obj);
            if(type == "function"){
                return obj(e);
            }
            else if(type == "string"){
                return eval("(" + obj + "(e))");
            }
        };
        
        var stopDefault = function(e){
            if(e && e.stopPropagation) {  
            	e.stopPropagation();
	        } else {
	            //否则，我们需要使用IE的方式来取消事件冒泡   
  　　		    e.cancelBubble = true;  
	        }
	        	        
	        if(e && e.preventDefault) {  
	        	e.preventDefault();
	        } else {  
	        　　  //IE中阻止函数器默认动作的方式   
	        　　  e.returnValue = false;   
	        } 
	        
	        return false;
        };
        
        var getId = function(id){
        	return time + '_' + id;
        };
        
        var nvaBarShow = function(ids){
        	if(ids.length < 1){
        		renderToDom.html('');
        		renderToDom.hide();
        		return ;
        	}
        	renderToDom.show();
        	clearTimeout(timeoutFun);
        	timeoutFun = setTimeout(function(){
        		createBarBut(ids);
        	},100);
        };
        
        init();
        
        return {
        	nvaBarShow : nvaBarShow
        };
    };
})();
