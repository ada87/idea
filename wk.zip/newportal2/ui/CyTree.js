/**
 * tree组件
 * @param {object} obj{
 * 							renderTo  : '树追加到dom元素的id',
 *                          animate   : 'true：有动画效果',
 * 							root      : {
 *                                        iconCls   : '结点树的作用class名称，一般用于图标显示',
 * 							              text      : '树结点名称',
 *                                        imageURL  : '结点背影图片',
 *                                        pid       : '生成结点的父结点id',
 * 						                  click     : function(){结点展开时的数据读取回调},
 * 							              select    : function(){结点选择时回调，可做一些文件夹判断操作。不传此回调，选择时默认行为为展开结点},
 *                                        fitter    : function(){}
 *                                       }
 *                       }
 */
;(function(){
    window.caiyun.ui.CyTree = function(obj){
        var cfg = obj; 
        var sNode;
        var rootNode;
        
        var init = function(){
            //判断是否输入了配置
            if(!cfg){
                alert("please input config!");
                return;
            }
            //判断是否指定了要生成tree的id
            if(cfg.root.length === 0){
                alert(nEnterMsg("root"));
                return;
            }
            //判断是否指定了要插入的页面元素的id
            if(!cfg.renderTo){
                alert(this.nEnterMsg("renderTo"));
                return;
            }
            //判断要注入树的对象是否存在
            rootNode=$("#"+cfg.renderTo);
            if(rootNode.length === 0){
                return;
            }
            
            //初始化树
            rootNode.html('<ul class="filetree treeview jTree"></ul>');
            var html="";
            $.each(cfg.root,function(i,n){
                addNode(n);
            });
        };
        
        /**
         * @param n     结点数据对象
         * 
         */
        var addNode = function(n){
             var params = {
                fitter        : function(){return false}
             };
             
             $.extend(params,n);
             
             var pNode;//获取父节点对象
             if(n.pid){
                pNode = $("#" + cfg.renderTo + "_" + n.pid);
             }
             else{
                pNode=$("#" + cfg.renderTo);
             }
             
             var pdiv = pNode.children("div");
           
             
             //获取父节点ul
             var pul = pNode.children("ul");
             //如果没有则创建
             if(pul.length === 0){
                if(n.pid && run(n.fitter,n.pid)){
                    pul=$('<ul class="filetree treeview top-node"></ul>').appendTo(pNode);
                }
                else{
                    pul=$('<ul class="filetree treeview"></ul>').appendTo(pNode);
                }
             }
             
             //构造节点
             var li_id = cfg.renderTo + '_' + n.id;
             html= '<li id="' + li_id + '" class="';
             if(n.leaf){
                html += '"><div class="';
             }
             else{
                html += 'expandable';
                if(!n.pid){
                    html += '"><div class="clearfix top-directory"><div ';
                    html += 'id=';
                    html += '"treeDiv_';
                    html += n.id;
                    html += '" class="hitarea expandable-hitarea';
                }
                else{
                    html += '"><div class="clearfix"><div ';
                    html += 'id=';
                    html += '"treeDiv_';
                    html += n.id;
                    html += '" class="hitarea expandable-hitarea';
                }
             }
            
             if(n.iconCls){
                html += ' ' + n.iconCls;
             }
            
             html += '" ></div><span ';
             html += 'id="';
             html += 'treeSpan_';
             html += n.id;
             html += '" class="close-hitarea ';
             
             if(n.iconCls){
                html += ' ' + n.iconCls;
             }
             
             html+='"><em';
             if(n.tip){
                html+=' title="'+n.tip+'"';
             }
             html += '>' + n.text + '</em></span></div></li>';
    
             //保存节点路径
             var path;
             if(n.pid){
                path = pNode.data("path") + "/" + n.id;
             }
             else{
                path = n.id;
             }
             
             var node;
            
             if(cfg.animate){
                 pul.append(html).hide().slideDown("fast");
	         }else{
	             pul.append(html);
	         }
             
             node = $('#'+li_id);
             node.data("path",path).children("div").unbind('click').bind('click',function(e){
                 if("c" == toggleNode($(this).parent())){
                    if(n.click){
                        e.id = n.id;
                        e.path = path;
                        run(n.click,e);
                    }
                 }
                 else{
                 	nodeClear($(this).parent());
                 }
                 stopDefault(e);
             }).end().children("div").children("span").unbind('mousedown').bind('mousedown',function(e){
                    e.id = n.id;
                    e.path = path;
                    if(n.select){
                        run(n.select,e);
                    }
                    else{
                        var sNode = $(this).parent();
                        if(e.which == 1){
                            if(sNode.children("ul").length !== 0){
                                sNode.children("ul").remove();
                            }
                            collapsableByObj(sNode);
                            if(n.click){
                                run(n.click,e);
                            }
                        }                   
                    }
                    selectNode($(this));
                }).unbind('click').bind('click',function(e){
                    stopDefault(e);
                });
             if(n.imageURL){
                $('#treeSpan_' + n.id).css("background","url("+n.imageURL+")"+" no-repeat 4px 0");
             }
        };
        
        //收起树
        var nodeExpandable = function(obj){
            var css=obj.attr("class");
            if(css.indexOf("collapsable")!=-1){
                obj.removeClass("collapsable").addClass("expandable");  
            }
            if(css.indexOf("lastCollapsable")!=-1){
                obj.removeClass("lastCollapsable").addClass("lastExpandable");
            }
            obj.children("div").removeClass("collapsable-hitarea").addClass("expandable-hitarea");
            obj.children("ul").hide();//隐藏下级目录
        };
        
        //展示树
        var nodeCollapsable = function(obj){
            if(!obj){return;}
            var css=obj.attr("class");
            if(css.indexOf("expandable")!=-1){
                obj.removeClass("expandable").addClass("collapsable");
            }
            if(css.indexOf("lastExpandable")!=-1){
                obj.removeClass("lastExpandable").addClass("lastCollapsable");
            }
            obj.children("div").removeClass("expandable-hitarea").addClass("collapsable-hitarea");
        };
        
        //打印参数未输入错误信息
        var nEnterMsg = function(param){
            return "Parameter "+param+" do not enter!";
        };
        
        //传入方法统一回调
        var run = function(obj,e){
            var type = typeof(obj);
            if(type == "function"){
                return obj(e);
            }
            else if(type == "string"){
                return eval("(" + obj + "(e))");
            }
        };
        
        var selectNode = function(node){
            if(node.length === 0){return;}
            rootNode.find(".selected").removeClass("selected");
            node.parent().addClass("selected");
            rootNode.find(".node-selected").removeClass("node-selected");
            node.addClass("node-selected");
        };
        
        //展开指定节点 通过id
        var collapsableById = function(nodeId){
            var node=$("#"+cfg.renderTo+"_"+nodeId);
            collapsableByObj(node);
        };
        
        //展开指定节点 通过对新
        var collapsableByObj = function(node){
            var css=node.attr("class");
            if(css.indexOf("expandable")!=-1){
                node.removeClass("expandable").addClass("collapsable");
            }
            if(css.indexOf("lastExpandable")!=-1){
                node.removeClass("lastExpandable").addClass("lastCollapsable");
            }
            var childNode = node.children("div").children("div");
            css = childNode.attr("class");
            if(css){
                if(css.indexOf("expandable-hitarea") != -1){
                    childNode.removeClass("expandable-hitarea").addClass("collapsable-hitarea");
                }
            }
        };
        
        //展开收起节点
        var toggleNode = function(node){
            var s="";
            var css=node.attr("class");
            if(css.indexOf("expandable")!=-1){
                node.removeClass("expandable").addClass("collapsable");
                 s="c";
            }
            else if(css.indexOf("collapsable")!=-1){
                node.removeClass("collapsable").addClass("expandable");
                s="e";
            }
            if(css.indexOf("lastExpandable")!=-1){
                node.removeClass("lastExpandable").addClass("lastCollapsable");
                 s="c";
            }else if(css.indexOf("lastCollapsable")!=-1){
                node.removeClass("lastCollapsable").addClass("lastCollapsable");
                s="e";
            }
            var childNode=node.children("div").children("div");
            var childSpan=node.children("div").children("span");
            css = childNode.attr("class");
            if(css.indexOf("expandable-hitarea")!=-1){
                childNode.removeClass("expandable-hitarea").addClass("collapsable-hitarea");
                childSpan.removeClass("close-hitarea").addClass("open-hitarea");
            }
            else if(css.indexOf("collapsable-hitarea")!=-1){
                childNode.removeClass("collapsable-hitarea").addClass("expandable-hitarea");
                childSpan.removeClass("open-hitarea").addClass("close-hitarea");
            }
            return s;
        };
        
        var getSelectedNode = function(){
            var obj = {};
            if(!sNode){
                obj.id = "";
                obj.text = "";
            }
            else{
                obj.id = sNode.attr("id").split("_")[1];
                obj.text = sNode.children("div").children("span").children("em").html();
            }
            return obj;
        };
        
       var expandable = function(nodeId){
                var node=$("#"+cfg.renderTo+"_"+nodeId);
                var css=node.attr("class");
                if(css.indexOf("collapsable")!=-1){
                    node.removeClass("collapsable").addClass("expandable");
                }
                if(css.indexOf("lastCollapsable")!=-1){
                    node.removeClass("lastCollapsable").addClass("lastCollapsable");
                }
                var childNode=node.children("div").children("div");
                css=childNode.attr("class");
                if(css.indexOf("collapsable-hitarea")!=-1){
                    childNode.removeClass("collapsable-hitarea").addClass("expandable-hitarea");
                }
        };
        
       var removeNode = function(nodeId){
                var idobj=$("#"+cfg.renderTo+"_"+nodeId);
                var pidobj=idobj.parent();
                var pli=pidobj.children("li");
                var lastli=$(pli[pli.length-1]);
                if(lastli.length === 0){return;}
                if(lastli.attr("class") && lastli.attr("class").indexOf("last") === -1){
                    lastli.removeClass().addClass("last").children("div").children("div").remove();
                }
                idobj.remove();
         };
         
        var isCollapsable = function(node){
                var css=node.attr("class");
                if(css.indexOf("collapsable")!=-1){
                    node.removeClass("collapsable").addClass("expandable");
                    return true;
                }else if(css.indexOf("lastCollapsable")!=-1){
                    node.removeClass("lastCollapsable").addClass("lastCollapsable");
                    return true;
                }
         };
         
         var nodeClear = function($node,fun){
         	if(cfg.animate){
                	$node.children("ul").slideUp("fast",function(){
                		$(this).remove();
                		if(fun){
                			fun();
                		}
                	});
            }else{
                	$node.children("ul").remove();
                	if(fun){
                		fun();
                	}
            }
         }
        
        
        /**
         * 文本框追加树的前面还是后面
         * 
         * param {
         * 	  submitFun :  创建结点，点击确定时的回调函数
         *    isBefor   ： 【true:创建文本输入框追加在前面】【false:创建文本输入框追加在后面】
         *    maxLength : 能输入的文件名最大字数
         * }
         * 
         */
        var createInputNode = function(param){
        	if($("input[id^='input_create']").focus().length > 0){
        		return ;
        	}
        	
        	var params = {
                isBefor        : false,
                maxLength  : 32
            };
            $.extend(params,param);
            
        	var pid = sNode.attr("id").split("_")[1];
        	var isColl = isCollapsable($("#"+cfg.renderTo+"_"+pid));
        	collapsableById(pid);
            var pNode;//获取父节点对象
            if(pid){
                pNode = $("#" + cfg.renderTo + "_" + pid);
             }
             else{
                pNode=$("#" + cfg.renderTo);
             }
             
             //获取父节点ul
             var pul = pNode.children("ul");
             
             if(pul.length === 0){
                pul=$('<ul class="filetree treeview"></ul>').appendTo(pNode);
             };
             
             //构造节点
             var date = new Date().getTime();
             var li_id = cfg.renderTo + '_' + date;
             html= '<li id="' + li_id + '" class="expandable"><div class="clearfix update_name">';
             html += '<input id="input_create'+date+'" class="newf-input" maxlength="'+ params.maxLength + '"/>' +
             		 '<a href="javascript:void(0);" class="newf-ok" id="sub_'+date+'"></a>&nbsp;' +
             		 '<a href="javascript:void(0);" class="newf-no" id="del_'+date+'"></a>';
             html += '</div></li>';
             
             if(params.isBefor){
                prepend(pul,html);
             }
             else{
                append(pul,html);
             }
             
             var input_create = $('#input_create' + date).focus();
             
             $('#sub_' + date).unbind('click').bind('click',function(e){
             	if(params.submitFun){
             		var folderName = input_create.val();
             		run(params.submitFun,{parentId:pid,folderName:folderName});
             	}
             	stopDefault(e);
             });
             
             $('#del_' + date).unbind('click').bind('click',function(e){
             	if(!isColl){
             		expandable(pid);
             	}
             	if(cfg.animate){
             		$('#'+li_id).slideUp("fast",function(){
                		$(this).remove();
             		});
             	}else{
             		$('#'+li_id).remove();
             	}
             	
             	stopDefault(e);
             });
             
        };
        
        /**
         *param {
         * 	  submitFun :  重命名结点时，确定按钮的回调函数.如果回调执行成功反回true时，结点命名才会更新
         * } 
         *
         */
        var setNodeName = function(params){
        	if($("input[id^='input_rename']").focus().length > 0){
        		return ;
        	}
        	
        	var date = new Date().getTime();
        	var nodeId = sNode.attr("id").split("_")[1];
        	var nodeText = $('#treeSpan_'+ nodeId);
        	var oldName = nodeText.html();
        	var $div = $('#treeSpan_'+ nodeId).addClass(' update_name');;
        	$div.html('<input id="input_rename'+date+'" />' +
        			'<a href="javascript:void(0);" class="newf-ok" id="sub_rename'+date+'"></a>&nbsp;' +
        			'<a href="javascript:void(0);" class="newf-no" id="del_rename'+date+'"></a>');
        	
        	var input_rename = $('#input_rename' + date).focus();
        	
        	$('#sub_rename' + date).unbind('click').bind('click',function(e){
             	if(params.submitFun){
             		var newName = input_rename.val();
             		if(run(params.submitFun,{id:nodeId,folderName:newName})){
             			$div.html('<em>'+newName+'</em>');
             		}
             	}else{
             		$div.html('<em>'+oldName+'</em>');
             	}
             	stopDefault(e);
             });
             
             $('#del_rename' + date).unbind('click').bind('click',function(e){
             	$div.html('<em>'+oldName+'</em>');
             	stopDefault(e);
             });
        };
        
        var stopDefault = function(e){
            if(e && e.stopPropagation) {  
            	e.stopPropagation();
	        } else {
	            //否则，我们需要使用IE的方式来取消事件冒泡   
  　　		    e.cancelBubble = true;  
	        }
	        	        
	        if(e && e.preventDefault) {  
	        	e.preventDefault();
	        } else {  
	        　　  //IE中阻止函数器默认动作的方式   
	        　　  e.returnValue = false;   
	        } 
	        
	        return false;
        };
        
         var append = function($obj,html){
        	 if(cfg.animate){
                 $obj.append(html).hide().slideDown("fast");
	         }else{
	             $obj.append(html);
	         }
        	
        };
        
        var prepend = function($obj,html){
        	 if(cfg.animate){
                 $obj.prepend(html).hide().slideDown("fast");
	         }else{
	             $obj.prepend(html);
	         }
        };
        
        init();
        
        return {
            addData:function(nodeId,data,parser){
                var node=$("#"+cfg.renderTo+"_"+nodeId);
                if(node.length === 0){return;}
                nodeClear(node);
                addNodes(nodeId,data,parser);
                this.collapsable(nodeId);
            },
    
            //添加一个节点
            addNode:addNode,
            
            //移除指定的节点
            removeNode:removeNode,
            
            //展开指定节点(id)
            collapsable:collapsableById,
            
            //是否为展开状态
            isCollapsable:isCollapsable,
            
            //展开指定节点($ node对象)
            collapsableNode:collapsableByObj,
            
            //收起指定结点
            expandable:expandable,
            
            //先择指定结点
            selectNode:selectNode,
            
            //清除指定结点下的树目录
            clear:function(nodeid){
                var node=$("#"+cfg.renderTo+"_"+nodeid);
                nodeClear(node);
            },
            
            //获取己先择的结点
            getSelectedNode:function(){
                return getSelectedNode();
            },
            
            //结点重命名
            setNodeName:setNodeName,
            
            selectNodeByID:function(nodeid){
                var node=$('#'+cfg.renderTo+'_'+nodeid);
                sNode=node;
                selectNode(node.children("div").children("span"));
            },
            
            getSelectedNodeName : function(nid){
                return $('#'+cfg.renderTo+'_'+nid).children("div").children("span").children("em").html();          
            },
            
            getSelectNodePath : function(nid){
                return $('#'+cfg.renderTo+'_'+nid).data('path');
            },
            
            createInputNode : createInputNode
        };
    };    
})();