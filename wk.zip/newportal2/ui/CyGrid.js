/**
 * Created with IntelliJ IDEA.
 * User: LiBing
 * Date: 13-6-26
 * Time: 上午11:15
 * 彩云内容列表组件
 */
;(function(){
    /**
     * 彩云内容列表对象
     * @param columnConfig {
     *          renderId："",         //渲染Div的ID
     *          columns[{
     *              columnType:"",   //可以支持:checkBox(显示勾选列),fileInfo(显示文件信息列),String(显示一行文字列)
     *              colName:"",      //列名称
     *
     *              prefixIcon:"",   //只针对String字段, 是否需要显示头图标[true/false]
     *              suffixIcon:"",   //只针对String字段, 是否需要显示尾图标[true/false]
     *              clickEvent:"",   //只针对String字段, 是否需要点击打开事件[true/false]
     *              width:"0",       //列宽可这百分比或像数(像数时带上单位px)
     *              align:"",        //可以取值 left|center|right
     *              valign:""        //可以取值 top|middle|bottom|baseline
     *          }]
     *       } 内容列配置
     * @constructor
     */
    window.caiyun.ui.CyGrid = function(columnConfig){
        var util = window.caiyun.util;
        /**
         * 获取一个时间戳的标记
         * @returns {number}
         */
        var getTimeFlag = function(){
            return new Date().getTime();
        };

        //根据指定行的内容ID添加一个定时器
        var addToolsTimer=function(itemId){
            return setTimeout(function(){
                $("#ptools_"+time+'_'+itemId).show();
            },200);
        };

        //阻止事件冒泡
        var stopDefault = function(e){
            if(e && e.stopPropagation) {
                e.stopPropagation();
            } else {
                //否则，我们需要使用IE的方式来取消事件冒泡
                e.cancelBubble = true;
            }
            if(e && e.preventDefault) {
                e.preventDefault();
            } else {
                //IE中阻止函数器默认动作的方式
                e.returnValue = false;
            }
            return false;
        };
        var hideColumnNames=[];  //设置需要置空隐藏的列名
        var winAttr={};
        var clickTimer=null;
        var isShow=false;
        var toolsTimer=null; //显示工具图标的定时器
        var time = getTimeFlag();
        var dataItems=[];    //接收到的显示内容列表中数据
        var palyMusicItemId=null;  //当前播放的音乐ID
        var selectIdsObj={}; //已选择数据item的id作为属性key的对象
        var handlerObj={};   //保存事件对应的处理方法
        var defaultColumnConfig={
            renderId:"doc_content",
            draggable:false,  //是否需要拖拽功能
            columns:[],
            createColumnHtmlByType:{
                checkBox:function(item,colName){
                    var $td=$('<td class="p5"><span class="input_on"></span></td>').attr("id",getId(colName)+ "_" + item.id).dblclick(function(e){
                        stopDefault(e);
                    });
                    $td.bind("click",function(e){
                        clearNewFolderHtml();
                        clearRenameHtml();
                        if(e.shiftKey){
                            var clickRowNo=$(this).parent().attr("rowNo");
                            shiftSelect(clickRowNo);
                            return stopDefault(e);
                        }
                        var parent=$(this).parent();
                        //已经选择时,去掉选择
                        if(parent.attr("class") == "current"){
                            $(this).find("p").hide();
                            parent.removeClass().addClass("hover");
                            delete selectIdsObj[item.id];
                            clearTimeout(toolsTimer);
                            handlerObj.selectedHandler(getSelectedItems(),dataItems.length);
                        //还没有选择
                        }else if(parent.attr("class") == "hover"){
                            $(this).find("p").hide();
                            parent.removeClass().addClass("current");
                            selectIdsObj[item.id]=getTimeFlag();
                            var selectNum=getSelectedItems().length;
                            if(selectNum == 1){
                                toolsTimer=addToolsTimer(item.id);
                            }
                            handlerObj.selectedHandler(getSelectedItems(),dataItems.length);
                        }
                        stopDefault(e);
                    });
                    return $td;
                },
                fileInfo:function(item,colName){
                    var $td=$('<td></td>').attr("id",getId(colName)+ "_" + item.id);
                    var $div=$('<div class="doc_nr_box clearfix"></div>');

                    //是否已经共享
                    if(item.isShare){
                        $div.append('<b class="min_icon m_people" title="分享给其他用户"></b>');
                    }

                    //是否有新已收到的共享文件
                    if(item.isReciveNew){
                        $div.append('<b class="min_icon m_minNew" title="有新收到的文件"></b>');
                    }

                    var $img=$('<img/>').attr("src",item.url).attr("width",32).attr("height",32).attr("style","cursor:pointer");
                    // 拖拽时显示的图用该属性保存的url;
                	item.imageForDrag = item.url;
                	// 显示大图时用该属性保存的url;
                	item.imageForMax = item.url;
                	$img.on('error', function(){
                		$(this).attr("src", "../images/newportal2/config_img.gif");
                		item.imageForDrag = "../images/newportal2/config_img.gif";
                		item.imageForMax = "../images/newportal2/config_img.gif";
                	});
//                    var $img=$('<img onerror="javascript:this.src=\'/Mcloud/images/newportal2/config_img.gif\';"/>').attr("src",item.url).attr("width",32).attr("height",32).attr("style","cursor:pointer");
                    
                    //是否不需要图标打开文件事件(针对文件外链的要求)
                    if(!item.imageNotClick){
                        $img.bind("click",function(e){
                            handlerObj.openHandler(item);
                            stopDefault(e);
                        }).dblclick(function(e){stopDefault(e);});
                    }

                    //是否需要缩略图预览
                    if(item.isImagePreview){
                        $img.hover(
                            function(){
                            	var $imgMax=$('<img/>').attr("src","../images/newportal2/s.gif").attr("style","width:142px;height:142px;background:url(" + 
                        				item.imageForMax + ") no-repeat scroll 50% 50%;");                   
		                        var $imagMaxDiv=$('<div class="img_max_look"></div>').attr("id",getId("maxImg")+"_"+item.id).append($imgMax).hide();
		                        $div.append($imagMaxDiv);		                        
                            	
                                $div.css("z-index","3");
                                if(isBottomItem(item.id)){
                                    $("#maxImg_"+time+"_"+item.id).css("top","-114px");
                                }
                                $("#maxImg_"+time+"_"+item.id).show();
                            },
                            function(){
                                if(isBottomItem(item.id)){
                                    $("#maxImg_"+time+"_"+item.id).css("top","8px");
                                }
                                $("#maxImg_"+time+"_"+item.id).hide();
                                $div.css("z-index","");
                            }
                        );
                        // IE6、IE7、IE8、Opera 10+、Safari 5+都支持Mousewheel事件，Firefox 3.5+却不支持Mousewheel事件，但支持DOMMouseScroll事件
                        if (/Chrome/igm.test(navigator.userAgent)) {
                        	$img.on('mousewheel', function(){
                                if(isBottomItem(item.id)){
                                    $("#maxImg_"+time+"_"+item.id).css("top","8px");
                                }
                                $("#maxImg_"+time+"_"+item.id).hide();
                                $div.css("z-index","");
                            });
                        }                
                    }
                    $div.append($img);

                    //对搜索视图的关键字样式处理
                    var fileName = item[colName].substringName(25);
                    var $fileName=$('<h2 title="'+item[colName]+'">'+fileName+'</h2>');
                    if(item.keyWords){
                        var tempName=util.strBound(fileName,item.keyWords);
                        $fileName=$('<h2 title="'+item[colName]+'">'+tempName+'</h2>');
                    }
                    $fileName.attr("id",getId("fileName")+'_'+item.id);
                    //是否不需要点击名字打开文件的事件(针对文件外链的要求)
                    if(!item.fileNameNotClick){
                        $fileName.attr("style","cursor:pointer").bind("click",function(e){
                            handlerObj.openHandler(item);
                            stopDefault(e);
                        }).dblclick(function(e){stopDefault(e);});
                    }

                    //如果是文件要显示来自于哪里并且需要用多一个Div包裹文件名和病毒图标，播放图标等
                    var $fileNameDiv = null;
                    var $divName=$('<div class="doc_nr_r"></div>');
                    if(item.fromPath){
                        //增加来自样式
                        $div.addClass("recycle_txt_box clearfix");
                        //增加新收到文件的未读标识
                        if(item.isRead){
                        	var id = "shareNew_"+item.id;
                        	$div.append('<b title="有新收到的文件" id='+id+' class="min_icon m_minNew"></b>');
                        }
                        
                        $divName.append('<div class="come_from clear">分享者：'+item.fromPath+'</div>');
                        //对文件名增加div包裹
                        $fileNameDiv = $('<div class="floatleft fileName_v"></div>').append($fileName);
                    }

                    //是否具有病毒标识
                    if(item.isVirus){
                        var $virus=$('<div class="virus_ico"></div>').attr("itemId",item.id)
                            .bind('mouseover mouseout mousemove', function(e) {
                                if (e.type  ==  'mouseover' || e.type  ==  'mousemove') {
                                    $("#virusTipDiv").css({
                                        top: e.pageY - 20,
                                        left: e.pageX - 473
                                    });
                                }
                                if (e.type  ==  'mouseover') {
                                    var $virusTip=$('<div id="virus_tipsCSS" class="virus_tipsCSS"><b></b><div class="ing_up_txt">此文件可能存在病毒，请谨慎下载与分享。</div></div>');
                                    $("#virusTipDiv").css("z-index","50").empty().append($virusTip).show();
                                }
                                if (e.type  ==  'mouseout') {
                                    $("#virusTipDiv").empty().css("z-index","").hide();
                                }
                        });
                        //是文件时$fileNameDiv是不为空的
                        if($fileNameDiv){
                            $fileNameDiv.append($virus);
                            $divName.prepend($fileNameDiv);
                        }else{
                            $divName.append($fileName).append($virus);
                        }
                    }else{
                        $divName.prepend($fileName);
                    }
                    $div.append($divName);

                    //是否需要显示工具条
                    var $ptools = $('<p class="hover_tools" ></p>').attr("id",getId("ptools")+"_"+item.id);
                    if(item.toolsBar){
                        var $btools1=$('<b title="分享文件链接" class="hover_tools_btn l_share"></b>').bind("click",function(e){
                            handlerObj.linkHandler(item);
                            stopDefault(e);
                        }).dblclick(function(e){stopDefault(e);});
                        var $btools2=$('<b title="分享给其他用户" class="hover_tools_btn l_Tshare"></b>').bind("click",function(e){
                            handlerObj.shareHandler(item);
                            stopDefault(e);
                        }).dblclick(function(e){stopDefault(e);});
                        var $btools3=$('<b title="下载" class="hover_tools_btn l_download"></b>').bind("click",function(e){
                            handlerObj.downLoadHandler(item);
                            stopDefault(e);
                        }).dblclick(function(e){stopDefault(e);});
                        $ptools.append($btools1).append($btools2).append($btools3);
                    }
                    $div.append($ptools);
                    $td.append($div);
                    return $td;
                },
                newfolder:function(item,colName){
                    //处理重命名和新建文件的处理函数
                    var renameOrNewHandler = function(item){
                        var newFolderName = $("#newName_"+time + "_"+ item.id).val();
                        if(item.id === ""){
                            handlerObj.confirmCreateItemHandler({newFolderName:newFolderName});
                        }else{
                            handlerObj.confirmRenameSelectedItemHandler({newFolderName:newFolderName,item:item});
                        }
                        $('div[id="newfolder_'+ time + '_' + item.id +'"]').remove();
                    };
                    var $td=$('<td></td>').attr("id",getId(colName)+ "_" + item.id);
                    var $imagDiv=$('<div class="floatleft"></div>');
                    var $img=$('<img onerror="javascript:this.src=\'/Mcloud/images/newportal2/config_img.gif\';" />').attr("src",item.url).attr("width",32).attr("height",32);
                    $imagDiv.append($img);
                    var $newFileDiv=$('<div class="newfile"></div>');
                    var $ul=$('<ul></ul>');
                    var $li1=$('<li class="nli_1"></li>').append($('<input type="text" maxlength="32" class="newfolder" maxlength="32"/>')
                        .attr("id",getId("newName")+ "_"+ item.id).val(util.removeSuffix(item[colName])));
                    var $li2=$('<li class="nli_2"><a href="javascript:void(0)" title="确定" class="newf-ok"></a></li>');
                        $li2.find("a").bind("click",function(e){
                            clearTimeout(clickTimer);
                            clickTimer=setTimeout(function(){
                                renameOrNewHandler(item);
                            },300);
                            stopDefault(e);
                        }).dblclick(function(e){stopDefault(e);});
                    var $li3=$('<li class="nli_3"><a href="javascript:void(0)" title="取消" class="newf-no"></a></li>');
                        $li3.find("a").bind("click",function(e){
                            if(item.id === ""){
                                $('div[id="newfolder_'+ time + '_' + item.id +'"]').remove();
                            }else{
                                updateItem(item);
                            }
                            stopDefault(e);
                        }).dblclick(function(e){stopDefault(e);});
                    $ul.append($li1).append($li2).append($li3);
                    $newFileDiv.append($ul);
                    return $td.append($imagDiv).append($newFileDiv);
                },
                String:function(item,colName,prefixIcon,suffixIcon,clickEvent){
                    var $td=$('<td></td>').attr("id",getId(colName) + "_" + item.id).append("<h2></h2>");
                    if(clickEvent){
                        $td.bind("click",function(e){
                            handlerObj.clickColumHandler(item);
                            stopDefault(e);
                        }).attr("style","cursor:pointer").hover(
                            function(){
                               $(this).attr("style","color:#5218AF;cursor:pointer");
                            },
                            function(){
                                $(this).attr("style","");
                            }
                        ).dblclick(function(e){stopDefault(e);});
                    }
                    if(prefixIcon && item.isEnterpriseDir){
                        $td.append($('<b class="min_icon m_share_p"></b>'));
                    }
                    var columValue=item[colName];
                    if(columValue === undefined){
                        columValue="";
                    }
                    $td.append('<span style="float:left;_margin-top: 3px">'+ columValue +'</span>');
                    if(item.isLink && suffixIcon){
                        $td.append('<b class="min_icon m_share" title="分享文件链接"></b>');
                    }
                    return $td;
                }
            }
        };

        $.extend(defaultColumnConfig,columnConfig);

        //根据Id找出当前列表中的item
        var getItemById=function(id){
            var x,len=dataItems.length;
            for(x=0;x<len; x++){
                var temp=dataItems[x];
                if(id == temp.id){
                    return temp;
                }
            }
            return null;
        };

        //当在新建文件名状态时,出现其他事件，新建文件名状态自动取消
        var clearNewFolderHtml=function(){
            $('div[id^="newfolder_'+ time +'"]').remove();
        };

        //当在重文件名编辑状态时,出现其他事件，重文件名编辑状态自动取消
        var clearRenameHtml=function(){
            var $trRenameData=$('tr[id^="trRenameData_'+time+'"]');
            if($trRenameData.length!==0){
                var id=$trRenameData.attr("id").split("_")[2];
                var item=getItemById(id);
                //清除已选择项
                delete selectIdsObj[item.id];
                var rowDiv=$('div[id="tabDiv_'+ time +'_'+item.id+'"]');
                var rowNo=rowDiv.attr("rowNo");
                var $row_div=createRowHtml(item,rowNo);
                rowDiv.after($row_div);
                rowDiv.remove();
            }
        };

        //判断是否是属于窗口底部的记录(用于处理悬浮图片自动上移一定位置的问题）
        var isBottomItem=function(selectedItemId){
            var thisDiv = $('div[id="tabDiv_' + time + '_' + selectedItemId + '"]');
            var currentTop = thisDiv.offset().top;
            var winHeight=winAttr.winHeight;
            var headerHeight=winAttr.headerHeight;
            //当前进度条的位置(通过当前进度条的位置判断显示的记录范围)
            var currentScorollTop=util.getScrollTop();
            //var contentViewHeight=winHeight-headerHeight;
            //可见视图可以显示的记录数
            //var diplayNum=Math.floor(contentViewHeight/50);
            //已经移动到的记录数
            //var moveNum=Math.round(currentScorollTop/50);
            //当前预览的记录号
            //var selectedNum=Number(thisDiv.attr("rowNo"));
            //不在当前页面范围内,将选择项滚动到当前视图窗口
            var diff=winHeight-(currentTop-currentScorollTop+headerHeight);
            if(diff<0){
                return true;
            }
            return false;
        };

        //处理滚动条和上下键联动的问题
        var windowScrollHandler=function(selectedItemId,isUp){
            var docHeight=winAttr.docHeight;
            var winHeight=winAttr.winHeight;
            var headerHeight=winAttr.headerHeight;
            var contentViewHeight=winHeight-headerHeight;
            //没有滚动条时
            if(docHeight < winHeight){
                return;
            }
            var selectedNum=Number($('div[id="tabDiv_' + time + '_' + selectedItemId + '"]').attr("rowNo"));

            //如果是没有选择时，点击向下默认选择的是最后一个
            if(selectedNum==dataItems.length && !isUp){
                window.scrollTo(0,selectedNum*50);
                return;
            }

            //如果是没有选择时，点击向上键时默认选择的是第一个
            if(selectedNum==1 && isUp){
                window.scrollTo(0,0);
                return;
            }

            //可见视图可以显示的记录数
            var diplayNum=Math.floor(contentViewHeight/50);
            //当前进度条的位置(通过当前进度条的位置判断显示的记录范围)
            var currentScorollTop=util.getScrollTop();
            //已经移动到的记录数
            var moveNum=Math.round(currentScorollTop/50);
            //不在当前页面范围内,将选择项滚动到当前视图窗口
            if(selectedNum<=moveNum || selectedNum>=(moveNum+diplayNum)){
                if(isUp){
                    window.scrollTo(0,(selectedNum-1)*51);
                }else{
                    window.scrollTo(0,(selectedNum-diplayNum)*51);
                }
                return;
            }

        };

        //注册键盘快捷键相关事件处理
        var registerKeyboardHandler= function(){
            if(!isShow){
                $(document).unbind("keydown",keyDownFun);
                return;
            }
            $(document).unbind("keydown",keyDownFun).keydown(keyDownFun);
        };

        //键盘快捷键事件的处理逻辑
        var keyDownFun = function(e){
            var key = e.keyCode;
            if (key == 13){
                //当有弹出层时不做任何操作
                if(window.caiyun.layershow){
                    stopDefault(e);
                    return;
                }
                //获取当前选择的items
                var selectItems=getSelectedItems();
                if(selectItems.length == 1){
                    handlerObj.openHandler(selectItems[0]);
                }
                stopDefault(e);
            }else if (key == 38) {
                //当有弹出层时不做任何操作
                if(window.caiyun.layershow){
                    stopDefault(e);
                    return;
                }
                //取得当前已经选择的行中的最小行
                var selectedState1 = getSelectMaxOrMinRowNo();
                var minNo=selectedState1.minRowNo;
                //没有选择项
                if (minNo == Number.MAX_VALUE) {
                    minNo=1;
                }
                unSelectAll();
                minNo = minNo == 1 ? 1 : (minNo - 1);
                var prevousTr = $('tr[id^="trData_' + time + '_' + '"][rowNo="' + minNo + '"]');
                if (prevousTr.length == 1) {
                    var prevousItemId = prevousTr.attr("id").split("_")[2];
                    //清除已选择行的悬浮工具条样式
                    clearTimeout(toolsTimer);
                    $('p[id^="ptools_' + time + '_' + '"]').hide();
                    //触发选择事件
                    $('div[id^="tabDiv_' + time + '_' + prevousItemId + '"]').click();
                    windowScrollHandler(prevousItemId,true);
                }
                stopDefault(e);
            }else if(key == 40) {
                //当有弹出层时不做任何操作
                if(window.caiyun.layershow){
                    stopDefault(e);
                    return;
                }
                //取得当前已经选择的行中的最小行
                var selectedState2 = getSelectMaxOrMinRowNo();
                var maxRowNo=selectedState2.maxRowNo;
                //没有选择项
                if (maxRowNo == Number.MIN_VALUE) {
                    maxRowNo = dataItems.length;
                }
                unSelectAll();
                maxRowNo= maxRowNo==dataItems.length ? dataItems.length:(maxRowNo+1);
                var nextTr = $('tr[id^="trData_' + time + '_' + '"][rowNo="' + maxRowNo + '"]');
                if (nextTr.length == 1) {
                    var nextItemId = nextTr.attr("id").split("_")[2];
                    //清除已选择行的悬浮工具条样式
                    clearTimeout(toolsTimer);
                    $('p[id^="ptools_' + time + '_' + '"]').hide();
                    //触发选择事件
                    $('div[id^="tabDiv_' + time + '_' + nextItemId + '"]').click();
                    windowScrollHandler(nextItemId,false);
                }
                stopDefault(e);
            }
        };

        /**
         * 根据列配置创建一个内容列表行html代码
         * @param item   数据Item
         * @param rowNo  行号
         * @returns {*|jQuery}
         */
        var createRowHtml=function(item,rowNo){
            var x,colLen=defaultColumnConfig.columns.length;
            var row_div=$('<div class="table_div"></div>').attr("id",getId("tabDiv") + "_" + item.id)
                .attr("rowNo",rowNo).dblclick(function(e){
                    stopDefault(e);
                }).click(function(e){
                    clearNewFolderHtml();
                    clearRenameHtml();
                    if(e.shiftKey){
                        var clickRowNo=$(this).attr("rowNo");
                        shiftSelect(clickRowNo);
                        stopDefault(e);
                        return;
                    }
                    var $trData=$(this).find('tr[id^="trData_'+time+'"]');
                    //已经选择时,去掉选择
                    if($trData.attr("class") == "current"){
                        $(this).find("p").hide();
                        $trData.removeClass().addClass("hover");
                        delete selectIdsObj[item.id];
                        clearTimeout(toolsTimer);
                        handlerObj.selectedHandler(getSelectedItems(),dataItems.length);
                        //还没有选择
                    }else{
                        $(this).find("p").hide();
                        $trData.removeClass().addClass("current");
                        selectIdsObj[item.id]=getTimeFlag();
                        var selectNum=getSelectedItems().length;
                        if(selectNum == 1){
                            toolsTimer=addToolsTimer(item.id);
                        }
                        handlerObj.selectedHandler(getSelectedItems(),dataItems.length);
                    }
                    stopDefault(e);
                }).bind("contextmenu",function(e){
                    //判断当前行是否选中
                    var $trData=$('tr[id="trData_'+ time + '_' +item.id+'"]');
                    if($trData.attr("class") == "current"){
                        handlerObj.contextmenuHandler(getSelectedItems(),e);
                    }else{
                        unSelectAll();
                        $(this).click();
                        handlerObj.contextmenuHandler(getSelectedItems(),e);
                    }
                    stopDefault(e);
                }
            );

            //是否需要拖拽功能
            if(defaultColumnConfig.draggable){
                //增加该文件能不能拖拽的逻辑的判断逻辑
                if(item.isMove){
                    row_div.draggable({
                            revert:true,
                            delay:300,
                            cursorAt: { left: 100 },
                            helper:getDragHelper
                        }
                    );
                }
                row_div.droppable({
                        drop:getDropHelper
                    }
                );
            }
            var table=$('<table width="100%" cellspacing="0" cellpadding="0" border="0"></table>');
            var width_tr=$('<tr></tr>');
            var data_tr=$('<tr></tr>').attr("id",getId("trData")+"_"+ item.id).attr("rowNo",rowNo).addClass("");
            for(x=0; x<colLen; x++){
                var columnType = defaultColumnConfig.columns[x].columnType;
                var colName = defaultColumnConfig.columns[x].colName;
                var columnWidth = defaultColumnConfig.columns[x].width;
                var columnAlign = defaultColumnConfig.columns[x].align;
                if(!columnAlign){
                    columnAlign="center";
                }
                var columnValign = defaultColumnConfig.columns[x].valign;
                if(!columnValign){
                    columnValign="middle";
                }
                var prefixIcon = defaultColumnConfig.columns[x].prefixIcon;
                var suffixIcon = defaultColumnConfig.columns[x].suffixIcon;
                var clickEvent = defaultColumnConfig.columns[x].clickEvent;
                width_tr.append($('<th></th>').attr("width",columnWidth));

                //增加判断是否需要置空隐藏该列的逻辑
                var temp_td=$('<td></td>').attr("align",columnAlign).attr("valign",columnValign);
                if(!isColumnHide(colName)){
                    temp_td=$(defaultColumnConfig.createColumnHtmlByType[columnType](item,colName,prefixIcon,suffixIcon,clickEvent))
                        .attr("align",columnAlign).attr("valign",columnValign);
                }
                data_tr.append(temp_td);
            }
            data_tr.hover(
                function(e){
                    $(this).find("p").hide();
                    var curClass=$(this).attr("class");
                    var selectNum=getSelectedItems().length;
                    if(curClass == "current"){
                        if(selectNum == 1){
                            toolsTimer=addToolsTimer(item.id);
                        }
                        stopDefault(e);
                        return;
                    }
                    $(this).addClass("hover");
                    if(selectNum === 0){
                        toolsTimer=addToolsTimer(item.id);
                    }
                    stopDefault(e);
                },
                function(e){
                    $(this).find("p").hide();
                    $(this).removeClass("hover");
                    clearTimeout(toolsTimer);
                    stopDefault(e);
                }
            );

            table.append(width_tr).append(data_tr);
            row_div.append(table);
            return row_div;
        };

        //创建一个新的文件夹的html代码
        var createNewfolderHtml = function(item,rowNo){
            var x,colLen=defaultColumnConfig.columns.length;
            var row_div=$('<div class="table_div"></div>').attr("id",getId("newfolder")+ "_" + item.id);
            var table=$('<table width="100%" cellspacing="0" cellpadding="0" border="0"></table>');
            var width_tr=$('<tr></tr>');
            var data_tr=$('<tr></tr>').attr("id",getId("trData")+"_"+rowNo+"_"+ item.id).addClass("");
            for(x=0; x< colLen; x++){
                var $td=$('<th></th>').attr("width",defaultColumnConfig.columns[x].width);
                width_tr.append($td);
                var columnType = defaultColumnConfig.columns[x].columnType;
                var colName = defaultColumnConfig.columns[x].colName;
                if(columnType == "fileInfo"){
                    columnType="newfolder";
                }
                data_tr.append(defaultColumnConfig.createColumnHtmlByType[columnType](item,colName));
            }
            table.append(width_tr).append(data_tr);
            row_div.append(table);
            return row_div;
        };

        //创建一个重命名文件夹的html代码
        var createRenameTrHtml = function(item){
            var x,colLen=defaultColumnConfig.columns.length;
            var data_tr=$('<tr></tr>').attr("id",getId("trRenameData")+"_"+ item.id).addClass("");
            for(x=0; x< colLen; x++){
                var columnType = defaultColumnConfig.columns[x].columnType;
                var colName = defaultColumnConfig.columns[x].colName;
                if(columnType == "fileInfo"){
                    columnType="newfolder";
                }
                //增加判断是否需要置空隐藏该列的逻辑
                var temp_td=$('<td></td>');
                if(!isColumnHide(colName)){
                    temp_td=defaultColumnConfig.createColumnHtmlByType[columnType](item,colName);
                }
                data_tr.append(temp_td);
            }
            return data_tr;
        };

        //初始化内容列表Div的相关事件
        var initContentListDiv = function(){
            var len=dataItems.length;
            if(len!==0){
                return;
            }
            $("#virusTipDiv").remove();
            $("body").prepend('<div id="virusTipDiv" style="position: absolute;width:505px;"></div>').css("-moz-user-select","none");
            $("#"+defaultColumnConfig.renderId).empty().css("min-height","447px");
            //如果文件夹为空的时候,或者没有文件夹的时候，手动调整renderId的div高度,并对其进行绑定拖拽本地文件事件
            if(defaultColumnConfig.draggable && window.FileReader){
                registerDragLocalEvent(defaultColumnConfig.renderId);
            }
            //处理IE6拖拽文字被选中事件
            onselectstartHandler();
            //注册键盘快捷键相关事件
            registerKeyboardHandler();
            //初始化相关参数
            initWinAttr();
            //注册窗口大小改变事件
            $(window).resize(function() {
                initWinAttr();
            });
        };

        //初始化窗口相关参数
        var initWinAttr = function(){
            winAttr.docHeight=$(document).height();
            winAttr.winHeight=$(window).height();
            winAttr.conentHeight=$("#"+defaultColumnConfig.renderId).height();
            winAttr.headerHeight=$("#cy_right_head").height()+$("#cy_header").height();
        };

        /**
         * 添加一个Item的Html代码到内容列表中
         * @param item   数据
         * @param rowNo  行号
         * @param actionType  添加的方式
         * @param array 元素缓存数组
         */
        var addItemToDiv = function(item,rowNo,actionType,array){
            var rowDiv = createRowHtml(item,rowNo);
            if(actionType ==="append"){
                if(array){
                    array.push(rowDiv);
                }else{
                    $("#"+defaultColumnConfig.renderId).append(rowDiv);
                }
            }else if(actionType ==="prepend"){
                if(array){
                    array.push(rowDiv);
                }else{
                    $("#"+defaultColumnConfig.renderId).prepend(rowDiv);
                }
            }else if(actionType ==="update"){
                var updateDiv = $('div[id="tabDiv_'+ time + '_' + item.id +'"]');
                updateDiv.after(rowDiv);
                updateDiv.remove();
                //判断是否是选中状态
                if(selectIdsObj[item.id]){
                    $('div[id="tabDiv_'+ time + '_' + item.id +'"]').click();
                }
            }
            //注册相关拖拽事件
            if(!array && defaultColumnConfig.draggable && window.FileReader){
                var divId="tabDiv_" + time + '_' + item.id;
                registerDragLocalEvent(divId);
            }
        };

        /**
         * 获取已选择的列表行中最大和最小的行号
         * @returns {Object}
         */
        var getSelectMaxOrMinRowNo=function(){
            var maxRowNo= Number.MIN_VALUE,minRowNo=Number.MAX_VALUE;
            var maxItemId="",minItemId="";
            var selectRowNum=0;
            $('tr[id^="trData_'+time+'"][class="current"]').filter(function(){
                var curRowNo=Number($(this).attr("rowNo"));
                if((maxRowNo - curRowNo) <0){
                    maxRowNo=curRowNo;
                    maxItemId=$(this).attr("id").split("_")[2];
                }
                if((minRowNo - curRowNo) > 0 ){
                    minRowNo=curRowNo;
                    minItemId=$(this).attr("id").split("_")[2];
                }
                selectRowNum ++;
            });
            return {
                maxRowNo:maxRowNo,minRowNo:minRowNo,
                maxItemId:maxItemId,minItemId:minItemId,
                selectRowNum:selectRowNum
            };
        };

        /**
         * 同时按住shift进行选择
         * @param clickRowNo 当前选择的行号
         */
        var shiftSelect=function(clickRowNo){
            selectIdsObj={};
            var startNo= 0,endNo=0;
            var selectObj=getSelectMaxOrMinRowNo();
            //判断当前位置在上方
            if((clickRowNo-selectObj.minRowNo) < 0){
                startNo=clickRowNo;
                endNo=selectObj.minRowNo;
                //没有选择任何数据时，按住shift进行选择
                if(selectObj.minRowNo==Number.MAX_VALUE){
                    endNo=clickRowNo;
                }
            //判断当前位置在上方
            }else if((clickRowNo -selectObj.maxRowNo) > 0 ){
                startNo=selectObj.maxRowNo;
                endNo=clickRowNo;
                //没有选择任何数据时，按住shift进行选择
                if(selectObj.maxRowNo==Number.MIN_VALUE){
                    startNo=clickRowNo;
                }
            //在两者之间的位置(以最靠近那一边为准)
            }else{
                var seq,middleNo=parseInt((selectObj.maxRowNo - selectObj.minRowNo +1)/2, 10);
                var nums=[];
                for(seq=selectObj.minRowNo;seq<=selectObj.maxRowNo;seq++){
                    nums.push(seq);
                }
                var diff=nums[middleNo];
                if((clickRowNo-diff) >=0 ){
                    startNo=clickRowNo;
                    endNo =selectObj.maxRowNo;
                }else{
                    startNo=selectObj.minRowNo;
                    endNo =clickRowNo;
                }
            }
            //清除已经选择的
            $('tr[id^="trData_'+time+'"][class="current"]').removeClass();
            selectIdsObj=[];
            $('tr[id^="trData_'+time+'"]').filter(function(){
                var curRowNo=Number($(this).attr("rowNo"));
                var itemId=$(this).attr("id").split("_")[2];
                //根据起始位置重新渲染
                if(curRowNo <=endNo  && curRowNo>=startNo){
                    $(this).find("p").hide();
                    $(this).addClass("current");
                    selectIdsObj[itemId]=getTimeFlag();
                }
            });
            handlerObj.selectedHandler(getSelectedItems(),dataItems.length);
        };


        //针对IE6拖拽时，选择文字的问题
        var onselectstartHandler = function(){
            $("body").bind("selectstart",function(e){
                if(e.srcElement.type != "text")
                {
                    return false;
                }
            });
        };

        /**
         * 在列表结尾添加列表项
         * @param items[
         *  {
         *      parentID:"",       //文件行的父类id
         *      id:"",             //文件列的文件id
         *      url:"",            //文件列的文件图标
         *      name:"",           //文件列的文件名字
         *      keyWords:"",       //在搜索视图中搜索的关键字(其他视图可以不需要)
         *      isFile:"",         //是否是文件
         *      fromPath:"",       //文件来自哪里的路径
         *      isEnterpriseDir:"" //是否是企业文件
         *      isImagePreview:"", //文件列的文件名字
         *      imageNotClick:"",  //是否不要图片上的点击事件(管理文件外链视图需要)
         *      fileNameNotClick:"",//是否不要文件名上的点击事件(管理文件外链视图需要)
         *      isShare:"",        //文件行是否可以分享
         *      isRename:"",       //文件列是否可以重命名
         *      isLink:"",         //文件行是否已经外链
         *      isRead:"",         //文件行是否已读
         *      isVirus:"",        //文件行是否带病毒
         *      toolsBar:"",       //是否需要显示文件信息右侧的工具栏[true/false]
         *      size:"",           //文件大小列
         *      time:""            //文件更新时间列
         *      ....其他自定义列的列名称
         *  }
         *  ] 列表项数组
         * @return Number 当前列表项数量
         */
        var pushItems=function(items){
            initContentListDiv();
            var x, len=items.length,rowNo=dataItems.length,cache = [];
            for(x=0;x<len;x++){
                var tempItem = items[x];
                dataItems.push(tempItem);
                rowNo++;
                addItemToDiv(tempItem,rowNo,"append",cache);
            }
            if(cache.length > 0 ){
                $("#"+defaultColumnConfig.renderId).append(cache);
                if(defaultColumnConfig.draggable && window.FileReader){
                    $(cache).each(function(){
                        var divId = this.attr('id');
                        registerDragLocalEvent(divId);
                    });
                }
            }
            //触发选择已选择文件的回调
            handlerObj.selectedHandler(getSelectedItems(),dataItems.length);
            //重新初始化窗口相关参数
            initWinAttr();
            return dataItems.length;
        };

        /**
         * 在列表头部添加列表项
         * @param items Array 列表项数组
         * @return Number 当前列表项数量
         */
        var unshiftItems=function(items){
            initContentListDiv();
            var x,rowNo= 0,len=items.length,cache = [];
            //先修改已经在列表中的数据的行号
            $('div[id^="tabDiv_'+ time + '_' +'"]').each(function(){
                var rowNo = Number(this.attr("rowNo"));
                this.attr("rowNo",rowNo+len);
            });
            $('tr[id^="trData_'+ time + '_' +'"]').each(function(){
                var rowNo = Number(this.attr("rowNo"));
                this.attr("rowNo",rowNo+len);
            });
            for(x=0;x<len;x++){
                var tempItem = items[x];
                dataItems.unshift(tempItem);
                rowNo++;
                addItemToDiv(tempItem,rowNo,"prepend",cache);
            }
            if(cache.length > 0 ){
                $("#"+defaultColumnConfig.renderId).prepend(cache);
                if(defaultColumnConfig.draggable && window.FileReader){
                    $(cache).each(function(){
                        var divId = this.attr('id');
                        registerDragLocalEvent(divId);
                    });
                }
            }
            //触发选择已选择文件的回调
            handlerObj.selectedHandler(getSelectedItems(),dataItems.length);
            //重新初始化窗口相关参数
            initWinAttr();
            return dataItems.length;
        };

        /**
         * 更新列表中的item
         * @param item 列表项
         * @return Boolean 是否更新成功
         */
        var updateItem=function(item){
            var j, isUpdate=false,len=dataItems.length;
            //更新json数据
            for(j=0;j<len;j++){
                var tempItem=dataItems[j];
                if(item.id == tempItem.id){
                    dataItems[j]=tempItem;
                    isUpdate=true;
                    break;
                }
            }
            //更新html代码
            if(isUpdate){
                var updateDiv = $('div[id="tabDiv_'+ time + '_' + item.id +'"]');
                var rowNo=updateDiv.attr("rowNo");
                addItemToDiv(item,rowNo,"update",null);
            }
            //重新初始化窗口相关参数
            initWinAttr();
            return isUpdate;
        };

        //清空列表项
        var clear=function(){
            dataItems=[];
            selectIdsObj={};
            $("#"+defaultColumnConfig.renderId).empty();
        };

        //为id加上时间，保证同一页面每new一个新的控件时，不会id冲突
        var getId = function(id){
            return id+'_'+time;
        };

        //获取列表的Div Id
        var getCyGridId = function(){
            return defaultColumnConfig.renderId;
        };

        //显示列表
        var show=function(){
            isShow=true;
            $("#"+defaultColumnConfig.renderId).show();
        };

        //隐藏列表
        var hide=function(){
            isShow=false;
            $("#"+defaultColumnConfig.renderId).hide();
        };

        /**
         * 空列表时的显示的HTML
         * @param html 要显示的HTML
         */
        var setEmptyStyle=function(html){
            $("#"+defaultColumnConfig.renderId).empty().append(html);
        };

        //全选
        var selectAll=function(){
            $('tr[id^="trData_'+time+'"]').removeClass();
            $('tr[id^="trData_'+time+'"]').filter(function(){
                var itemId=$(this).attr("id").split("_")[2];
                $(this).addClass("current");
                selectIdsObj[itemId]=getTimeFlag();
            });
            handlerObj.selectedHandler(getSelectedItems(),dataItems.length);
        };

        //全不选
        var unSelectAll=function(){
            $('tr[id^="trData_'+time+'"]').removeClass();
            selectIdsObj={};
            handlerObj.selectedHandler(getSelectedItems(),dataItems.length);
        };

        //播放mp3音乐
        var mp3Player = function(itemId){
            //清除存在的播放图标
            mp3PlayerClose();
            //渲染当前播放的item的图标
            var $trData = $("#trData_" + time + '_' + itemId);
            if($trData){
                palyMusicItemId=itemId;
                var musicIco = '<div id="playMusicIco" class="music_ico2"></div>';
                var parentDiv = $trData.find('div[class="doc_nr_r"]');
                var playerItem=getItemById(itemId);
                if(playerItem && playerItem.fromPath){
                    musicIco = '<div id="playMusicIco" class="music_ico"></div>';
                    var floatDiv = parentDiv.find('div[class="floatleft fileName_v"]');
                    var $h2 = $("#fileName_" + time + '_' + itemId).addClass("music_color");
                    if(floatDiv.length !==0){
                        floatDiv.append(musicIco);
                    }else{
                        floatDiv=$('<div class="floatleft fileName_v"></div>');
                        floatDiv.append($h2).append(musicIco);
                        parentDiv.prepend(floatDiv);
                    }
                }else{
                    parentDiv.append(musicIco);
                    $("#fileName_" + time + '_' + itemId).addClass("music_color");
                }


            }
        };

        //mp3播放器关闭
        var mp3PlayerClose = function(){
            palyMusicItemId = null;
            //清除存在的播放图标
            var playerIco=$("#playMusicIco");
            if(playerIco.length !==0){
                var floatDivOld = playerIco.parent();
                var h2Old =floatDivOld.find("h2").removeClass("music_color");
                if(floatDivOld.attr("class")==="doc_nr_r"){
                    playerIco.remove();
                }else{
                    var otherIcon = floatDivOld.find("div");
                    //有其他图标时
                    if(otherIcon.length !== 0){
                        playerIco.remove();
                    }else{
                        var pparentDiv=playerIco.parent().parent();
                        pparentDiv.prepend(h2Old);
                        floatDivOld.remove();
                    }
                }
            }
        };

        /**
         * 获取当前选中的items
         * @return 前选中的items[]
         */
        var getSelectedItems=function(){
            var j, selectItems=[], len=dataItems.length;
            for(j=0;j<len;j++){
                var item=dataItems[j];
                var timeFlag=selectIdsObj[item.id];
                if(timeFlag){
                    selectItems.push(item);
                }
            }
            return selectItems;
        };

        /**
         * 选择的文件项变化处理函数，在当前选中的文件发生变化时触发
         * 选择事件和其他事件同时触发时，先调用选择事件再调用其他事件
         * 回调时传入选中的文件项数组，没有文件选中时传入null
         * function handler (items,total){};
         * @params handler {Function} 文件项变化函数
         */
        var setSelectedHandler = function(handler){
            handlerObj.selectedHandler=handler;
        };

        /**
         * 打开文件项时，触发的事件
         * 回调参数如下，item 打开的文件项
         * function handler(item){};
         * @params handler {Function}　回调函数
         */
        var setOpenHandler = function(handler){
            handlerObj.openHandler=handler;
        };

        /**
         * 点击字段时触发的回调函数
         * 回调参数如下，item 打开的文件项
         * function handler(item){};
         * @params handler {Function}　回调函数
         */
        var setClickColumHandler = function(handler){
            handlerObj.clickColumHandler=handler;
        };

        /**
         * 右键点击文件项时，触发的事件
         * 回调参数如下，items 被右键点击的元素（右键可以多选），event 右键事件用于获取鼠标位置作为定位
         * function handler(items,event){};
         * @params handler Function　回调函数
         */
        var setContextmenuHandler = function(handler){
            handlerObj.contextmenuHandler=handler;
        };

        /**
         * 显示创建文件项
         * @param item 要创建的文件项参数
         */
        var createItem = function(){
            var newItem={id:"",name:"新建文件夹",columnType:"newfolder",url:"/Mcloud/images/newportal2/web_small/folder.gif"};
            if($('div[id="newfolder_'+ time + '_' + newItem.id +'"]').length!==0){
                return;
            }
            var rowDiv = createNewfolderHtml(newItem,0);
            $("#"+defaultColumnConfig.renderId).prepend(rowDiv);
            $("#newName_"+ time+ '_' + newItem.id).select();
        };

        /**
         * 确认创建文件项的回调函数
         * function handler(params) 返回true表示去除创建文件项，返回false表示不去除创建文件项
         * @param handler Function 回调函数
         */
        var setConfirmCreateItemHandler = function(handler){
            handlerObj.confirmCreateItemHandler=handler;
        };

        /**
         * 对选中的文件项进行重命名
         */
        var renameSelectedItem= function(){
            var mySelectedItems = getSelectedItems();
            if(mySelectedItems.length == 1){
                var selectedItem = mySelectedItems[0];
                if(!selectedItem.isRename){
                    return;
                }
                //清除新建文件夹的编辑状态
                clearNewFolderHtml();
                //清除重命名的编辑状态
                clearRenameHtml();
                $("#trData_"+time+'_'+selectedItem.id).remove();
                var $data_tr = createRenameTrHtml(selectedItem);
                $("#tabDiv_"+ time + "_" + selectedItem.id).unbind("contextmenu").unbind("dblclick").unbind("click").find("table").append($data_tr);
                $("#newName_"+ time+ '_' + selectedItem.id).select();
            }
        };

        //设置需要隐藏的列
        var setHideColumns = function(columnNames){
            if(columnNames){
                hideColumnNames=columnNames;
            }else{
                hideColumnNames=[];
            }
        };

        //判断此列是否需要隐藏
        var isColumnHide = function(columnName){
            var isOK=false,x=hideColumnNames.length;
            for(var i=0;i<x;i++){
                if(columnName==hideColumnNames[i]){
                    isOK=true;
                    break;
                }
            }
            return isOK;
        };

        /**
         * 确认重命名的回调函数
         * @param handler function handler(params){} // 返回true表示结束重命名，返回false表示不结束重命名，让用户继续输入
         */
        var setConfirmRenameSelectedItemHandler= function(handler){
            handlerObj.confirmRenameSelectedItemHandler=handler;
        };

        /**
         * 外链回调函数
         * @param handler
         */
        var setLinkHandler= function(handler){
            handlerObj.linkHandler=handler;
        };

        /**
         * 生成外链后，回调更新列表外链状态
         * @param itemId 更新id
         * @param isLink 是否已经外链
         */
        var callBackUpdateLinkItem = function(itemId,isLink){
            var linkItem=getItemById(itemId);
            if(linkItem){
                linkItem.isLink=isLink;
                updateItem(linkItem);
            }
        };

        /**
         * 用户收到新文件后，回调更新收到文件的文件图标样式
         * @param itemId
         */
        var callBackeceReciveNewFileItem = function(itemId){
            var reciveNewItem=getItemById(itemId);
            if (reciveNewItem) {
                reciveNewItem.isReciveNew=true;
                updateItem(reciveNewItem);
            }
        };

        /**
         * 共享的回调函数
         * @param handler function handler(item){}
         */
        var setShareHandler= function(handler){
            handlerObj.shareHandler=handler;
        };

        /**
         * 文件分享后，回调更新列表外链状态
         * @param itemId
         */
        var callBackUpdateShareItem = function(itemId){
            var shareItem=getItemById(itemId);
            shareItem.isShare=true;
            updateItem(shareItem);
        };

        /**
         * 下载的回调函数
         * @param handler function handler(item){}
         */
        var setDownLoadHandler= function(handler){
            handlerObj.downLoadHandler=handler;
        };

        /**
         * 设置判断列表项是否可以放置拖拽文件项
         * @param handler 回调函数
         * function handler(item){} // 返回true表示可以放置，false表示不可以放置，不可以放置的列表项不触发放置效果
         */
        var setItemDropableHandler = function(handler){
            handlerObj.itemDropableHandler=handler;
        };

        /**
         * 设置在列表内 拖拽项被放置到放置项时触发事件的回调函数
         *  @param handler (dragItems,dropItem)  回调函数
         *  dragItems  被拖拽的文件项
         *  dropItem  要放置到的文件项
         */
        var setItemDropHandler = function(handler){
            handlerObj.itemDropHandler = handler;
        };

        /**
         * 设置本地文件 拖拽项被放置到放置项时触发事件的回调函数
         *  @param handler (dragItems,dropItem)  回调函数
         *  files     被拖拽的本地电脑文件
         *  dropItem  要放置到的文件项
         */
        var setLocalFileDropHandler=function(handler){
            handlerObj.localFileDropHandler = handler;
        };

        /**
         * 拖拽事件的处理函数，展示拖拽过程的效果
         */
        var getDragHelper = function(e){
            e.stopPropagation();
            e.preventDefault();
            var id=$(this).attr("id").split("_")[2];
            //没有选择就触发选择事件
            if($('tr[id="trData_'+time+'_'+ id +'"]').attr("class")!=="current"){
                unSelectAll();
                $(this).click();
            }
            //获取已选择的最后一张图片作为拖拽图片
            var selectObj=getSelectMaxOrMinRowNo();
            var maxRowId=selectObj.maxItemId;
            var maxRowItem=getItemById(maxRowId);
            var selectItems = getSelectedItems();
            var selectNums = selectItems.length;
            var innerHtml = '<div class="dom_num">' + selectNums + '</div>';
            var innerImg = '<img src="'+maxRowItem.imageForDrag+'" border="0" />';
            var divDom = $('<div class="minDrag" style="z-index: 99999;background:#d8cce8;opacity: 1;margin: 0;padding: 0;"></div>');
            divDom.append(innerImg).append(innerHtml);
            return divDom;
        };

        /**
         * 拖拽事件释放时的处理函数
         */
        var getDropHelper = function(event, ui){
            // 判断是否在页面的头部位置
			if (event.clientY < 181) {
                return;
			}
            var selectItems=getSelectedItems();
            var id=$(this).attr("id").split("_")[2];
            var currentItem=getItemById(id);
            if(currentItem.name == "收到的分享"){
                window.caiyun.ui.iMsgTip.tip('"收到的分享"目录不支持拖拽移入文件或文件夹操作!',"error");
                return;
            }
            if(handlerObj.itemDropableHandler(selectItems,currentItem)){
                ui.helper.remove();
                handlerObj.itemDropHandler(selectItems,currentItem,false);
            }
        };

        //一下是采用html5对本地电脑上的文件进行拖拽到web上传的相关辅助函数
        var handleLocalFileSelect = function(e){
            e.stopPropagation();
            e.preventDefault();
            var id=$(this).attr("id").split("_")[2];
            var dropItem=getItemById(id);
            if(dropItem !== null && dropItem.name == "收到的分享"){
                window.caiyun.ui.iMsgTip.tip('"收到的分享"目录不支持拖拽上传文件操作!',"error");
                return;
            }
            var files = e.dataTransfer.files;
            handlerObj.localFileDropHandler(files,dropItem);
        };

        //给每一行内容注册本地文件拖拽上传事件
        var registerDragLocalEvent=function(divId){
            var cnt=document.getElementById(divId);
            cnt.addEventListener('dragenter', function(){
                var id=$(this).attr("id").split("_")[2];
                if(id){
                    $("#trData_"+time+'_'+id).removeClass().addClass("hover");
                }
            }, false);
            cnt.addEventListener('dragleave', function(){
                var id=$(this).attr("id").split("_")[2];
                if(id){
                    $("#trData_"+time+'_'+id).removeClass().addClass("");
                }
            }, false);
            cnt.addEventListener('dragover', function(e){
                e.stopPropagation();
                e.preventDefault();
            }, false);
            cnt.addEventListener('drop', handleLocalFileSelect, false);
        };

        return {
            show:show,
            hide:hide,
            getCyGridId:getCyGridId,
            pushItems:pushItems,
            unshiftItems:unshiftItems,
            updateItem:updateItem,
            callBackUpdateLinkItem:callBackUpdateLinkItem,
            callBackUpdateShareItem:callBackUpdateShareItem,
            callBackeceReciveNewFileItem:callBackeceReciveNewFileItem,
            clear:clear,
            createItem:createItem,
            selectAll:selectAll,
            unSelectAll:unSelectAll,
            mp3Player:mp3Player,
            mp3PlayerClose:mp3PlayerClose,
            renameSelectedItem:renameSelectedItem,
            getSelectedItems:getSelectedItems,
            setHideColumns:setHideColumns,
            setEmptyStyle:setEmptyStyle,
            setSelectedHandler:setSelectedHandler,
            setOpenHandler:setOpenHandler,
            setClickColumHandler:setClickColumHandler,
            setContextmenuHandler:setContextmenuHandler,
            setConfirmCreateItemHandler:setConfirmCreateItemHandler,
            setConfirmRenameSelectedItemHandler:setConfirmRenameSelectedItemHandler,
            setLinkHandler:setLinkHandler,
            setDownLoadHandler:setDownLoadHandler,
            setShareHandler:setShareHandler,
            setItemDropableHandler:setItemDropableHandler,
            setItemDropHandler:setItemDropHandler,
            setLocalFileDropHandler:setLocalFileDropHandler
        };
    };
})();
