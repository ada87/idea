/**
 * 依赖 jQuery,artTemplate,caiyun-utils.js
 */
(function() {

    /**
     * 定义会使用到的公共方法
     */
    window.caiyun.ui.CyGridBase = {

        /**
         * 记录所有已经创建的列表对象
         * grids[id] = grid
         */
        grids: {},

        /**
         * 获取一个时间戳的标记
         *
         * @returns {number}
         */
        getTimeFlag: function() {
            return new Date().getTime() + '' + Math.floor(Math.random() * 100000);
        },

        /**
         * 生成一个ID，并加上时间戳
         *
         * @returns 加时间戳的ID号
         */
        getId: function(id, time) {
            return id + time;
        },

        /**
         * 绑定事件函数，需要考虑兼容自定义事件(eventName_gridId)
         */
        on: function(grid, gridElement, gridId, ons, colIndex) {
            var array;
            if(ons && !(ons instanceof Array)){
                array = [];
                array.push(ons);
            }else{
                array = ons;
            }
            var $grid = $(gridElement),
                i = 0,
                len = array.length,
                temp, events, j, newEvents = [],
                eventName, evensLength;
            for (; i < len; i++) {
                temp = array[i];
                events = temp.events.split(' ');
                evensLength = events.length;
                for (j = 0; j < evensLength; j++) {
                    eventName = events[j];
                    if (window.caiyun.ui.CyGridEvents[eventName]) {
                        newEvents.push(eventName + '_' + gridId);
                    } else {
                        newEvents.push(eventName);
                    }
                }
                $grid.on(newEvents.join(' '), temp.selector, {
                    grid: grid,
                    colIndex: colIndex
                }, temp.handler);
                newEvents = [];
            }
        },

        /**
         * 触发一个列表事件
         *
         * @param grid {CyGrid} 彩云列表对象，这个对象可以通过event.grid获取
         * @param eventName {String} 事件名称
         * @param otherdata {Object} 自定义数据，这些数据会被传到事件处理函数的第二个参数开始的参数
         */
        trigger: function(grid, eventName, otherdata) {
            var event = $.Event(eventName + '_' + grid.getId());
            event.eventName = eventName;
            $(grid.getGridElement()).trigger(event, otherdata);
        },

        /**
         * 获取某一个行的生成的DOM元素
         *
         * @param row{Row} 每一行的定义
         * @param columns {Column} 每一列的定义
         * @param grid {CyGird} 列表对象
         * @param item {Object} 数据
         */
        generateRowDOM: function(row, columns, grid, item) {
            var columnsHTML = [],
                col, j = 0,
                colItems = item.colItems,
                collen = colItems.length;
            for (j = 0; j < collen; j++) {
                col = columns[j];
                columnsHTML.push(col.render(grid, colItems[j], item));
            }
            columnsHTML = columnsHTML.join('');
            return row.generateDOM(columns, columnsHTML, grid, item);
        }
    };

    /**
     * 自定义列表事件
     * 自定义事件的类型通过event.eventName来获取
     */
    window.caiyun.ui.CyGridEvents = {
        // 列表被创建
        init: 'init',
        // 列表被销毁
        destory: 'destory',
        // 新项目被添加
        addItems: 'addItems',
        // 项目被删除
        removeItems: 'removeItems',
        // 项目被更新
        updateItem: 'updateItem'
    };

    /**
     * 定义会使用的行类型，此对象可以通过扩展来自定义行
     *
     * 每一行类型都需要提供以下属性和方法，以用于实现生成列的HTML和绑定事件
     * row{
     *     // 行类型，用于区分不同类型的行的字符串
     *     rowType : ''
     *     //  用于创建列表时，添加每一行的事件处理函数，等同于jQuery的on函数
     *     ons :  [{events [, selector ] [, data ], handler(eventObject),... ]
     *     //  用于销毁列表时，销毁每一行事件处理函数，等同于jQuery的on函数
     *     offs : [{events [, selector ] , handler(eventObject),... ]
     *     // 生成行对应的DOM对象，item 行数据,return 生成的HTML
     *     generateDOM : function(columns,columnsHTML,grid,item)
     * }
     */
    window.caiyun.ui.CyGridRows = {};

    // 默认行定义
    window.caiyun.ui.CyGridRows.DefaultRow = function(className) {
        this.className = 'table_div';
    };
    window.caiyun.ui.CyGridRows.DefaultRow.prototype.rowType = 'DefaultRow';
    window.caiyun.ui.CyGridRows.DefaultRow.prototype.element = 'div';
    window.caiyun.ui.CyGridRows.DefaultRow.prototype.template = template.compile(
        '<table width="100%" cellspacing="0" cellpadding="0" border="0">' +
        '<tbody>' +
        '<tr> <% for(var i=0 ; i < columns.length ; i++){%>' +
        '<th width="<%=columns[i].width%>"></th>' +
        '<%}%>' +
        '</tr>' +
        '<tr id="gridrow_tr_<%=grid.getId()%>_<%=item.id%>" class="gridRowTr gridrow_tr_<%=grid.getId()%>"><%==columnsHTML%>' +
        '</tr>' +
        '</tbody>' +
        '</table>');
    window.caiyun.ui.CyGridRows.DefaultRow.prototype.generateDOM = function(columns, columnsHTML, grid, item) {
        var context = {
            className: this.className,
            columns: columns,
            columnsHTML: columnsHTML,
            grid: grid,
            item: item,
            row : this
        };
        var innerHTML = this.template(context);
        var row = document.createElement(this.element);
        row.innerHTML = innerHTML;
        $(row).attr('id', 'gridrow_' + grid.getId() + '_' + item.id).addClass(this.className).addClass('gridRow').addClass('gridRow_' + grid.getId());
        return row;
    };
    window.caiyun.ui.CyGridRows.DefaultRow.prototype.findElementByItemId = function(grid, itemId) {
        return document.getElementById('gridrow_' + grid.getId() + '_' + itemId);
    };
    window.caiyun.ui.CyGridRows.DefaultRow.prototype.getItemId = function(rowElement) {
        var id = $(rowElement).attr('id');
        var index = id.lastIndexOf('_');
        return id.substr(index + 1);
    };
    window.caiyun.ui.CyGridRows.DefaultRow.prototype.getRowTrId = function(grid, rowElement) {
        return 'gridrow_tr_' + grid.getId() + '_' + this.getItemId(rowElement);
    };
    window.caiyun.ui.CyGridRows.DefaultRow.prototype.generateRowTrId = function(grid, itemId) {
        return 'gridrow_tr_' + grid.getId() + '_' + itemId;
    };

    window.caiyun.ui.CyGridRows.DefaultRow.prototype.ons = [{
        events: 'mouseenter mouseleave',
        selector: '.gridRow',
        handler: function(event) {
            var type = event.type;
            var grid = event.data.grid;
            var row = grid.getRow();
            var $tr = $(document.getElementById(row.getRowTrId(grid, this)));
            if (type === 'mouseenter') {
                $tr.addClass('hover');
            } else {
                $tr.removeClass('hover');
            }
        }
    }];

    // 默认行定义END

    // 可选中的行END

    /**
     * 定义会使用的列类型，此对象可以通过扩展来自定义列
     *
     * 每一个列类型都需要提供以下属性和方法，以用于实现生成列的HTML和绑定事件
     * column{
     *      // 列类型，用于区分不同类型的列的字符串
     *      columnType : ''
     *      // 用于创建列表时，添加每一列的事件处理函数，等同于jQuery的on函数
     *      // 建议使用className作为selector，然后className使用columnType_className这样的格式来定义避免冲突
     *      ons :  [{events [, selector ] [, data ], handler(eventObject),... ]
     *      // 生成HTML grid 对应的列表对象，item 列数据, rowItem{CyGridItem}列表行数据,return 生成的HTML
     *      render : function(grid,item,rowItem)
     * }
     */
    window.caiyun.ui.CyGridColumns = {};

    // 基础列，所有列表列都需要继承此类
    window.caiyun.ui.CyGridColumns.BaseColumn = function(columnType, valign, align, width) {
        this.columnType = columnType;
        this.valign = valign ? valign : 'middle';
        this.align = align ? align : 'center';
        this.width = width;
    };

    window.caiyun.ui.CyGridColumns.BaseColumn.prototype.getItemId = function(columnElement) {
        var id = $(columnElement).attr('id');
        var index = id.lastIndexOf('_');
        return id.substr(index + 1);
    };

    /**
     * 列表项的行数据
     */
    window.caiyun.ui.CyGridItem = function(id) {
        return {
            id: id, // 项ID
            colItems: [] // 列数据数组
        };
    };

    /**
     * 彩云内容列表对象
     * @param config {
     *          renderId："",         //  渲染Div的ID（必须传）
     *          columns[{              // 列表用到的列 （必须传）
     *              columnType:"",   // 可以支持:checkBox(显示勾选列),fileInfo(显示文件信息列),String(显示一行文字列)等
     *              ons : {},         // 事件监听
     *              render : function() // 用于生成列的HTML
     *          }],
     *          ons[{                // 用于列表上的页面事件
     *              events : '',     // 要监听的事件（除了DOM事件，还可以监听自定义事件）
     *              selector : '',  // 选择器
     *              data : {},
     *              handler : function // 事件处理函数
     *          }],
     *          row : {                    // 行定义
     *              rowType : ''
     *          }
     *
     *       } 内容列配置
     */
    window.caiyun.ui.CyGrid2 = function(config) {

        //变量定义区域
        // 引入工具类
        var utils = window.caiyun.util;

        // 引入base方法
        var base = window.caiyun.ui.CyGridBase;
        // 创建列表ID
        var id = 'cygrid' + base.getTimeFlag();

        // target
        var targetElement = document.getElementById(config.renderId);
        var target = $(targetElement);

        // 以下参数必须传
        if (!target || target.length === 0 || !config.columns || config.columns.length === 0) {
            return null;
        }

        // 列定义
        var columns = config.columns;

        // 行定义
        var row = config.row ? config.row : new window.caiyun.ui.CyGridRows.DefaultRow();

        // 是否可用，如果设置为不可用则停止响应所有事件
        var enable = true;

        // 自己
        var self = {};

        row.grid = self;

        // 当前列表中的item列表
        var items = [];

        // 当前item列表的ID映射
        var itemsMap = {};

        //变量定义区域 end

        //绑定事件
        // 其他事件
        var onsi = 0,
            ontemp, ons = config.ons;
        if (ons && ons.length > 0) {
            base.on(self, target, id, ons);
        }
        // 行事件
        ons = row.ons;
        if (ons && ons.length > 0) {
            base.on(self, target, id, ons);
        }
        // 列事件
        var colslength = columns.length;
        var col = null;
        for (onsi = 0; onsi < colslength; onsi++) {
            col = columns[onsi];
            col.colIndex = onsi;
            col.grid = self;
            ons = columns[onsi].ons;
            if (ons && ons.length > 0) {
                base.on(self, target, id, ons, onsi);
            }
        }
        col = null;
        onsi = null;
        ons = null;
        colslength = null;

        //绑定事件end

        // 公共函数定义区域
        /**
         * 清除所有变量和引用解绑事件，包括var和self中的引用，加一个清一个，事件包括所有注册的事件
         */
        self.destory = function() {
            // 解绑事件
            target.off('*');
            // 解绑事件end

            items = null;
            // 移除此列表
            base.grids[id] = null;
            for (var name in self) {
                self[name] = null;
            }
            columns = null;
            self = null;
            target = null;
            targetElement = null;
            id = null;
            base = null;
            utils = null;
        };

        self.getId = function() {
            return id;
        };

        self.show = function() {
            target.show();
        };

        self.hide = function() {
            target.hide();
        };

        self.getRenderId = function() {
            return config.renderId;
        };

        self.getGridElement = function() {
            return targetElement;
        };

        self.pushItems = function(newItems) {
            var temp, i, len, html, r;
            if (newItems instanceof Array) {
                items.push.apply(items, newItems);
                temp = newItems;
            } else {
                items.push(newItems);
                temp = [];
                temp.push(newItems);
            }
            len = temp.length;
            var fragement = document.createDocumentFragment();
            for (i = 0; i < len; i++) {
                itemsMap[temp[i].id] = temp[i];
                r = base.generateRowDOM(row, columns, self, temp[i]);
                fragement.appendChild(r);
            }
            targetElement.appendChild(fragement);
            // 触发事件
            base.trigger(self, window.caiyun.ui.CyGridEvents.addItems, {
                items: newItems
            });
        };

        self.unshiftItems = function(newItems) {
            var temp, i, len, html, r;
            if (newItems instanceof Array) {
                items.unshift.apply(items, newItems);
                temp = newItems;
            } else {
                items.unshift(newItems);
                temp = [];
                temp.push(newItems);
            }
            len = temp.length;
            var fragement = document.createDocumentFragment();
            for (i = 0; i < len; i++) {
                itemsMap[temp[i].id] = temp[i];
                r = base.generateRowDOM(row, columns, self, temp[i]);
                fragement.appendChild(r);
            }
            var firstChild = targetElement.firstChild;
            if(firstChild){
                targetElement.insertBefore(fragement,firstChild);
            }else{
                targetElement.appendChild(fragement);
            }
            // 触发事件
            base.trigger(self, window.caiyun.ui.CyGridEvents.addItems, {
                items: newItems,
                unshift: true
            });
        };

        self.updateItem = function(item) {
            var itemLength = items.length,
                oldItem, oldRow, newRow;
            for (var i = 0; i < itemLength; i++) {
                temp = items[i];
                if (temp.id === item.id) {
                    oldRow = row.findElementByItemId(self, temp.id);
                    newRow = base.generateRowDOM(row, columns, self, item);
                    oldRow.parentElement.replaceChild(newRow, oldRow);
                    oldRow = null;
                    oldItem = items[i];
                    items[i] = item;
                    // 刷新映射表
                    itemsMap[temp.id] = item;
                    break;
                }
            }
            // 触发事件
            base.trigger(self, window.caiyun.ui.CyGridEvents.updateItem, {
                newItem: item,
                oldItem: oldItem
            });
        };

        self.removeItems = function(ids) {
            var temp,newItems = [],
                i = 0,
                j = 0,
                itemsLength = items.length,
                removedItems = [],
                newItemsMap = {}, item, removedRow, removed;
            if (!(ids instanceof Array)) {
                temp = [];
                temp.push(ids);
                ids = temp;
            }

            for (j = 0; j < items.length; j++) {
                removed = false;
                item = items[j];
                for (i = ids.length; i >= 0; i--) {
                    if (item.id === ids[i] && itemsMap[ids[i]]) {
                        removed = true;
                        removedItems.push(item);
                        removedRow = row.findElementByItemId(self, item.id);
                        targetElement.removeChild(removedRow);
                        break;
                    }
                }
                if (!removed) {
                    newItems.push(item);
                    newItemsMap[item.id] = item;
                }
            }

            items = newItems;
            itemsMap = newItemsMap;
            // 触发事件
            base.trigger(self, window.caiyun.ui.CyGridEvents.removeItems, {
                removedItems: removedItems
            });
            removedItems = null;
        };

        self.getItems = function() {
            return [].concat(items);
        };

        self.getItemById = function(id) {
            return itemsMap[id];
        };

        self.clear = function() {
            var all = items;
            items = [];
            itemsMap = {};
            target.empty();
             // 触发事件
            base.trigger(self, window.caiyun.ui.CyGridEvents.removeItems, {
                removedItems: all
            });
            all = null;
        };

        self.getRow = function() {
            return row;
        };

        self.getColumns = function() {
            return [].concat(columns);
        };

        self.getColumnsByColumnType = function(columnType) {
            var i = 0,
                length = columns.length,
                result = [],
                col;
            for (; i < length; i++) {
                col = columns[i];
                if (col === columnsType) {
                    result.push(col);
                }
            }
            return result;
        };

        // 公共函数定义区域 end


        base.grids[id] = self;
        return self;
    };
})();