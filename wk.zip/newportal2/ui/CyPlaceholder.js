(function($) {

	// 是否浏览器本身支持placeholder
	var _DO_SUPPORT_PLACEHOLDER = 'placeholder' in document.createElement('input');
	
	// 全部placeholder
	var ALL_PLACEHOLDERS = [];
	
	/**
	 * 文本输入框显示内嵌默认文字的控件，如果浏览器支持placeholder的话，此控件不起作用
	 * 
	 * 除了IE基本上不需要使用此控件
	 * 
	 * 用法： <input id="name" type="text" placeholder="请输入用户名">
	 * 
	 * var texts = $('#name').CyPlaceholder({ className : 'defaultText' });
	 * 
	 */
	$.fn.CyPlaceholder = function(options) {
		var result = [];
		var options = options ? options : {};
		var className = options.className ? options.className : '';
		this
				.each(function() {
					
					// 如果浏览器本身就支持placehloder不处理，立刻返回
					if(_DO_SUPPORT_PLACEHOLDER){
						result.push($this);
						return;
					}
					
					var $this = $(this);	
					var html = cloneElementHTML(this);
					var status = {placeholder : null};
					
					// 监听prepertychange
					$this.bind('blur',function(){
						if($this.val() && $this.val().length > 0){
							if(status.placeholder){
								destoryPlaceholder($this,status.placeholder,status);
							}
						}else{
							if(!status.placeholder){
								status.placeholder = createPlaceholder($this, html,status,className);
								$this.hide();
							}
						}
					});
					
					if($this.val() && $this.val().length > 0){
					}else{
						status.placeholder = createPlaceholder($this, html,status,className);
						$this.hide();
					}
					
					$this.showPlaceholder = function(){
						if(!status.placeholder){
							status.placeholder = createPlaceholder($this, html,status,className);
							$this.hide();
						}
					};
					ALL_PLACEHOLDERS.push(this);
					result.push($this);

				});

		return result;
	};
	
	/**
	 * 克隆当前元素，返回其HTML
	 */
	function cloneElementHTML(element){
		var $element = $(element).clone();
		var $html = $('<div></div>');
		$element.appendTo($html);
		return $html.html();
	};
	
	/**
	 * 创建placeholder
	 */
	function createPlaceholder(real,html,status,className){
		var placeholder,type = real.attr('type').toLowerCase(),$placeholder,defaultText = real.attr('placeholder');
		// 密码框做替换
		if(type === 'password'){
			placeholder = html.replace('type="password"', 'type="text"')
			.replace('type=password', 'type="text"')
			.replace("type='password'", 'type="text"');
		}else {
			placeholder =html;
		}
		
		$placeholder = $(placeholder).removeAttr('id').removeAttr('name').val(defaultText).appendTo(real.parent()).bind('focus',function(){
				destoryPlaceholder(real,$(this),status);
		});
		
		if(className){
			$placeholder.addClass(className);
		}
		
		return $placeholder;
	};
	
	/**
	 * 摧毁placeholder
	 */
	function destoryPlaceholder(real,placeholder,status){
		if(placeholder){
			placeholder.remove();
		}
		real.show().focus();
		status.placeholder = null;
	};
	
})(jQuery);