/**
 * 新视频播放器
 */

;(function(){
	var sURL,lURL,hURL;
		
	var currentVideo;
	//初始化的播放级别
	var defaultLevel = "h";
	var player;
	
	var flashvars = {
		"onPlayerLoaded":"newPlayer.initPlayList",
		"bgColor":"0x000000",
		"callback":"newPlayer.callbackPre,newPlayer.callbackNext"
	};
	
	var params = {
		quality:"autolow",
		scale:"noscale",
		loop:"true",
		wmode:"opaque",
		menu:"true",
		devicefont:"false",
		allowFullScreen:"true",
		allowScriptAccess:"sameDomain"
	};
	
	var getPlayer = function(){
		return navigator.appName.indexOf("Microsoft") != -1 ? document.all.vplayer_area : document.vplayer_area;
	};
	
	//回调函数，参看flashvars中onPlayerLoaded参数
	function initPlayList() {
		//这里根据videoid重新设置content内容，以下为demo
		
		var newcontent = {
			"url":createURLContent(sURL,hURL,lURL),
			"default":defaultLevel,//增加缺省码流
			"contentid":currentVideo.contentID
		};
		player = getPlayer();
		setShareFileButtonVisible(currentVideo.canShare);
		setShareLinkButtonVisible(currentVideo.canLink);
    	player.setContent(newcontent);
	}

	var createURLContent = function(sURL,hURL,lURL){
		var arr = new Array();
		sURL ? arr.push({"s":sURL}) : '';
		hURL ? arr.push({"h":hURL}) : arr.push({"h":hURL});
		lURL ? arr.push({"l":lURL}) : '';
		return arr;
	}
	
	//根据权限控制功能键的显示与隐藏
	function setShareFileButtonVisible(isVisible){
	  player = getPlayer();
    player.setShareFileButtonVisible(isVisible);
	};
	
	function setShareLinkButtonVisible(isVisible){
	  player = getPlayer();
    player.setShareLinkButtonVisible(isVisible);
	};
	
	var init = function(opts,callback){
		currentVideo = opts;
		//标清
		lURL = opts.presentLURL,
		//高清
		hURL = opts.presentURL,
		//超清
		sURL = opts.presentHURL;
		
		swfobject.embedSWF("/Mcloud/live139/caiyunVideoPlayer.swf?" + new Date().getTime(), "vplayer_area",
			 590, 390, "9.0.0","Expressinstall.swf",flashvars,params);
		$.isFunction(callback)?callback():'';
	}

	window.newPlayer = {
		initPlayer : init,
		closePlayer : close,
		initPlayList : initPlayList,
		getCurrent : function(){return currentVideo},
		setShareFileButtonVisible : setShareFileButtonVisible,
		setShareLinkButtonVisible : setShareLinkButtonVisible
	}
	
})();