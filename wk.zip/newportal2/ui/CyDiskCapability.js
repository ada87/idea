/* 
 * 名称：window.caiyun.ui.CyDiskCapability
 * 说明：用户容量条,用于显示用户网盘容量、已用容量及占比
 * 
 * 参数params{
 *              renderTo     :  'capacityBar2', //指向要加载的id
 *              userDiskSize :  userDiskSize,   //用户已用容量
 *              diskSize     :  diskSize        //用户总容量
 *    }
 */
;(function(){
    window.caiyun.ui.CyDiskCapability = function(params){
        var init = function(){
            diskSizeSucc(params);
        };
        
        var diskSizeSucc = function(params){
            var cfgs = params ||{};
            var capacityBar  = $('#'+cfgs.renderTo);
            var diskSize  = cfgs.diskSize;
            var userDiskSize  = cfgs.userDiskSize;
            var percent;
            if(diskSize <= 0){       
                percent = "0%";
                userDiskSize = "0MB";
                diskSize = "0MB";                
            } else {
                if(userDiskSize <= 0){
                    percent = 0;
                } else {
                    percent = Math.abs((userDiskSize / diskSize*100 ).toFixed(1));
                    if (percent <= 0.1) {
                        percent = 0.1;
                    }else if(percent > 1){
                        percent = percent.toFixed(0);
                    }
                    
                    if (percent > 100) {
                        percent = 100;
                    }
                    if(percent >= 90){
                        capacityBar.attr('class','process-bar w_red');
                    }else{
                        capacityBar.attr('class','process-bar');
                    }
                }
                percent += "%";

                userDiskSize = convertDiskSize(userDiskSize);
                diskSize = convertDiskSize(diskSize);
                
                capacityBar.html('<div class="siteBar" style="left:'+percent+'">'+percent+'</div>' +
                                 '<div class="pb-text">' +
                                    '<p><em>'+userDiskSize+'</em> / <span>'+diskSize+'</span>' +
                                    '<a target="_blank" href="index_freeMission.jsp" style="display:block;color:#7025e5;position: absolute;top:0px;right:0px;">免费扩容</a></p>' +
                                 '</div>' +
                                 '<div class="pb-wrapper" style="width:'+percent+'" >' +
                                    '<div class="pb-highlight"></div>' +
                                    '<div class="pb-container"></div>' +
                                 '</div>' );
            }
        };
        var convertDiskSize = function(diskSize){
            var oneTB = 1024 * 1024;
            var oneGB = 1024;        
            var oneHundredTB = 1024 * 1024 * 100;
            var oneHundredGB = 1024 * 100;
            var oneHundredMB = 100;
            var oneThousandMB = 1000;
            var tenThousandGB = 1024 * 10000;            
            var replaceLastZeroNum = function(numStr){
                var newNumStr = numStr.replace(/\.0*$/g, '').replace(/(\.\d+?)(0+?)$/g, '$1');
                return newNumStr;
            };
            
            if (diskSize < oneHundredMB) {
                diskSize = replaceLastZeroNum((diskSize / 1).toFixed(2)) + "M";
            } else if(diskSize < oneThousandMB) {
                diskSize = Math.floor(diskSize) + "M";
            } else if(diskSize < oneHundredGB) {
                diskSize = replaceLastZeroNum((diskSize / oneGB).toFixed(2)) + "G";
            } else if(diskSize < tenThousandGB) {
                diskSize = Math.floor(diskSize / oneGB) + "G";
            } else if(diskSize < oneHundredTB) {
                diskSize = replaceLastZeroNum((diskSize / oneTB).toFixed(2)) + "T";
            } else {
                diskSize = Math.floor(diskSize / oneTB) + "T";
            }
            
            return diskSize;
        };
        var show = function(){
            capacityBar.show();
        };
        var hide = function(){
            capacityBar.hide();
        };
        
        return {
            cyDiskCapabilityShow : show,
            cyDiskCapabilityHide : hide,
            cysetDiskSize        : diskSizeSucc
        };  
    };
})();
