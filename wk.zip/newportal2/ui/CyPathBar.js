/**
 * 导航条Model
 * 
 * options{ className : '' // 导航条的样式class名称 totalPathLength : '' //
 * 导航条可以用于显示目录名称的字数总数，超过此总数路径名称会自动截取增加缩略 } callbacks{ back : function() //
 * 返回被点击的触发方法 }
 */
(function(){
	
	caiyun.ui.CyPathBar = CyPathBar;
	caiyun.ui.CyPathItem = CyPathItem;
	
	function CyPathBar(options, callbacks) {
	var self = this;
	var _options = options;
	
	// 文件路径项，实际上是一个栈，不要直接操作这个数组，使用下面的方法对栈进行操作
	this.paths = ko.observableArray();
	
	// 修改导航条可现实的每个路径项的缩略显示
	var _modifyMaxPathLength = function(){
		var totalPathLength = _options.totalPathLength;
		// 计算出每项可以显示的字数
		var paths = self.paths();
		var arrayLength = paths.length;
		if(arrayLength >= 1){
			// 中文当两个字计算长度
			var newLength = Math.floor(totalPathLength/arrayLength);
			// 设置每一个路径项长度
			$(paths).each(function(){
				this.maxNameLength(newLength);
			}
			);
		}
	};
	
	// 样式class名称
	this.className = ko.observable(_options.className);
	
	/**
	 * 增加文件路径项
	 */
	this.pushPath = function(cyPathItem) {
		self.paths.push(cyPathItem);
		_modifyMaxPathLength();
	};

	/**
	 * 从某路径项弹出到栈顶
	 */ 
	this.popFromPath = function(cyPathItem){
		var index = self.paths.indexOf(cyPathItem);
		if(index >= 0){
			self.paths.slice(index);
		}
		_modifyMaxPathLength();
	};
	
	/**
	 * 弹出栈顶元素
	 */
	this.pop = function(){
		return self.paths.pop();
		_modifyMaxPathLength();
	};
	
	/**
	 * 点击返回
	 */
	this.back = function(){
		if(callbacks && callbacks.back){
			callbacks.back(self);
		}
		_modifyMaxPathLength();
	};
	
	// 清除所有
	this.removeAll = function(){
		self.paths.removeAll();
		_modifyMaxPathLength();
	};
	
	/**
	 * 修改最大长度
	 */
	this.modifyMaxPathLength = function(length){
		_options.totalPathLength = length;
		_modifyMaxPathLength();
	};
};

/**
 * 导航项
 * 
 * parent 指向对应的导航条model fileInfo{ id : '', // 路径ID name : '', // 显示名称 data : {} //
 * 文件信息对象，存放文件的ID等 } options{ id : '', // 文件项的DOM元素，ID属性 className : '', //
 * 文件项的样式class名称 } callbacks{ click: function(CyPathItem){} // 点击回调事件 }
 */
function CyPathItem(parent,fileInfo,options,callbacks){
	var self = this;
	
	this.parent = parent;
	this.fileInfo = fileInfo;
	
	// 最大文件名长度
	this.maxNameLength = ko.observable(10);
	
	this.pathName = ko.observable(fileInfo.name);
	
	this.pathId = ko.observable(fileInfo.id);
	
	// 计算显示名称
	this.showName = ko.computed(function(){
		var newLength = self.maxNameLength();
		var pathName = self.pathName();
		if(pathName&&pathName.strLen() > newLength){
			return pathName.subCHStr(0,newLength - 2) + '…';
		}else{
			return pathName;
		}
	}
	);
	// 设置属性
	this.id = ko.observable();
	this.className = ko.observable();
	if(options){
		this.id(options.id);
		this.className(options.className);
	}
	
	// 点击事件
	this.click = function(){
		if(callbacks && callbacks.click){
				callbacks.click(this);
		}
	};
};})();