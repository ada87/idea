/*
 * 名称：CyScroller
 * 
 * 说明：自定义大小的垂直滚动窗口，支持自定义的滚动条样式，并且提供滚动的各种功能 用法：$(selector).CyScroller();
 * 
 * 方法列表：
 * 
 * CyScroller(options,callbacks) 
 * 说明：将一个元素封装到一个滚动窗口中，如果该元素大小超过滚动窗口限制的大小会出现滚动
 * 输入参数： options{ id : '', // 元素的id名称
 * 					 className : 'CyScrollerWindow' , // * 顶层样式类，默认为：CyScrollerWindow，设置滚动窗口最外层class设置为此值
 * 					 bindToGloalWheel:false, //  * 是否不需要焦点，只要用户滚动滚轮就能触发，默认为：false
 * 					 srcollSpeed : 18 // 滚动速度，旋转滚轮时页面的移动速度
 * 					 autoHidden : true // 是否自动隐藏，鼠标悬浮时才显示
 * 				}
 * callbacks{
 * 			 'onScroll' : callback(position,$scroller), // 在滚动中触发的事件
 * 			 'onScrollToTop' : callback(position,$scroller) , // 滚动到顶部触发的事件
 * 			 'onScrollToBottom' : callback(position,$scroller), // 滚动到底部触发的事件 } // * 距离滚动窗口顶端的滚动距离 
 * 				position // 单位像素，相对于顶部的滚动距离 $Scroller // 滚动窗口的JQuery对象
 * }
 * 
 * scrollTo(postion) 说明：滚动到指定位置，绝对位置，position为负数表示向上滚动，正数表示向下滚动
 * 
 * scrollBy(postion) 说明：滚动到相对位置，相对位置
 * 
 * getContent() 说明：获取滚动窗口封装的元素
 * 
 */
(function($) {
	$.fn.CyScroller = function(options, callbacks) {
		var opt = $.extend( {}, $.fn.CyScroller.defaults, options);
		var caks = $.extend( {}, callbacks);
		var result = [];
		this
				.each(function() {
					var $inner = $(this);
					$inner.wrap('<div id=' + opt.id + ' class=' + opt.className
							+ '/>');

					var $parent = $inner.parent();

					// 加入滚动条
					var scrollerHTML = '<div class="CyScrollerArea"><div class="CyScrollerTop"></div><div class="CyScrollerUp"></div><div class="CyScrollerBar"><div class="CyScroller"> <span><span></span></span></div></div><div class="CyScrollerDown"></div></div>';
					$parent.append(scrollerHTML);

					var $scrollerArea = $parent.find('.CyScrollerArea');
					var $scrollerBar = $parent.find('.CyScrollerBar');
					var $scroller = $parent.find('.CyScroller');
					var $scrollerUp = $parent.find('.CyScrollerUp');
					var $scrollerDown = $parent.find('.CyScrollerDown');
					var $scrollerTop = $parent.find('.CyScrollerTop');
					// 鼠标是否在滚动区域悬浮
					var mouseHoverOnScrollerArea = false;
					
					// 悬浮在上面时才出现滚动条
					if(opt.autoHidden){
						$scrollerUp.hide();
						$scrollerDown.hide();
						$parent.hover(function(){
							$scrollerUp.fadeIn('fast');
							$scrollerDown.fadeIn('fast');
						},function(){
							$scrollerUp.fadeOut('fast');
							$scrollerDown.fadeOut('fast');
						}
						);
					}
					
					// 悬浮在滚动条上时样式变化
					$scrollerArea.hover(function(){
						mouseHoverOnScrollerArea = true;
						$scrollerArea.addClass('hover');
					},function(){
						mouseHoverOnScrollerArea = false;
						$scrollerArea.removeClass('hover');
					}
					);
					
					
					// 更新滚动条，内部包含的内容变化时需要调用此方法
					var _updateSrcollerBar = function() {
						var parentH = $parent.height();
						var innerH = $inner.height();

						if($scroller.css("top") == "0px")
						{
						$inner.css( {
							position : 'absolute',
							top : 0
						});
						}

						$parent.css( {
							position : 'relative',
							overflow : 'hidden'
						});

						$scrollerArea.css( {
							'height' : parentH + 'px',
							'position' : 'absolute',
							'right' : $scrollerBar.width() + 'px',
							'top' : '0px'
						});

						$scrollerBar
								.css( {
									'height' : (parentH - $scrollerUp.height() - $scrollerDown
											.height() - $scrollerTop.height())
											+ 'px',
									'position' : 'absolute',
									'top' : $scrollerUp.height() + $scrollerTop.height() + 'px'
								});

						$scrollerTop.css({
							'position' : 'absolute',
							'top' : '0px'
						}
						);
								
						$scrollerUp.css( {
							'position' : 'absolute',
							'top' : $scrollerTop.height() + 'px'
						});

						$scrollerDown.css( {
							'position' : 'absolute',
							'bottom' : '0px'
						});

						// 计算滚动条的长度
						var scrolllerAreaHeight = parentH - $scrollerUp.height() - $scrollerDown
											.height() - $scrollerTop.height();
						var scrollerHeight
						if(parentH > innerH){
							scrollerHeight = scrolllerAreaHeight;
						}else{
							scrollerHeight =  parentH * scrolllerAreaHeight / innerH;
						}
						// 最小长度
						if (scrollerHeight < 10) {
							scrollerHeight = 10;
						}
						// 重新计算滚动条的位置

						$scroller.css( {
							height : scrollerHeight + 'px',
							width : '100%',
							position : 'absolute'
						});

					}
					_updateSrcollerBar();

					// 滚动条移动
					var _scrollerMoveTo = function(position, withAnimate) {
						var pos;
						var bottom = $scrollerBar.height() - $scroller.height();
						if (position < 0) {
							pos = 0;
						} else if (position > bottom) {
							pos = bottom;
						} else {
							pos = position;
						}

						if (withAnimate) {
							$scroller.animate( {
								top : pos
							}, 400);
						} else {
							$scroller.css( {
								top : pos + 'px'
							});
						}
					}
					var hasFocus = false;

					var _scrollTo = function(position, withAnimate) {
						var bottom = $parent.height() - $inner.height();
						if (position >= 0) {
							position = 0;
							if (caks.onScrollToTop) {
								caks.onScrollToTop(position, $parent);
							}
						} else if (position <= bottom) {
							position = bottom;
							if (caks.onScrollToBottom) {
								caks.onScrollToBottom(position, $parent);
							}
						}
						if(position <= 0)  //position大于等于0证明只有一页
						{
							if (withAnimate) {
								$inner.animate( {
									top : position
								}, 400);
							} else {
								$inner.css( {
									'top' : position + 'px'
								});
							}
						}

						if (caks.onScroll) {
							caks.onScroll(position, $parent);
						}

						// 计算出滚动条移动距离
						var scrollPosition = 0;
						if($inner.height() != 0)
						{
							scrollPosition = (-position)
								* $scrollerBar.height() / $inner.height();
						}
						_scrollerMoveTo(scrollPosition, withAnimate);
					}
					var _scrollBy = function(position, withAnimate) {
						var top = $inner.css('top');
						top = parseInt(top.substr(0, top.length - 2));
						var pos = top + position;
						_scrollTo(pos, withAnimate);
					}
					// 绑定滚轮事件
					$parent.bind('mousewheel', function(event, delta) {
						_scrollBy(opt.srcollSpeed * delta);
					});

					// 拖动滚动条处理
					var _onDrag = false;
					var _currentPos;
					$scroller.bind('mousedown', function(event) {
						_onDrag = true;
						_currentPos = event.clientY;
						event.preventDefault();
						event.stopPropagation();
					}).bind('click', function(event) {
						event.preventDefault();
						event.stopPropagation();
						
					});

					//兼容ie6，$(window)需改为$(document)
					$(document).bind('mouseup', function(event) {
						_onDrag = false;
					});

					//兼容ie6，$(window)需改为$(document)
					$(document).bind(
							'mousemove',
							function(event) {
								if (_onDrag) {
									event.preventDefault();    //添加此处，ie6才能阻止默认拖拉事件
									var newPosition = event.clientY
											- _currentPos;
									_currentPos = event.clientY;
									var innerPosition = newPosition
											* $inner.height()
											/ $scrollerBar.height();
									_scrollBy(-innerPosition);
								}
							});

					// 处理滚动槽被点击的动作
					$scrollerBar.bind('mousedown', function(event) {
						var distance = event.clientY - $scroller.offset().top;
						distance = distance * $inner.height()
								/ $scrollerBar.height();
						_scrollBy(-distance, true);
					});

					// 上下箭头移动滚动条事件
					var _distance;
					var _moveByArrow = function() {
						_scrollBy(_distance, false);
					};
					var _moveHandler;
					// 处理上箭头被按下的动作
					$scrollerUp.bind('mousedown', function() {
						clearInterval(_moveHandler);
						_distance = 10 * $inner.height()
								/ $scrollerBar.height();
						_moveByArrow();
						_moveHandler = setInterval(_moveByArrow, 200);
					});
					// 处理下箭头被按下的动作
					$scrollerDown.bind('mousedown', function() {
						clearInterval(_moveHandler);
						_distance = -10 * $inner.height()
								/ $scrollerBar.height();
						_moveByArrow();
						_moveHandler = setInterval(_moveByArrow, 200);
					});
					$(document).bind('mouseup', function() {
						clearInterval(_moveHandler);
					});
					// 处理回到顶部箭头
					$scrollerTop.bind('click',function(){
						_scrollTo(0,true);
					}
					);

					// 暴露的方法
					$parent.scrollTo = _scrollTo;
					$parent.scrollBy = _scrollBy;
					$parent.getContent = function() {
						return $inner;
					};
					$parent.updateScroller = _updateSrcollerBar;
					$parent.getPosition = function(){
						var top = $inner.css('top');
						return top.substr(0,top.length-2);
					};
					
					result.push($parent);
				});

		return $(result);
	};

	$.fn.CyScroller.defaults = {
		className : 'CyScrollerWindow', // 顶层样式类，默认为：CyScrollerWindow，设置滚动窗口最外层class设置为此值
		bindToGloalWheel : false, // 是否不需要焦点，只要用户滚动滚轮就能触发，默认为：false
		srcollSpeed : 18,
		autoHidden : true
	// 滚动速度，旋转滚轮时页面的移动速度
	};
})(jQuery);
