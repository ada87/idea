/**
 * 视图切换器
 */
(function() {
	var self = window.caiyun.ui.model.viewswitch;

	self.init = function() {
		var $viewSwitch = $('#view_switch');
		var fileOperator = caiyun.operate;
		var constants = caiyun.constants;
		var $toGridView = $viewSwitch.find('#to_grid');
		var $toThumbnailView = $viewSwitch.find('#to_thumbnail');

		// 控制选中哪一个的Element
		var $focu = $viewSwitch.find('ul');

		$toGridView.bind('click', function() {
			if (fileOperator.getCurrentView() != constants.view.web) {
				fileOperator.viewSwitch(constants.view.web);
				fileOperator.reLoad();
			}
		});
		$toThumbnailView.bind('click', function() {
			if (fileOperator.getCurrentView() != constants.view.win) {
				fileOperator.viewSwitch(constants.view.win);
				fileOperator.reLoad();
			}
		});

		// 提供个进入方法给视图切换器回调
		self.enter = function() {
			// 获取当前目录展示模式
			var view = fileOperator.getCurrentView();
			if (view == constants.view.web) {
				$focu.addClass('ul_1');
				$focu.removeClass('ul_2');
			} else if (view == constants.view.win) {
				$focu.addClass('ul_2');
				$focu.removeClass('ul_1');
			}
		};

		// 监听视图切换事件
		fileOperator.onListen('viewSwitch', function(viewMode) {
			if (viewMode == constants.view.win) {
				$focu.addClass('ul_2');
				$focu.removeClass('ul_1');
			} else if (viewMode == constants.view.web) {
				$focu.addClass('ul_1');
				$focu.removeClass('ul_2');
			}
		});

		// 提供个离开方法给视图切换器回调
		self.leave = function() {

		};

		self.show = function() {
			$viewSwitch.show();
		};

		self.hide = function() {
			$viewSwitch.hide();
		};

	};

	// 将自己的初始化方法加载到ui的initList中
	caiyun.ui.initList.push(self);
})();