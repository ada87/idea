/**
 * 同步文件夹用户取消同步
 */
(function(){
	var self = caiyun.ui.model.syncDialog;
	var ui = caiyun.ui;
	
	// 初始化方法
	self.init = function(){
		var fileOperator = caiyun.operate;
		var html =	'<div class="popContent">'+
		'<div class="system_main"></div>' + 
		'<div class="off_line_tips_YN">'+
		'<div class="tips_img"></div>'+
		'<div class="floatleft" style="width:420px;">' + 
		'<p class="content">确定要取消同步吗？<br/> 取消后将导致其他终端无法继续同步。</p> ' +
		'</div>' +
       '</div>'+
       '</div>';
		
       	// 创建对话框
		var dialog;
		
		dialog = ui.msgBox({
				title : "系统提示",
				width :650,			
				leftBtn : false,     //左下角是否有按钮
				middleBtn : false,      //底部按钮是否居中
				html :html,
				btnName :["确定","取消"],
				okHandle :function(){
					fileOperator.syncCancelfunc();
					dialog.close();
				}
		});		
		// 监听用户取消同步事件
		fileOperator.onListen('syncCancel',function(selected){
			
			dialog.show();
		});
	};
	
	// 将自己的初始化方法加载到ui的initList中
	caiyun.ui.initList.push(self);
})();