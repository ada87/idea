/**
 * 历史版本列表 
 */
(function(){
	var self = caiyun.ui.model.versionList;		
	self.init = function(){
		var fileOperator = window.caiyun.operate;
		var cache = caiyun.util.cache;
		var constants = caiyun.constants;
	    var versionManager = caiyun.biz.versionManager;
	    var judgement = caiyun.judgement;
	    var util = window.caiyun.util;
	    var fileManager = caiyun.biz.fileManager;
		var dialog;
		self.isOpen = false;
		self.ContenID =null;
		self.show = function(){
			openHistlistWindow();
		};
		self.open = function(){
			histvisionlist_Paramers.histListwind.show();
			$('span[id$="_clear"]').css("cursor","default").css("color","#cccccc");
		    $('span[id$="_down"]').css("cursor","default").css("color","#cccccc");
		    $('span[id$="_recover"]').css("cursor","default").css("color","#cccccc");
		    isOpen = true;
		};
		self.close = function(){
		    histvisionlist_Paramers.histListwind.close();
		    isOpen = false;
		    ContentID =null;
		};
		var ids = null;		
		// 监听选择事件
		fileOperator.onListen('selectData',function(selectedIds){
			ids = selectedIds;
			self.ContenID = ids[0];
			if(ids.length == 1){
			}
		}
		);	
	self.canCancelSync = function(){
		return false;
	};		
	
	/********************************************************************************文件历史版本相关*********************************************************************/
	
       var histvisionlist_Paramers = {
		lodingHtml: '',
		bindEvnet: function(){
		
		},
		
		histvision_listHtml: function(){
			var html = new StringBuffer();
			html.append('<div class="detailCon" style="height:325px;"><div class="History-Content1"><div class="off_line_m_main">')
			.append('<ul id="id_histvisionData">')
			.append('</ul></div></div></div>');
			return html.toString();
		},
		
		histvisionTaskAjax: function(){
			var iMsgTip = caiyun.ui.iMsgTip;
			if(!ids[0]){
				ids[0]=self.ContentID;
			};
			//通知修改收到的分享目录下的已读状态
			window.caiyun.operate.setReceDirReadStatus(ids[0]);
			var reData = {};
			var param = {
					contentID: ids[0]
				};
			//如果是在我接收到的文件夹二级目录下,则需要变成全路径方式
		    if (judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)) {
				var path = judgement.getPath(caiyun.operate.getCatalogStack());
				reData = {
					path: path + "/" + ids[0]
				};
				$.extend(param, reData);
			}else if(judgement.isEnterprisePath()){
                $.extend(param, {path:judgement.getPathForEnterprise() + '/' + ids[0]});
            }
		    versionManager.getVersionList(
                    param, 
                    function(params, result){                                      
                        var obj = result.result;
                        var code=obj['@resultCode'];                                              
                       if(code==0&&(!obj.getFileVerInfoRes)){
									   iMsgTip.tip("文件没有历史版本信息!");
									   self.close();
									   return;
									}
					  if(code!=0)
									{
										var showMessage = obj['@showMessage'];
										if(showMessage){
											 iMsgTip.tip(showMessage, "error");	
										}else{
											iMsgTip.tip("系统繁忙，请稍后再试！", "error");											   
										}
					     				 self.close();
									    return;
									}
                        
                     var versionList = obj.getFileVerInfoRes.fileVerInfoList.contentInfo;
					 var length = obj.getFileVerInfoRes.fileVerInfoList['@length'];
					 if (versionList && length == 1)
						{
						   iMsgTip.tip("文件没有历史版本信息!");
						   self.close();
						   return;
						}
						if(versionList && length > 1){
							 if(!self.isOpen){
							 	self.open();
							 }	
							 var $dataUl = $('#id_histvisionData').html('');									   					 				
							 histvisionlist_Paramers.histvisionDataView(versionList,$dataUl);
						}
                    },
                    function(){
						self.close();
                       iMsgTip.tip("系统异常，请稍后再试！","error");
                    }			
			);
			//统计历史版本管理操作
			caiyun.pvlog('syncFile','histManage',ids[0]);
			},
			
			histvisionDataView :function(versionList, $dataUl){
			 var ContentID = '';
	    	 $.each(versionList, function(i, n){
	     	    
	     	    if(i==0)
	     	    {
	     	      ContentID = n.contentID;
	     	    }
	            var index = versionList.length-i;
	    		var filevis = i == 0 ? '当前版本':'版本'+index;
	    		var time = util.newFormateTime(n.updateTime).split(' ');	  
	    		var t_d = time[0];
	    		var t_t = time[1];
                var param = {
                type    : 'File',
                name    : n.contentName,
                style   : 'web'
                             };         
	    		var name = null;
	    		if (n.contentName.length <= 20) {
						 name = n.contentName;
					} else {
						 name = n.contentName.substring(0, 14) + "..." + n.contentName.substring(n.contentName.length - 4);
					}
			     
	    		var icon = util.Icon.getIconByExtName(n.contentSuffix,true);
			     var $data = $('<li' +' id=versionList_' + n.fileVersion + ' >');
			     $data.css('cursor','pointer');
			     var $img = $('<img class="off_line_m_main_logo" src="' + icon +'">');
			     var $name = $('<span class="m1"></span>').text(name);
			     var $date = $('<span class="t_nav">'+
			    		  '<span class="m3">' + t_d + '</span>' + '<span class="m4">' + t_t + '</span>' + '<span class="m5">'+ filevis +'</span>'+
                         '</span>');
			     
			     $data.append($img).append($name).append($date);
			    $dataUl.append($data);
			    if(i>0){
			    $("#versionList_" + n.fileVersion).unbind('click').bind('click',function(e){
			    	 $('li[id^="versionList_"]').css("background","#ffffff");
			    	 $("#versionList_" + n.fileVersion).css("background","#E0D3F4");
			         $('span[id$="_clear"]').css("cursor","pointer").css("color","#000000");
		             $('span[id$="_down"]').css("cursor","pointer").css("color","#000000");
		             $('span[id$="_recover"]').css("cursor","pointer").css("color","#000000");
		             
		             $('span[id$="_clear"]').unbind('click').bind('click',function (event){
		             event.preventDefault();
		             histvisionlist_Paramers.histvision_clear(self.ContenID,n.fileVersion);
		             return false;
		             });
		             
		             $('span[id$="_down"]').unbind('click').bind('click',function (event){
		             event.preventDefault();
		             histvisionlist_Paramers.histvision_down(self.ContenID,n.fileVersion);
		             return false;
		             });
		             
		             $('span[id$="_recover"]').unbind('click').bind('click',function (event){
		             event.preventDefault();
		             histvisionlist_Paramers.histvision_recv(self.ContenID,n.fileVersion);
		             return false;
		             });
			    });
			    };
			}); 
			
			},		
		 
		 histvision_clear:function(contentID,visionID){
		 	//统计历史版本管理清除操作
		 	caiyun.pvlog('syncFile','clearVersion',contentID);
		 	var iMsgTip = caiyun.ui.iMsgTip;
            var params ={version:visionID,contentID:contentID};
			if(caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)){
				var path = judgement.getPath(caiyun.operate.getCatalogStack());
				$.extend(params,{path:path + "/" + contentID});
			}else if(caiyun.judgement.isEnterprisePath()){
                $.extend(params,{path:caiyun.judgement.getPathForEnterprise() + "/" + contentID});
            }
			versionManager.histvisionClear(
			            params,
						function(params,result){
											var obj = result.result;
											var code=obj['@resultCode'];
											if(code!=0){
												var showMessage = obj['@showMessage'];
												if(showMessage){
													 iMsgTip.tip(showMessage, "error");	
												}else{
													iMsgTip.tip("系统繁忙，请稍后再试！", "error");											   
												}
												self.close();											   
											}else{										   	   
												histvisionlist_Paramers.histvisionTaskAjax();
												$('span[id$="_clear"]').unbind('click');
												$('span[id$="_down"]').unbind('click');
												$('span[id$="_recover"]').unbind('click');
											}
											       	            
								  },
								  function(){
								             iMsgTip.tip("系统繁忙，请稍后再试！", "error");											   
											 self.close(); 
								  }
						);
			   			  	
		 },
		 histvision_down: function(contentID,visionID){
		 	//统计历史版本管理下载操作
		 	caiyun.pvlog('syncFile','download',contentID);
		    var params ={visionID:visionID,contentID:contentID};
			if(caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)){
				var path = judgement.getPath(caiyun.operate.getCatalogStack());
				$.extend(params,{path:path+"/"+contentID});
			}else if(caiyun.judgement.isEnterprisePath()){
                $.extend(params,{path:caiyun.judgement.getPathForEnterprise() + "/" + contentID});
            }
			if(!$.browser.msie){
				fileManager.downloadFile (params,function(params,result){
					var downurl= result.downloadUrl;
					var downloadFrame = $('#downloadFile');
					downloadFrame.attr('src',downurl);
				},null);
			}else{
			   	var queryStr = '';
			   	var downloadFrame = $('#downloadFile');
				for (var pname in params){
					queryStr += pname + '=' + encodeURIComponent(params[pname]) + '&';
					if(pname === 'contentID'){
						queryStr += 'shareContentIDs=' + params[pname] + '&';
					}
				}
				queryStr += 'redirect=t';
				if(judgement.isSafeBox()){
					downloadFrame.attr('src',address + 'safebox/downLoadAction!downloadToPC.action?' + queryStr);
				}else{
					downloadFrame.attr('src', '/webdisk2/downLoadAction!downloadToPC.action?' + queryStr);
				}
			}
		 },
		 histvision_recv: function(contentID,visionID){
		 	//统计历史版本管理恢复操作
		 	caiyun.pvlog('syncFile','restore',contentID);
		 	var iMsgTip = caiyun.ui.iMsgTip;
            var params ={version:visionID,contentID:contentID};
			if(caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)){
				var path = judgement.getPath(caiyun.operate.getCatalogStack());
				$.extend(params,{path:path+"/"+contentID});
			}else if(caiyun.judgement.isEnterprisePath()){
                $.extend(params,{path:caiyun.judgement.getPathForEnterprise() + "/" + contentID});
            }
		 	versionManager.histvisionRecv(
						params,						
						function(params,result){
											var obj = result.result;
											var code=obj['@resultCode'];
											if(code!=0){
												var showMessage = obj['@showMessage'];
												if(showMessage){
													 iMsgTip.tip(showMessage, "error");	
												}else{
													iMsgTip.tip("系统繁忙，请稍后再试！", "error");											   
												}								   
												self.close();	
											}else{
											    histvisionlist_Paramers.histvisionTaskAjax();
											    $('span[id$="_clear"]').unbind('click');
												$('span[id$="_down"]').unbind('click');
												$('span[id$="_recover"]').unbind('click');
											}
											       	            
								  },
								  function(){
								              iMsgTip.tip("系统繁忙，请稍后再试！", "error");											   
											  self.close();	 
								  }
						);
							  
			
		 },		 
		
	  openHistlistWindow :function (){
			self.isOpen = false;
			histvisionlist_Paramers.histListwind = caiyun.ui.msgBox({
			title: '历史版本管理',
			type: 'history',
			html: histvisionlist_Paramers.histvision_listHtml()
		});	
		histvisionlist_Paramers.histvisionTaskAjax();
		}
		};
		
		/**
		 * 离线文件列表窗体
		 */		
		var openHistlistWindow = function (){
			self.isOpen = false;
			histvisionlist_Paramers.histListwind = caiyun.ui.msgBox({
			title: '历史版本管理',
			type: 'history',
			html: histvisionlist_Paramers.histvision_listHtml()       
		});		
		histvisionlist_Paramers.histvisionTaskAjax();
		};
	
				
	

		};
	// 将自己的初始化方法加载到ui的initList中
	caiyun.ui.initList.push(self);
})();
