/*  免费扩容*/
caiyun.ui.model.freemission = {};;
(function() {
	var self = caiyun.ui.model.freemission;
	var $free_upload = $('#free_upload');
	var $free_invite = $('#free_invite');
	var $free_loginClient = $('#free_loginClient');
	var $free_openSafe = $('#free_openSafe');
	var $free_loginPC = $('#free_loginPC');
	var $free_synchroMcloud = $('#free_synchroMcloud');
	var $free_shareWeibo = $('#free_shareWeibo');
	var $freeAdd_title = $('#freeAdd_title');
	var m = 1;
	self.init = function() {
		getLoginInfos();
	};

	self.show = function() {

	};

	self.hide = function() {

	};

	self.enter = function() {
		disable = false;
	};

	self.leave = function() {
		disable = true;

	};
	
	//读取广告
	$.ajax({
	    type    : 'post', 
	    url     : '../marketplat/getAdvertAction.action?date=' + new Date().getTime(), 
	    dataType: 'json',
	    data    : {advertPos:'2007'}, 
	    success : function(response){
		    if(respone != null && respone.showMessage == "")
			{
				var res = respone.getAdvertResult;
				if(res != null && res.resultCode == "0")
				{
					var advertImg = res.advertInfos;
					if(advertImg[0] && advertImg[0].linkUrl)
					{
					  $('.ad_box a').attr('href', advertImg[0].linkUrl + '&mssc=' + rcsToken).html(advertImg[0].title);
					}
				}
			}
		},
           error   : null
	});
	
	// 获取记录
	var getLoginInfos = function() {

		$.ajax({
			url : "../getFree_expansion_Infos!querygetMissonInfos.action?date="
					+ new Date().getTime(),
			type : "POST",
			data : {},
			dataType : "json",
			success : initQuerySuccess

		});

	};
	var initQuerySuccess = function(src) {
		// 登录超时，跳转到登录页面
		if ("timeout" == src.showMessage) {
			timeOutUrl();
			return;
		}
		if (src.retCode == 0) {
			var items = src.info.freeMissionInfos;
			var trs = "";
			var l = 0;
			itemCount = items.length;
			for ( var i in items) {

				l += createstate(items[i]);
			}
			$('#free_invite_input').val("" + src.info.inviteCode).end();
			$('#free_invite_input').select();
			if (l > 0) {
				$freeAdd_title.html(
						"完成任务，免费赠送永久空间（最大可获得<em>16G</em>， 您已经成功获得<em>" + l
								+ "G</em>免费扩容容量）").end();
			}
			bindFlash();
		} else {

		}

	};
	 
	window.onresize = function() {
		
				
				setTimeout(bindFlash,100);
			
		
	};

	// 绑定flash事件(复制按钮操作)
	var bindFlash = function() {
		if (m == 1) {
			var clip = new ZeroClipboard.Client();
			clip.setHandCursor(true);
			clip.setText($('#free_invite_input').val());
			clip.addEventListener('mouseup', function(client) {
				$('#copyL_su').show();
				setTimeout(function() {
					$('#copyL_su').hide();
				}, 1000);
			});
			clip.glue('free_invite_copy');
		}
	};

	var createstate = function(item) {
		var terminal = item.terminal;
		var i = item.missionId;
		var j = item.finishTimes;
		if (terminal == -1) {
			return 0;
		}
		if ("20001" == i && 0 < j) {
			$free_upload.addClass('success');
			$('#free_upload a').removeAttr("href");
			j = 1;

		}
		if ("20002" == i && 0 < j) {
			$free_openSafe.addClass('success');
			$('#free_openSafe a').removeAttr("href");
			j = 2;
		}
		if ("20003" == i && 0 < j) {
			$free_synchroMcloud.addClass('success');
			j = 2;
		}
		if ("20004" == i && 0 < j) {
			$free_loginPC.addClass('success');
			$('#free_loginPC a').removeAttr("href");
			j = 1;

		}
		if ("20005" == i && 0 < j) {
			$free_loginClient.addClass('success');
			$('#free_loginClient a').removeAttr("href");
			j = 1;

		}
		if ("20006" == i && 0 < j) {
			$free_shareWeibo.addClass('success');
			j = 1;
		}
		if ("20007" == i) {

			if (j < 8) {

				var n = 8 - j
				$('#freeAdd_num').removeClass('num_8G');
				$('#freeAdd_num').addClass('num_' + n + 'G');
			} else {
				$free_invite.addClass('success');
				m = 0;
				j = 8;
			}

		}

		return j;
	};

	// 设置切换

	$('#userMenu_his').hover(function() {
		$(this).addClass('hover');
	}, function() {
		$(this).removeClass('hover');
	});
	$('#userMenu_sms').hover(function() {
		$(this).addClass('hover');
	}, function() {
		$(this).removeClass('hover');
	});
	$('#userMenu_out').hover(function() {
		$(this).addClass('hover');
	}, function() {
		$(this).removeClass('hover');
	});
	$(document).ready(function() {
		self.init();

	});
	/**
	 * 初始化头部方法
	 */

	var $cy_header = $('#cy_header');
	var $top_thumb = $(".top-thumb");
	var $user_u = $(".user_u");
	var $mySetup = $("#mySetup");
	var $userMenu = $(".userMenu");

	// 去掉IE6下a标签框框
	$user_u.find("a").focus(function() {
		$(this).blur();
	});

	// 初始化鼠标移过设置时下拉框
	$mySetup.click(function(event) {
		if ($userMenu.is(":hidden")) {
			$userMenu.show()
		} else {
			$userMenu.hide();
		}
		event.stopPropagation();
	});

	$("html").click(function() {
		$userMenu.hide();
	});

	// 设置悬浮鼠标滑过效果
	$('#userMenu_pri,#userMenu_his,#userMenu_sms,#userMenu_out').hover(
			function() {
				$(this).addClass('hover');
			}, function() {
				$(this).removeClass('hover');
			});

	caiyun.ui.initList.push(self);
})();
