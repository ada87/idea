/**
 * 分享工具栏
 */
(function() {

	var self = caiyun.ui.model.toolbarformyshare;
	var $tool_bar = $('#share_bar');
	var $share_title = $('#share_title');
	var $share_title0 = $('#share_title0');
	var $share_title1 = $('#share_title1');
	var $share_title2 = $('#share_title2');
	var $share_title3 = $('#share_title3');
	var $selectShareAll = $('#selectShareAll');
	var disable = false;

	self.init = function() {
		var operate = caiyun.myFileShareOperate;

		var commandList = [ {
			id : 'cancelMyShare',
			name : '取消分享',
			style :'look_all_btn l_share_cancel',
			click : function() {
				operate.cancelFileShare();
			},
			isDisable : function() {
				return operate.canExecute('cancelMyShare');
			}
		}, {
			id : 'meberMyShare',
			name : '成员管理',
			style : 'look_all span l_share_member',
			click : function() {
				operate.memberManager();
			},
			isDisable : function() {
				return operate.canExecute('meberMyShare');
			}
			
		}, {
			id : 'enterEPDirTools',
			name : '进入企业空间',
			style : 'look_all span l_share_enter',
			click : function() {
				operate.enterEnterpriseSpace();
			},
			isDisable : function() {
				return operate.canExecute('enterEPDirTools');
			}
			
		} ];

		// 工具栏内部对象
		var toolBar = window.caiyun.ui.CyNavBar( {
			renderTo : 'share_bar',
			items : commandList
		});

		// operate.cancelFileShare(),
		// operate.memberManager(),
		operate.onListen('selectData',toolBar.nvaBarShow);

		// 监听选择事件
		operate.onListen('selectData', function(ids,total) {
			if (disable) {
				return;
			}
			if (!ids || ids.length == 0) {
				//$share_title.show();
				$share_title0.show();
				$share_title1.show();
				$share_title2.show();
				$share_title3.show();
				
				$selectShareAll.removeClass('input_first_on');
				$selectShareAll.addClass('input_first');
			} else {
				$share_title0.hide();
				$share_title1.hide();
				$share_title2.hide();
				$share_title3.hide();
				//$share_title.hide();
			}
			if(ids.length < total){
				$selectShareAll.removeClass('input_first_on');
				$selectShareAll.addClass('input_first');
			}
		});
	};

	self.show = function() {
		$tool_bar.show();
		$share_title0.show();
		$share_title1.show();
		$share_title2.show();
		$share_title3.show();

	
		//$share_title.show();
	};

	self.hide = function() {
		$tool_bar.hide();
		$share_title0.hide();
		$share_title1.hide();
		$share_title2.hide();
		$share_title3.hide();
	
		//$share_title.hide();
	};

	self.enter = function() {
		disable = false;
	};

	self.leave = function() {
		disable = true;
		self.hide();
	};

	caiyun.ui.initList.push(self);

})();
