/**
 * 功能按钮栏
 */
(function(){
	var self = caiyun.ui.model.functionChangeNewStatus;
	
	// 初始化
	self.init = function(){
		var fileOperator = caiyun.operate;
		
		//监听修改接收到的文件夹new状态
		fileOperator.onListen('changeNew', function() {
			$('#span_receviNew').show();
		});
		
		//监听修改接收到的文件夹二级目录下的new状态
		fileOperator.onListen('changeReceNew', function() {
			$('max_icon m_maxNew').show();
		});
	};
	
	// 注册初始化事件
	caiyun.ui.initList.push(self);
}
)();