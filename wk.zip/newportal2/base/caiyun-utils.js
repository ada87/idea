(function() {
	var util = window.caiyun.util;// 缓存全局变量

	/*
	 * 替换电话号码前缀+86 86
	 */
	util.replace86 = function(mobile) {
		mobile = mobile + '';
		if (mobile.indexOf('0086') != -1 && mobile.substring(0, 4) == '0086') {
			return mobile.substring(4, mobile.length);
		}
		if (mobile.indexOf('86') != -1 && mobile.substring(0, 2) == '86') {
			return mobile.substring(2, mobile.length);
		}
		if (mobile.indexOf('+86') != -1 && mobile.substring(0, 3) == '+86') {
			return mobile.substring(3, mobile.length);
		}
		return mobile;
	};

	util.timeoutHref = function() {
		top.window.location.href = "https://caiyun.feixin.10086.cn?hash=" + encodeURIComponent(location.hash);
	};

	util.stopDefault = function(e) {
		if (e && e.stopPropagation) {
			e.stopPropagation();
		} else {
			// 否则，我们需要使用IE的方式来取消事件冒泡
			e.cancelBubble = true;
		}

		if (e && e.preventDefault) {
			e.preventDefault();
		} else {
			// IE中阻止函数器默认动作的方式
			e.returnValue = false;
		}

		return false;
	};

	/*
	 * 截取名称
	 */
	util.splitName = function(param) {
		var maxLen = param.maxLen;
		if (param['name'].strLen() <= maxLen) {
			return param['name'];
		} else {
			if (param['type'] == '-1') {
				return param['name'].subCHStr(0, maxLen - 3) + '...';
			} else {
				var suffixIndex = param['name'].lastIndexOf(".");
				var suffixName = param['name'].substring(suffixIndex + 1);
				if (suffixName.strLen() > 4) {
					return param['name'].subCHStr(0, maxLen - 3) + "..";
				} else {
					return param['name'].subCHStr(0, maxLen - 6) + ".."
							+ suffixName;
				}
			}
		}
	};
	util.countSec=function(seconds){
		if(seconds >0){  
            var minutes = Math.floor(seconds/60);  
            seconds = seconds - minutes * 60;  
            return formatMinutes(minutes) + (seconds > 0 ? seconds + "秒" : "");  
        }  
        return seconds;
	};
	function formatMinutes(minutes){  
        var day = parseInt(Math.floor(minutes / 1440));  
        var hour = day >0  
                       ?Math.floor((minutes - day*1440)/60)  
                       :Math.floor(minutes/60);  
        var minute = hour > 0  
                          ? Math.floor(minutes -day*1440 - hour*60)  
                          :minutes;  
        var time="";  
        if (day > 0) time += day + "天";  
        if (hour > 0) time += hour + "小时";  
        if (minute > 0) time += minute + "分钟";  
        return time;  
    } 
	/**
	 * 回收站解决路径太长导致页面样式问题
	 */
	util.splitRecovery = function(param) {
		var maxLen = param.maxLen;
		var myStringBuffer = new StringBuffer();
		if (param['name'].strLen() <= maxLen) {
			return param['name'];
		} else if (param['type'] == "1") { // 弹出框名称
			return myStringBuffer.append(param['name'].substr(0, 20)).append(
					"...");
		} else {
			var arryName = param['name'].split("/");
			var temp = "";
			for ( var i = 0; i < arryName.length; i++) {
				temp = arryName[i];
				if (temp.length > 5) {
					if (param['type'] == 2) {
						myStringBuffer.append(temp.substr(0, 5)).append("..")
								.append("/");
						if (myStringBuffer.toString().length >= 60) {
							return myStringBuffer.toString().substr(0,
									myStringBuffer.toString().length - 2);
							break;
						}
					} else {
						myStringBuffer.append(temp.substr(0, 5)).append("..")
								.append("/");
						if (myStringBuffer.toString().length >= 75) {
							return myStringBuffer.toString().substr(0,
									myStringBuffer.toString().length - 1);
							break;
						}
					}
				} else {
					myStringBuffer.append(temp).append("/");

				}
			}
			return myStringBuffer.toString().substr(0,
					myStringBuffer.toString().length - 1);
		}
	};

	/*
	 * 格式化文件大小 @param {object} data
	 */
	util.formateSize = function(size) {
		if (!size || size == '-1') {
			return '';
		}
		var fixed = 2;
		var arr = [ "KB", "MB", "GB", "TB" ];
		size = size / 1024;
		if (!size.toFixed(fixed)) {
			return "1KB";
		}
		var index = 0;
		while (size >= 1024) {
			index++;
			size = size / 1024;
		}
		return size.toFixed(fixed) + arr[index];
	};

	util.newFormateTime = function(time) {
		if (!time) {
			return "";
		}
		var year = time.substring(0, 4);
		var month = time.substring(4, 6);
		var day = time.substring(6, 8);
		var hour = time.substring(8, 10);
		var minute = time.substring(10, 12);
		var second = time.substring(12, 14);

		return [ year, month, day ].join('-') + ' '
				+ [ hour, minute, second ].join(':');
	};
	util.myFormateTime = function(time) {
		var year = time.substring(0, 4);
		var month = time.substring(4, 6);
		var day = time.substring(6, 8);
		var hour = time.substring(8, 10);
		var minute = time.substring(10, 12);

		return [ year, month, day ].join('-') + ' '
				+ [ hour, minute ].join(':');
	};
	/*
	 * 当前日期时间格式化 @return {} 经过格式化后日期时间
	 */
	util.simpleDateformat = function() {
		var month = new Date().getMonth() + 1;
		var date = new Date().getDate();
		var year = new Date().getFullYear();
		var hours = new Date().getHours();
		var minutes = new Date().getMinutes();
		var seconds = new Date().getSeconds();

		month = month >= 10 ? ('' + month) : ('0' + month);
		date = date >= 10 ? ('' + date) : ('0' + date);
		hours = hours >= 10 ? ('' + hours) : ('0' + hours);
		minutes = minutes >= 10 ? ('' + minutes) : ('0' + minutes);
		seconds = seconds >= 10 ? ('' + seconds) : ('0' + seconds);

		return year + month + date + hours + minutes + seconds;
	};

	/*
	 * 格式化时间
	 */
	util.formateShareTime = function(time) {
		if (!time) {
			return "";
		}
		var year = time.substring(0, 4);
		var month = time.substring(4, 6);
		var day = time.substring(6, 8);
		var hour = time.substring(8, 10);
		var minute = time.substring(10, 12);

		return [ year, month, day ].join('-') + ' '
				+ [ hour, minute ].join(':');
	};
	
	/*
	 * 格式化时间（外链整体信息）
	 */
	util.formateOutLinkTime = function(time) {
		if (!time) {
			return "";
		}
		var year = time.substring(0, 4);
		var month = time.substring(4, 6);
		var day = time.substring(6, 8);

		return [ year, month, day ].join('-') ;
	};
	
	/*
	 * 格式化时间（外链文件夹时间）YYYY/MM/DD hh:mm
	 */
	util.formateOutLinkFileTime = function(time) {
		if (!time) {
			return "";
		}
		var year = time.substring(0, 4);
		var month = time.substring(4, 6);
		var day = time.substring(6, 8);
		var hour = time.substring(8, 10);
		var minute = time.substring(10, 12);

		return [ year, month, day ].join('/') + ' '
				+ [ hour, minute].join(':');
	};

    /**
     * 目录为空时的页面显示Html代码
     * @param tipMsg
     * @returns {*|jQuery|HTMLElement}
     */
    util.getEmptyHtmlStr=function(tipMsg){
        var $emptyHtml=$('<div class="cy_null"></div>');
        $emptyHtml.append('<div class="cy_null_logo"></div>');
        $emptyHtml.append('<p class="cy_null_txt">'+ tipMsg +'</p>');
        return $emptyHtml;
    };

    /*
     * 格式化时间(XX小时之前)
     */
    util.formateLifeTime = function(time) {
        if (!time) {
            return "";
        }
        if(time === '---'){
        	return time;
        }
        var dipalyTime="";
        var currentTime=new Date();
        var currentTimeStr=caiyun.util.simpleDateformat();
        var year = time.substring(0, 4);
        var month = time.substring(4, 6);
        var day = time.substring(6, 8);
        var hour = time.substring(8, 10);
        var minute = time.substring(10, 12);
        var second = time.substring(12, 14);
        var updateTime=new Date(year,month-1,day,hour,minute,second);
        var diffMills=Number(currentTime.getTime()-updateTime.getTime());
        var oneSecond=Number(1000);
        var oneMin=60*oneSecond;
        var oneHour=60*oneMin;
        var oneDay=24*oneHour;
        var twoDay=2*oneDay;
        var oneWeek=7*oneDay;
		var curDayInWeek=currentTime.getDay();
        if(diffMills < oneSecond){
            dipalyTime="1 秒之前";
        }else if(diffMills < oneMin){
            var sec=parseInt(diffMills/oneSecond);
            dipalyTime= sec+" 秒之前";
        }else if(diffMills < oneHour){
            var min=parseInt(diffMills/oneMin);
            dipalyTime= min+" 分钟之前";
        }else if(diffMills < oneDay){
            if(currentTimeStr.substring(0,8)=== time.substring(0,8)){
                var _hour=parseInt(diffMills/oneHour);
                dipalyTime= _hour+" 小时之前";
            }else{
                dipalyTime="昨天 " + [ hour, minute ].join(':');
            }
        }
		else if(diffMills > oneDay&&diffMills<(oneDay+currentTimeStr.substring(8, 10)*oneHour+currentTimeStr.substring(10, 12)*oneMin+oneSecond*currentTimeStr.substring(12, 14))){
			dipalyTime="昨天 " + [ hour, minute ].join(':');
		}
		else if(diffMills < oneWeek){ 
			var numx=updateTime.getDay();
            var weeks=["日","一","二","三","四","五","六"];
			if(curDayInWeek -updateTime.getDay()>0){//
				dipalyTime="星期" + weeks[numx] + ' ' + [ hour, minute ].join(':');
			}else{
				dipalyTime= [ year, parseInt(month,10), parseInt(day,10) ].join('/') + ' ' + [ hour, minute ].join(':');
			}
        }else{
            dipalyTime= [ year, parseInt(month,10), parseInt(day,10) ].join('/') + ' ' + [ hour, minute ].join(':');
        }
        return dipalyTime;
    };

    /**
     * 替换字符串中出现的所有字符(不区分大小写)
     * @param str  原本的字符串
     * @param searchChar  要替换的字符
     * @param repaceChar  替换的字符
     * @returns {*}  返回替换后的字符串
     */
    util.replaceAll = function(str,searchChar,repaceChar){
        var index = -1, acceptStr=str, tempStr="",originalStrSuffix="";
        if(!acceptStr){
           return str;
        }
        //统一转换成小写进行匹配
        acceptStr=acceptStr.toLowerCase();
        searchChar=searchChar.toLowerCase();
        index = acceptStr.indexOf(searchChar);

        while(index >= 0 ){
            tempStr+=str.substring(0,index) + repaceChar;
            originalStrSuffix=str.substring(index+searchChar.length);
            acceptStr=acceptStr.substring(index+searchChar.length);
            index=acceptStr.indexOf(searchChar);
        }
        tempStr+=originalStrSuffix;

        return tempStr;
    };
    
    /**
     * 为字符串中出现的所有子字符串添加<b>标签(不区分大小写)
     * @param str  原本的字符串
     * @param searchChar  要添加标签的字符串
     * @returns {*}  返回添加标签后的字符串
     */
    util.strBound = function(str,searchChar){
        var indexBegin = -1,indexEnd=-1, acceptStr=str, tempStr="";
        if(!acceptStr){
           return str;
        }
        //统一转换成小写进行匹配
        acceptStr=acceptStr.toLowerCase();
        searchChar=searchChar.toLowerCase();
        indexBegin = 0;
        indexEnd = acceptStr.indexOf(searchChar);

        while(indexEnd >= 0 ){
            indexEnd += indexBegin ;
            tempStr += str.substring(indexBegin,indexEnd) +
            		'<b>'+ util.htmlEscape(str.substring(indexEnd,indexEnd+searchChar.length)) + '</b>';
            acceptStr = acceptStr.substring(indexEnd+searchChar.length - indexBegin);
            indexBegin = indexEnd + searchChar.length;
            indexEnd = acceptStr.indexOf(searchChar);
        }
        tempStr+=str.substring(indexBegin);

        return tempStr;
    };
    
    /**
     * 替换字符串中出现的特殊字符
     * @param fileName {String}
     */
    util.htmlEscape = function(fileName) {
        if (!fileName) {
            return;
        }
        fileName = fileName.replace(/&/ig, '&amp;');
        return fileName;
    };

	util.formateSearchTime = function(time) {
		if (!time) {
			return "";
		}

		var year = time.substring(0, 4);
		var month = time.substring(5, 7);
		var day = time.substring(8, 10);
		var hour = time.substring(11, 13);
		var minute = time.substring(14, 16);
		var seconds = time.substring(17, 19);

		return year + month + day + hour + minute + seconds;
	};

	/**
	 * 格式化时间只剩月日
	 */
	util.formatTimeToMonthAndDay = function(time) {
		if (!time) {
			return '';
		}
		var month = parseInt(time.substring(4, 6), 10);

		var day = time.substring(6, 8);

		return month + '月' + day + '日';
	};

	/*
	 * 取得文件后缀名
	 */
	util.getSuffix = function(contentName) {
		if (!contentName) {
			return " ";
		}
		var index = contentName.lastIndexOf('.');
		if (index == -1) {
			return " ";
		}
		return contentName.substring(index + 1, contentName.length);
	};

	/**
	 * 去除后缀，获取文件名称
	 */
	util.removeSuffix = function(name) {
		if (!name)
			return '';
		var index = name.lastIndexOf('.');
		if (index == -1) {
			return name;
		}
		return name.substring(0, index);
	};

	/**
	 * 处理ie6图片加载不出来问题
	 */
	util.enhancedImage = function(src, onLoaded) {
		var self = this;
		this.interval = null;
		this.src = src;
		this.width = 0;
		this.height = 0;
		this.onLoaded = onLoaded;
		this.loaded = false;
		this.image = null;
		this.load = function() {
			if (this.loaded)
				return;
			this.image = new Image();
			this.image.src = this.src;
			function loadImage() {
				if (self.width && self.height) {
					clearInterval(self.interval);
					self.loaded = true;
					self.onLoaded(self);
				}
				self.width = self.image.width;
				self.height = self.image.height;
			}
			self.interval = setInterval(loadImage, 100);
		};
		this.kill = function() {
			if (self.interval) {
				window.clearInterval(self.interval);
			}
		};
	};

	util.newEnhancedImage = function(src, onLoaded, onError) {
		var self = this;
		this.interval = null;
		this.tryTimes = 1500;
		this.src = src;
		this.width = 0;
		this.height = 0;
		this.onLoaded = onLoaded;
		this.onErrored = onError;
		this.loaded = false;
		this.image = null;
		this.load = function() {
			if (this.loaded) {
				return;
			}
			this.image = new Image();
			this.image.onerror = function() {
				self.onErrored.call(null, {});
				window.clearInterval(self.interval);
				self.interval = null;
			};
			this.image.src = this.src;
			function loadImage() {
				self.tryTimes--;
				if (self.tryTimes < 0) {
					self.onErrored.call(null, {});
					if (self.interval) {
						window.clearInterval(self.interval);
						self.interval = null;
					}
				} else {
					if (self.width && self.height) {
						clearInterval(self.interval);
						self.loaded = true;
						self.onLoaded(self);
					}
					self.width = self.image.width;
					self.height = self.image.height;
				}
			}
			self.interval = setInterval(loadImage, 100);
		};
		this.kill = function() {
			if (self.interval) {
				window.clearInterval(self.interval);
			}
		};
	};

	/**
	 * 判断是否此文件要从本地图库显示缩略图
	 * 
	 * @param fileName
	 *            文件的名称
	 * 
	 * @return boolean 【true】:本地图库获取 【false】:获取外部地址缩略图
	 */
	util.isViewLocalImg = function(fileName) {
		var suffix = util.getSuffix(fileName);
		var suffixs = "bmp|iff|ilbm|tiff|tif|png|gif|jpeg|jpg|mng|xpm|psd|psp|xcf|pcx|ppm|dxf|cdr|"
				+ "avi|mpeg|mpg|dat|divx|xvid|rm|rmvb|mov|qt|asf|wmv|navi|vob|3gp|mp4|flv|avs|"
				+ "mkv|ogm|ts|tp|nsv|m4v";

		return suffixs.indexOf(suffix.toLowerCase()) != -1 ? false : true;
	};

	/**
	 * 根据返回的类型数字获取相对应的类型名称
	 */
	util.getTypeByNum = function(type) {
		switch (type) {
		case '':
			return "未知";
		case '-1':
			return "目录";
		case '0':
			return "未分类";
		case '1':
			return "图片";
		case '2':
			return "音频";
		case '3':
			return "视频";
		case '4':
			return "消息";
		case '5':
			return "文档";
		case '6':
			return "共享编辑";
		case '7':
			return "电子表格";
		case '8':
			return "幻灯片";
		case '9':
			return "";
		case '10':
			return "接收共享播放列表快捷方式";
		case '11':
			return "别人公开区内容快捷方式";
		case '12':
			return "手机软件";
		case '13':
			return "Email正文";
		case '14':
			return "";
		case '19':
			return "图片快捷方式";
		case '21':
			return "push to talk媒体";
		case '29':
			return "音频快捷方式";
		case '39':
			return "视频快捷方式";
		case '59':
			return "文档快捷方式";
		case '79':
			return "电子表格快捷方式";
		case '89':
			return "幻灯片快捷方式";
		case '129':
			return "手机软件快捷方式";
		default:
			return "未知";

		}
	};

	util.Validate = {

		// 非法字符正在表达式
		illegal : /^[0-9a-zA-Z\u4e00-\u9fa5]+$/,

		/*
		 * 判断字符串长度是否超出 参数n:字符个数(1个汉字占2字符)
		 */
		isOutSize : function(s, n) {
			if (!s) {
				return false;
			}
			return s.strLen() > n;
		},

		newIsOutSize : function(s, n) {
			if (!s) {
				return false;
			}
			return s.newStrLen() > n;
		},

		/*
		 * 是否包含非法字符 @param {Object} str @param {Object} charset @return
		 * {Boolean} true:包含,false:不包含 @author xiehe
		 */
		isContainIllegalFolder : function(str) {
			var regex = /^.*[\\\/\:\*\?\"\<>\|]+.*$/;
			return regex.test(str);
		},

		isContainIllegalCharacter : function(str) {
			var regex = /^.*[\\\/:\*\?\"\'<>\|\&#%\“\‘\＜\＞\＃\＆\％\？]+.*$/;
			return regex.test(str);
		},

		isContainHeadDotCharacter : function(str) {
			var regex = /^(\.)+.*$/;
			return regex.test(str);
		},

		isDescContainIllegal : function(str) {
			var regex = /^.*[\\\/:\*\?\"\<\>\|\“\＜\＞\？]+.*$/;
			return regex.test(str);
		},

		/*
		 * 字符串包含测试函数
		 */
		contain : function(str, charset) {
			for ( var i = 0; i < charset.length; i++) {
				if (str.indexOf(charset.charAt(i)) >= 0) {
					return true;
				}
			}
			return false;
		}
	};

	util.formateRecoverySize = function(data) {
		var size = data.itemSize;
		if (!size || size == '-1') {
			return '';
		}
		var fixed = 2;
		var arr = [ "KB", "MB", "GB", "TB" ];
		size = size / 1024;
		if (!size.toFixed(fixed)) {
			return "1KB";
		}
		var index = 0;
		while (size > 1024) {
			index++;
			size = size / 1024;
		}
		return size.toFixed(fixed) + arr[index];
	};

	/*
	 * 基础控件对象
	 */
	util.base = {
		run : function(obj, e) {
			var type = typeof (obj);
			if (type == "function") {
				return obj(e);
			} else if (type == "string") {
				return eval("(" + obj + "(e))");
			}
		},
		msg : {
			notInput : function(param) {
				return "Parameter " + param + " do not enter!";
			}
		}
	};

	/*
	 * 获取指定文件类型的图标
	 */
	util.Icon = {
		/*
		 * 获取列表显示时图标
		 */
		getIcon : function(obj, isWeb) {
			var icon;
			if (obj.thumbnailURL) {
				icon = obj.thumbnailURL;
			} else if (obj.objType) {// 文件外链类型
				var objType = obj.objType;

				if (objType == 1) {// 如果是文件
                    if(obj.smallThumbnail){
                        icon = obj.smallThumbnail;
                    }else{
                        var contentName = obj.lkName;
                        var fileType = util.getSuffix(contentName);
                        icon = util.Icon.getIconByExtName(fileType, true);
                    }
				} else {// 否则是目录
					icon = util.Icon.getIconByExtName('folder', true);
				}
			} else {
				var suffix = obj.suffix
						|| obj.contentSuffix || (obj.type ? 'folder' : 'defaultFile');

				// 如果是固定文件夹并且有默认图标使用默认图标
				var id = obj.id;
				if (id) {
					icon = caiyun.util.Icon.getIconById(obj, isWeb);
				}
				if (!icon) {
					icon = util.Icon.getIconByExtName(suffix, isWeb);
				}
			}
			
			return icon;
		},

		getRecycIcon : function(obj) {
			obj.name = obj.name || '';
			var fileType = "folder";
			if (obj.type != "-1") {
				fileType = util.getSuffix(obj.name);
			}

			var icon = util.Icon.getIconByExtName(fileType, false);

			return icon;
		},

		/**
		 * 根据ID获取图标
		 */
		getIconById : function(obj, isWeb) {
			var cannotModifyIDs = caiyun.constants.cannotModifyIDs;
			var folder = isWeb ? 'web_small' : 'web_big';
            var id = obj.id;
            var icon = '';
            if(obj.shareType == '4')
            {
            	icon = '/Mcloud/images/newportal2/' + folder + '/' + 'm_enterprise.png';
            }else
            {
                /**
                 *
                 * root_phonePhoto : wdUserId+"00019700101000000043",//手机文件夹图片id
                 * root_phoneVideo : wdUserId+"00019700101000000044",//手机文件夹视频id
                 * root_phoneDoc : wdUserId+"00019700101000000046",//手机文件夹文档id
                 * root_syncMobile : wdUserId + '00019700101000000062',
                 * //新增预设同步目录'手机文档' root_syncGalary : wdUserId +
                 * '00019700101000000061', //新增预设同步目录'手机相册' root_syncMusic :
                 * root_syncEbook : wdUserId + '00019700101000000064',
                 * //新增预设同步目录'手机电子书' root_syncVideo : wdUserId +
                 * '00019700101000000065', //新增预设同步目录'手机视频' root_receiveShare :
                 * wdUserId+"00019700101000000067"//我收到的文件
                 */
                switch (id) {
                    // 图片
                    case cannotModifyIDs.root_phonePhoto:
                    	icon = '/Mcloud/images/newportal2/' + folder + '/' + 'm_pic.png';
                    	break;
                    case cannotModifyIDs.root_syncGalary:
                    	icon = '/Mcloud/images/newportal2/' + folder + '/' + 'm_pic.png';
                    	break;
                    // 视频
                    case cannotModifyIDs.root_phoneVideo:
                    	icon = '/Mcloud/images/newportal2/' + folder + '/'
                            + 'm_video.png';
                    	break;
                    case cannotModifyIDs.root_syncVideo:
                    	icon = '/Mcloud/images/newportal2/' + folder + '/'
                            + 'm_video.png';
                    	break;
                    // 文档
                    case cannotModifyIDs.root_phoneDoc:
                    	icon = '/Mcloud/images/newportal2/' + folder + '/'
                            + 'm_file.png';
                    	break;
                    case cannotModifyIDs.root_syncMobile:
                    	icon = '/Mcloud/images/newportal2/' + folder + '/'
                            + 'm_file.png';
                    	break;
                    // 收到的分享
                    case cannotModifyIDs.root_receiveShare:
                    	icon = '/Mcloud/images/newportal2/' + folder + '/'
                            + 'm_share.png';
                    	break;
                }

            }
            
            // 针对IE6浏览器，将png替换为gif
			if ($.browser.msie && $.browser.version === '6.0') {
				var re = /\.png$/;
				icon = icon.replace(re, '.gif');
			}
			
			return icon;
		},

		/*
		 * 根据扩展名获取缩略图图标 @param {} extName @return {String}
		 */
		getIconByExtName : function(extName, isWeb) {
			extName = extName || '';
			var ico = 'web_big/';
			var icon = '';
			if (isWeb) {
				ico = 'web_small/';
			}
			switch (extName.toLowerCase()) {
			case 'folder':
				icon = "/Mcloud/images/newportal2/" + ico + "folder.gif";
				break;
			case '3gp'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'3gp.png';
				break;
			case 'apk'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'apk.png';
				break;
			case 'avi'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'avi.png';
				break;
			case 'bmp'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'bmp.png';
				break;
			case 'cdr'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'cdr.png';
				break;
			case 'csv'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'csv.png';
				break;
			case 'dat'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'dat.png';
				break;
			case 'doc'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'doc.png';
				break;
			case 'docx'   : 
				icon = '/Mcloud/images/newportal2/'+ico+'docx.png';
				break;
			case 'dvd'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'dvd.png';
				break;
			case 'eps'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'eps.png';
				break;
			case 'exe'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'exe.png';
				break;
			case 'file'   : 
				icon = '/Mcloud/images/newportal2/'+ico+'file.png';
				break;
			case 'flv'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'flv.png';
				break;
			case 'gif'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'gif.png';
				break;
			case 'html'   : 
				icon = '/Mcloud/images/newportal2/'+ico+'html.png';
				break;
			case 'iff'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'iff.png';
				break;
			case 'ilbm'   : 
				icon = '/Mcloud/images/newportal2/'+ico+'ilbm.png';
				break;
			case 'ipa'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'ipa.png';
				break;
			case 'java'   : 
				icon = '/Mcloud/images/newportal2/'+ico+'java.png';
				break;
			case 'jpg'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'jpg.png';
				break;
			case 'jpeg'   : 
				icon = '/Mcloud/images/newportal2/'+ico+'jpg.png';
				break;
			case 'log'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'log.png';
				break;
			case 'mov'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'mov.png';
				break;
			case 'mp3'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'mp3.png';
				break;
			case 'mp4'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'mp4.png';
				break;
			case 'music'  : 
				icon = '/Mcloud/images/newportal2/'+ico+'music.png';
				break;
			case 'none'   : 
				icon = '/Mcloud/images/newportal2/'+ico+'none.png';
				break;
			case 'odp'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'odp.png';
				break;
			case 'ods'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'ods.png';
				break;
			case 'odt'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'odt.png';
				break;
			case 'pdf'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'pdf.png';
				break;
			case 'png'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'png.png';
				break;
			case 'pps'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'pps.png';
				break;
			case 'ppt'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'ppt.png';
				break;
			case 'pptx'   : 
				icon = '/Mcloud/images/newportal2/'+ico+'pptx.png';
				break;
			case 'psd'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'psd.png';
				break;
			case 'psp'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'psp.png';
				break;
			case 'rar'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'rar.png';
				break;
			case 'rm'     : 
				icon = '/Mcloud/images/newportal2/'+ico+'rm.png';
				break;
			case 'rmvb'   : 
				icon = '/Mcloud/images/newportal2/'+ico+'rmvb.png';
				break;
			case 'rtf'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'rtf.png';
				break;
			case 'sxc'    : 
				icon = '/Mcloud/images/newportal2/'+ico+'sxc.png';
				break;
			case 'symbian': 
				icon = '/Mcloud/images/newportal2/'+ico+'symbian.png';
				break;
			case 'tif'   :  
				icon = '/Mcloud/images/newportal2/'+ico+'tif.png';
				break;
			case 'tiff'  :  
				icon = '/Mcloud/images/newportal2/'+ico+'tiff.png';
				break;
			case 'ttf'   :  
				icon = '/Mcloud/images/newportal2/'+ico+'ttf.png';
				break;
			case 'txt'   :  
				icon = '/Mcloud/images/newportal2/'+ico+'txt.png';
				break;
			case 'wav'   :  
				icon = '/Mcloud/images/newportal2/'+ico+'wav.png';
				break;
			case 'wma'   :  
				icon = '/Mcloud/images/newportal2/'+ico+'wma.png';
				break;
			case 'wmv'   :  
				icon = '/Mcloud/images/newportal2/'+ico+'wmv.png';
				break;
			case 'wov'   :  
				icon = '/Mcloud/images/newportal2/'+ico+'wov.png';
				break;
			case 'xcf'   :  
				icon = '/Mcloud/images/newportal2/'+ico+'xcf.png';
				break;
			case 'xls'   :  
				icon = '/Mcloud/images/newportal2/'+ico+'xls.png';
				break;
			case 'xlsx'  :  
				icon = '/Mcloud/images/newportal2/'+ico+'xlsx.png';
				break;
			case 'xml'   :  
				icon = '/Mcloud/images/newportal2/'+ico+'xml.png';
				break;
			case 'zip'   :  
				icon = '/Mcloud/images/newportal2/'+ico+'zip.png';
				break;
			case 'recycle'  :  
				icon = '/Mcloud/images/newportal2/'+ico+'recycle.png';
				break;
			case 'recover'  :  
				icon = '/Mcloud/images/newportal2/'+ico+'recover.png';
				break;
			case 'eml' :
				icon = '/Mcloud/images/newportal2/'+ico+'eml.png';
				break;	
			case 'l-phoneapp'  :  
				icon = '/Mcloud/images/newportal2/'+ico+'L-phoneApp.png';
				break;
			case 'l-addressbook'  :  
				icon = '/Mcloud/images/newportal2/'+ico+'L-addressBook.png';
				break;
			case 'l-calendar'  :  
				icon = '/Mcloud/images/newportal2/'+ico+'L-calendar.png';
				break;
			case 'l-phonepic'  :  
				icon = '/Mcloud/images/newportal2/'+ico+'L-phonePic.png';
				break;
			case 'l-phonesms'  :  
				icon = '/Mcloud/images/newportal2/'+ico+'L-phoneSms.png';
				break;
			case 'l-phonevideo'  :  
				icon = '/Mcloud/images/newportal2/'+ico+'L-phoneVideo.png';
				break;
			case 'l-gift'  :  
				icon = '/Mcloud/images/newportal2/'+ico+'gift.png';
				break;
			default : 
				icon = '/Mcloud/images/newportal2/'+ico+'none.png';
			}
			
			// 针对IE6浏览器，将png替换为gif
			if ($.browser.msie && $.browser.version === '6.0') {
				var re = /\.png$/;
				icon = icon.replace(re, '.gif');
			}
			
			return icon;
		}

	};

	/**
	 * input输入框为空时，添加默认提示 inputId 需要提示的文本框ID options 相关的参数对象 调用方式：
	 * util.textAutoTips({ blurColor:gray, 失去焦点文本框内容的颜色 focusColor:black,
	 * 获取焦点文本框内容的颜色 chgClass : ... 获取焦点执行的css样式名 });
	 * 
	 */
	util.textAutoTips = function(inputId, options) {
		options = options || {};
		var defaults = {
			blurColor : "#999",// 灰色
			focusColor : "#000",// 黑色
			auto : true,
			chgClass : "",
			focusFun : null,
			blurFun : null
		};
		var settings = $.extend(defaults, options);
		$(inputId).each(function() {
			if (defaults.auto) {
				$(this).css("color", settings.blurColor);
			}
			var v = $.trim($(this).val());
			if (v) {
				$(this).focus(function() {
					if ($.trim($(this).val()) === v) {
						$(this).val("");
						$(this).css("color", settings.focusColor);
					}
					if (typeof (settings.focusFun) == "function") {
						settings.focusFun();
					}
					if (settings.chgClass) {
						$(this).toggleClass(settings.chgClass);
					}
				}).blur(function() {
					if ($.trim($(this).val()) === "") {
						$(this).val(v);
						$(this).css("color", settings.blurColor);
					}
					if (typeof (settings.blurFun) == "function") {
						settings.blurFun();
					}
					if (settings.chgClass) {
						$(this).toggleClass(settings.chgClass);
					}
				});
			}
		});
	};
	// 判断是否是合法E-mail地址
	util.isValidEmail = function(eMail) {
		if (null == eMail && "" == eMail) {
			return false;
		}
		var Rex = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
		return Rex.test(eMail);
	};

	// 判断是否是移动号码
	util.isChinaMobile = function(num) {
		if ("13800138000" == num) {
			return false;
		}
		var Rex = /^((134[0-8]{1})|(13[5-9]\d)|(15[0,1,2,7,8,9]\d)|(18[2378]\d)|(14\d\d))\d{7}$/;
		if (null != regexp_mobile && "" != regexp_mobile) {
			Rex = regexp_mobile;
		} else {
			return false;
		}
		return Rex.test(util.replace86(num));
	};

	// 判断是否是手机号码
	util.isCellPhone = function(num) {
		if ("13800138000" == num) {
			return false;
		}
		var Rex = /^((134[0-8]{1})|(13[0,1,2,3,5,6,7,8,9]\d)|(15[0,1,2,3,5,6,7,8,9]\d)|(18[0|1|5|2|3|(5-9)]\d)|(14\d\d))\d{7}$/;
		if (null != regexp_cellphone && "" != regexp_cellphone) {
			Rex = regexp_cellphone;
		} else {
			return false;
		}
		return Rex.test(util.replace86(num));
	};

	// 返回数组a中剔除了与b有重复的部分的数组(即a-(a&b))
	util.delRepeatArr = function(a, b) {
		if (a.length == 0 || b.length == 0) {
			return a;
		} else {
			var newArr = new Array();
			for ( var i = 0; i < a.length; i++) {
				var noRepeat = true;
				for ( var j = 0; j < b.length; j++) {
					if (a[i] == b[j]) {
						noRepeat = false;
					}
				}
				if (noRepeat) {
					newArr.push(a[i]);
				}
			}
			return newArr;
		}

	};

    //转义html标签字符串 <、>、'、"
    util.formatHTMLEncode = function(str){
        if(str == undefined || str == "")
        {
			return "";        
        }
        else if(str.indexOf('<') != -1 ||str.indexOf('>') != -1 ||str.indexOf('\'')!= -1 || str.indexOf('\"')!= -1){
            return str.replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\'/g,'&apos;').replace(/\"/g,'&quot;');
        }
        else
        {
        	return str;
        }
    };

	/**
	 * 截取指定字段长度变成...
	 * 
	 * @param {Object}
	 *            str
	 * @param {Object}
	 *            len
	 */
	util.subStringByLen = function(str, len) {
		if (str) {
			if (str == "") {
				return "";
			} else if (str.length <= len) {
				return str;
			} else {
				return str.substring(0, len) + '...';
			}
		}
	};
	/**
	 * 进入通讯录，彩云应用，短信息时，调用的统计 例如：进入彩云应用 util.sendPvlog("feature","AppCloud");
	 * 
	 * @param {Object}
	 *            pmodule
	 * @param {Object}
	 *            pkey
	 * @param {Object}
	 *            p1
	 * @param {Object}
	 *            p2
	 * @param {Object}
	 *            p3
	 * @param {Object}
	 *            p4
	 * @param {Object}
	 *            p5
	 * @param {Object}
	 *            p6
	 * @param {Object}
	 *            p7
	 * @param {Object}
	 *            p8
	 * @param {Object}
	 *            p9
	 */
	util.sendPvlog = function(pmodule, pkey, p1, p2, p3, p4, p5, p6, p7, p8, p9) {
		// 来源
		var source = "portal";
		// 浏览器信息
		var browser = "";
		var ua = $.browser;
		if (ua) {
			if (ua.msie) {
				browser = "msie" + ua.version;
			} else if (ua.chrome) {
				browser = "chrome" + ua.version;
			} else if (ua.mozilla) {
				browser = "mozilla" + ua.version;
			} else if (ua.safari) {
				browser = "safari " + ua.version;
			} else if (ua.opera) {
				browser = "opera" + ua.version;
			} else if (ua.webkit) {
				browser = "webkit" + ua.version;
			}
		}
		// 统计项
		var module = (typeof (pmodule) != "undefined" && pmodule != "") ? pmodule
				: "portal";
		var key = typeof (pkey) != "undefined" ? pkey : "";
		var other1 = typeof (p1) != "undefined" ? p1 : "";
		var other2 = typeof (p2) != "undefined" ? p2 : "";
		var other3 = typeof (p3) != "undefined" ? p3 : "";
		var other4 = typeof (p4) != "undefined" ? p4 : "";
		var other5 = typeof (p5) != "undefined" ? p5 : "";
		var other6 = typeof (p6) != "undefined" ? p6 : "";
		var other7 = typeof (p7) != "undefined" ? p7 : "";
		var other8 = typeof (p8) != "undefined" ? p8 : "";
		var other9 = typeof (p9) != "undefined" ? p9 : "";

		var bistr = [ module, key, source, browser, other1, other2, other3,
				other4, other5, other6, other7, other8, other9 ].join("|");
		$.ajax("../bi.gif?t=" + new Date().getTime(), {
			'headers' : {
				'BISTR' : bistr
			}
		});
	};

	/**
	 * 获取滚动条位置
	 */
	util.getScrollTop = function() {
		var scrollTop = 0;
		if (document.documentElement && document.documentElement.scrollTop) {
			scrollTop = document.documentElement.scrollTop;
		} else if (document.body) {
			scrollTop = document.body.scrollTop;
		}
		return scrollTop;
	};
	
	/**
	 * 计算滚动条是否滚动到页面底部
	 */
	util.isScrollToBottom = function() {
		function getScrollTop() {
			var scrollTop = 0;
			if (document.documentElement && document.documentElement.scrollTop) {
				scrollTop = document.documentElement.scrollTop;
			} else if (document.body) {
				scrollTop = document.body.scrollTop;
			}
			return scrollTop;
		}

		/***********************************************************************
		 * 取窗口可视范围的高度
		 **********************************************************************/
		function getClientHeight() {
			var clientHeight = 0;
			if (document.body.clientHeight
					&& document.documentElement.clientHeight) {
				var clientHeight = (document.body.clientHeight < document.documentElement.clientHeight) ? document.body.clientHeight
						: document.documentElement.clientHeight;
			} else {
				var clientHeight = (document.body.clientHeight > document.documentElement.clientHeight) ? document.body.clientHeight
						: document.documentElement.clientHeight;
			}
			return clientHeight;
		}

		/***********************************************************************
		 * 取文档内容实际高度
		 **********************************************************************/
		function getScrollHeight() {
			return Math.max(document.body.scrollHeight,
					document.documentElement.scrollHeight);
		}
		if(getScrollTop() + getClientHeight() == getScrollHeight()){
			return true;
		}
		
		return false;

	};
	
	/**
	 * （通用）等比缩放图片方法(正方形)
	 * picObj : 图片对象
	 * maxSize : 图片长\宽最大值
	 */
	util.setPictureSize = function(picObj , maxSize)
	{
		if(picObj == null || typeof(maxSize) != "number")
		{
			return false;
		}
		
		var height = picObj.height();
		var width = picObj.width();
		
		if(width > height)
		{
			if(width > maxSize)
			{
				var temp_h = Math.floor(height*maxSize/width);
				picObj.width(maxSize);
				picObj.height(temp_h);
			}
		}
		else
		{
			if(height > maxSize)
			{
				var temp_w = Math.floor(width*maxSize/height);
				picObj.height(maxSize);
				picObj.width(temp_w);
			}
		}
	};
	
	
	/**
	 * （通用）等比缩放图片方法(长方形)
	 * picObj : 图片对象
	 * maxSize : 图片长\宽最大值
	 */
	util.setRectPictureSize = function(picObj , maxSize)
	{
		if(picObj == null || typeof(maxSize) != "number")
		{
			return false;
		}
		
		var height = picObj.height();
		var width = picObj.width();
		
		
		if(height > maxSize)
		{
			var temp_w = Math.floor(width*maxSize/height);
			picObj.height(maxSize);
			picObj.width(temp_w);
		}
		
	};
	
	
	

    /**
     * 事件工具
     */
    util.Event = {
        getEvent: function(e){
            return e || window.event;
        },
        getTarget: function(e){
            return e.target || e.srcElement;
        },
        stopPropagation: function(e){
            if (e.stopPropagation) {
                e.stopPropagation();
            } else {
                e.cancelBubble = true;
            }
        },
        preventDefault: function(e){
            if (e.preventDefault) {
                e.preventDefault();
            } else {
                e.returnValue = false;
            }
        },
        stopEvent: function(e){
            this.stopPropagation(e);
            this.preventDefault(e);
        }
    };
})();

/**
 * *********************** 以下为自定义类和原生方法扩展
 * ****************************************************************
 */
// 自定义的对象,模拟java的StringBuffer类
function StringBuffer() {
	this._stringBuffer_ = [];
}
StringBuffer.prototype = {
	append : function(str) {
		this._stringBuffer_.push(str);
		return this;
	},
	empty : function() {
		this._stringBuffer_ = [];
	},
	toString : function() {
		return this._stringBuffer_.join('');
	}
};

/*
 * 判断字符串长度是否超出范围 @param {Object} n 字符个数(1个汉字占2字符)
 */
String.prototype.isOutSize = function(n) {
	var w = 0;
	for ( var i = 0; i < this.length; i++) {
		var c = this.charCodeAt(i);
		if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
			w++;
		} else {
			w += 2;
		}
	}
	return w > n;
};

/*
 * 截取字符串长度. @param {Object} n 字符个数
 */
String.prototype.substringName = function(n,isFolder) {
	var lastindex = this.lastIndexOf(".");
	if ((lastindex == '-1' || isFolder) && this.isOutSize(n)) {
		var w = 0;
		var str = '';
		for ( var i = 0; i < this.length; i++) {
			var c = this.charCodeAt(i);
			if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
				w++;
			} else {
				w += 2;
			}
			if (w > n) {
				break;
			}
			str += this.charAt(i);
		}
		return str + "...";
	}
	var name = this.substring(0, lastindex);
	if (name.isOutSize(n)) {
		var w = 0;
		var str = '';
		for ( var i = 0; i < name.length; i++) {
			var c = name.charCodeAt(i);
			if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
				w++;
			} else {
				w += 2;
			}
			if (w > n) {
				break;
			}
			str += name.charAt(i);
		}
		return str + "..." + this.substring(lastindex);
	} else {
		return this.toString();
	}
};

// 计算字符长度
String.prototype.strLen = function() {
	var len = 0;
	var charCode;
	for ( var i = 0, length = this.length; i < length; i++) {
		charCode = this.charCodeAt(i);
		if (charCode > 255 || charCode < 0 || charCode === 32) {
			len += 2;
		} else {
			len += 1;
		}
	}
	return len;
};

// 新的计算字符数的方法
String.prototype.newStrLen = function() {
	var len = 0;
	var charCode;
	for ( var i = 0, length = this.length; i < length; i++) {
		charCode = this.charCodeAt(i);
		if (charCode > 255 || charCode < 0 || charCode === 32) {
			len += 2;
		} else {
			len += 1;
		}
	}
	return len;
};

// 用于截取
String.prototype.strToChars = function() {
	var chars = new Array();
	for ( var i = 0; i < this.length; i++) {
		chars[i] = [ this.substr(i, 1), this.isCHS(i) ];
	}
	String.prototype.charsArray = chars;
	return chars;
};

// 判断某个字符是否是汉字
String.prototype.isCHS = function(i) {
	if (this.charCodeAt(i) > 255 || this.charCodeAt(i) < 0)
		return true;
	else
		return false;
};

// 截取字符串（从start字节到end字节
String.prototype.subCHString = function(start, end) {
	var len = 0;
	var str = "";
	this.strToChars();
	for ( var i = 0; i < this.length; i++) {
		if (this.charsArray[i][1]) {
			len += 2;
		} else {
			len++;
		}
		if (end < len) {
			return str;
		} else if (start < len) {
			str += this.charsArray[i][0];
		}
	}
	return str;
};

// 截取字符串（从start字节截取length个字节
String.prototype.subCHStr = function(start, length) {
	return this.subCHString(start, start + length);
};

// 用于截取
String.prototype.newStrToChars = function() {
	var chars = [];
	for ( var i = 0; i < this.length; i++) {
		chars[i] = [ this.substr(i, 1), this.isCHS(i) ];
	}
	String.prototype.newCharsArray = chars;
	return chars;
};

// 截取字符串（从start字节到end字节
String.prototype.newSubCHString = function(start, end) {
	var len = 0;
	var str = "";
	this.newStrToChars();
	for ( var i = 0; i < this.length; i++) {
		if (this.newCharsArray[i][1]) {
			len += 3;
		} else {
			len++;
		}
		if (end < len) {
			return str;
		} else if (start < len) {
			str += this.newCharsArray[i][0];
		}
	}
	return str;
};

String.prototype.newSubCHStr = function(start, length) {
	return this.newSubCHString(start, start + length);
};

String.prototype.toTime = function() {
	var time = parseInt(this);
	if (time < 0) {
		return I18N.wd_new.unknown;
	}
	var s = time % 60;
	var M = Math.floor(time / 60);
	if (M >= 1) {
		M = M % 60;
	} else {
		M = 0;
	}
	var h = Math.floor(time / 3600);
	if (h >= 1) {
		h = h % 24;
		if (h == 0) {
			return I18N.wd_new.oneDay;
		}
	} else {
		h = 0;
	}
	return (h < 10 ? "0" + h : h) + ":" + (M < 10 ? "0" + M : M) + ":"
			+ (s < 10 ? "0" + s : s);
};

// ajax的data参数，格式化
var parseParam = function(param, key) {
	var paramStr = "";
	if (param instanceof String || param instanceof Number
			|| param instanceof Boolean) {
		paramStr += "&" + key + "=" + encodeURIComponent(param);
	} else {
		$.each(param, function(i) {
			var k = key == null ? i : key
					+ (param instanceof Array ? "[" + i + "]" : "." + i);
			paramStr += '&' + parseParam(this, k);
		});
	}
	return paramStr.substr(1);
};
