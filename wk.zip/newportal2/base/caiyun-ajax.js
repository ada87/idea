(function() {
	var util = window.caiyun.util;
	var judgement = window.caiyun.judgement;
	var constants = window.caiyun.constants;
	var profile = caiyun.profile;
	util.caiyunAjax = {
		/*
		 * 请求获取后台数据统一调用
		 * @param {object} param{
		 *                      type    : '', get/post
		 *                      url     : '', 请求URL
		 *                      dataType: '', json或其他
		 *                      data    : {}, 参数
		 *                      succFun : function(){}, 成功回调函数
		 *                      errFun  : function(){},  失败回调函数
		 *                      hideLoading : boolean , 是否隐藏loading
		 *                      loadingTips : string 等待后台响应时的提示语
		 *                 }
		 */
		ajaxRequest: function(param) {
			if (!param) {
				alert('please enter paramters');
				return;
			}
			var params = {
				type: 'post',
				dataType: 'json',
				timeout: 25000,
				hideLoading: false,
				async: true,
				loadingTips: '正在加载，请稍候...'
			};
			$.extend(params, param);
			var tips = null;
			if (judgement && judgement.isSafeBox()) {
				var srcUrl = params.url;
				var index = srcUrl.lastIndexOf("/");
				var _url = address + '/safebox' + srcUrl.substring(index, srcUrl.length);
				$.extend(params, {
					url: _url,
					dataType: "jsonp"
				});
			}

			var obj = {};
			obj.url = params.url + '?date=' + new Date().getTime();
			obj.type = params.type;
			obj.dataType = params.dataType;
			obj.data = params.data;

			// 用于性能统计
			var pid = profile.time(params.url);

			//用于BI统计
			if (params.bi && typeof(params.bi) == "object" && params.bi.length >= 2 && params.bi.length <= 11) {
				var module = params.bi[0];
				var key = params.bi[1];
				//来源
				var source = "portal";
				if (typeof(PAGE_SOURCE) != "undefined") {
					source = PAGE_SOURCE;
				}
				//浏览器信息
				var browser = "";
				var ua = $.browser;
				if (ua) {
					if (ua.msie) {
						browser = "msie" + ua.version;
					} else if (ua.chrome) {
						browser = "chrome" + ua.version;
					} else if (ua.mozilla) {
						browser = "mozilla" + ua.version;
					} else if (ua.safari) {
						browser = "safari " + ua.version;
					} else if (ua.opera) {
						browser = "opera" + ua.version;
					} else if (ua.webkit) {
						browser = "webkit" + ua.version;
					}
				}
				var bistr = module + "|" + key + "|" + source + "|" + browser;
				if (key == "publish" || key == "delete" || key == "download" || key == "move" || key == "copy") {
					if (window.caiyun.judgement.isSafeBox && window.caiyun.judgement.isSafeBox()) {
						module = "safeBox";
					}
					var contentids = params.bi[2] ? params.bi[2] : [];
					var catalogids = params.bi[3] ? params.bi[3] : [];
					var drag = params.bi[4] ? params.bi[4] : '';
					if (typeof(contentids) == "string") {
						contentids = contentids.split(',');
					}
					if (typeof(catalogids) == "string") {
						catalogids = catalogids.split(',');
					}
					bistr = "";
					for (var i = 0; i < contentids.length; i++) {
						var p1 = contentids[i];
						//var id=typeof(p1)!="undefined"?p1.replace(/^folder_/,"").replace(/^file_/,""):"";
						//if("" != id)
						//{
						if (p1.indexOf('/') != -1) {
							p1 = p1.slice(p1.lastIndexOf('/') + 1, p1.length);
						}
						var toIdObj = window.caiyun.util.cache.getFileCache(window.caiyun.constants.FILE_LIST_CACHEGROUP, p1);
						var type = toIdObj ? toIdObj.contentType : "";
						var size = toIdObj ? toIdObj.contentSize : "";
						var suffix = toIdObj ? toIdObj.contentSuffix : "";
						if (judgement.isEnterprisePath()) { //如果是在企业空间下，获取该企业空间的企业ID
							var accID = toIdObj ? toIdObj.owner : "";
							var eID = entryPriseInfoData.getEidByAcc(accID);
							bistr += module + "|" + key + "|" + source + "|" + browser + '|' + p1 + '|' + type + '|' + size + '|' + suffix + '|' + eID + '|' + drag + '|||;';
						} else {
							bistr += module + "|" + key + "|" + source + "|" + browser + '|' + p1 + '|' + type + '|' + size + '|' + suffix + '||' + drag + '|||;';
						}
						//}
					}

					for (var i = 0; i < catalogids.length; i++) {
						var p1 = catalogids[i];
						if (p1.indexOf('/') != -1) {
							p1 = p1.slice(p1.lastIndexOf('/') + 1, p1.length);
						}
						//							var id=typeof(p1)!="undefined"?p1.replace(/^folder_/,"").replace(/^file_/,""):"";
						//							if("" != id)
						//							{
						var toIdObj = window.caiyun.util.cache.getFileCache(window.caiyun.constants.FILE_LIST_CACHEGROUP, p1);
						if (judgement.isEnterprisePath()) {
							var accID = toIdObj ? toIdObj.owner : "";
							var eID = entryPriseInfoData.getEidByAcc(accID);
							bistr += module + "|" + key + "|" + source + "|" + browser + '|' + p1 + '|folder|||' + eID + '|' + drag + '|||;';
						} else {
							bistr += module + "|" + key + "|" + source + "|" + browser + '|' + p1 + '|folder||||' + drag + '|||;';
						}
						//							}
					}
					bistr = bistr.substring(0, bistr.length - 1);
				} else {
					for (var i = 2; i < 11; i++) {
						if (params.bi[i]) {
							bistr = bistr + "|" + params.bi[i];
						} else {
							bistr = bistr + "|";
						}
					}
				}
				obj.headers = {
					"BISTR": bistr
				};
				if (window.caiyun.judgement.isSafeBox()) {
					obj.data['BISTR'] = bistr;
				}
			}
			if (param.succFun) {
				// 隐藏loading提示
				if (!params.hideLoading) {
					tips = window.caiyun.ui.iMsgTip.tip(params.loadingTips, 'loading', 25);
				}
				obj.success = function(resjson, textStatus, request) {
					profile.timeEnd(pid, 200, request.responseText ? request.responseText.length : 0);
					if (!resjson) {
						util.timeoutHref();
						return;
					}
					if (resjson.message && ("timeout" == resjson.message || "error_01" === resjson.showMessage)) {
						util.timeoutHref();
						return;
					} else if (resjson.showMessage && ("timeout" == resjson.showMessage || "error_01" === resjson.showMessage)) {
						util.timeoutHref();
						return;
					} else if (resjson.returnMsg && "timeout" == resjson.returnMsg) {
						util.timeoutHref();
						return;
					} else if (judgement && judgement.isSafeBox() && resjson.isInvalid) {
						var objFrame = constants.safeboxCloseWin;

						for (var frame in objFrame) {
							objFrame[frame].close();
						}

						//上传容器特殊对待
						window.caiyun.ui.iMsgTip.tip("操作超时，请重新登录后继续!", "error");
						return;
					}
					if (!params.hideLoading && tips) {
						tips.close();
						tips = null;
					}
					var pid2 = profile.time(params.url + '(callback)');
					param.succFun.apply(null, [params, resjson]);
					profile.timeEnd(pid2);
				};
			}

			obj.error = function(request, textStatus, errorThrown) {
				profile.timeEnd(pid, request.status, 0);
				if (params.errFun) {
					if (!params.hideLoading && tips) {
						tips.close();
						tips = null;
					}
					param.errFun.apply(null, [request, textStatus, errorThrown, params]);
				}
				if (textStatus != 'abort') {
					window.caiyun.tips.showErrorMsg('NETWORK_ERROR');
				}
			};

			obj.complete = function(request, textStatus) {
				profile.timeEnd(pid, request.status, request.responseText ? request.responseText.length : 0);
				if (!params.hideLoading && tips) {
					tips.close();
					tips = null;
				}
				if (params.complete) {
					param.complete.apply(null, [request, textStatus, params]);
				}
			};

			return $.ajax(obj);
		}
	};

})();
