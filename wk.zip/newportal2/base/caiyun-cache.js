/**
 * JS缓存操作类，与jcs使用类似但需手动清除无用缓存没有过期时间设置。读取或是写入缓存时都先要找到组对象，
 * 然后才能其中的缓存数据进行操作。由于本工程主要缓存为文件显示列表缓存，所以单独对列表数据进行了缓存操
 * 作封装。 
 * 
 * 注：此对象为单例，在清除全部缓存组时请注意
 * 
 */
;(function(){
	window.caiyun.util.cache=(function(){
		//cache对象，key:组id ,value:cache对象操作类
		var allCache = {};
		
		//cache对象操作类
		var groupCacheObj = function() {
			var cache = {};
			
			var getCache = function(key){
				return cache[$.trim(key)];
			};
			
			var getCaches = function(key){
				return cache;
			};
			
			var putCache = function(key,value){
				cache[$.trim(key)]=value;
			};
			
			var upCache = function(key,value){
			    putCache($.trim(key),value);
			};
			var delCache = function(key){
				delete  cache[$.trim(key)];
			};
			var clearCache = function(){
				cache={};
			};
			
			return {
				getCache   :  getCaches,
				getValue   :  getCache,
				putValue   :  putCache,
				delValue   :  delCache,
				clearValues:  clearCache
			};
		};
		
		//获取group缓存对象
		var getGroupCache = function(groupId){
			groupId = $.trim(groupId);
			var cacheObj = allCache[groupId];
			
			if(!cacheObj){
				cacheObj = new  groupCacheObj();
				allCache[groupId] = cacheObj;
			}
			
			return cacheObj;
		};
		
		//删除group缓存组对象
		var delGroupCache = function(groupId){
			delete  allCache[$.trim(groupId)];
		};
		
		//清除所有group缓存组对象
		var claerGroupCache = function(){
			allCache={};
		};
		
		/*
		 * 彩云文件列表缓存写入函数
		 * 
		 * @param groupId  彩云文件列表缓存组id
		 * @param jsonData 彩云文件列表反回的json dci对象
		 */
		var putFileCache = function(groupId,jsonData){
			jsonData = jsonData || {};
			var fileGroupCache = getGroupCache(groupId);
			var cataloginfos = jsonData.cataloginfos;
        	var contents = jsonData.contents;
        	
        	if(cataloginfos){
        		$.each(cataloginfos,function(i,data){
	        		fileGroupCache.putValue(data.catalogID,data);
	        	}); 
        	}
        	
        	if(contents){
        		$.each(contents,function(i,data){
	        		fileGroupCache.putValue(data.contentID,data);
	        	}); 
        	}
        	return this;
		};
		
		var addCatalogCache = function(groupId,catalogInfo){
			var fileGroupCache = getGroupCache(groupId);
			fileGroupCache.putValue(catalogInfo.catalogID,catalogInfo);
		};
		
		var getFileCache = function(groupId,key){
			var fileGroupCache = getGroupCache(groupId);
			return fileGroupCache.getValue(key);
		};
		
		var upFileCache = function(groupId,key,data){
			var fileGroupCache = getGroupCache(groupId);
			fileGroupCache.upValue(key,data);
			return this;
		};
		
		var delFileCache = function(groupId,key){
			var fileGroupCache = getGroupCache(groupId);
			fileGroupCache.delValue(key);
			return this;
		};
		
		var clearFileCache = function(groupId){
			delGroupCache(groupId);
			return this;
		};
		
		/*
		 * 彩云图片浏览缓存数据写入
		 * 
		 * @param groupId  彩云图片浏览缓存组id
		 * @param jsonData 彩云图片浏览返回的每个图片对象信息
		 */
		var putPictureCache = function(groupId,info){
			info = info || {};
			var fileGroupCache = getGroupCache(groupId);
        	if(info){
        	    fileGroupCache.putValue(info.contentID,info);	
        	}
        	return this;
		};
		
		var getPictureCache = function(groupId,key){
			var fileGroupCache = getGroupCache(groupId);
			return fileGroupCache.getValue(key);
		};
		
		var clearPictureCache = function(groupId){
			delGroupCache(groupId);
			return this;
		};
		
		/*
		 * 彩云视频播放缓存数据写入
		 * 
		 * @param groupId  彩云视频播放缓存组id
		 * @param jsonData 彩云视频播放返回的每个视频对象信息
		 */
		var putVideoCache = function(groupId,info){
			info = info || {};
			var fileGroupCache = getGroupCache(groupId);
        	if(info){
        	    fileGroupCache.putValue(info.contentID,info);	
        	}
        	return this;
		};
		
		var getVideoCache = function(groupId,key){
			var fileGroupCache = getGroupCache(groupId);
			return fileGroupCache.getValue(key);
		};
		
		var clearVideoCache = function(groupId){
			delGroupCache(groupId);
			return this;
		};
		/*
		 * 彩云分享列表缓存写入函数
		 * 
		 * @param groupId  彩云分享列表缓存组id
		 * @param jsonData 彩云文件列表反回的json dci对象
		 */
		var putShareFileCache = function(groupId,jsonData){
			jsonData = jsonData || {};
			var fileGroupCache = getGroupCache(groupId);
			var fileShareinfos = jsonData.outLinks;
        	
        	if(fileShareinfos){
        		$.each(fileShareinfos,function(i,data){
	        		fileGroupCache.putValue(data.linkID,data);
	        	}); 
        	}
        	return this;
		};

		var getFileShareCache = function(groupId,key){
			var fileGroupCache = getGroupCache(groupId);
			return fileGroupCache.getValue(key);
		};
		
		var delFileShareCache = function(groupId,key){
			var fileGroupCache = getGroupCache(groupId);
			fileGroupCache.delValue(key);
			return this;
		};

        /*
         * 我的分享文件列表缓存写入函数
         *
         * @param groupId  彩云分享列表缓存组id
         * @param jsonData 彩云文件列表反回的json detailShareRspInfoList对象
         */
        var putMyFileShareCache = function(groupId,jsonData){
            jsonData = jsonData || {};
			var fileGroupCache = getGroupCache(groupId);
			var cataloginfos = jsonData.cataloginfos;
        	var contents = jsonData.contents;
        	
        	if(cataloginfos){
        		$.each(cataloginfos,function(i,data){
	        		fileGroupCache.putValue(data.catalogID,data);
	        	}); 
        	}
        	
        	if(contents){
        		$.each(contents,function(i,data){
	        		fileGroupCache.putValue(data.contentID,data);
	        	}); 
        	}
        	return this;
        };

        var getMyFileShareCache = function(groupId,key){
            var fileShareGroupCache = getGroupCache(groupId);
            return fileShareGroupCache.getValue(key);
        };

        var delMyFileShareCache = function(groupId,key){
            var fileShareGroupCache = getGroupCache(groupId);
            fileShareGroupCache.delValue(key);
            return this;
        };

        /*
         * 企业权限缓存写入函数
         *
         * @param groupId  企业权限信息groupid
         * @param enterpriseID 企业id
         * @param jsonData 查询企业成员接口返回的getEnterpriseMemberRes对象
         */
        var putEnterpriseAuthCache = function(groupId,enterpriseID,jsonData){
            jsonData = jsonData || {};
            var enterpriseGroupCache = getGroupCache(groupId);
            enterpriseGroupCache.putValue(enterpriseID,jsonData.member.memberInfo);
            return this;
        };

        /**
         *
         * @param groupId 企业权限信息groupid
         * @param key 企业id
         * @return 返回当前传入企业id的企业成员列表数据memberInfos
         */
        var getEnterpriseAuthCache = function(groupId,key){
            var enterpriseGroupCache = getGroupCache(groupId);
            return enterpriseGroupCache.getValue(key);
        };
		
		return {
			getInstanceCache    : getGroupCache,
			delInstanceCache    : delGroupCache,
			claerAllInstance    : claerGroupCache,
			putFileCache        : putFileCache,
			putShareFileCache   : putShareFileCache,
            putMyFileShareCache : putMyFileShareCache,
			addCatalogCache		: addCatalogCache,
			getFileCache        : getFileCache,
			getFileShareCache   : getFileShareCache,
            getMyFileShareCache : getMyFileShareCache,
			upFileCache         : upFileCache,
			delFileCache        : delFileCache,
			delFileShareCache   : delFileShareCache,
            delMyFileShareCache : delMyFileShareCache,
            putEnterpriseAuthCache: putEnterpriseAuthCache,
            getEnterpriseAuthCache : getEnterpriseAuthCache,
			clearFileCache      : clearFileCache,
			putPictureCache     : putPictureCache,
			getPictureCache     : getPictureCache,
			clearPictureCache   : clearPictureCache,
			putVideoCache     : putVideoCache,
			getVideoCache     : getVideoCache,
			clearVideoCache   : clearVideoCache,
			getGroupCache : getGroupCache
        };
    })();  
})();

