/**
 * PV统计
 */
caiyun.pvlog=function(pmodule,pkey,p1,p2,p3,p4,p5,p6,p7,p8,p9){
    	//来源
    	var source="portal";
		var judgementMgr = window.caiyun.judgement;
    	if(typeof(PAGE_SOURCE)!="undefined"){
    		source=PAGE_SOURCE;
    	}
    	//浏览器信息
    	var browser="";
    	var ua = $.browser;
    	if(ua){
    		if(ua.msie){
    			browser="msie"+ua.version;
    		}else if(ua.chrome){
    			browser="chrome"+ua.version;
    		}else if(ua.mozilla){
    			browser="mozilla"+ua.version;
    		}else if(ua.safari ){
    			browser="safari "+ua.version;
    		}else if(ua.opera){
    			browser="opera"+ua.version;
    		}else if(ua.webkit){
    			browser="webkit"+ua.version;
    		}
    	}
    	//统计项
    	
    	var module=(typeof(pmodule)!="undefined"&&pmodule!="")?pmodule:"portal";
    	var key=typeof(pkey)!="undefined"?pkey:"";
    	var other1=typeof(p1)!="undefined"?p1:"";
    	var other2=typeof(p2)!="undefined"?p2:"";
    	var other3=typeof(p3)!="undefined"?p3:"";
    	var other4=typeof(p4)!="undefined"?p4:"";
    	var other5=typeof(p5)!="undefined"?p5:"";
    	var other6=typeof(p6)!="undefined"?p6:"";
    	var other7=typeof(p7)!="undefined"?p7:"";
    	var other8=typeof(p8)!="undefined"?p8:"";
    	var other9=typeof(p9)!="undefined"?p9:"";
    	
    	var isAllowOper = false;
		//如果是回收站文件统计
		if(pmodule == "recycle"&&("restore|delete".indexOf(key)!= -1)){
			var toIdObj = window.caiyun.util.cache.getFileCache(window.caiyun.constants.FILE_RECYCLEBIN_LIST_CACHEGROUP,other1);
    		other2 = toIdObj ? toIdObj.contentType||toIdObj.type : other2;
    		other3 = toIdObj ? toIdObj.contentSize||toIdObj.itemSize : other3;
    		other4 = toIdObj ? toIdObj.contentSuffix||"" : other4;
    		isAllowOper = true;
		}
    	else if("createFold|download|delete|move|copy|rename|viewVideo|viewMusic|viewPic|viewDoc|editDoc|picembellish|histManage|clearVersion|restore|remvsync|openFold".indexOf(key)!= -1){
			var toIdObj = window.caiyun.util.cache.getFileCache(window.caiyun.constants.FILE_LIST_CACHEGROUP,other1);
    		other2 = toIdObj ? toIdObj.contentType||toIdObj.type : other2;
    		other3 = toIdObj ? toIdObj.contentSize||toIdObj.itemSize : other3;
    		other4 = toIdObj ? toIdObj.contentSuffix||"" : other4;
            if(judgementMgr.isEnterprisePath()){//如果是企业空间下，则传入该企业空间的企业ID
                other5 = judgementMgr.getCurrentEnterpriseID();
            }
    		isAllowOper = true;
    	}
		//如果是文件分享统计
		else if("unPublish|copyLink|msgShare|emailShare".indexOf(key)!= -1){
			var toIdObj = window.caiyun.util.cache.getFileCache(window.caiyun.constants.FILE_SHARE_LIST_CACHEGROUP,other1);
    		other2 = toIdObj ? toIdObj.contentType||toIdObj.type : other2;
    		other3 = toIdObj ? toIdObj.contentSize||toIdObj.itemSize : other3;
    		other4 = toIdObj ? toIdObj.contentSuffix||"" : other4;
    		isAllowOper = true;
		}
    	
    	if(judgementMgr.isSafeBox()){
	    	if(isAllowOper){
	    		module="safeBox";	
    		}
    	}

        if(judgementMgr.isInReceivedPublishDir()){
            other8 = other8 || '-1';
        }
		var bistr=[module,key,source,browser,other1,other2,other3,other4,other5,other6,other7,other8,other9].join("|");
    	$.ajax("../bi.gif?t="+new Date().getTime(),{'headers':{'BISTR':bistr}});
     };
     
   caiyun.pvlogforTimeline=function(pmodule,pkey,p1,p2,p3,p4,p5,p6,p7,p8,p9){
    	//来源
    	var source="timeline";
		var judgementMgr = window.caiyun.judgement;
    	//浏览器信息
    	var browser="";
    	var ua = $.browser;
    	if(ua){
    		if(ua.msie){
    			browser="msie"+ua.version;
    		}else if(ua.chrome){
    			browser="chrome"+ua.version;
    		}else if(ua.mozilla){
    			browser="mozilla"+ua.version;
    		}else if(ua.safari ){
    			browser="safari "+ua.version;
    		}else if(ua.opera){
    			browser="opera"+ua.version;
    		}else if(ua.webkit){
    			browser="webkit"+ua.version;
    		}
    	}
    	//统计项
    	
    	var module=(typeof(pmodule)!="undefined"&&pmodule!="")?pmodule:"portal";
    	var key=typeof(pkey)!="undefined"?pkey:"";
    	var other1=typeof(p1)!="undefined"?p1:"";
    	var other2=typeof(p2)!="undefined"?p2:"";
    	var other3=typeof(p3)!="undefined"?p3:"";
    	var other4=typeof(p4)!="undefined"?p4:"";
    	var other5=typeof(p5)!="undefined"?p5:"";
    	var other6=typeof(p6)!="undefined"?p6:"";
    	var other7=typeof(p7)!="undefined"?p7:"";
    	var other8=typeof(p8)!="undefined"?p8:"";
    	var other9=typeof(p9)!="undefined"?p9:"";
    	
    	var isAllowOper = false;
		//如果是回收站文件统计
		if(pmodule == "recycle"&&("restore|delete".indexOf(key)!= -1)){
			var toIdObj = window.caiyun.util.cache.getFileCache(window.caiyun.constants.FILE_RECYCLEBIN_LIST_CACHEGROUP,other1);
    		other2 = toIdObj ? toIdObj.contentType||toIdObj.type : other2;
    		other3 = toIdObj ? toIdObj.contentSize||toIdObj.itemSize : other3;
    		other4 = toIdObj ? toIdObj.contentSuffix||"" : other4;
    		isAllowOper = true;
		}
    	else if("createFold|download|delete|move|copy|rename|viewVideo|viewMusic|viewPic|viewDoc|editDoc|picembellish|histManage|clearVersion|restore|remvsync|openFold".indexOf(key)!= -1){
			var toIdObj = window.caiyun.util.cache.getFileCache(window.caiyun.constants.FILE_LIST_CACHEGROUP,other1);
    		other2 = toIdObj ? toIdObj.contentType||toIdObj.type : other2;
    		other3 = toIdObj ? toIdObj.contentSize||toIdObj.itemSize : other3;
    		other4 = toIdObj ? toIdObj.contentSuffix||"" : other4;
            if(judgementMgr.isEnterprisePath()){//如果是企业空间下，则传入该企业空间的企业ID
                other5 = judgementMgr.getCurrentEnterpriseID();
            }
    		isAllowOper = true;
    	}
		//如果是文件分享统计
		else if("unPublish|copyLink|msgShare|emailShare".indexOf(key)!= -1){
			var toIdObj = window.caiyun.util.cache.getFileCache(window.caiyun.constants.FILE_SHARE_LIST_CACHEGROUP,other1);
    		other2 = toIdObj ? toIdObj.contentType||toIdObj.type : other2;
    		other3 = toIdObj ? toIdObj.contentSize||toIdObj.itemSize : other3;
    		other4 = toIdObj ? toIdObj.contentSuffix||"" : other4;
    		isAllowOper = true;
		}
    	
    	if(judgementMgr.isSafeBox()){
	    	if(isAllowOper){
	    		module="safeBox";	
    		}
    	}
		var bistr=[module,key,source,browser,other1,other2,other3,other4,other5,other6,other7,other8,other9].join("|");
    	$.ajax("../bi.gif?t="+new Date().getTime(),{'headers':{'BISTR':bistr}});
     };
     