/**
 * 功能按钮栏
 */
(function(){
	var self = caiyun.ui.model.functionBtnChange;
	
	// 初始化
	self.init = function(){
		var fileOperator = window.caiyun.operate;
		var judgement = window.caiyun.judgement;
		var oldMargin = '0px';
		
		//监听修改接收到的文件夹new状态
		fileOperator.onListen('enterDir', function() {
			var catalogStack = fileOperator.getCatalogStack();
			var isInMyFile = judgement.isInMyFile(catalogStack);
			if(isInMyFile || judgement.isSafeBox())
			{
				var isReceviteDir = judgement.isReceviteDir(catalogStack);
				if(isReceviteDir)
				{
					$('#uploadBtnDiv').css("margin-left","-2000px");
					$('#uploadBtn').css("visibility","hidden");
					$("#createNewFolder").addClass("btnhidden");
				}
				else
				{
					$('#uploadBtnDiv').css("margin-left",oldMargin);
					$('#uploadBtn').css("visibility","visible");
					$("#createNewFolder").removeClass("btnhidden");
				}
			}
		});
	};
	
	// 注册初始化事件
	caiyun.ui.initList.push(self);
}
)();