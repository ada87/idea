/**
 * 默认的搜索视图
 */
(function(){
        var view = {
                leave : function(){
                    window.caiyun.operate.clearSetCatalogStack();
                },
                name : caiyun.constants.SEARCH_CONTENT_VIEW ,//显示方式名字
                modelList :[ // 包含的UI对象
                		{
                                model:caiyun.ui.model.leftNav
                        },
						{
								model:caiyun.ui.model.viewswitch
						},
						{
								model:caiyun.ui.model.fileTitle
						},
                        {
                                model:caiyun.ui.model.thumbnailView // 该显示类型下，会出现的对象，不管该对象是否显示，只要该对象有可能在该显示类型下出现都需要加到列表中
                        },
                        {
                                model:caiyun.ui.model.searchListView // 该显示类型下，会出现的对象，不管该对象是否显示，只要该对象有可能在该显示类型下出现都需要加到列表中
                        },
                        {
                                model:caiyun.ui.model.searchBar
                        }
                ],
                data : {},
                after : function(){
					// 如果是列表视图则显示列表视图，否则显示缩略图
					var view = window.caiyun.operate.getCurrentView();
					var thumbnail = caiyun.ui.model.thumbnailView;
					var grid = caiyun.ui.model.searchListView; //caiyun.ui.model.listView;
					if(view == caiyun.constants.view.win){
						thumbnail.show();
						grid.hide();
					}else if(view == caiyun.constants.view.web){
						grid.show();
						thumbnail.hide();
					}
					$('#createFolderBtn').hide();
                	$('#uploadBtn').css("visibility","hidden").css('left','-1000px');
					filterBar.hide();
				}
				
				
        };
        // 注册到文件视图管理器下
        caiyun.ui.model.fileContent.addContentView(view);
})();
