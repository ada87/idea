/**
 * 过滤器条和快捷排序列
 */
(function(){
	var self = caiyun.ui.model.filterBar;
	var $filterBar = $('#filter_bar');
	var $filterBarAndColumn = $('#filter_bar_and_title');
	var $selectAll = $('#select_all');
	var disable = false;
	
	self.init = function(){
		var fileOperate = caiyun.operate;
		var options = {
			appendToId : 'filter_bar',// 指定控件添加的dom元素id,必须 如：filterBar
			spans      : [{
	                           id: 'all' ,  // 元素id后缀，代表一种过滤类型
	                           title  : '全部', // 元素名称
	                           click : function(){
	                        	   fileOperate.filterHandler({contentType : 0});
	                           }   // 点击事件
	                       }, // 第一个默认为全部，该项默认显示
	                       {
	                           id: 'Img' ,  
	                           title  : '图片', 
	                           click : function(){
	                        	   fileOperate.filterHandler({contentType : 1});
	                           }  
	                       },
	                       {
	                           id: 'video' ,  
	                           title  : '视频',
	                           click : function(){
	                        	   fileOperate.filterHandler({contentType : 3});
	                           }   
	                       },
	                       {
	                           id: 'music' ,  
	                           title  : '音乐',
	                           click : function(){
	                        	   fileOperate.filterHandler({contentType : 2});
	                           }   
	                       },
	                       {
	                           id: 'document' ,  
	                           title  : '文档',
	                           click : function(){
	                        	   fileOperate.filterHandler({contentType : 5});
	                           }   
	                       }] 
	                   } ;
		filterBar = window.caiyun.ui.CyFilterBar(options);
		
		// 监听选择事件
		fileOperate.onListen('selectData',function(ids){
			if(disable){
				return;
			}
			if(!ids || ids.length == 0){
				$filterBarAndColumn.show();
			}else{
				$filterBarAndColumn.hide();
			}
		});
		
	};
	
	self.show = function(){
		$filterBar.show();
		$filterBarAndColumn.show();
	};
	
	self.hide = function(){
		$filterBar.hide();
		$filterBarAndColumn.hide();
	};
	
	self.enter = function(){
		disable = false;
	};
	
	self.leave = function(){
		disable = true;
		self.hide();
	};
	
	caiyun.ui.initList.push(self);
})();