;(function(){

	if($('#newGuideDiv').length < 1) {
		return;
	}
	
	var newGuideAutoSwitchPtr = null;
	var index = 1;
	var newGuideDiv = $('#newGuideDiv');
	
	function goNewGuide() {
		// hide all
		for (var k = 1; k < 5; k++) {
			$('.guide-step-' + k).hide();
		}
		
		// show target
		if (index == 1) {
			if(Html5Util.isHtml5Support()) {
				$('#newGuideDiv > div.for-html5').show();
			} else {
				$('#newGuideDiv > div.for-ie').show();
			}
		} else {
			$('.guide-step-' + index).show();
		}
		
		onResize();
		
		if (index == 4) {
			clearInterval(newGuideAutoSwitchPtr);
		}
	};
	
	function goAndResetSwitch() {
		goNewGuide();
		clearInterval(newGuideAutoSwitchPtr);
		newGuideAutoSwitch();
	};
	
	$('#newGuideDiv > div').each(function(i, dom) {
		var $dom = $(dom);
		$dom.find('.switch-dot i').click(function() {
			index = $(this).attr('index');
			goAndResetSwitch();
		});;
		
		$dom.find('div.nextStep span').click(function() {
			index = parseInt($(this).attr('index')) + 1;
			if(index >= 5) {
				clearNewGuide();
			} else {
				goAndResetSwitch();
			}
		});
		
		$dom.find('div.nextStep a').click(function() {
			clearNewGuide();
		});
	});
	
	function clearNewGuide() {
		clearInterval(newGuideAutoSwitchPtr);
		$('#newGuideDiv').hide();
		$('#newguideoverlay').hide();
		
		$.ajax({
			type: "GET",
			url: "newguide/newGuideAction!updateShowedNewGuideVersion.action",
			dataType: "json",
			success: function(json) {
			}
		});
		
		 $("html").css("overflow-y","auto");
	};
	
	function newGuideAutoSwitch() {
		newGuideAutoSwitchPtr = setInterval(function() {
			index++;
			if (index < 5) {
				goNewGuide();
			}
		}, 5000);
	};
	
	function onResize() {
		$("html").css("overflow-y","hidden");
		$('body').width(1100);
		
		var set = {};
		if (index == 1) {
			set = $('#uploadBtndiv').offset();
		} else if (index == 2) {
			set = $('#toTimeLine').offset();
			set.top = parseInt(set.top) + 200;
			set.left = parseInt(set.left) + 30;
			
		} else if (index == 3) {
			set = $('#toShare').offset();
			set.left = set.left + 19;
		} else {//  if (index == 4)
			set = $('#toTimeLine').offset();
		}
		
		newGuideDiv.offset(set);
	};
	
	$(window).resize(function(){
		onResize();
	});
	$(window).scroll(function(){
		onResize();
	});
	
	goNewGuide();
	$('#newguideoverlay').show();
	newGuideDiv.show();
	onResize();
	
	newGuideAutoSwitch(1);
	
})();