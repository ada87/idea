/**
 * 用户授权第三方应用
 */
var Mcloud_I18N = {login_error:{
                      "400":"请求格式错误", 
                      "401":"密码错误，请输入正确的密码", 
                      "404":"用户不存在", 
                      "420":"验证码错误，请重新输入", 
                      "421":"请您输入验证码", 
                      "431":"用户正在更换飞信号，暂时无法登陆", 
                      "432":"该飞信号已停止使用，请使用新帐号登录", 
                      "435":"用户手机已销号，未绑定安全邮箱", 
                      "490":"已发送短信密码，请1分钟后重试！",
                      "500":"系统繁忙，请稍后再试", 
                      "AAS_9103":"您输入的帐号或密码不正确，请重新输入",
                      "AAS_9431":"仅支持中国移动用户",
                      "AAS_9441":"您输入的帐号或密码不正确，请重新输入",
                      "AAS_9999":"用户名或密码错误，请重试",
                      "AAS_200059504":"请您输入验证码",
                      "AAS_200059508":"您今天的免费短信密码已用完", 
                      "AAS_200059505":"帐号已被冻结，请24小时后再试",
                      "AAS_200050401":"您输入的帐号或密码不正确，请重新输入",
                      "AAS_200050411":'为保证您帐号安全须绑定手机号！<a href="http://www.cmpassport.com" target="_blank">绑定</a>',
                      "AAS_200050422":"验证码错误，请重新输入",
                      "AAS_200050423":"请您输入验证码"}};
;(function() {
	var account = $('#account');               //账号
	var passwd_real = $('#passwd_real');       //密码
	var login_btn = $('#login_btn');           //登录按钮
	var regist = $('.registerBtn');            //注册
	var authorize = $('#authorize');           //授权
	var cancel = $('#cancel');                 //取消
	var valid_passwd_box = $('#valid_passwd_box');   //验证码区域
	var chang_valid_btn = $('#changvalid-btn');      //验证码切换
	var chang_valid_pic = $('#changvalid-img');      // 换验证码图片 
	var valid_code = $('#valid_code');               // 验证码输入框
	
	var needValidCodePhone = "";
	
	//注册
    var regired = "http://www.cmpassport.com/umcsso/notify?optype=2&sourceid=5&backurl=caiyun.feixin.10086.cn/Mcloud/index.jsp&check=df3004714f2ee3454c6e5e37b7b09eba";
	$("#error_msg_div").hide();
	
	//激活登录按钮样式
	$().ready(function () {
	    $(function () {	
            setInterval(function(){
            if ($("#account").val() != "") {
                $("#account").removeClass("accountInput-bg");
            }
            if ($("#passwd_real").val() != "") {
                $("#passwd_real").removeClass("passwordInput-bg");
            }
            if ($("#account").val() == "" || $("#passwd_real").val() == ""){
	            document.getElementById("login_button").disabled = true;
	            $("#login_btn").removeClass("memberBtn_live");
	        }else if($("#account").val() != "" && $("#passwd_real").val() != ""){
	            document.getElementById("login_button").disabled = false;
	            if (!$("#login_btn").hasClass("memberBtn-ing")){
	                $("#login_btn").addClass("memberBtn_live");
	            }
	        }
            }, 100);
        });
	});
	
	// 如果帐号输入框或密码输入框有输入，则不显示提示。用于处理缓存的情况
	account.focus(function(){
	    $(this).removeClass("accountInput-bg");
	}).keyup(function(){
        $(this).removeClass("accountInput-bg");
        if (needValidCodePhone != "" && account.val() == needValidCodePhone){
            valid_passwd_box.show();
            $('.input-password-bg').addClass("input-password-bot");
            regist.addClass("registerBtn-top");
        }
        else {
            valid_passwd_box.hide();
            $('.input-password-bg').removeClass("input-password-bot");
            regist.removeClass("registerBtn-top");
            $("#error_msg_div").hide();
        }
    }).blur(function () {
		if (account.val() == "") {
			$(this).addClass("accountInput-bg");
		}
	}).change(function(){
	    if ($("#passwd_real").val() != "") {
            $("#passwd_real").removeClass("passwordInput-bg");
            document.getElementById("login_btn").disabled = false;
            $("#login_btn").addClass("memberBtn_live");
        }
	});
	
	
	//密码输入框
	passwd_real.focus(function(){
	    $(this).removeClass("passwordInput-bg");
	}).blur(function () {
		if (passwd_real.val() == "") {
			$(this).addClass("passwordInput-bg");
		}
	}).keyup(function (e) {
		if (e.which == 13) {
			login_btn.click();
		}
	});
	
	//验证码输入框
	valid_code.focus(function(){
	    $(this).removeClass("Code_bg");
	}).blur(function(){
	    if (valid_code.val() == "") {
            valid_code.addClass("Code_bg");
        }
    }).keyup(function(e){
        if(e.which == 13) {
            login_btn.click();
        }
    });
	
	//验证码
	chang_valid_pic.click(function(e){
        var src = $(this).attr('src');
        
        if ($("#hidden_verfycode").val() == "true") {
            src = '/Mcloud/sso/passverifycode.action?date=' + new Date().getTime() + '&errorpwd=1&account=' + $("#account").val();
        }
        else{
	        if (src.indexOf('errorpwd') != -1) {
	            src = '/Mcloud/sso/verifycode.action?date=' + new Date().getTime() + '&errorpwd=1&random=' + Math.random();
	        } else {
	            src = '/Mcloud/sso/verifycode.action?date=' + new Date().getTime() + '&random=' + Math.random();
	        }
        }
        
        $(this).attr('src', src);
    });
    chang_valid_btn.click(function(e){
        chang_valid_pic.click();
    });
    
	
	//跳转注册页
	regist.click(function(){
	    window.open(regired);
	});
	
	//登录按钮事件
	var logining = false;
	$("#login_btn").click(function (e) {
	    //$("#login_btn").addClass("memberBtn-ing");
	    $("#error_msg_div").hide();
			var accountVal = $("#account").val();
			var password = $("#passwd_real").val();
			//输入号码格式检查
			if (accountVal == "") {
                account.focus();
                $("#error_msg_div").html("请您输入帐号").show();
                account.parent().addClass("input-account-error-bg");
                $('#login_btn').removeClass("memberBtn-ing");
                return false;
            }
            //检查密码输入是否为空
            if (password == "") {
                passwd_real.show().focus();
                $("#error_msg_div").html("请您输入密码").show();
                passwd_real.parent().addClass("input-password-error-bg");
                $('#login_btn').removeClass("memberBtn-ing");
                return false;
            }
            // 验证码
			var validate = $('#valid_code').val();       
			var autotype = $("#next_auto_login").hasClass("selected")?1:0;
			//输入信息:帐号、密码、类型？
			var data = {account:accountVal, password:password, autotype:autotype};
			//验证码框图
			var src = chang_valid_pic.attr('src');
			// 需要输入验证码
	        if(src.indexOf('errorpwd') != -1 && accountVal == needValidCodePhone) {     
	            data.errorpwd = 1;
	            if((validate == '')) {
	                //显示出验证码框调整整体样式
                    valid_passwd_box.addClass("validateCode_error").show();
	                $("#error_msg_div").html('请您输入验证码').show();
	                $('#valid_code').focus();
	                return false;
	            } else {
	                data.validate = validate;
	            }
	        }
			if(logining){
                return;         
	        }
	        logining = true;
	        $("#login_btn").removeClass('memberBtn_live').addClass("memberBtn-ing");
			var login_url = basePath + "sso/cmlogin.action";
			//var login_url = "https://127.0.0.1:8443/Mcloud/sso/cmlogin.action";
			$.ajax({
			url:login_url, 
			data:data, 
			dataType:"jsonp", 
			type:"POST", 
			success:function (res) {
				if (res.auth == "true") {
					$('#thirdContent1').hide();
					$('#thirdContent2').show();
					userid = accountVal;
				} else {
					var errorTip = Mcloud_I18N.login_error[res.code];
					if (!errorTip) {
						errorTip = Mcloud_I18N.login_error["500"];
					}
					if (res.code == '401'){
					    $("#passwd_real").parent().addClass("input-password-error-bg");
					}
					else if(res.code == '421' || res.code == '420' || res.code=="AAS_200050423" 
					    || res.code=="AAS_200050422" || res.code == "AAS_200059504" || res.code == "AAS_9441") {
					    var addr_verfycode = '/Mcloud/sso/verifycode.action?errorpwd=1&random=' + Math.random();  // 必须带 errorpwd=1
					    if (res.code == "AAS_200059504" || res.code == "AAS_9441"){ //通行证用户获取验证码通道
					        addr_verfycode = '/Mcloud/sso/passverifycode.action?date='+new Date().getTime()+'&errorpwd=1&account=' + $("#account").val();
					        $("#hidden_verfycode").val("true");
					        if (res.code == "AAS_9441") {
					            errorTip = "验证码错误，请重新输入";//区分短信动态密码登录错误提示
					        }else if(res.code == "AAS_200059504"){
					            errorTip = "您输入的帐号或密码不正确，请重新输入";
					        }
					    }
					    valid_code.val('').focus();
                        chang_valid_pic.attr('src', addr_verfycode); 
                        
                        //显示出验证码框调整整体样式
                        valid_passwd_box.addClass("validateCode_error").show();
                        $('.input-password-bg').addClass("input-password-bot");
                        regist.addClass("registerBtn-top");
                        needValidCodePhone = account.val();
                    }
                    else if(res.code == "432" || res.code == "AAS_200059505"){
                        $("#account").parent().addClass("input-account-error-bg");
                    }
                    $("#error_msg_div").html(errorTip).show();
                    $('#login_btn').removeClass("memberBtn-ing").addClass('memberBtn_live');
				}
			},
			error : function(){
			    $("#error_msg_div").html("网络不可用，请稍后再试").show();
			    $('#login_btn').removeClass("memberBtn-ing").addClass('memberBtn_live');
			},complete : function(){
				logining = false;
			}});
	});

	
	//授权
	authorize.click(function(){
	    //userid = ownerMSISDN;
	    //获取url请求参数
	    var response_type = getUrlParam("response_type");
        var client_id = getUrlParam("client_id");
        var redirect_uri = getUrlParam("redirect_uri");
        var scope = getUrlParam("scope");
        var state = getUrlParam("state");
        var id = userid;
        var redirect = "";
        var data = {response_type:response_type, client_id:client_id, redirect_uri:redirect_uri, scope:scope, state:state, userid:id};
        
        //发送请求获取授权码并转发到指定页面   
        $.ajax({
            url:"webdisk/thirdAuthorize.action?s=" + new Date().getTime(), 
			data:data, 
			dataType:"json", 
			type:"GET", 
			success:function (res) {
			    if(!res.authorize.error){
			        redirect = redirect_uri + "?code=" + res.authorize.code + "&state=" + res.authorize.state;
			    }else{
			        redirect = redirect_uri + "?error=" + res.authorize.error + "&state=" + res.authorize.state;
			    }
			    //跳转至错误界面
			    window.location.href = redirect;
			},error : function(){
			    $('#thirdContent1').hide();
                $('#thirdContent2').hide();
                $('#thirdContent3').show();
                var i = 6;
                clock();
			},complete : function(){
			
		    }
		});
              
	});	
	
	//获取get请求url参数
	var getUrlParam = function(name){
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r != null){
            return unescape(r[2]);
        }
        return null;
    } 
    
})();
