/*
 * 彩云初始化
 */
$(function() {

	var ui = caiyun.ui;
	var rootIds = window.caiyun.constants.rootIds;

	caiyun.ui.init();

	window.caiyun.initdata.init();


	//
	var nav = caiyun.hashnav;

	if (menuStatus == caiyun.constants.menuStatus.fileShare) {
		location.hash = nav.getHashByContentName(caiyun.constants.SHARE_CONTENT_VIEW);
	} else if (menuStatus == caiyun.constants.menuStatus.myphone) {
		location.hash = nav.getHashByContentName(caiyun.constants.MY_PHONE_CONTENT_VIEW);
	} else if (menuStatus == caiyun.constants.menuStatus.timeline) {
		location.hash = nav.getHashByContentName(caiyun.constants.TIMELINE_CONTENT_VIEW);
	} else if (menuStatus == caiyun.constants.menuStatus.recyclebin) {
		location.hash = nav.getHashByContentName(caiyun.constants.RECYCLEBIN_CONTENT_VIEW);
	}
	if (menuStatus == caiyun.constants.menuStatus.safebox || location.hash.indexOf('#' + nav.getHashByContentName(caiyun.constants.SAFEBOX_FILE_CONTENT_VIEW)) === 0) {
		// 保险箱要先判断开通状态，因此在查询状态回调的地方处理
	} else {
		if(!location.hash || location.hash.indexOf('#' + nav.getHashByContentName(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW)) !== 0){
			// 必须先进入默认视图
			ui.model.fileContent.switchToView(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW);
		}
		nav.switchContent(true);
	}

	window.caiyun.biz.bosh.init();
	//彩云登录成功后进入的首页统计
	window.caiyun.util.sendPvlog('view', 'login');

	//提示领取1T免费空间成功                           
	var html = '<div class="popContent">' +
		'<p style="padding:25px 0 18px 0;text-align:center;font-size:14px;color:#2a2a2a;">恭喜！您已成功领取1T彩云永久空间。</p>' +
		'</div>';
	if (taskDone) {
		// 创建对话框
		var dialog;
		dialog = ui.msgBox({
			title: "领取成功",
			width: 475,
			height: 207,
			leftBtn: false, //左下角是否有按钮
			middleBtn: false, //底部按钮是否居中
			closeBtn: false, //无关闭按钮
			html: html,
			okOnly: true,
			okHandle: function() {
				dialog.close();
			}
		});
		dialog.show();
	}
});