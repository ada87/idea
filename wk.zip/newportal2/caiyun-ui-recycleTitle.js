/**
 * 回收站按钮视图
 */
(function(){
	var self = caiyun.ui.model.recycleTitle;
	var $recycleTitle = $('#recycle_title');
	var $recycleTitle1 = $('#recycle_title1');
	var $recycleTitle2 = $('#recycle_title2');  
	var $recycleTitle3 = $('#recycle_title3');	//文件大小
	var $recycleTitle4 = $('#recycle_title4');  //文件删除时间及排序
	var disable = true;
	var sortDisable = false;
	var $sortByTimeArrow = $recycleTitle4.find('.arrow');
	
	self.init = function(){
		var recycleOperate = caiyun.recycleBinOperate;
		
		// 监听选择事件
		recycleOperate.onListen('selectData',function(ids,total){
			if(disable){
				return;
			}
			if(!ids || ids.length == 0){
				$recycleTitle2.show();
				$recycleTitle3.show();
				$recycleTitle4.show();
				$recycleTitle1.removeClass('input_first_on');
				$recycleTitle1.addClass('input_first');
			}else{
				$recycleTitle2.hide();
				$recycleTitle3.hide();
				$recycleTitle4.hide();
			}
			if(ids.length < total){
				$recycleTitle1.removeClass('input_first_on');
				$recycleTitle1.addClass('input_first');
			}
		});
		
		// 全选按钮
		$recycleTitle1.bind('click', function() {
			if ($recycleTitle1.hasClass('input_first')) {
				$recycleTitle1.removeClass('input_first');
				$recycleTitle1.addClass('input_first_on');
				recycleOperate.selectAll();
			} else {
				$recycleTitle1.removeClass('input_first_on');
				$recycleTitle1.addClass('input_first');
				recycleOperate.unSelectAll();
			}
		});
		
		$recycleTitle4.click(function() {
			if (sortDisable) {
				return;
			}
			var arrow = $sortByTimeArrow;
			// 如果是隐藏掉表示，不是按照时间排序
			if (arrow.is(':hidden')) {
				recycleOperate.sortHandler({
					sortField : 'time',
					sortType : 'desc'
				});
				return false;
			} else if (arrow.hasClass('m_time_down')) {
				recycleOperate.sortHandler({
					sortField : 'time',
					sortType : 'asc'
				});
				arrow.removeClass('m_time_up m_time_down').addClass('m_time_up');
				return false;
			} else {
				recycleOperate.sortHandler({
					sortField : 'time',
					sortType : 'desc'
				});
				arrow.removeClass('m_time_up m_time_down').addClass('m_time_down');
				return false;
			}
		});
	};
	
	
	self.show = function(){
		$recycleTitle.show();
	};
	
	self.hide = function(){
		$recycleTitle.hide();
	};
	
	self.enter = function(){
		$sortByTimeArrow.removeClass('m_time_up m_time_down').addClass(
				'm_time_down').show();
		disable = false;
	};
	
	self.leave = function(){
		$sortByTimeArrow.attr("style","cursor: pointer;display: table-cell;");
		disable = true;
		self.hide();
	};
	
	caiyun.ui.initList.push(self);
})();