/**
 * 保险箱登录的视图
 */
(function(){
		var view = {
				name : caiyun.constants.SAFEBOX_CONTENT_VIEW ,//显示方式名字
				modelList :[ // 包含的UI对象
						{
								model:caiyun.ui.model.safebox // 该显示类型下，会出现的对象，不管该对象是否显示，只要该对象有可能在该显示类型下出现都需要加到列表中
						},
						{
								model:caiyun.ui.model.leftNav // 该显示类型下，会出现的对象，不管该对象是否显示，只要该对象有可能在该显示类型下出现都需要加到列表中
						}
				],
				data : {}
		};
		// 注册到文件视图管理器下
		caiyun.ui.model.fileContent.addContentView(view);
})();
