/**
 * 默认的文件视图
 */
(function(){
		var view = {
				leave : function(){
					window.caiyun.operate.clearSetCatalogStack();
					// 中断查询
					window.caiyun.operate.abortQuery();
				},
				name : window.caiyun.constants.DEFAULT_FILE_CONTENT_VIEW ,//显示方式名字
				modelList :[ // 包含的UI对象
						{
								model: window.caiyun.ui.model.leftNav
						},
						{
								model: window.caiyun.ui.model.sortorButton
						},
						{
								model: window.caiyun.ui.model.fileTitle
						},
						{
								model: window.caiyun.ui.model.pathBar
						},
						{
								model: window.caiyun.ui.model.viewswitch
						},
                        {
                                model: window.caiyun.ui.model.thumbnailView
						},
                        {
                                model: window.caiyun.ui.model.listView
                        },
                        {
                        		model: window.caiyun.ui.model.nodeCount
                        }
				],
				data : {},
				after : function(){
					// 如果是列表视图则显示列表视图，否则显示缩略图
					var view = window.caiyun.operate.getCurrentView();
					var thumbnail = window.caiyun.ui.model.thumbnailView;
					var grid = window.caiyun.ui.model.listView;
					if(view == window.caiyun.constants.view.win){
						thumbnail.show();
						grid.hide();
					}else if(view == window.caiyun.constants.view.web){
						grid.show();
						thumbnail.hide();
					}
				}
		};
		// 注册到文件视图管理器下
        window.caiyun.ui.model.fileContent.addContentView(view);
})();
