(function() {
    var constants = window.caiyun.constants;
    var util = window.caiyun.util;
    var $selectShareAll = $('#selectShareAll');


    var $sortBySize = $('#share_title1');
    var $sortByTime = $('#share_title3');
    var $sortByTimeArrow = $sortByTime.find('.arrow');
    var $sortBySizeArrow = $sortBySize.find('.arrow');

    // 我的文件分享ListView对象
    var self = window.caiyun.ui.model.myFileShareListView;

    var genExtraHoverTool = template.compile(
        '<%if(showCancel){%>' +
        '<b title="取消分享" class="hover_tools_btn l_cancelshare" id="gridcancelshare_<%=grid.getId()%>_<%=rowItem.id%>"></b>' +
        '<%}%>' +
        '<%if(showMember){%>' +
        '<b title="成员管理" class="hover_tools_btn l_member" id="gridmemeber_<%=grid.getId()%>_<%=rowItem.id%>"></b>' +
        '<%}%>' +
        '<%if(showEnter){%>' +
        '<b title="进入我的企业" class="hover_tools_btn l_enter" id="gridenter_<%=grid.getId()%>_<%=rowItem.id%>"></b>' +
        '<%}%>'
    );

    // 初始化我的文件分享listView
    self.init = function() {
        var operate = window.caiyun.myFileShareOperate;
        var visible = false;

        var checkBoxCol = new caiyun.ui.CyGridColumns.SelectCheckBox();
        checkBoxCol.width = '5%';
        var fileInfoCol = new caiyun.ui.CyGridColumns.FileInfo();
        fileInfoCol.width = '47%';
        var sizeCol = new caiyun.ui.CyGridColumns.Words();
        sizeCol.width = '17%';
        var ownerCol = new caiyun.ui.CyGridColumns.Words();
        ownerCol.width = '16%';
        var dateCol = new caiyun.ui.CyGridColumns.Words();
        dateCol.width = '14%';
        var fileShareGrid = window.caiyun.ui.CyDefaultGrid({
            renderId: 'sharelistView',
            row: new caiyun.ui.CyGridRows.SelectedRow(),
            columns: [checkBoxCol, fileInfoCol, sizeCol, ownerCol, dateCol]
        });

        // 增加数据
        var addDatas = function(data) {
            var items = [];
            if (data && visible) {
                // 添加文件夹
                self.addFolders(data.cataloginfos);
                // 添加文件
                self.addFiles(data.contents || data.contentList);

            }
        };

        //全选与取消全选
        $selectShareAll.unbind().bind('click', function() {

            if ($selectShareAll.hasClass('input_first')) {
                $selectShareAll.removeClass('input_first');
                $selectShareAll.addClass('input_first_on');
                fileShareGrid.selectAll();
            } else {
                $selectShareAll.removeClass('input_first_on');
                $selectShareAll.addClass('input_first');
                fileShareGrid.unSelectAll();
            }

        });

        $sortBySize.click(function() {

            var arrow = $sortBySizeArrow;
            if (arrow.is(':hidden')) {
                arrow.show();
            }
            $sortByTimeArrow.hide();
            if (arrow.hasClass('m_time_down')) {
                $sortBySizeArrow.removeClass('m_time_down');
                $sortBySizeArrow.addClass('m_time_up');
                operate.sortHandler({
                    sortField: 'size',
                    sortType: 'asc'
                });
                return false;
            } else {
                $sortBySizeArrow.removeClass('m_time_up');
                $sortBySizeArrow.addClass('m_time_down');
                operate.sortHandler({
                    sortField: 'size',
                    sortType: 'desc'
                });
                return false;
            }
        });


        $sortByTime.click(function() {
            var arrow = $sortByTimeArrow;
            if (arrow.is(':hidden')) {
                arrow.show();
            }
            $sortBySizeArrow.hide();

            if (arrow.hasClass('m_time_down')) {
                $sortByTimeArrow.removeClass('m_time_down');
                $sortByTimeArrow.addClass('m_time_up');
                operate.sortHandler({
                    sortField: 'time',
                    sortType: 'asc'
                });
                return false;
            } else {
                $sortByTimeArrow.removeClass('m_time_up');
                $sortByTimeArrow.addClass('m_time_down');
                operate.sortHandler({
                    sortField: 'time',
                    sortType: 'desc'
                });
                return false;
            }
        });



        // 设置相关处理器 =============================================================
        fileShareGrid.setSelectedHandler(function(items, total) {
            var ids = [];
            $(items).each(function() {
                ids.push(this.id);
            });
            operate.selectHandler(ids, total);
        });
        fileShareGrid.setContextmenuHandler(function(e) {
            var menu = caiyun.ui.model.myFileShareRightClickMenu;
            menu.openAndLocate(e);
        });

        function extraHoverToolHandler(event){
            var $this = $(this);
            var itemId = $this.attr('id').split('_')[2];
            if ($this.hasClass('l_member')) {
                operate.memberManager(itemId);
            }else if($this.hasClass('l_cancelshare')){
                operate.cancelFileShare(itemId);
            }else if($this.hasClass('l_enter')){
                operate.enterEnterpriseSpace(itemId);
            }
            event.stopPropagation();
            return false;
        }

        // 注册悬浮菜单处理器
        fileShareGrid.addEventListener('click', 'b.l_member,b.l_cancelshare,b.l_enter', extraHoverToolHandler);

        // 添加文件夹，将彩云的文件夹信息转化为视图要显示的格式
        self.addFolders = function(folders, inFront) {
            var items = [];
            $(folders).each(function() {
                var data = new window.caiyun.ui.CyGridItem(this.catalogID);
                data.type = 'folder';
                // 第一列空对象
                data.colItems.push({});
                // 第二列文件信息
                var catalogName = this.catalogName;
                //过滤&nbsp
                if (catalogName.indexOf("&nbsp") >= 0) {
                    re = new RegExp("&", "g");
                    catalogName = catalogName.replace(re, "&amp;");
                }
                data.colItems.push({
                    showName: catalogName.substringName(25 , true),
                    fileName: catalogName,
                    thumbnail: window.caiyun.util.Icon.getIcon({
                        id: this.catalogID,
                        suffix: 'folder'
                    }, true),
                    extraHoverTool: genExtraHoverTool({
                        grid: fileShareGrid,
                        rowItem: data,
                        showCancel : operate.canExecute('cancelMyShare',[this.catalogID]),
                        showEnter : operate.canExecute('enterEPDir',[this.catalogID]),
                        showMember : operate.canExecute('meberMyShare',[this.catalogID])
                    })
                });
                // 第三列大小
                data.colItems.push({
                    str: '---'
                });
                // 第四列分享人
                data.colItems.push({
                    isEnterprisePath: this.shareType == 4,
                    str: this.shareType == 4 ? util.replace86(this.owner) : "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;我"
                });
                // 第五列分享时间
                data.colItems.push({
                    str: util.formateLifeTime(this["0"])
                });

                items.push(data);
            });
            if (items.length > 0) {
                if (inFront) {
                    fileShareGrid.unshiftItems(items);
                } else {
                    fileShareGrid.pushItems(items);
                }
            }
        };

        // 添加文件，将彩云的文件信息转化为视图要显示的格式
        self.addFiles = function(files, inFront) {
            var items = [];
            $(files).each(function() {

                var data = new window.caiyun.ui.CyGridItem(this.contentID);
                data.type = 'file';
                // 第一列空对象
                data.colItems.push({});
                // 第二列文件信息
                // 缩略图
                var thumbnail = window.caiyun.util.Icon.getIcon(this, true);
                var contentName = this.contentName;
                //过滤&nbsp
                if (contentName.indexOf("&nbsp") >= 0) {
                    re = new RegExp("&", "g");
                    contentName = contentName.replace(re, "&amp;");
                }
                data.colItems.push({
                    showName: contentName.substringName(25),
                    fileName: contentName,
                    thumbnail: thumbnail,
                    extraHoverTool: genExtraHoverTool({
                        grid: fileShareGrid,
                        rowItem: data,
                        showCancel : operate.canExecute('cancelMyShare',[this.contentID]),
                        showMember : operate.canExecute('meberMyShare',[this.contentID])
                    })
                });
                // 第三列文件大小
                data.colItems.push({
                    str: util.formateSize(this.contentSize)
                });
                // 第四列分享人
                data.colItems.push({
                    str: this.shareType == 4 ? util.replace86(this.owner) : "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;我"
                });
                // 第五列分享时间
                data.colItems.push({
                    str: util.formateLifeTime(this["0"])
                });
                items.push(data);
            });
            if (items.length > 0) {
                if (inFront) {
                    fileShareGrid.unshiftItems(items);
                } else {
                    fileShareGrid.pushItems(items);
                }
            }
        };


        // 绑定窗口滚动事件
        $(window).bind('scroll', function() {
            // 如果滚动到底部，触发加载更多事件
            if (caiyun.util.isScrollToBottom()) {
                if (visible) {
                    operate.scrollLoadData();
                }
            }
        });


        // 监听进入到文件分享模块事件
        operate.onListen('enterFileShare', function() {
            visible = true;
            //			window.caiyun.ui.model.fileShareListView.hide();
            //			fileShareScrollerWrapper.scrollTo(0);
            fileShareGrid.clear();
            self.show();
        });

        // 监听加载数据事件
        operate.onListen('loadData', function(data) {
            // 记录当前窗口滚动条位置
            var scrollTop = util.getScrollTop();
            addDatas(data);
            // 还原滚动条位置
            window.scrollTo(0, scrollTop);
            if (data.nodeCount == "0") {
                fileShareGrid.setEmptyStyle("");
            } else {
                fileShareGrid.show();
            }
        });



        operate.onListen('cancelFileShare', function(data) {
            //隐藏工具栏
            operate.selectHandler([]);
        });

        self.show = function() {
            visible = true;
            fileShareGrid.show();
            $("#linklistView").hide();
        };

        self.hide = function() {
            visible = false;
            fileShareGrid.hide();
            // 隐藏
            operate.selectHandler([]);
        };

        self.enter = function() {
            //console.info("进入我的文件分享");
        };

        self.leave = function() {
            // 离开
            fileShareGrid.clear();
            $("#share_title").hide();
        };

        //		// 重新设置大小
        //		self.resize = function(height){
        //			$('#myfileshareThumbnailView').height(height+'px');
        //			fileShareScrollerWrapper.updateScroller();
        //		};
    };

    // 鼠标右键菜单
    var myFileShareRightClick = caiyun.ui.model.myFileShareRightClickMenu;

    myFileShareRightClick.init = function() {
        var operator = caiyun.myFileShareOperate;
        // 创建右键菜单
        var menu = $('body').CyDropDownMenu({
            id: 'myFileShareOperaionMenu',
            items: [{
                id: 'enterEPDir',
                iconClass: 'ico-3-3',
                name: '进入我的企业',
                click: function() {
                    operator.enterEnterpriseSpace();
                    caiyun.pvlog('fileShare', 'enterEnterprise');
                },
                hiddenBy: function() {
                    return !operator.canExecute('enterEPDir');
                }
            }, {
                id: 'memberManager',
                iconClass: 'ico-3-2',
                name: '成员管理',
                click: function() {
                    operator.memberManager();
                    caiyun.pvlog("fileShare", "mgtMember");
                },
                hiddenBy: function() {
                    return !operator.canExecute('meberMyShare');
                }
            }, {
                id: 'cancelMyFileShare',
                iconClass: 'ico-3-6',
                name: '取消分享',
                click: function() {
                    operator.cancelFileShare();
                },
                hiddenBy: function() {
                    return !operator.canExecute('cancelMyShare');
                }
            }]
        })[0];

        menu.hover(function() {}, function() {
            menu.close();
        });

        var _scrollBegin = 0;
        // 传入右键点击的鼠标事件
        myFileShareRightClick.openAndLocate = function(event) {
            var position = {
                top: event.clientY - 5, // 偏移几个像素使鼠标能够悬浮在菜单区域内
                left: event.clientX - 15
            };
            menu.open();
            var menuHeight = menu.height();
            var windowHeight = $(window).height();
            // 判断菜单是否超过显示范围，超出则反过来显示
            if (position.top + menuHeight > windowHeight) {
                position.top = position.top - menuHeight + 10;
            }
            _scrollBegin = $(window).scrollTop();
            position.top += _scrollBegin;
            menu.locate(position, true);
            $(window).bind('scroll', locateByScroll);
        };

        function locateByScroll() {
            var position = menu.getPosition();
            var newTop = $(window).scrollTop();
            position.top += (newTop - _scrollBegin);
            _scrollBegin = newTop;
            menu.locate(position, true);
        };

        // 阻止在右键菜单上再点击右键菜单
        menu.unbind('contextmenu').bind('contextmenu', function(e) {
            e.preventDefault();
            e.stopPropagation();
        });
    };

    caiyun.ui.initList.push(myFileShareRightClick);
    caiyun.ui.initList.push(window.caiyun.ui.model.myFileShareListView);
})();