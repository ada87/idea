/**
 *  图片冲印
 */
(function(){
	var self = caiyun.ui.model.printImage;
	var ajax = caiyun.util.caiyunAjax;
	var tools = caiyun.util;
	
	
	
	var name = "", width = 766, height = 496;
	
	self.init = function(){
		
	}
	
	self.getLightBox = function(opts){
		var zIndex = tools.layerIndex.getIdx();
		var lightBoxId = 'lightbox_' + zIndex;
		var outerImage = '<div id="frameContainer" style="width:770px;height:500px;background-color:white;margin:80px auto;">' +
							'<div class="head"><span id="print_iamge_close" title="关闭" style="display:block;width:20px;height:20px;float:right;background:url(../images/wda6/lightbox_closebtn.gif) 4px 4px no-repeat;cursor: pointer;"></span></div>' +
						 '</div>';
		$("body").append('<div style=" " id="' + lightBoxId + '" class="myLightbox">' + outerImage +'</div>').find('#'+lightBoxId).css('z-index',zIndex);
		//添加进入弹出框缓存
		tools.layerIndex.hasLayer(lightBoxId);
		//展示遮罩层
		tools.maskDiv.show(lightBoxId);
		getEncryptURL(opts);
		bindHandler(lightBoxId);
	}
	
	/** 获取加密URL 并且跳转 */
	var getEncryptURL = function(opts){
		var contentID = opts.contentID;
		var thumbnailURL = opts.thumbnailURL;
		var sucFuc = function(src){
			if(src.rstCode == 0){
				var url = familyPrintImageUrl + src.url + "&thumbnailURL=" + encodeURIComponent(thumbnailURL);
				var frame = '<iframe id="printImageFrame" src="'+ url +'"style = "width:770px;height:480px; border: 0 none;"></iframe>';
				$("#frameContainer").append(frame);
			}
		}
		
		$.ajax({
			url      : "getPrintImage.action?date=" + new Date().getTime(),
			data     : {contentID : contentID},
			type     : "GET",
			dataType : "JSON",
			success  : sucFuc
		});
	}
	
	var closeBox = function(lightBoxId){
			$('#'+lightBoxId).remove();
			//最后一层 清除所有的遮罩
			tools.layerIndex.deleteLayer(lightBoxId);
			tools.maskDiv.hide(lightBoxId);
	}
	
	var bindHandler = function(lightBoxId){
		$("#" +lightBoxId).find("#print_iamge_close").unbind('click').bind('click',function(){
			closeBox(lightBoxId);
		});
	}
	
	caiyun.ui.initList.push(self);
})();

