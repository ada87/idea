/**
 * myphone model
 */
(function(){
	var self = caiyun.ui.model.myphone;
	
	self.init = function(){
		var $myphone = $('#myphone');
		var $content = $('#embedmyphone');
		// 到联系人
		var $toContact = $('#to_contact');
		// 到短彩
		var $toSms =$('#to_sms');
		var $toApp =$('#to_app');
		var $tocal = $('#to_cal');
		var $toPic = $('#to_pic');
		var $toVideo = $('#to_video');
		var ui = window.caiyun.ui;
		
		var operate = caiyun.myPhoneOperate;
		var fileOperate = caiyun.operate;
		var fileContent = caiyun.ui.model.fileContent;
		var constants = caiyun.constants;
		
		var reset = function(){
			$content.attr('src','about:blank').hide();
			$myphone.show();
		};
		//smstype:toSMS表示进入短信，toMMS表示进入彩信
		var resize = function(pim_frame,_id,smstype){
			var bodyHeight = $(document).height();
			var cyheaderHeight = $('#cy_right_head').height();
			var headerHeight = $('#cy_header').height();
			var footerHeight = 40;
			var $h = bodyHeight - headerHeight - cyheaderHeight - footerHeight;
			//加载IFRAME 显示加载中提示语
			var url = pim_frame + ((_id==='calendar')?'':'?tstamp='+new Date().valueOf()
				+'&height='+($h-(_id==='sms'?45:0))+(smstype&&(_id==='sms' || _id === 'mms') ?'&type='+smstype:''));
			window.caiyun.ifameLoadTip ={};
			/**/
			var ifr = document.getElementById('embedmyphone');
			$(ifr).remove();
			$('#cy_content').append(ifr);
			window.caiyun.ifameLoadTip = window.caiyun.ui.iMsgTip.tip("正在加载，请稍候…", "",20);
			ifr.onload = ifr.onreadystatechange  = function() {
				if (this.readyState && this.readyState != 'complete') {
					return;
				}else{
					if(window.caiyun.ifameLoadTip.close){
						window.caiyun.ifameLoadTip.close();	
					}
				}
			}
			$content.width(840).css('border','none').attr('src',url);
			_id === 'contact' ? $content.attr("scrolling","yes") : "no";
			
			var autoResize = function(){
				$content.height($h);
			};
			autoResize();
			$(window).bind('resize',autoResize);   
			$content.show();
		};
		
		operate.addListen('switchTo',function(data){
			if(data.id === 'my_phone'){
				$('#cy_content').addClass('cy_message_content');
				$('#cy_right_head').addClass('cy_right_message_head');
				reset();
			}else if(data.id === 'my_image'){
				fileContent.switchToView(constants.DEFAULT_FILE_CONTENT_VIEW);
				fileOperate.clearSetCatalogStack({
					catalogID : constants.rootIds.myFolder,
					catalogName : constants.rootIdsName[constants.rootIds.myFolder]
				});
				fileOperate.enterDir(constants.cannotModifyIDs.root_phonePhoto,{
					catalogID : constants.cannotModifyIDs.root_phonePhoto,
					catalogName : '手机图片'
				});
			}else if(data.id === 'my_video'){
				fileContent.switchToView(constants.DEFAULT_FILE_CONTENT_VIEW);
				fileOperate.clearSetCatalogStack({
					catalogID : constants.rootIds.myFolder,
					catalogName : constants.rootIdsName[constants.rootIds.myFolder]
				});
				fileOperate.enterDir(constants.cannotModifyIDs.root_phoneVideo,{
					catalogID : constants.cannotModifyIDs.root_phoneVideo,
					catalogName : '手机视频'
				});
			}
			else if(data.id === 'sms'){
				if(data.url){
					resize(data.url,data.id);
					$myphone.hide();
				}
			}else if(data.id === 'mms'){
				if(data.url){
					resize(data.url,data.id,'toMMS');
					$myphone.hide();
				}
			}
			else{
/*				if(data.id === 'sms'){
				}else{
					$('#cy_content').removeClass('cy_message_content');
					$('#cy_right_head').removeClass('cy_right_message_head');
				}*/
				if(data.url){
					resize(data.url,data.id);
					$myphone.hide();
				}
			}
		}
		);
		fileOperate.onListen('fileContentSwitch', function(e) {
			var newView = e.newView;
			if(newView.name === constants.MY_PHONE_CONTENT_VIEW){
				$('#cy_content').addClass('cy_message_content');
				$('#cy_right_head').addClass('cy_right_message_head');
			}
			else{
				$('#cy_content').removeClass('cy_message_content');
				$('#cy_right_head').removeClass('cy_right_message_head');
			}
			if(window.caiyun.ifameLoadTip){
				window.caiyun.ifameLoadTip.close();
			}
		});
		
		$toContact.bind('click',function(){
			operate.switchTo('contact');
			//pv统计
			caiyun.util.sendPvlog('feature','contacts');
		}
		);
		
		$toSms.bind('click',function(){
			operate.switchTo('sms');
		}
		);
		
		$toApp.bind('click',function(){
			operate.switchTo('apps');
			//pv统计
			caiyun.util.sendPvlog('feature','apps');
		}
		);
		
		$tocal.bind('click',function(){
			operate.switchTo('calendar');
			//pv统计
			caiyun.util.sendPvlog('feature','mCalendar');
			return false;
		}
		);
		
		$toPic.bind('click',function(){
			operate.switchTo('my_image');
			//pv统计
			caiyun.util.sendPvlog('feature','mPic');
		}
		);
		
		$toVideo.bind('click',function(){
			operate.switchTo('my_video');
			//pv统计
			caiyun.util.sendPvlog('feature','mVideo');
			
		}
		);
		
		$('#myphone_tip span').bind('click',function(){
			$('#myphone_tip').hide();
		}
		);
		
		
		self.show = function(){
			$myphone.show();
		};
		
		self.hide = function(){
			$myphone.hide();
			$content.hide();
		};
		
		self.enter = function(){
			reset();
		};
		
		self.leave = function(){
		};
		
	};
	
	 // 注册到页面初始化方法中
    caiyun.ui.initList.push(self);
}
)();