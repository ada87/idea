/**
 * 用于获取错误码对应的文字提示
 */
(function() {
	var self = caiyun.tips;

	/**
	 * 错误码和文字提示表
	 */
	self.errorCodeTipsMap = {
		'FOLDER_NAME_EMPTY': '请输入文件夹名称',
		'FOLDER_NAME_INVALID_CHARACTER': '文件夹名不能包含 \\ / : * ? " < > | 等特殊字符',
		'FOLDER_NAME_TOO_LONG': '文件夹名超过32个字',
		'FOLDER_DEPTH_EXCEEDED': '不支持更多层次的文件夹创建',
		'FILE_NAME_EMPTY': '请输入文件（夹）名称',
		'FILE_NAME_INVALID_CHARACTER': '文件名不能包含 \\ / : * ? " < > | 等特殊字符',
		'FILE_NAME_TOO_LONG': '文件名过长,必须少于32个字',
		'FILE_NAME_STARTBY_POINT': '文件名不能以"."开头',
		'SYSTEM_ERROR': '系统繁忙，请稍后再试...',
		'NETWORK_ERROR': '因网络或其它原因访问失败，请稍候再试...'
	};

	/**
	 * 普通提示文字表
	 */
	self.tipsMap = {};

	/**
	 * 根据系统提示码，显示对应的提示文字
	 */
	self.showTips = function(code) {
		var msg = self.tipsMap[code];
		if (msg) {
			var iMsgTip = caiyun.ui.iMsgTip;
			iMsgTip.tip(msg);
		}
	};

	/**
	 * 根据系统提示，显示对应的错误信息
	 *
	 * code 错误码
	 */
	self.showErrorMsg = function(code) {
		var msg = self.errorCodeTipsMap[code];
		if (msg) {
			var iMsgTip = caiyun.ui.iMsgTip;
			iMsgTip.tip(msg, 'error');
		}
	};

})();