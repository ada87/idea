/**
 * 功能按钮栏
 */
(function(){
	var self = caiyun.ui.model.functionBtnList;
	
	// 初始化
	self.init = function(){
		var fileOperator = caiyun.operate;
		
		// 绑定新建文件夹按钮
		$('#createNewFolder').click(function(){
			fileOperator.userCreateFolder();
		}
		);
	};
	
	// 注册初始化事件
	caiyun.ui.initList.push(self);
}
)();