/**
 * 回收站视图
 */
(function() {
    window.caiyun.recycleBinOperate = (function() {
        var util = window.caiyun.util;
        var iMsgTip = window.caiyun.ui.iMsgTip;
        var constants = window.caiyun.constants;
        var fileManager = caiyun.biz.fileManager;
        var sortType = { //排序
            'asc': '1',
            'desc': '0'
        };
        var sortFields = { //按照什么来排序
            'time': '0', //删除时间
            'name': '1', //名称
            'size': '2' //大小
        };

        //查询数据初页数
        var startPage = 1;
        //是否是滚动加载数据请求
        var isScrollLoad = false;
        //是否正在处理数据
        var isProcessing = false;
        //已选中文件ID数组
        var selectedIDs = [];
        //文件总数
        var count = 0;
        //每页显示记录数
        var pageNum = 15;
        // 查询句柄，用于中断查询
        var queryHandler = null;

        //查询数据初始参数，用于保存状态之用
        var queryParams = {
            contentSortType: sortFields['time'],
            sortDirection: sortType['desc'],
            startNumber: 1,
            endNumber: pageNum
        };

        var reductionDialog = null; //保存当前显示的对话框对象

        //排序
        var sortHandler = function(params) {
            sortClear();
            var params = {
                contentSortType: sortFields[params.sortField],
                sortDirection: sortType[params.sortType]
            };

            getRecycleBinInfos(params);
        };

        // 排序查询数据前的清理工作
        var sortClear = function() {
            // 文件缓存清空
            window.caiyun.util.cache.clearFileCache(constants.FILE_LIST_CACHEGROUP);
            startPage = 1;
            isScrollLoad = false;
            trigger(keys.clearData);
            selectedIDs = [];
        };


        var listens = {};

        var selectHandler = function(ids, total) {
            selectedIDs = ids;
            trigger(keys.selectData, ids, total);
        };

        var dbclickHandler = function(obj) {
            var fileGroupCache = window.caiyun.util.cache.getInstanceCache(constants.FILE_RECYCLEBIN_LIST_CACHEGROUP);
            var fileInfo = fileGroupCache.getValue(obj.id);

            var html = createInfoHtml(fileInfo);
            reductionDialog = window.caiyun.ui.msgBox({
                title: "文件信息",
                width: 500,
                leftBtn: false, //左下角是否有按钮
                middleBtn: false, //底部按钮是否居中
                html: html,
                cancelOnly: true,
                btnName: ["关闭"],
                okHandle: function() {
                    reductionDialog.close();
                }
            });
            reductionDialog.show();
        };

        var createInfoHtml = function(obj) {
            var htmlBuffer = new StringBuffer();
            if (obj.type == -1) {
                htmlBuffer
                    .append('<div class="re_box" style="width:498px;"><div class="re_content con_01"><img src="' + util.Icon.getIconByExtName('folder', false) + '" class="img_01 local-pic"  style="float:left;margin:0 60px 0 24px" /><div class="info_right">')

            } else {
                htmlBuffer
                    .append('<div class="re_box" style="width:498px;"><div class="re_content con_01"><img src="' + util.Icon.getRecycIcon(obj) + '" class="img_01 local-pic" style="float:left;margin:0 60px 0 24px"  /><div class="info_right">')
            }
            htmlBuffer.append('<p title=' + obj.name + ' style="padding-top:10px;">' + util.splitRecovery({
                name: obj.name,
                maxLen: 45,
                type: "1"
            }) + '</p><table>')
            htmlBuffer.append('<tr><td class="text_01" style="text-align:right">类型：</td><td class="text_02">' + util.getTypeByNum(obj.type) + '</td></tr>')
            htmlBuffer.append('<tr><td class="text_01" style="vertical-align:top;text-align:right">原位置：</td><td class="text_02"><p title=' + obj.parPath.substr(1, obj.parPath.length) + '>' + util.splitRecovery({
                name: obj.parPath
            }).substr(1, util.splitRecovery({
                name: obj.parPath,
                maxLen: 65,
                type: 2
            }).length) + '</p></td></tr>')
                .append('<tr><td class="text_01" style="text-align:right">大小：</td><td class="text_02">' + util.formateRecoverySize(obj) + '</td></tr>')
                .append('<tr><td class="text_01" style="text-align:right">创建时间：</td><td class="text_02">' + util.newFormateTime(obj.updateTime) + '</td></tr>')
                .append('<tr><td class="text_01" style="text-align:right">删除时间：</td><td class="text_02">' + util.newFormateTime(obj.virUpdateTime) + '</td></tr></table>')
            //                  .append('<tr><td class="text_01"></td><td class="text_02 t_02" style="padding:8px 0;_padding:8px 0 0 0;"><a href="javascript:void(0);" onclick="window.caiyun.recycleBinOperate.toReduction(\''
            //                          + obj.itemID + '\', \'' + obj.type 
            //                          + '\');"><span class="btn_01">还原</span></a</td></tr></table>')
            .append('</div></div></div>');

            return htmlBuffer.toString();
        };

        var getQueryParams = function(param) {
            if (typeof(param) != 'undefined') {
                queryParams.contentSortType = param.contentSortType ? param.contentSortType : queryParams.contentSortType;
                queryParams.sortDirection = param.sortDirection ? param.sortDirection : queryParams.sortDirection;
                queryParams.startNumber = param.startNumber ? param.startNumber : 1;
                queryParams.endNumber = param.endNumber ? param.endNumber : pageNum;
            } else {
                queryParams.startNumber = 1;
                queryParams.endNumber = pageNum;
            }
            return queryParams;
        };

        var loadRecycleBinInfos = function() {
            sortClear();
            selectHandler([]);
            getRecycleBinInfos();
        };

        //加载回收站文件信息
        var getRecycleBinInfos = function(param) {
            var params = getQueryParams(param);
            $('#listLoading').fadeIn('fast');
            if (queryHandler) {
                queryHandler.abort();
            }
            queryHandler = fileManager.queryRecycleBin(params, queryRecycleBinSuccCallBack, queryRecycleBinFailCallBack, false);
            isProcessing = true;
            // 显示加载更多的提示栏
            $('#listLoading').fadeIn('fast');
        };

        var queryRecycleBinSuccCallBack = function(params, json) {
            isProcessing = false;
            $('#listLoading').fadeOut('slow');
            var listView = window.caiyun.ui.model.recycleBinView;
            $('#listLoading').fadeOut('slow');
            if ($.trim(json.showMessage)) {
                //弹出对话框
                iMsgTip.tip(json.showMessage, "error");
            } else {
                count = json.dci.nodeCount;
                // 没有新数据
                var noNewData = false;
                // 有新数据才更新缓存
                if (hasNewData(json)) {
                    var fileGroupCache = window.caiyun.util.cache.getInstanceCache(constants.FILE_RECYCLEBIN_LIST_CACHEGROUP);
                    if (json.dci.vitem) {
                        $.each(json.dci.vitem, function(i, data) {
                            fileGroupCache.putValue(data.itemID, data);
                        });
                    }
                    scrollLoadSucc();
                }
                trigger(keys.loadData, json.dci);
            }

        };

        var queryRecycleBinFailCallBack = function(request, textStatus, errorThrown, params) {
            //弹出error对话框
            isProcessing = false;
            $('#listLoading').fadeOut('slow');
        };

        //还原文件
        var revertFile = function(ids) {
            var msg = '<div class="popContent">' +
                '<div class="system_main"></div>' +
                '<div class="off_line_tips_YN">' +
                '<div class="tips_img"></div>' +
                '<div class="floatleft">' +
                '<p class="content" style="line-height:50px;">确定要还原选中的文件吗？</p> ' +
            //          '<p class="sub_content">你可以进入回收站彻底删除或恢复此文件(夹)</p> '+
            '</div>' +
                '</div>' +
                '</div>';
            var dropIDs = ids || selectedIDs;
            dialogs({
                html: msg,
                OKfun: function() {
                    if (dropIDs.length <= 200) {
                        var dataArr = getSelectedArr(ids);
                        fileManager.recoverFromRecycleBin({
                                catalogIDs: dataArr[0],
                                contentIDs: dataArr[1],
                                _path: dataArr[2]
                            },
                            revertFileSuccCallbackFunc, revertFileFailCallbackFunc);
                        //统计从回收站还原操作
                        var cataIDs = dataArr[0];
                        var conentIDs = dataArr[1];
                        if (cataIDs.length > 0) {
                            for (var i = 0, length = cataIDs.length; i < length; i++) {
                                caiyun.pvlog('recycle', 'restore', cataIDs[i]);
                            }
                        }
                        if (conentIDs.length > 0) {
                            for (var i = 0, length = conentIDs.length; i < length; i++) {
                                caiyun.pvlog('recycle', 'restore', conentIDs[i]);
                            }
                        }
                    } else {
                        iMsgTip.tip("一次最多只能还原200个文件或目录", "error");
                    }
                }
            });
        };

        var toReduction = function(id, type) {
            /**
            if (type == '-1'){
                fileManager.recoverFromRecycleBin({catalogIDs:[id],contentIDs:[]},
                    revertFileSuccCallbackFunc, revertFileFailCallbackFunc)
            }
            else {
                fileManager.recoverFromRecycleBin({catalogIDs:new Array(),contentIDs:[id]},
                    revertFileSuccCallbackFunc, revertFileFailCallbackFunc)
            }
            reductionDialog.close();
         */
            selectedIDs.push(id);
            revertFile();
        };

        var revertFileSuccCallbackFunc = function() {
            var param = arguments[0];
            var json = arguments[1];
            if ($.trim(json.showMessage)) {
                iMsgTip.tip(json.showMessage, "error");
            } else {
                iMsgTip.tip("文件已还原成功");
                trigger(keys.clearData);
                startPage = 0;
                selectedIDs = [];
                trigger("selectData", selectedIDs);
                getRecycleBinInfos();
            }
        };

        var revertFileFailCallbackFunc = function() {};

        //彻底删除文件
        var deleteFile = function(ids) {
            var workIds = ids || selectedIDs;
            var msg = '<div class="popContent">' +
                '<div class="system_main"></div>' +
                '<div class="off_line_tips_YN">' +
                '<div class="tips_img"></div>' +
                '<div class="floatleft" style="width:420px;">' +
                '<p class="content">确定要彻底删除选中的文件吗？<BR/>删除后将无法恢复。</p> ' +
            '</div>' +
                '</div>' +
                '</div>';
            dialogs({
                html: msg,
                OKfun: function() {
                    if (workIds.length <= 200) {
                        var dataArr = getSelectedArr(ids);
                        fileManager.drop({
                                catalogIDs: dataArr[0],
                                contentIDs: dataArr[1]
                            },
                            deleteFileSuccCallbackFunc, deleteFileFailCallbackFunc);
                        //统计从回收站删除操作
                        var cataIDs = dataArr[0];
                        var conentIDs = dataArr[1];
                        if (cataIDs.length > 0) {
                            for (var i = 0, length = cataIDs.length; i < length; i++) {
                                caiyun.pvlog('recycle', 'delete', cataIDs[i]);
                            }
                        }
                        if (conentIDs.length > 0) {
                            for (var i = 0, length = conentIDs.length; i < length; i++) {
                                caiyun.pvlog('recycle', 'delete', conentIDs[i]);
                            }
                        }
                    } else {
                        iMsgTip.tip("一次最多只能删除200个文件或目录", "error");
                    }
                }
            });
        };

        var deleteFileSuccCallbackFunc = function() {
            var json = arguments[1];
            if ($.trim(json.showMessage)) {
                iMsgTip.tip(json.showMessage, "error");
            } else {
                iMsgTip.tip("删除成功！");
                trigger(keys.clearData);
                window.caiyun.initdata.setDiskSize();
                selectedIDs = [];
                trigger("selectData", selectedIDs);
                startPage = 0;
                getRecycleBinInfos();
            }
        };

        var deleteFileFailCallbackFunc = function() {};

        //弹窗
        var dialogs = function(param) {
            var html = '<div class="deleteDialog">' + '<div class="tip-getlink"><span class="ico-sign"></span>' + param.html + '</div></div>';
            var dialog = window.caiyun.ui.msgBox({
                title: "系统提示",
                width: 650,
                leftBtn: false, //左下角是否有按钮
                middleBtn: false, //底部按钮是否居中
                html: html,
                btnName: ["确定", "取消"],
                okHandle: function() {
                    dialog.close();
                    param.OKfun();
                    if (reductionDialog != null) {
                        reductionDialog.close();
                        reductionDialog = null;
                    }
                }
            });
            dialog.show();
        };

        //清空回收站
        var dropRecycleBin = function() {
            var msg = '<div class="popContent">' +
                '<div class="system_main"></div>' +
                '<div class="off_line_tips_YN">' +
                '<div class="tips_img"></div>' +
                '<div class="floatleft">' +
                '<p class="content oneline">确定清空回收站吗?</p> ' +
                '<p class="sub_content"></p> ' +
                '</div>' +
                '</div>' +
                '</div>';

            //            var msg = "确定清空回收站吗？<br/><p style='font-size:12px;font-weight:normal;padding-top:5px;'>如果点击确定，文件将被彻底删除且无法恢复！</p>";
            dialogs({
                html: msg,
                OKfun: function() {
                    fileManager.clearRecycleBin(null, dropSuccCallbackFunc, dropFailCallbackFunc);
                    //统计清空回收站操作
                    caiyun.pvlog('recycle', 'clean', caiyun.constants.rootIds.myRecycleBin);
                }
            });
        };

        var dropSuccCallbackFunc = function() {
            var json = arguments[1];
            if ($.trim(json.showMessage)) {
                window.caiyun.ui.iMsgTip.tip(json.showMessage, 'error');
            } else {
                iMsgTip.tip("清空回收站成功！");
                trigger(keys.clearData);
                window.caiyun.initdata.setDiskSize();
                selectedIDs = [];
                trigger("selectData", selectedIDs);
                startPage = 0;
                getRecycleBinInfos();
            }
        };

        var dropFailCallbackFunc = function() {};

        var getSelectedArr = function(ids) {
            var catalogIDs = [];
            var contentIDs = [];
            var _path = [];
            var data = {};
            var workIds = ids || selectedIDs;
            var fileGroupCache = window.caiyun.util.cache.getInstanceCache(constants.FILE_RECYCLEBIN_LIST_CACHEGROUP);
            for (var i = 0; i < workIds.length; i++) {
                data = fileGroupCache.getValue(workIds[i]);
                _path = data.parPath;
                if (data.type == "-1") {
                    catalogIDs.push(workIds[i]);
                } else {
                    contentIDs.push(workIds[i]);
                }
            }

            return [catalogIDs, contentIDs, _path];
        };

        //清除缓存对应的数据
        var removeCache = function() {
            var fileGroupCache = window.caiyun.util.cache.getInstanceCache(constants.FILE_RECYCLEBIN_LIST_CACHEGROUP);

            for (var i = 0; i < selectedIDs.length; i++) {
                fileGroupCache.delValue(selectedIDs[i]);
            }
        };

        //对外滚动条数据加载回调函数
        var scrollBottomLoadData = function() {
            if (!caiyun.util.isScrollToBottom()) {
                return;
            }

            // 超出页数不做查询
            count = count || 0;
            var curPage = Math.ceil(count / pageNum);
            // 处理中，不操作
            if (isProcessing || startPage >= curPage) {
                return;
            }
            isScrollLoad = true;
            var sNumber = startPage * pageNum + 1;
            var eNumber = (startPage + 1) * pageNum;

            getRecycleBinInfos($.extend(queryParams, {
                startNumber: sNumber,
                endNumber: eNumber
            }));

        };

        // 绑定窗口滚动事件
        $(window).bind('scroll', function() {
            // 如果滚动到底部，触发加载更多事件
            if (caiyun.util.isScrollToBottom()) {
                scrollBottomLoadData();
            }
        });

        // 是否存在新数据
        var hasNewData = function(json) {
            if (!json) {
                return false
            }
            if (json.dci.vitem && json.dci.vitem.length > 0) {
                return true;
            }
        };

        //滚动数据查询中止或是失败时对于page的恢复
        var scrollLoadSucc = function() {
            if (isScrollLoad) {
                startPage++;
            }
        };

        //操作的key
        var keys = {
            revertFile: 'revert', // 文件已还原
            loadData: 'loadData', // 加载到数据
            selectData: 'selectData', // 文件被选中
            deleteFile: 'delete', // 文件被删除
            clearData: 'clearData', // 清除数据
            selectAll: 'selectAll',
            unSelectAll: 'unSelectAll'
        };

        /*
         * 监听注册，里面提供了3个监听
         * 1.revert ：还原文件
         * 2.选择文件，参数为当前所有选择的文件ids
         * 3.loadData ： 数据载入，参数为请求后台的json数据对象
         * 4.delete: 彻底删除文件
         */
        var addListen = function(key, fun) {
            var ref, stack;
            key = $.trim(key);

            if (keys[key]) {
                stack = (ref = listens[key]) == null ? [] : ref;
                stack.push(fun);
                listens[key] = stack;
            }
            return this;
        };

        var removeListen = function(key) {
            delete listens[$.trim(key)];
            return this;
        };

        var trigger = function(key) {
            var events = listens[key] || {}, params = [],
                i = 1,
                length = arguments.length;
            if (length > 1) {
                for (; i < length; i++) {
                    params.push(arguments[i]);
                }
            }

            $.each(events, function() {
                this.apply(null, params);
            });
        };

        /**
         * 发起全选
         */
        var selectAll = function() {
            trigger(keys.selectAll);
        };

        /**
         * 取消全选
         */
        var unSelectAll = function() {
            trigger(keys.unSelectAll);
        };

        return {
            loadRecycleBinInfos: loadRecycleBinInfos, // 加载回收站内文件
            onListen: addListen, // 添加监听器 
            scrollLoadData: scrollBottomLoadData, // 根据滚动条加载更多
            sortHandler: sortHandler, // 排序处理器
            deleteFile: deleteFile, // 彻底删除文件
            revertFile: revertFile, // 还原文件
            toReduction: toReduction, // 不弹出对话框，直接还原文件
            clearRecyc: dropRecycleBin, // 清空回收站
            selectHandler: selectHandler, // 选择处理器
            dbclickHandler: dbclickHandler, // 双击处理器
            selectAll: selectAll,
            unSelectAll: unSelectAll
        };

    })();
})();