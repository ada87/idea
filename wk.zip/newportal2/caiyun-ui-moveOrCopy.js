/**
 * 移动或复制文件
 * @param {} type 【move copy】
 * @param {} ids   要移动的所有文件与文件夹ID
 */
;(function(){
		window.caiyun.ui.model.moveOrCopy=function(param){		
			var CyTree = window.caiyun.ui.CyTree;
			var constants = window.caiyun.constants;
			var judgement = window.caiyun.judgement;
			var operate = window.caiyun.operate;
			var ui = window.caiyun.ui;
			var iMsgTip = ui.iMsgTip;
			var ajax = window.caiyun.util.caiyunAjax.ajaxRequest;
			var cache = window.caiyun.util.cache;
			var msgBox = ui.msgBox;
			var title = param.type === 'move' ? '移动到' : ((judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)&& !judgement.isEnterprisePath())?"转存到":'复制到');
			var typeStr = param.type === 'move' ? '移动' : ((judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)&& !judgement.isEnterprisePath())?"转存":'复制');
			var treeFrame;
			var syncBoxTips;
			var tree;
            var path = "";
            var enterID ="";
            var enterName = "";
			
			var init = function(){
				createTreeFrame();
				createTree();
			};
			
			/*
			 * 创建树的弹出框
			 */
			var createTreeFrame = function() {
				var html = '<div id="treeRoot" class="detailCon" style="height:300px;"> </div>';
				treeFrame = msgBox({
					html		:  html,
					leftBtn		:  true,
					width		:  650,
					title       :  title,
					height      :  438,
					creatHandle :  createTreeFloder,
					okHandle	:  moveOrCopyOpe
				});
				treeFrame.show();
				constants.safeboxCloseWin["treeFrame"] = treeFrame;
			};
			
			/*
			 * 创建文件夹树
			 */
			var createTree = function() {
				tree = CyTree({
					 renderTo : "treeRoot",
		             root     : getTreeRoot(),
		             select   : nodeSelect
				});
				
				var judgement = window.caiyun.judgement;
                var _id;
                if(judgement.isEnterprisePath()){
                    var stackInfo  = operate.getCatalogStack();
                    if(stackInfo[0].shareType =='4'){
                        enterID = stackInfo[0].catalogID;
                        enterName = stackInfo[0].catalogName;
                        path = stackInfo[0].path;
                    }else{
                        enterID = stackInfo[2].catalogID;
                        enterName = stackInfo[2].catalogName;
                        path = stackInfo[2].path;
                    }
                    tree.selectNodeByID(enterID);
                    openTreeNode({id:enterID,path:path});
                }else if(judgement.isSafeBox()){
                    _id = constants.rootIds.mySafeBox;
                    tree.selectNodeByID(_id);
                    openTreeNode({id:_id});
                }else{
                    _id = constants.rootIds.myFolder;
                    tree.selectNodeByID(_id);
                    openTreeNode({id:_id});
                }
			};
			
			
			/*
			 * 根节点的数据拼装
			 */
			var getTreeRoot = function(){
		         var root = [];
			    
		         if(judgement.isSafeBox()){
		         	var safebox = {
			                id      : constants.rootIds.mySafeBox,
			                iconCls : 'ico-floder-root',
			                text    : constants.rootIdsName[constants.rootIds.mySafeBox],
			                click   : function(e) {
				                       openTreeNode({id:e.id});
			                     	 },
			                select  : function(e){
				                       tree.selectNodeByID(e.id);
			                     	 }
			         };
			        root.push(safebox);
		         }else if(judgement.isEnterprisePath()){
                     var enterID = "";
                     var name = "";
                     var stackInfo  = operate.getCatalogStack();

                     if(stackInfo[0].shareType =='4'){
                         enterID = stackInfo[0].catalogID;
                         name = stackInfo[0].catalogName;
                         path = stackInfo[0].path;
                     }else{
                         enterID = stackInfo[2].catalogID;
                         name = stackInfo[2].catalogName;
                         path = stackInfo[2].path;
                     }
                     var enterprise = {
                         id      : enterID,
                         iconCls : 'ico-floder-root',
                         text    : name,
                         click   : function(e) {
                             openTreeNode({id:e.id,path:path});
                         },
                         select  : function(e){
                             tree.selectNodeByID(e.id);
                         }
                     };
                     root.push(enterprise);
                 }else{
		         	var myFolder = {
			            id      : constants.rootIds.myFolder,
			            iconCls : 'ico-floder-root',
			            text    : constants.rootIdsName[constants.rootIds.myFolder],
			            click   : function(e) {
			                        openTreeNode({id:e.id});
			                      },
			            select  : function(e){
						            tree.selectNodeByID(e.id);
						          }
		            };
		            
		            root.push(myFolder);
		         }
		         
		        return root;
	        };   
	        
	        //可能不要提醒了
	        var nodeSelect = function(node){
	        	tree.selectNodeByID(node.id);
	        	return;
	        	var html = '<div style="padding:38px 0 0 35px;height:90px;" class="">'+
					         '<div class="tip-getlink">'+
					            '<span class="ico-sign"></span>'+
					            '<h3>往该文件夹添加内容（包括上传、复制至、移动至）将会同步到用户的手机上，是否继续操作？</h3>'+
					            '<p><input type="checkbox" id="swtichbox_syncAdd" name="swtichbox_syncadd">  下次不再提示！</p>'+
					         '</div>'+
					      '</div>';
	        	/*if((isSyncSetCata(node.id) || isUnderSyncSetCata()) && constants.hint_syncAdd = 1){
	        		
	        	}*/
	        	syncBoxTips = msgBox({
					html		:  html,
					width		:  480,
					title       :  '系统提示',
					height      :  211,
					okHandle    :  noTips
				});
				syncBoxTips.show();
	        };
			
			//用户选择不再提示后，向后台发送请求记住用户选择，所以在页面加载时要读取此配制信息
			var noTips = function(){
				if($('#swtichbox_syncAdd').attr("checked")) {
   	                constants.hint_syncAdd = 0;
   	                	ajax({
   	                		url:"../funcparm!stParam.action",
   	                		data:{
	                		 		key:"hint_syncAdd",
	                		        val:constants.hint_syncAdd
	                	         }
   	                	});
   	            }
   	            syncBoxTips.close();
			};
			
			/*
			 * 树中创建文件夹回调函数
			 */
			var createTreeFloder = function(){
				tree.createInputNode({isBefor:true,submitFun:createFolder});
			};
			
			
			var createFolder = function(obj){
				var path ='';
				path = tree.getSelectNodePath(obj.parentId);
				if(judgement.isEnterprisePath()){
					path = constants.rootIds.myFolder +'/'+path;
					$.extend(obj,{path:path});
				}
				if(judgement.isInPublisherDir(path)){
					tips.text('公开目录下不能新建文件夹').show();
					return;
				}
				window.caiyun.operate.createFolder({parentcatalogID:obj.parentId,catalogName:obj.folderName,path:path,noEnterDir:true,
					successCallback :function(){
                        var param = {id:obj.parentId};
                        if(judgement.isEnterprisePath()){
                            $.extend(param,{path:obj.path});
                        }
						openTreeNode(param);
					}
				}
				);
			};
			
			/*
			 * move或copy的规则校验与ajax数据发送
			 */
			var moveOrCopyOpe = function(){
				var node = tree.getSelectedNode();
				var ids = getIdsData();
				var url = param.type === 'move' ?  "../webdisk2/moveAction.action" : "../webdisk2/copyAction.action";
				var type = param.type === 'move' ? 'move':'copy';
				
				var tips = $('.msg-noavail-tip2');
				
				// 是否存在同步目录
				var hasSyncCatalog = false;
				var cataIds = ids.catalogIDList.split(",");
				for(var i  in cataIds){
					var item = cache.getFileCache(constants.FILE_LIST_CACHEGROUP,cataIds[i]);
					// 是否有同步目录
					if(judgement.isSyncCatalog(item)){
						hasSyncCatalog = true;
						break;
					}
				}
				var path = tree.getSelectNodePath(node.id);
				if(judgement.isInPublisherDir(path)){
					tips.text('公开目录下不能'+typeStr).show();
					return;
				}
				if(ids.catalogIDList.indexOf(node.id) != -1){
                    var cataIDs = ids.catalogIDList.split('/');
					if(cataIDs[cataIDs.length-1] == node.id){
						tips.text('选择当前所在的目录不能'+typeStr).show();
					    return ;
					}
				}else if(hasSyncCatalog && param.type === 'move'){
					tips.text('同步目录无法移动！').show();
					return
				}
				
//				ajax({
//		            url      : url,
//		            type     : 'post',
//		            data     : {
//		            			contentIDList : ids.contentIDList,
//					            catalogIDList : ids.catalogIDList,
//					            newCatalogID  : node.id
//					           },
//		            succFun  :    moveOrCopySuccCallBack,
//					errFun     :    moveOrCopyFailCallBack
//		        });
				//var currentPath = tree.getSelectNodePath(node.id);
				var currentPath = node.id;
				
				if(judgement.isEnterprisePath())  //企业空间目录下
				{
					currentPath = constants.rootIds.myFolder + "/"+ tree.getSelectNodePath(node.id);
				}
				else if(judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare))  //收到的分享目录下
				{
					currentPath = tree.getSelectNodePath(node.id);
				}
				
				window.caiyun.util.caiyunAjax.ajaxRequest({
					url      : url,
		            type     : 'post',
					dataType : 'json',
		            data     : {
		            			contentIDList : ids.contentIDList,
					            catalogIDList : ids.catalogIDList,
					            newCatalogID  : currentPath
					           },
		            succFun  :    moveOrCopySuccCallBack,
					errFun   :    moveOrCopyFailCallBack,
					bi       : ['fileOper',type,ids.contentIDList,ids.catalogIDList]//统计移动，复制文件操作
					
				});        
			};
			
			
			
			var moveOrCopySuccCallBack = function(reqParam,json){
				var tips = $('.msg-noavail-tip2');
				if(json.message){
		            //弹出error对话框
					  tips.text(json.message).show();
		            return;
		        }
		        if(param.type == 'move'){
                    iMsgTip.tip('移动成功');
		        	//当前页面数据重新加载 
		        	window.caiyun.operate.reLoad();
		        }else{
		        	if(typeStr == "转存"){
		        		var cataid = json.newCatalogID;
		        		if(cataid.indexOf('/')<0){}
		        		else{
		        			var a = new Array();
		        			a = cataid.split('/');
		        			for(var i=0;i<a.length;i++)
 							{
								cataid=a[i];
							}
		        		}
		        		if(caiyun.judgement.isEnterprisePath())  //如果是企业空间目录
						{
                            iMsgTip.tip('复制成功!');
                        }else{
                        	if(judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)){
	                        	 //优化转存成功提示
				        		iMsgTip.tip(typeStr+'成功，<a href="javascript:void(0)" style="font-family:Applied Font' +
					    		';font-size:13px;font-weight:normal;font-style:normal;text-decoration:underli' +
					    		'ne;color:#0000CC;"  onclick="window.caiyun.ui.model.moveOrCopy.toLookFile(\''+cataid+'\');'+
					    		'">点击看看</a>保存的文件!',"html",5);
                        	}else{
                        		iMsgTip.tip(typeStr+'成功');
                        	}
	                        
                        }
		        	   
		        	}else{
		        		iMsgTip.tip(typeStr+'成功');
		        	}
		        	
		        	//容量重新查询 
		        	window.caiyun.initdata.setDiskSize();
		        }
		        
		        treeFrame.close();
			};
			
			window.caiyun.ui.model.moveOrCopy.toLookFile = function(id){
				var idparams = {cataID:id}
				window.caiyun.operate.enterCopyDirLocate(idparams);
			}
			
			var moveOrCopyFailCallBack = function(request,textStatus,errorThrown,params){
			};
			
			var openTreeNode = function(param){
		        var data = {
		            contentID           : param.id,
		            filtertype          : 1,    
		            entryShareCatalogID : '',           
		            startNumber         : -1,
		            endNumber           : 10,               
		            catalogSortType     : 0,
		            contentSortType     : 0,
		            sortDirection       : 1
		        };
                if(judgement.isEnterprisePath()){//如果打开的是企业空间
                    $.extend(data,{path:param.path});
                }
		        var param = {
		            type    : "post",
		            url     : "../webdisk2/queryContentAndCatalog!disk.action", 
		            dataType: 'json', 
		            data    : data, 
		            succFun : openTreeNodeSuccCallBack,
					hideLoading : true
		        };      
		        ajax(param);         
	        };
	        
	         /**
		     * 展开树节点成功的回调函数
		     */
		    var openTreeNodeSuccCallBack = function(param,json){
		        var parentId = param.data.contentID;
		        var catalogInfos = json.dci && json.dci.cataloginfos;
		        tree.clear(parentId);
		        if(!catalogInfos){
		            return;
		        }
		        
		        $.each(catalogInfos, function(i, node) {
		              var tNode = {};
					  tNode.pid = parentId;
					  tNode.id = node.catalogID;
					  tNode.text = window.caiyun.util.htmlEscape(node.catalogName);
					  tNode.click = function(e) {
                          var path = {};
                          if(caiyun.judgement.isEnterprisePath()){
                              path = {path:node.path};
                              openTreeNode($.extend({id:e.id},path));
                          }else{
                              openTreeNode({id:e.id});
                          }
					  };
					  tNode.select = nodeSelect;
				      tree.addNode(tNode);
		        });   
		        
		        tree.collapsable(parentId);  
		    };
		    
		    /*
		     * 把id分区成文件夹id和文件id
		     */
		    var getIdsData = function(){
		    	var catalogIDList = [];
		    	var contentIDList = [];
				var path = judgement.getPath(caiyun.operate.getCatalogStack());
				var pId = null;
				var stack = operate.getCatalogStack();
				
			    $.each(param.ids, function(i, id){
	               var obj = cache.getFileCache(constants.FILE_LIST_CACHEGROUP,id);
	               
	               if(obj.catalogType){
				   		
				   		if(caiyun.judgement.isEnterprisePath())  //如果是企业空间目录
						{
                            catalogIDList.push(caiyun.judgement.getPathForEnterprise()+'/'+id);
                        }
						else if (caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare))
						{
							//如果是在我接收到的文件夹二级目录下,则需要变成全路径方式
							catalogIDList.push(obj.path);
						}
						else
						{
	               			catalogIDList.push(id);
						}
	               }else{
				   		
				   		if(caiyun.judgement.isEnterprisePath())  //如果是企业空间目录
                        {
                            contentIDList.push(caiyun.judgement.getPathForEnterprise()+'/'+id);
                        }
                        else if (caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare))
						{
							// 如果是公共账号目录下的下载，path特殊处理
                    		if (judgement.isInReceivedPublishDir()) {
                    			if(stack.length > 3){
                    				pId = stack[3].parentCatalogId;
                    			}else{
                    				pId = obj.parentCatalogId;
                    			}
                    			path = judgement.getPathInPublishDir(pId, id);
                    			// 如果路径中没有目标ID，补上
                    			if(path.indexOf(id) === -1){
                    				path += '/' + id;
                    			}
                         		contentIDList.push(path);
                    		}else{
                    			//如果是在我接收到的文件夹二级目录下,则需要变成全路径方式
								contentIDList.push(path+"/"+id);
                    		}
						}
						else
						{
	               			contentIDList.push(id);
						}
	               }
	            });
	            
	           return {
	           			catalogIDList:catalogIDList.join(','),
	           		    contentIDList:contentIDList.join(',')
					  };
		    };
			
			init();
		};
})();
