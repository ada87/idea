(function() {
	var constants = window.caiyun.constants;
	var util = window.caiyun.util;
	var $selectLinksAll = $("#selectLinksAll");


	var $sortBySize = $('#links_title1');
	var $sortByTime = $('#links_title2');
	var $sortByTimeArrow = $sortByTime.find('.arrow');
	var $sortBySizeArrow = $sortBySize.find('.arrow');

	var genExtraHoverTool = template.compile(
		'<b title="取消分享" class="hover_tools_btn l_cancelshare" id="gridcancelshare_<%=grid.getId()%>_<%=rowItem.id%>"></b>'
	);

	// 文件分享ListView对象
	var self = window.caiyun.ui.model.fileShareListView;
	// 初始化文件分享listView
	self.init = function() {

		var operate = window.caiyun.fileShareOperate;
		var visible = false;


		var checkBoxCol = new caiyun.ui.CyGridColumns.SelectCheckBox();
		checkBoxCol.width = '5%';
		var fileInfoCol = new caiyun.ui.CyGridColumns.FileInfo();
		fileInfoCol.width = '47%';
		var downloadCountCol = new caiyun.ui.CyGridColumns.Words();
		downloadCountCol.width = '17%';
		var ownerCol = new caiyun.ui.CyGridColumns.Words();
		ownerCol.width = '16%';
		var dateCol = new caiyun.ui.CyGridColumns.Words();
		dateCol.width = '14%';
		var fileShareGrid = window.caiyun.ui.CyDefaultGrid({
			renderId: 'linklistView',
			row: new caiyun.ui.CyGridRows.SelectedRow(),
			columns: [checkBoxCol, fileInfoCol, downloadCountCol, ownerCol, dateCol]
		});

		// 增加数据
		var addDatas = function(data) {
			var items = [];
			if (data && visible) {
				self.addFiles(data.outLinks);
			}
		};

		//全选与取消全选
		$selectLinksAll.unbind().bind('click', function() {
			if ($selectLinksAll.hasClass('input_first')) {
				$selectLinksAll.removeClass('input_first');
				$selectLinksAll.addClass('input_first_on');
				fileShareGrid.selectAll();
			} else {
				$selectLinksAll.removeClass('input_first_on');
				$selectLinksAll.addClass('input_first');
				fileShareGrid.unSelectAll();
			}

		});


		$sortBySize.click(function() {
			var arrow = $sortBySizeArrow;
			if (arrow.is(':hidden')) {
				arrow.show();
			}
			$sortByTimeArrow.hide();
			if (arrow.hasClass('m_time_down')) {
				$sortBySizeArrow.removeClass('m_time_down');
				$sortBySizeArrow.addClass('m_time_up');
				operate.sortHandler({
					sortField: 'size',
					sortType: 'asc'
				});
				return false;
			} else {
				$sortBySizeArrow.removeClass('m_time_up');
				$sortBySizeArrow.addClass('m_time_down');
				operate.sortHandler({
					sortField: 'size',
					sortType: 'desc'
				});
				return false;
			}
		});


		$sortByTime.click(function() {
			var arrow = $sortByTimeArrow;
			if (arrow.is(':hidden')) {
				arrow.show();
			}
			$sortBySizeArrow.hide();

			if (arrow.hasClass('m_time_down')) {
				$sortByTimeArrow.removeClass('m_time_down');
				$sortByTimeArrow.addClass('m_time_up');
				operate.sortHandler({
					sortField: 'time',
					sortType: 'asc'
				});
				return false;
			} else {
				$sortByTimeArrow.removeClass('m_time_up');
				$sortByTimeArrow.addClass('m_time_down');
				operate.sortHandler({
					sortField: 'time',
					sortType: 'desc'
				});
				return false;
			}
		});



		// 设置相关处理器 =============================================================
		fileShareGrid.setSelectedHandler(function(items, total) {
			var ids = [];
			$(items).each(function() {
				ids.push(this.id);
			});
			operate.selectHandler(ids, total);
		});
		fileShareGrid.setContextmenuHandler(function(e) {
			var menu = caiyun.ui.model.shareRightClickMenu;
			menu.openAndLocate(e);
		});

		function extraHoverToolHandler(event) {
			var $this = $(this);
			var itemId = $this.attr('id').split('_')[2];
			if ($this.hasClass('l_cancelshare')) {
				operate.delOutLinkForShare([itemId]);
			}
			event.stopPropagation();
			return false;
		}

		fileShareGrid.addEventListener('click','b.l_cancelshare',extraHoverToolHandler);

		// 添加文件，将彩云的文件信息转化为视图要显示的格式
		self.addFiles = function(files, inFront) {
			var items = [];
			$(files).each(function() {
				var data = new window.caiyun.ui.CyGridItem(this.linkID);
				data.type = 'file';
				// 第一列空对象
				data.colItems.push({});
				// 第二列文件信息
				// 缩略图
				var thumbnail = window.caiyun.util.Icon.getIcon(this, true);
				var lkName = this.lkName;
				//过滤&nbsp
				if (lkName.indexOf("&nbsp") >= 0) {
					re = new RegExp("&", "g");
					lkName = lkName.replace(re, "&amp;");
				}
				data.colItems.push({
					showName: lkName.substringName(25 , this.objType === 2),
					fileName: lkName,
					thumbnail: thumbnail,
					extraHoverTool: genExtraHoverTool({
						grid: fileShareGrid,
						rowItem: data
					})
				});
				// 第三列下载次数
				data.colItems.push({
					str: this.dlTimes
				});
				// 第四列分享人
				data.colItems.push({
					str: '我'
				});
				// 第五列分享时间
				data.colItems.push({
					str: util.formateLifeTime(this.ctTime)
				});

				items.push(data);
			});
			if (items.length > 0) {
				if (inFront) {
					fileShareGrid.unshiftItems(items);
				} else {
					fileShareGrid.pushItems(items);
				}
			}
		};

		// 绑定窗口滚动事件
		$(window).bind('scroll', function() {
			// 如果滚动到底部，触发加载更多事件
			if (caiyun.util.isScrollToBottom()) {
				if (visible) {
					operate.scrollLoadData();
				}
			}
		});

		// 监听进入到文件分享模块事件
		operate.onListen('enterFileShare', function() {
			visible = true;
			//window.caiyun.ui.model.myFileShareListView.hide();
			//fileShareScrollerWrapper.scrollTo(0);
			fileShareGrid.clear();
			self.show();
		});

		// 监听加载数据事件
		operate.onListen('loadData', function(data) {
			// 记录当前窗口滚动条位置
			var scrollTop = util.getScrollTop();
			addDatas(data);
			// 还原滚动条位置
			window.scrollTo(0, scrollTop);
			if (data.nodeCount == "0") {
				fileShareGrid.setEmptyStyle("");
			} else {
				fileShareGrid.show();
			}
		});

		operate.onListen('cancelFileShare', function(data) {
			//隐藏工具栏
			operate.selectHandler([]);
		});

		self.show = function() {
			visible = true;
			fileShareGrid.show();
			$("#sharelistView").hide();
		};

		self.hide = function() {
			visible = false;
			fileShareGrid.hide();
			// 隐藏
			operate.selectHandler([]);
		};

		self.enter = function() {

		};

		self.leave = function() {
			// 离开
			fileShareGrid.clear();
			$("#links_title").hide();
		};

	};

	// 鼠标右键菜单
	var shareRightClick = caiyun.ui.model.shareRightClickMenu;

	shareRightClick.init = function() {
		var menu;
		var operator = caiyun.fileShareOperate;
		var selecetData = [];
		var clips = [];
		// 创建右键菜单
		var menu = $('body').CyDropDownMenu({
			id: 'shareOperaionMenu',
			items: [{
				id: 'openFileShare',
				iconClass: 'ico-3-4',
				name: '查看详情',
				click: function() {
					operator.openFileShareInfo();
				},
				hiddenBy: function() {
					return !operator.canExecute('openFileShare');
				}
			}, {
				id: 'copyFileShare',
				iconClass: 'ico-3-5',
				name: '复制链接',
				click: function() {

				},
				hiddenBy: function() {
					return !operator.canExecute('openFileShare');
				}
			}, {
				id: 'cancelFileShare',
				iconClass: 'ico-3-6',
				name: '取消分享',
				click: function() {
					operator.delOutLinkForShare();
				},
				hiddenBy: function() {

				}
			}]
		})[0];

		menu.hover(function() {}, function() {
			menu.close();
			$('#copyFileShare').removeClass('hover');
			destroyZeroClipboard();
		});

		//绑定flash事件
		var flashHandler = function(selecetData) {

			//var copyText = selecetData.url;
			var copyText = centreLinkId == '' ? selecetData.url : selecetData.url + "&centreLinkId=" + centreLinkId;

			if (selecetData.passwd != null && selecetData.passwd != "") {
				copyText += "  提取码：" + selecetData.passwd;
			}

			destroyZeroClipboard();
			var rightClickObj = new ZeroClipboard.Client();
			clips.push(rightClickObj);
			rightClickObj.setHandCursor(true);
			rightClickObj.setText(copyText);
			rightClickObj.glue("copyFileShare", "shareOperaionMenu");
			rightClickObj.addEventListener("complete", function() {
				caiyun.ui.iMsgTip.tip("复制成功", "success");
				destroyZeroClipboard();
				$('#copyFileShare').removeClass('hover');
				menu.close();
				caiyun.pvlog('fileLink', 'copyLink', selecetData.linkID); //统计复制文件外链
			});
		};

		var destroyZeroClipboard = function() {
			if (clips.length <= 0) {
				return false;
			}
			for (var n = 0; n < clips.length; n++) {
				if (null != clips[n]) {
					clips[n].destroy();
				}
			}
			clips = [];
		};

		operator.onListen('selectData', function(datas) {
			if (datas.length > 0) {
				var selectID = datas[0];
				selecetData = window.caiyun.util.cache.getFileShareCache(constants.FILE_SHARE_LIST_CACHEGROUP, selectID);
			}
		});

		var _scrollBegin = 0;
		// 传入右键点击的鼠标事件
		shareRightClick.openAndLocate = function(event) {
			var position = {
				top: event.clientY - 5, // 偏移几个像素使鼠标能够悬浮在菜单区域内
				left: event.clientX - 15
			};
			if (selecetData.passwd != null && selecetData.passwd != "") {
				$('#copyFileShare').html("<i class='ico-3-5'></i>复制链接和提取码");
			} else {
				$('#copyFileShare').html("<i class='ico-3-5'></i>复制链接");
			}

			menu.open();
			var menuHeight = menu.height();
			var windowHeight = $(window).height();
			// 判断菜单是否超过显示范围，超出则反过来显示
			if (position.top + menuHeight > windowHeight) {
				position.top = position.top - menuHeight + 10;
			}
			_scrollBegin = $(window).scrollTop();
			position.top += _scrollBegin;
			menu.locate(position, true);
			$(window).bind('scroll', locateByScroll);
			flashHandler(selecetData);

		};

		function locateByScroll() {
			var position = menu.getPosition();
			var newTop = $(window).scrollTop();
			position.top += (newTop - _scrollBegin);
			_scrollBegin = newTop;
			menu.locate(position, true);
		};

		// 阻止在右键菜单上再点击右键菜单
		menu.unbind('contextmenu').bind('contextmenu', function(e) {
			e.preventDefault();
			e.stopPropagation();
		});
	}

	caiyun.ui.initList.push(shareRightClick);
	caiyun.ui.initList.push(window.caiyun.ui.model.fileShareListView);
})();