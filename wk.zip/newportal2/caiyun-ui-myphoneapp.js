(function() {
	var self = {};
	var isAjaxing = null;  //正在请求的ajax对象
	var isScrollLoading = false;  //是否正在加载数据
	var listenerMap = {};
	var $myApplist = $('#myApplist');
	var $myApplistWrap = $('#myApplistWrap');
	var ajax = window.parent.caiyun?window.parent.caiyun.util.caiyunAjax.ajaxRequest:$.ajax; 
	var util = window.parent.caiyun.util;
	var app = function() {
		$('#myphone_area > div').hide();
		controller.applist();
	};
	var $noPic = '../images/newportal2/phone-application-logo2.gif'
	var appEmpty=function(){
		$('#appEmpty').show();
		$('#myApplist').hide();
	}
	var delClickfun = function(e){
		var _id = (typeof e.id)==='string'?e.id:e.id();
		var _cid = (typeof e.contentID)==='string'?e.contentID:e.contentID();
    	$('#'+_cid).remove();
    	$.getJSON("../webdisk2/myPhoneAct!removeApp.action",{removeAppId:_id},function(res){
 			//TODO
    		if($('#myApplistWrap ul li').length==0)
    			appEmpty();
   		});
   		//0930新增统计脚本
   		util.sendPvlog('fileOper','deleteApp');
	}
	var appVM = function(array) {
		var self = this;
		
		self.list = ko.observableArray(ko.utils.arrayMap(array, function(data) {
	        return { 
	        name: truncateContent(data.name,8,'...'), 
	        nametitle: data.name, 
	        versionName: "版本信息："+(data.versionName?truncateContent(data.versionName,9,'...'):'1.0'),
	        size: "大小："+formatSizeType(data.state==="2"?data.size:data.size*1024),
	        title:data.name,
	        iconURL:data.iconURL===null||!data.iconURL?$noPic:data.iconURL,
	        verNametitle:data.versionName?data.versionName:'1.0',
	        id:data.id,
	        contentID:data.contentID,
	        delClick:delClickfun
	        };
	    }));
	}
	var truncateContent = function(str,len,def){
		if(!str)return " ";
   		return str.length>len?str.substring(0,len)+def:str;
	};
	var formatSizeType = function(size)
	{
		size = parseInt(size)
   		return size>1024*1024?(Math.floor(size/1024/1024)*100 + Math.floor(size%1024%1024/1024*100))/100+"M":Math.round(size/1024)+"K"
	}; 
	var app2Vm = function(obj) {
		var self = this;
		this.nametitle = ko.observable(obj.name);

		this.name = ko.computed(function(){
			return truncateContent(obj.name,8,'...');
		});;
		this.size = ko.computed(function(){
			return "大小："+formatSizeType(obj.state==="2"?obj.size:obj.size*1024);
		});
		this.id=ko.observable(obj.id);
		this.contentID=ko.observable(obj.contentID);
		
		this.iconURL = ko.computed(function(){return obj.iconURL===null||!obj.iconURL?$noPic:obj.iconURL});
		this.versionName = ko.computed(function(){
			return "版本信息："+(obj.versionName?truncateContent(obj.versionName,8,''):'1.0');
		});
		this.verNametitle=ko.observable(obj.versionName);
		
		this.delClick=delClickfun;
	};
	self.appCache = [];
	self.index = 1;
	self.total = 1;
	self.size = 12;
	self.dw = 130;
	self.appPage = function(fun) {
		if(self.index < self.total){
			var _tmp = self.appCache.slice(self.index * self.size,  (self.index+1)*self.size);
			self.index++;
			return fun.call(null,_tmp);
		}
	}
	var initAppList = function(apps) {
		var element = document.getElementById('myApplist');
		var aVM = new appVM(apps.slice(0, 12));
		ko.applyBindings(aVM, element);
		$myApplistWrap.show();
		$myApplist.height(winHeigth+3);
		
		if(self.total>1||((self.appCache.length %3==0?Math.floor(self.appCache.length /3):Math.floor(self.appCache.length /3)+1)*self.dw)>winHeigth){	
			var scrollerWrapper = $('#myApplistWrap').CyScroller({
						id : 'myApplistCyScroller',
						className : 'right-main-sms-wrapper',
						autoHidden : true
					}, {
						onScrollToBottom : function(position, scroller) {
							var list = self.appPage(function(list){
							$(list).each(function() {
										aVM.list.push(new app2Vm(this));
									});
							//if(!$.browser.chrome&&winHeigth<525){
								$('.phone-application li').css('margin-bottom','2px').css('margin-top','2px');
								$('.phone-application li').last().css('margin-bottom','0px')
							//}
							});
							scrollerWrapper.updateScroller();
						}
					})[0];
			//$("#myApplistCyScroller").height($.browser.chrome?540:winHeigth);
			$("#myApplistCyScroller").height(winHeigth);		
			scrollerWrapper.updateScroller();
			
			
			//if(!$.browser.chrome&&winHeigth<525) {
				//$('.phone-application li').css('margin-bottom','2px').css('margin-top','2px');
			//}
			//3*110 3列的高度
			
			
			//ie FF 
		}
		return {
			hide : function() {
				$(element).hide();
			},
			show : function() {
				$(element).show();
			},
			resize : function(h) {

			},
			scrollerWrapper : scrollerWrapper,
			vm : aVM
		}
	};
	init = function() {
		isScrollLoading = true;
		
		if(isAjaxing)
		{
			isAjaxing.abort();
		}
		
		var succFun=function(params,result) {
			self.appCache = result.applist|| [];
			if(self.appCache.length==0){
				appEmpty();					
			}else{
				self.total = Math.floor(self.appCache.length / self.size)+ (self.appCache.length % self.size == 0 ? 0 : 1);
				self.applistHM = initAppList(self.appCache);
			}
		}
		succFun2=function(result) {
			self.appCache = result.applist|| [];
			if(self.appCache.length==0){
				appEmpty();					
			}else{
				self.total = Math.floor(self.appCache.length / self.size)+ (self.appCache.length % self.size == 0 ? 0 : 1);
				self.applistHM = initAppList(self.appCache);
			}
		}
		ajax({
			type : "post",
			url : "../webdisk2/myPhoneAct!applist.action",
			dataType : "json",
			hideLoading:true,
			succFun:succFun,
			success:succFun2
		});
	};
	init();
})();
