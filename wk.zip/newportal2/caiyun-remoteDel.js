/*
 * 远程删除
 */
(function(){
    var get_dina_passwd_success = $('#get_dina_passwd_success');    // 获取短信密码成功
    var get_dina_passwd_fail = $('#get_dina_passwd_fail');          // 获取短信密码失败的提示
    var sd_dwurl_msg_toomany = $('#sd_dwurl_msg_toomany');          // 发送下载链接短信次数超过限定提示框
    var mask_bg_layer = $('#mask_bg_layer');                       // 遮罩层
    
	var mcloud_phone = $("#mcloud_phone");
	var sendSMS = $("#sendSMS");
	
	mcloud_phone.bind("focus", function(){
	    if (mcloud_phone.val() == "您的手机号码"){
	        mcloud_phone.val('');
	    }
	}).bind("blur", function(){
	    if (mcloud_phone.val() == ""){
            mcloud_phone.val("您的手机号码");
        }
	}).bind("keyup", function(e){
	    if(e.which == 13) {
            sendSMS.click();
        }
	});
	
	sendSMS.click(function(){
        var target_phone_num = $.trim(mcloud_phone.val());
        
        if(target_phone_num === '' || ! /^1\d{10}$/.test(target_phone_num)) {
            mcloud_phone.focus();
            return false;
        }
        sendDownloadUrl(target_phone_num);
    });
    
    function sendDownloadUrl(target_phone_num, type) {
        var url = "../sendUrl.jsp";
        if(type) {
            url += '?type=' + type;
        }
        var data = {num: target_phone_num};
        var cb = function(json){
            if(json.code == 0) {
                get_dina_passwd_success.find('p').html('下载地址已发送到手机，请查收').end().show();
                setTimeout(function(){
                    get_dina_passwd_success.hide();
                }, 1500);
            } else if(json.code == 1){
                get_dina_passwd_fail.find('p').html('信息发送失败，请重试').end().show();
                setTimeout(function(){
                    get_dina_passwd_fail.hide();
                }, 2000);
            } else if(json.code == 2){
                sd_dwurl_msg_toomany.show();
                mask_bg_layer.show();
            }
        };
        
        $.post(url, data, cb, 'json');
    };
    
    $().ready(function(){
        cySetDiskSize();
    })
})();

