/**
 * MUSIC播放页面操作对象
 */
;caiyun.ui.model.musicBox = {}
;empty_callback = function(){
}
;(function(){
	// 本地缓存全局变量
    var box = caiyun.ui.model.musicBox;
    
    var CONSTANTS = {};
    CONSTANTS.UIID = "musicBox";
    var id;
    var flashvars = {
    		//onPlayerLoaded设置回调函数，当flash加载完成后，调用onPlayerLoaded绑定的js函数
    		"onPlayerLoaded":"_musicInitCallback",
    		"onPanelShow":"_musicOnPanelShowing"
    };
    var flashparams = {
    		quality:"autolow",
    		scale:"noscale",
    		loop:"true",
    		wmode:"transparent",
    		AutoStart:"-1",
    		menu:"true",
    		devicefont:"false",
    		allowFullScreen:"true",
    		allowScriptAccess:"sameDomain"
    };
    
    var $box = $('#'+CONSTANTS.UIID);
    var $boxDiv = $('.musicBoxDiv');
    var $boxCon = $('#musicContainer');
    var player;
    
    // 获取flash播放器
    var getPlayer = function(){
    	return swfobject.getObjectById(CONSTANTS.UIID);
    };
    
    // flash播放器加载完成后回调
    _musicInitCallback = function() {
    };
    
    // flash播放器panel切换回调
    _musicOnPanelShowing = function(flag) {
    	if(flag) {
    		box.popup();
    	}else {
    		box.collapse();
    	}
    };
    
    // 加载列表param contents[{id:string,title:string,url:string}]
    box.startPlay = function(contents){
    	try {
    		// 弹出控件
            box.popup();
            // 播放器展开
            mini(false);
            // 加载播放文件
    		var content = contents[0];
            getPlayer().playSong(content);
            $('.music_close').unbind('click').bind('click',function(){
		        box.close(content.id);
		    });
		} catch (e) {
			
		}
    };
    
    //播放器展开和收起
    function mini(fal){
	    getPlayer().mini(fal);
    }
    
    // 音乐播放控件弹出
    box.popup = function(){
    	$boxDiv.animate({"right":"10px"},"normal",null,function(){});
    	$(".musicBoxDiv #close").css({right:"-8px"});
    	$boxCon.attr("class","mp3_out");
    };
	
	// 音乐播放控件收起
    box.collapse = function(){
    	// right:-389(full)+99(square)
    	$boxDiv.animate({"right":"-270px"},"normal",null,function(){});
    	$(".musicBoxDiv #close").css({right:"280px"});
    	$boxCon.attr("class","mp3_in");
	};
	
	// 音乐播放控件关闭
    box.close = function(id){
    	$boxDiv.animate({"right":"-389px"},"normal",null,function(){});
    	$boxCon.attr("class","mp3_no");
    	//音乐播放器监听事件
    	window.caiyun.operate.mp3PlayerClose(id);
    	//清空播放列表
    	var newcontent = {
			"id":"no content",
			"title":"暂无歌曲",
			"url":""
		};
		getPlayer().playSong(newcontent);
	};
	
	// 销毁音乐播放控件
	box.destroy = function() {
	};
    
	// 初始化音乐播放控件
	var initPlayer = function(){
		swfobject.embedSWF("../flash/caiyunMusicPlayer.swf?nonce"+new Date().valueOf(),
				CONSTANTS.UIID,389,99,"9.0.0","Expressinstall.swf",flashvars, flashparams);
    };
    
    // 要接收上UI变化时间的对象方法
    var eventReceivers = $([]);
    
    // 广播控件Close事件
	var closeNotice = function(obj) {
		var listeners = eventReceivers || {};
		$.each(listeners, function() {
			this.call(null,obj);
		});
	};
	
    // 注册监听
	box.onCloseListen = function(fun) {
		eventReceivers.push(fun);
		return this;
	};
	// 删除监听
	box.removeCloseListen = function(key) {
		delete eventReceivers[$.trim(key)];
		return this;
	};
	
	// 初始化播放控件musicBox
	box.init = function() {
		initPlayer();
		
	};
	
	// 添加音乐播放到ui列表
	caiyun.ui.initList.push(box);
})(this)