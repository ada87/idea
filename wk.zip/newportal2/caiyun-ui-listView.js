﻿/**
 * 文件列表视图
 */
(function() {
    var constants = window.caiyun.constants;
    var judgement = window.caiyun.judgement;
    var util = window.caiyun.util;
    var self = window.caiyun.ui.model.listView;
    var profile = caiyun.profile;
    self.init = function() {
        var operate = window.caiyun.operate;
        var cache = window.caiyun.util.cache;
        var fileShareOperate = window.caiyun.fileShareOperate;
        var visible = true;
        var disable = true;
        var checkBoxCol = new caiyun.ui.CyGridColumns.SelectCheckBox();
        checkBoxCol.width = '5%';
        var fileInfoCol = new caiyun.ui.CyGridColumns.FileInfo();
        fileInfoCol.width = '60%';
        var sizeCol = new caiyun.ui.CyGridColumns.Words();
        sizeCol.width = '18%';
        var dateCol = new caiyun.ui.CyGridColumns.Words();
        dateCol.width = '17%';
        var fileGrid = window.caiyun.ui.CyDefaultGrid({
            renderId: 'listView',
            row: new caiyun.ui.CyGridRows.SelectedRow(),
            columns: [checkBoxCol, fileInfoCol, sizeCol, dateCol],
            dropable: true
        });

        // 做一个消除文件列表的代理
        fileGrid.clear = (function(clear) {
            return function() {
                var pid = profile.time('clearList', fileGrid.getItems().length);
                clear.apply(this);
                profile.timeEnd(pid);
            };
        })(fileGrid.clear);

        //判断是否可以显示图标的缩略图
        var isImagePreview = function(contentType) {
            return 1 == contentType || 3 == contentType ? true : false;

        };

        //判断是否是外链文件
        var isLink = function(shareType) {
            return 1 == shareType || 3 == shareType ? true : false;

        };

        //判断是否是外链文件
        var isShare = function(shareType) {
            var shareFlag = shareType == 2 || 3 == shareType ? true : false;
            if (judgement.isInCurrentCatalogs(window.caiyun.constants.cannotModifyIDs.root_receiveShare) && !judgement.isEnterprisePath()) {
                shareFlag = false;
            }
            return shareFlag;

        };

        // 增加数据
        var addDatas = function(data) {
            if (data && visible) {
                var pid = profile.time('addDataToList');
                // 添加文件夹
                self.addFolders(data.cataloginfos);
                // 添加文件
                self.addFiles(data.contents || data.contentList);
                var fileCount = 0;
                if (data.cataloginfos) {
                    fileCount += data.cataloginfos.length;
                }
                if (data.contents) {
                    fileCount += data.contents.length;
                }
                if (data.contentList) {
                    fileCount += data.contentList.length;
                }
                profile.timeEnd(pid, fileCount);
            }
        };

        // 设置相关处理器 =========================================
        var changeGridHeight = function() {
            // var headerHeight=$("#cy_right_head").height()+$("#cy_header").height();
            var winHeight = $(window).height();
            fileGrid.setViewHeight(winHeight);
        };
        changeGridHeight();

        $(window).bind('resize', changeGridHeight);

        fileGrid.setSelectedHandler(function(items, total) {
            var ids = [];
            $(items).each(function() {
                ids.push(this.id);
            });
            operate.selectHandler(ids, total);
        });
        fileGrid.setOpenHandler(function(id) {
            operate.dbclickHandler({
                id: id
            });
        });
        // fileGrid.setClickColumHandler(function() {});
        fileGrid.setContextmenuHandler(function(e) {
            var menu = window.caiyun.ui.model.fileRightClickMenu;
            menu.openAndLocate(e);
        });
        fileGrid.setConfirmCreateItemHandler(function(param) {
            var folder = {};
            folder.catalogName = $.trim(param.newFolderName);
            folder.parentcatalogID = operate.getCurrentPathId();
            // 如果是我接收到的文件下，则需要传path参数
            if (judgement.isInCurrentCatalogs(window.caiyun.constants.cannotModifyIDs.root_receiveShare)) {
                var path = judgement.getPath(operate.getCatalogStack());
                var pathParam = {
                    path: path
                };
                $.extend(folder, pathParam);
            }
            var errorCode = operate.createFolder(folder);
            return errorCode ? false : true;

        });
        fileGrid.setConfirmRenameSelectedItemHandler(function(param) {
            var updateItem = param.item;
            operate.rename(updateItem.id, param.newName,
                function(params, result) {
                    //返回成功状态
                    if (result.result.retCode == "0") {
                        updateItem.name = result.result.retObj;
                        updateItem.time = util.formateLifeTime(util.simpleDateformat());
                        var item = fileGrid.getItemById(updateItem.id);
                        item.colItems[1].fileName = window.caiyun.util.htmlEscape(updateItem.name);
                        if (updateItem.name.length > 25) {
                            item.colItems[1].showName = updateItem.name.substringName(25, item.type === 'folder');
                        } else {
                            item.colItems[1].showName = updateItem.name;
                        }
                        item.colItems[1].showName = window.caiyun.util.htmlEscape(item.colItems[1].showName);
                        item.colItems[3].value = util.formateLifeTime(util.simpleDateformat());
                        fileGrid.updateItem(updateItem);
                    } else {
                        //显示系统错误，重试
                        window.caiyun.ui.iMsgTip.tip('系统繁忙,请重试！', "error");
                    }
                },
                function() {

                });
        });
        fileGrid.setLinkHandler(function(item) {
            operate.creatFileLink([item.id]);
        });
        fileGrid.setDownLoadHandler(function(item) {
            operate.userDownload([item.id]);
        });
        fileGrid.setShareHandler(function(item) {
            operate.createShareFile([item.id]);
        });
        /**
         * 设置判断列表项是否可以放置拖拽文件项
         * dragIds []被拖拽的文件Id dropId 要放置到的文件Id
         * function handler(dragIds, dropId)
         * 返回true表示可以放置，false表示不可以放置，不可以放置的列表项不触发放置效果
         */
        fileGrid.setItemDropableHandler(function(dragIds, dropId) {
            // 是否存在同步目录
            var hasSyncCatalog = false,
                isSelected = false,
                i = 0,
                id = null,
                dragItem = null,
                length = dragIds ? dragIds.length : 0;
            if (length === 0 || !dropId) {
                return false;
            }

            // 是否收到的分享目录
            if (dropId === constants.cannotModifyIDs.root_receiveShare) {
                window.caiyun.ui.iMsgTip.tip('"收到的分享"目录不支持拖拽移入文件或文件夹操作!', "error");
                return false;
            }

            var dropItem = cache.getFileCache(constants.FILE_LIST_CACHEGROUP,
                dropId);
            if (!dropItem || !dropItem.catalogID) {
                return false;
            }

            // 是否有同步目录
            for (; i < length; i++) {
                id = dragIds[i];
                //不能移动到已被选择的行中
                if (dropId === id) {
                    return false;
                }
                dragItem = cache.getFileCache(constants.FILE_LIST_CACHEGROUP,
                    id);
                if (!dragItem) {
                    return false;
                }
                if (judgement.isSyncCatalog(dragItem)) {
                    window.caiyun.ui.iMsgTip.tip('同步目录不能进行移动操作！', "error");
                    return false;
                }
            }

            return true;
        });
        /**
         * 设置在列表项内拖拽项被放置到放置项时触发事件的回调函数
         * dragIds Array 被拖拽的文件项
         * dropId Object 要放置到的文件项
         */
        fileGrid.setItemDropHandler(function(dragIds, dropId) {
            var params = {
                catalogIds: [],
                contentIds: []
            }, x = 0,
                len = dragIds.length,
                dragItem = null,
                id;
            var catalogIds = params.catalogIds,
                contentIds = params.contentIds;
            for (x = 0; x < len; x++) {
                id = dragIds[x];
                dragItem = cache.getFileCache(constants.FILE_LIST_CACHEGROUP,
                    id);
                if (dragItem.contentID) {
                    contentIds.push(dragItem.contentID);
                } else {
                    catalogIds.push(dragItem.catalogID);
                }
            }
            operate.dragMoveFiles(params, dropId);
        });
        /**
         * 设置将本地文件拖拽项被放置到放置项时触发事件的回调函数
         * files Array 被拖拽的本地电脑文件
         * dropId String 要放置到的文件夹ID
         */
        fileGrid.setLocalFileDropHandler(function(files, dropId) {
            var item = null;
            var dropItemId = null;
            item = cache.getFileCache(constants.FILE_LIST_CACHEGROUP,
                dropId);
            if (!item || item.contentID) {
                dropItemId = operate.getCurrentPathId();
            } else {
                dropItemId = item.catalogID;
            }
            // 是否收到的分享目录
            if (dropItemId === constants.cannotModifyIDs.root_receiveShare) {
                window.caiyun.ui.iMsgTip.tip('"收到的分享"目录不支持拖拽移入文件或文件夹操作!', "error");
                return false;
            }
             //是否是公共账号目录
            if (dropId === caiyun.constants.publisherAccountConstants.publisherDir) {
                window.caiyun.ui.iMsgTip.tip('目标目录不支持拖拽移入文件或文件夹操作', "error");
                return false;
            }
            operate.dragUploadFiles(files, dropItemId);
        });
        // // 设置相关处理器 =========================================

        // 注册文件操作监听事件======================================
        // 监听视图切换
        operate.onListen('viewSwitch', function(viewMode) {
            if (viewMode == constants.view.web) {
                self.show();
            } else {
                self.hide();
                fileGrid.clear();
            }
        });

        // // 绑定滚动事件触发加载文件
        $(window).bind('scroll', function() {
            if (visible && util.isScrollToBottom()) {
                operate.scrollLoadData();
            }
        });

        // 监听加载文件列表事件
        operate.onListen('loadData', function(data) {
            if (visible) {
                if (data.nodeCount == "0") {
                    if (judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)) {
                        if (judgement.isReceviteDir(operate.getCatalogStack())) {
                            fileGrid.setEmptyStyle(util.getEmptyHtmlStr("您还没有收到分享哦，不如先去分享给别人吧"));
                        } else {
                            fileGrid.setEmptyStyle(util.getEmptyHtmlStr(""));
                        }
                    } else {
                        fileGrid.setEmptyStyle(util.getEmptyHtmlStr("这里是空的哦，快点上传文件吧!"));
                    }
                } else {
                    fileGrid.clearEmptyStyle();
                    // 记录当前窗口滚动条位置
                    var scrollTop = util.getScrollTop();
                    addDatas(data);
                    // 还原滚动条位置
                    window.scrollTo(0, scrollTop);
                }
            }
        });

        // 监听删除文件事件
        operate.onListen('dropItems', function(ids) {
            if (ids && ids.length > 0) {
                fileGrid.removeItems(ids);
            }
        });

        //监听加载“我收到的文件”事件
        operate.onListen('loadReceiveData', function(data) {
            if (visible) {
                if (data.nodeCount == "0") {
                    fileGrid.setEmptyStyle(util.getEmptyHtmlStr("您还没有收到分享哦，不如先去分享给别人吧"));
                } else {
                    fileGrid.clearEmptyStyle();
                    // 记录当前窗口滚动条位置
                    var scrollTop = util.getScrollTop();
                    addDatas(data);
                    // 还原滚动条位置
                    window.scrollTo(0, scrollTop);
                }
            }
        });

        // 监听进入目录
        operate.onListen('enterDir', function() {
            if (!visible) {
                return;
            }
            if (fileGrid.getItems().length > 0) {
                fileGrid.clear();
            }
            // 还原滚动条位置
            window.scrollTo(0, 0);
        });

        // 监听刷新数据
        operate.onListen('reload', function() {
            if (!visible) {
                return;
            }
            fileGrid.clear();
        });

        // 监听创建目录
        operate.onListen('userCreateFolder', function(item) {
            if (!visible) {
                return;
            }
            //将滚动条移动到最上方
            window.scrollTo(0, 0);
            fileGrid.createItem('新建文件夹');
        });

        // // 监听重命名
        operate.onListen('userRename', function() {
            if (!visible) {
                return;
            }
            fileGrid.renameSelectedItem(function(item) {
                var name = item.colItems[1].fileName;
                if (item.type === 'file') {
                    return util.removeSuffix(name);
                } else {
                    return name;
                }
            });
        });

        // // 监听全选命令
        operate.onListen('selectAll', function() {
            if (disable || !visible) {
                return;
            }
            fileGrid.selectAll();
        });

        // // 监听取消全选命令
        operate.onListen('unSelectAll', function() {
            if (disable || !visible) {
                return;
            }
            fileGrid.unSelectAll();
        });

        // 监听有新收到的文件时显示图标的事件
        operate.onListen('changeNew', function() {
            var item = fileGrid.getItemById(window.caiyun.constants.cannotModifyIDs.root_receiveShare);
            if (item) {
                item.hasReciveNew = true;
                fileGrid.updateItem(item);
            }
        });

        // 监听分享已读
        operate.onListen('changeRecNew', function(id) {
            if (!id) {
                return false;
            }
            var item = fileGrid.getItemById(id);
            if (item) {
                item.hasReciveNew = false;
                fileGrid.updateItem(item);
            }
        });


        // 监听播放MP3
        var playingItemId = null;
        operate.onListen('mp3Player', function(itemId) {
            if (disable || !visible) {
                return;
            }
            if (playingItemId && playingItemId !== itemId) {
                var oldItem = fileGrid.getItemById(playingItemId);
                if (oldItem) {
                    oldItem.playing = false;
                    fileGrid.updateItem(oldItem);
                }
            }
            var item = fileGrid.getItemById(itemId);
            item.playing = true;
            fileGrid.updateItem(item);
            playingItemId = itemId;
        });

        // 监听MP3播放器关闭
        operate.onListen('mp3PlayerClose', function(itemId) {
            if (disable || !visible) {
                return;
            }
            var item = fileGrid.getItemById(itemId);
            if (item) {
                item.playing = false;
                fileGrid.updateItem(item);
            }
            playingItemId = null;
        });

        // 监听生成外链成功
        fileShareOperate.onListen('creatFileShare', function(fileShareInfosSet) {
            if (disable || !visible) {
                return;
            }
            if (fileShareInfosSet === null || fileShareInfosSet.length <= 0) {
                return false;
            }
            var objID = fileShareInfosSet[0].objID;
            var item = fileGrid.getItemById(objID);
            item.colItems[3].hasLink = true;
            fileGrid.updateItem(item);
        });

        // 监听取消外链成功
        fileShareOperate.onListen('cancelFileShare', function(objID) {
            if (disable || !visible) {
                return;
            }
            if (objID === null || objID == "'") {
                return false;
            }
            var item = fileGrid.getItemById(objID);
            item.colItems[3].hasLink = false;
            fileGrid.updateItem(item);
        });

        // END 注册文件操作监听事件==================================

        // 添加文件夹，将彩云的文件夹信息转化为视图要显示的格式
        self.addFolders = function(folders, inFront) {
            var items = [],
                toolbarShow = true,
                isReceiveShareFolder;
            // 如果在保险箱或者文件夹不显示悬浮
            if (judgement.isSafeBox()) {
                toolbarShow = false;
            }
            if (judgement.isEnterprisePath()) {
                toolbarShow = false;
            }
            if (judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)) {
                toolbarShow = false;
            }
            if (judgement.isReceviteDir(operate.getCatalogStack())) {
                isReceiveShareFolder = true;
            }
            if (judgement.isInPublisherDir() || judgement.isInDraftBox()) {
                toolbarShow = false;
            }
            $(folders).each(function() {
                var isNotFixed = true;
                // 如果是固定目录不出现悬浮
                if (judgement.isFixedCatalog(this) || this.catalogID === constants.publisherAccountConstants.publisherDir || this.catalogID === constants.publisherAccountConstants.draftBox) {
                    isNotFixed = false;
                } else {
                    isNotFixed = true;
                }
                var isRead = false;
                if (this.shareeInfoList) {
                    isRead = this.shareeInfoList.shareeInfo[0].readStus != 2 ? true : false;
                }
                var data = new window.caiyun.ui.CyGridItem(this.catalogID);
                data.unSelectable = true;
                data.hasShare = isShare(this.shareType);
                data.hasReciveNew = !isRead && isReceiveShareFolder;
                data.draggable = operate.canExecute("move", [this.catalogID]);
                data.unselectable = judgement.isSystemItem(data.id);
                data.type = 'folder';
                // 第一列空对象
                data.colItems.push({});
                // 第二列文件信息
                var showName = this.catalogName;
                if (showName.length > 25) {
                    showName = showName.substringName(25, true);
                }
                data.colItems.push({
                    showName: window.caiyun.util.htmlEscape(showName),
                    fileName: window.caiyun.util.htmlEscape(this.catalogName),
                    thumbnail: window.caiyun.util.Icon.getIcon({
                        id: this.catalogID,
                        shareType: this.shareType || '0',
                        suffix: 'folder'
                    }, true),
                    fromPath: operate.getFileSrc(this),
                    hasHoverTool: toolbarShow && isNotFixed
                });
                // 第三列文件大小
                data.colItems.push({
                    str: '---'
                });
                // 第四列文件时间
                data.colItems.push({
                    str: util.formateLifeTime(this.updateTime),
                    hasLink: isLink(this.shareType)
                });
                items.push(data);
            });
            if (items.length > 0) {
                if (inFront) {
                    fileGrid.unshiftItems(items);
                } else {
                    fileGrid.pushItems(items);
                }
            }
        };

        // 添加文件，将彩云的文件信息转化为视图要显示的格式
        self.addFiles = function(files, inFront) {
            var items = [],
                toolbarShow = true,
                isReceiveShareFolder;
            // 如果在保险箱下不显示悬浮工具条
            if (judgement.isSafeBox()) {
                toolbarShow = false;
            }
            if (judgement.isEnterprisePath()) {
                toolbarShow = false;
            }
            if (judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)) {
                toolbarShow = false;
            }
            if (judgement.isInPublisherDir() || judgement.isInDraftBox()) {
                toolbarShow = false;
            }
            if (judgement.isReceviteDir(operate.getCatalogStack())) {
                isReceiveShareFolder = true;
            }
            $(files).each(function() {
                var isRead = false;
                if (this.shareeInfoList) {
                    isRead = this.shareeInfoList.shareeInfo[0].readStus != 2 ? true : false;
                }
                var data = new window.caiyun.ui.CyGridItem(this.contentID);
                data.hasReciveNew = !isRead && isReceiveShareFolder;
                data.hasShare = isShare(this.shareType);
                data.type = 'file';
                data.hasVirus = this.safestate == 2;
                data.draggable = operate.canExecute("move", [this.contentID]);
                // 第一列空对象
                data.colItems.push({});
                // 第二列文件信息
                // 缩略图
                var thumbnail = window.caiyun.util.Icon.getIcon(this, true);
                var bigThumbnail = null;
                // 是否需要显示大缩略图
                if (isImagePreview(this.contentType)) {
                    data.bigThumbnail = thumbnail;
                }
                // 第二列文件信息
                var showName = this.contentName;
                if (showName.length > 25) {
                    showName = showName.substringName(25);
                }
                data.colItems.push({
                    showName: window.caiyun.util.htmlEscape(showName),
                    fileName: window.caiyun.util.htmlEscape(this.contentName),
                    thumbnail: thumbnail,
                    fromPath: operate.getFileSrc(this),
                    hasHoverTool: toolbarShow
                });
                // 第三列文件大小
                data.colItems.push({
                    str: util.formateSize(this.contentSize)
                });
                // 第四列文件时间
                data.colItems.push({
                    str: util.formateLifeTime(this.updateTime),
                    hasLink: isLink(this.shareType)
                });
                items.push(data);
            });
            /*
            $(files).each(function() {
                var data = {
                    id: this.contentID,
                    name: this.contentName,
                    time: util.formateLifeTime(this.updateTime),
                    fromPath: operate.getFileSrc(this),
                    url: window.caiyun.util.Icon.getIcon(this, true),
                    isFile: true,
                    isRename: operate.canExecute("rename", [this.contentID]),
                    isImagePreview: isImagePreview(this.contentType),
                    isVirus: this.safestate == 2,
                    isMove: operate.canExecute("move", [this.contentID]),
                    isLink: isLink(this.shareType),
                    isShare: isShare(this.shareType),
                    size: util.formateSize(this.contentSize),
                    toolsBar: toolbarShow
                };
                items.push(data);
            });
            */
            if (items.length > 0) {
                if (inFront) {
                    fileGrid.unshiftItems(items);
                } else {
                    fileGrid.pushItems(items);
                }
            }
        };

        self.show = function() {
            visible = true;
            fileGrid.show();
        };

        self.hide = function() {
            visible = false;
            fileGrid.hide();
            operate.selectHandler([]);
        };

        self.leave = function() {
            disable = true;
            fileGrid.clear();
        };

        self.enter = function() {
            disable = false;
        };

    };
    // 注册到页面初始化方法中
    window.caiyun.ui.initList.push(self);
})();