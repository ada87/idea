/*
 * 彩云缩略图视图对象，用knockout实现简单
 */
// 防止局部变量污染全局
(function() {
    // 消息主题
    var topics = caiyun.topics;
    // 记住自己是谁
    var self = caiyun.ui.model.thumbnailView;
    // 文件管理器
    var fileManager = caiyun.biz.fileManager;
    // 缩略图类
    var CyThumbnailList = caiyun.ui.CyThumbnailList;

    // 初始化方法
    self.init = function() {
        // 文件操作对象
        var fileOperator = caiyun.operate;

        // 工具类
        var utils = caiyun.util;
        
        // 判断工具类
        var judgement = window.caiyun.judgement;

        // 常量
        var constants = caiyun.constants;

        var element = document.getElementById('innerThumbnailView');
        
        var  $thumbnail = $(element);

         // 由于用knockout实现，第一步就是绑定model和view
        var view = new CyThumbnailList({
            emptyTargetId : 'humbnailView_emptyStyle',
            renderTargetId : 'list-thumb',
            targetId : 'innerThumbnailView',
            fileIdPrefix : 'thumbnail_'
        });

        var visible = true;
        
        //判断是否是分享文件
        var isShare = function(shareType) {
            var shareFlag = shareType == 2 || 3 == shareType ? true : false;
            if (judgement.isInCurrentCatalogs(window.caiyun.constants.cannotModifyIDs.root_receiveShare) && !judgement.isEnterprisePath()) {
                shareFlag = false;
            }
            return shareFlag;

        };

        // 绑定滚动事件触发加载文件
        $(window).bind('scroll',function(){
            if(visible && utils.isScrollToBottom()){
                fileOperator.scrollLoadData();
            }
        })
        
        /*var $body = $(document.body);
        $body.on('dragover', '#innerThumbnailView li', function(event){
            utils.Event.stopPropagation(event);
            utils.Event.preventDefault(event);
            var $Li = $(utils.Event.getTarget(event)).parents('li');
            if ($Li.attr('type') !== 'file') {
                $Li.addClass('hover');
            }
        });
        
        $body.on('dragleave', '#innerThumbnailView li', function(event){
            utils.Event.stopPropagation(event);
            utils.Event.preventDefault(event);
            var target = utils.Event.getTarget(event);
            if (target.tagName.toLowerCase() == 'li') {
                $(target).removeClass('hover');
            } else {
                $(target).parents('li').removeClass('hover');
            }
        });*/
        
        // 绑定上下左右键的事件
       $(document).bind(
	        'keydown',
	        {
	          util : utils,
	          thumbnailList : view
	        },
	        function(event){
	            if (!visible) {
	               return;
	            }
	            var data = event.data;
	            var thumbnailList = data.thumbnailList;
	            thumbnailList.keyHandler(event);
	        }
	    );
        
        // 添加文件夹，将彩云的文件夹信息转化为视图要显示的格式
        self.addFolders = function(folders, inFront) {
            var items = [];            
            $(folders).each(function() {
                  var isread=false;
                  if(this.shareeInfoList){
                    isread=this.shareeInfoList.shareeInfo[0].readStus==2 ? true:false;
                  }
                var data = {
                    fileID : this.catalogID,
                    fileName : this.catalogName,
                    fileType : 'folder',
                    catalogType : this.catalogType, // 判断同步目录要用到该属性
                    isFixedDir : this.isFixedDir, // 判断系统固定目录要用到该属性
                    date : this.updateTime,
                    imgPath : caiyun.util.Icon.getIcon({id:this.catalogID,shareType:this.shareType||'0',suffix : 'folder'}, false),
                    // 固定目录，收到的分享目录不能分享和外链
                    share : isShare(this.shareType),
                    linkedFile : (this.shareType === '1' || this.shareType === '3') && !caiyun.judgement.isFixedCatalog(this),
                    virus : null,
                    isRead:isread,
                    isVideo : false,
                    inReceviteShareDir : judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare),
                    inEnterpriseDir : judgement.isEnterprisePath(),
                    unselectAllable : judgement.isSystemItem(this.catalogID)
                };
                items.push(data);
            });
            
            if (items.length > 0) {
                if (inFront) {
                    view.unshiftItems(items);
                } else {
                    view.pushItems(items);
                }
            }
            
        };

        // 添加文件，将彩云的文件信息转化为视图要显示的格式
        self.addFiles = function(files, keyWord, inFront) {
            var items = [];
            $(files).each(function() {
                var isread=false;
                if(this.shareeInfoList){
                    isread=this.shareeInfoList.shareeInfo[0].readStus==2 ? true:false;
                }
                var data = {
                        fileID : this.contentID,
                        fileName : this.contentName,
                        keyWords : keyWord,
                        fileType : 'file',
                        catalogType : null, // 判断同步目录要用到该属性
                        isFixedDir : null, // 判断系统固定目录要用到该属性
                        date : this.updateTime,
                        imgPath : caiyun.util.Icon.getIcon(this, false),
                        share : isShare(this.shareType),
                        linkedFile : (this.shareType === '1' || this.shareType === '3'),
                        virus : thirdFlag.killVirus&&this.safestate == '2', // true 有毒
                        isRead:isread,
                        isVideo : judgement.isVideo(this), // 视频文件，contentType值是3
                        inReceviteShareDir : judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare),
                        inEnterpriseDir : judgement.isEnterprisePath(),
                        unselectAllable : false
                    };
                items.push(data);
                
                // TODO 如果加载图片失败显示默认图标

                // TODO 是否可以播放，增加播放事件

            });
            
            if (items.length > 0) {
                if (inFront) {
                    view.unshiftItems(items);
                } else {
                    view.pushItems(items);
                }           
            }
            
        };

        // 隐藏
        self.hide = function() {
            view.unSelectAll();
            $thumbnail.hide();
            visible = false;
        };

        // 显示
        self.show = function() {
            $thumbnail.show();
            visible = true;
        };

        // 进入回调
        self.enter = function(newView, oldView, data) {
            // TODO 替换文件为空的提示文字
        };

        // 离开回调
        self.leave = function() {
            view.unSelectAll();
            // 清空提示，否侧每次leave时调用view.clear()后，会先显示空文件夹的提示，然后显示文件
            view.setEmptyStyle('');
            view.clear();
        };

        // TODO 绑定文件处理函数
        // 右键
        view.setContextmenuHandler(function(target, event) {
            var menu = caiyun.ui.model.fileRightClickMenu;
            menu.openAndLocate(event);
        });

        // 被选中
        view.setSelectedHandler(function(selectedItems) {
            var ids = [];
            $(selectedItems).each(function() {
                if (this.fileID) {
                    ids.push(this.fileID);
                }
            });
            fileOperator.selectHandler(ids, ids.length);
        });

        // 打开文件
        view.setOpenHandler(function(target) {
            var file = target;
            fileOperator.dbclickHandler({
                id : file.fileID
            });
        });

        // 创建文件夹处理器
        view
                .setConfirmCreateItemHandler(function(name) {
                    var judgement = caiyun.judgement;
                    var params = {
                        catalogName : $.trim(name),
                        parentcatalogID : fileOperator.getCurrentPathId()
                    };
                    // 如果是我接收到的文件下，则需要传path参数
                    if (judgement
                            .isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)) {
                        var path = judgement.getPath(fileOperator
                                .getCatalogStack());
                        var pathParsm = {
                            path : path
                        };
                        $.extend(params, pathParsm);
                    }
                    fileOperator.createFolder(params);
                });

        // 重命名文件处理器
        view.setConfirmRenameSelectedItemHandler(function(target) {
            var oldName = utils.removeSuffix(target.fileOldName);
            var newName = $.trim(target.newName);
            if (oldName == newName) {
                return true;
            }
            var errorCode = fileOperator.rename(target.fileID, newName, function(params,result) {
                if (result.result.retObj) {
                    target.fileName = result.result.retObj;
                } else {
                    target.fileName = newName;
                }
                view.updateItem(target);
            }, function() {
                target.fileName = oldName;
            });

            // 如果检查有错误，则不关闭重命名框
            if (errorCode) {
                return false;
            }

            return true;
        });
        
        /**
         * 设置判断列表项是否可以放置拖拽文件项
         * dragItems {CyThumbnailItem Array}被拖拽的文件项 dropItem {CyThumbnailItem} 要放置到的文件项            
         * function handler(dragItems, dropItem){ return true ; //
         * 返回true表示可以放置，false表示不可以放置，不可以放置的列表项不触发放置效果 };
         */
        view.setItemDropableHandler(function(dragItems, dropItem){
            // 是否存在系统默认目录
            var hasFixedCatalog = false,
                hasSyncCatalog = false,
                i = 0,
                length = dragItems ? dragItems.length : 0;
            
            if (length === 0 || dropItem.selected || dropItem.fileType === 'file') {
                return false;
            }
            
            // 不能将文件(夹)拖拽到"收到的分享"目录
            if (judgement.isReceiveShareFolder(dropItem.fileID)) {
                window.caiyun.ui.iMsgTip.tip('"收到的分享"目录不能支持移动操作！',"error");
                return false;
            }
            
            for (i = 0, length = dragItems.length; i < length; i++) {
                // 是否有同步目录
                if(judgement.isFixedCatalog(dragItems[i])){
                    hasFixedCatalog = true;
                    break;
                }
                
                // 是否有同步目录
                if(judgement.isSyncCatalog(dragItems[i])){
                    hasSyncCatalog = true;
                    break;
                }
            }
            
            if (hasFixedCatalog) {
                window.caiyun.ui.iMsgTip.tip('系统默认目录不能进行移动操作！',"error");
                return false;
            }
            if (hasSyncCatalog) {
                window.caiyun.ui.iMsgTip.tip('同步目录无法移动！',"error");
                return false;
            }
            return true;
        });
        
        /**
         * 设置拖拽项被放置到放置项时触发drop事件的回调函数
         * dragItems {CyThumbnailItem Array}被拖拽的文件项 
         * dropItem {CyThumbnailItem}要放置到的文件项 
         */
        view.setItemDropHandler(function(dragItems, dropItem){
            var targetDirID = dropItem.fileID || window.caiyun.operate.getCurrentPathId();
            var catalogIds = [],
                contentIds = [],
                i = 0,
                length = 0,
                dragItem = null;
        
            for (i = 0, length = dragItems.length; i < length; i++) {
                dragItem = dragItems[i];
                if (dragItem.fileType === 'file') {
                    contentIds.push(dragItem.fileID);
                } else {
                    catalogIds.push(dragItem.fileID);
                }
            }
            fileOperator.dragMoveFiles({
                catalogIds : catalogIds,
                contentIds : contentIds
            }, targetDirID);
        });

        // 注册文件操作监听事件
        // 进入目录
        fileOperator.onListen('enterDir', function() {
            if (!visible) {
                return;
            }
            // 清空提示，否侧每次enter folder时调用view.clear()后，会先显示空文件夹的提示，然后显示文件
            view.setEmptyStyle('');
            view.clear();
            window.scrollTo(0,0);
        });

        // 刷新数据
        fileOperator.onListen('reload', function() {
            if (!visible) {
                return;
            }
            // 清空提示，否侧每次reload时调用view.clear()后，会先显示空文件夹的提示，然后显示文件
            view.setEmptyStyle('');
            view.clear();
            window.scrollTo(0,0);
        });

        // 创建目录
        fileOperator.onListen('userCreateFolder', function() {
            if (!visible || judgement.isSearchCatalog()) {
                return;
            }
            window.scrollTo(0, 0);
            if (view.thumbnailItems.length === 0) {
	            // 隐藏空文件夹提示
	            view.displayEmptyFolderStyle(view.emptyStyle, 'none');
            }
            view.createItem();
        });

        // 监听重命名
        fileOperator.onListen('userRename', function(selected) {
            if (!visible) {
                return;
            }
            // 没选中不处理
            if (!selected || selected.length == 0) {
                return;
            }
            view.renameSelectedItem();
        });
        
         // 监听全选命令
        fileOperator.onListen('selectAll', function() {
            if (!visible) {
                return;
            }
            view.selectAll();
        });
        
        // 监听取消全选命令
        fileOperator.onListen('unSelectAll', function() {
            if (!visible) {
                return;
            }
            view.unSelectAll();
        });

        // 向缩略图添加数据
        var addData = function(data) {
            if (!visible) {
                return;
            }
            
            if(data.nodeCount == "0"){
                // 设置空文件提示
                if(judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)){
                    if(judgement.isReceviteDir(fileOperator.getCatalogStack())){
                        view.setEmptyStyle(utils.getEmptyHtmlStr("你还没有收到分享哦，不如先去分享给别人吧!").html());
                    }else{
                        view.setEmptyStyle(utils.getEmptyHtmlStr('').html());
                    }
                } else if (judgement.isEnterprisePath()){
                    view.setEmptyStyle(utils.getEmptyHtmlStr('').html());
                } else {
                    view.setEmptyStyle(utils.getEmptyHtmlStr("这里是空的哦，快点上传文件吧!").html());
                }
                view.displayEmptyFolderStyle(view.emptyStyle, 'block');
                return;
            }
            
            // 记录当前窗口滚动条位置
            var  scrollTop = utils.getScrollTop();
            // 添加文件夹
            self.addFolders(data.cataloginfos);
            // 添加文件
            self.addFiles(data.contents || data.contentList,data.keyWord);
            // 还原滚动条位置
            window.scrollTo(0,scrollTop);
            // 隐藏空文件夹提示
            view.displayEmptyFolderStyle('', 'none');
            // 如果选中全选文件(夹)checkbox，加载新文件(夹)后，选中新加载的文件(夹)
            fileOperator.selectHandler(view.getSelectedItems(), view.thumbnailItems.length);
            
        };

        // TODO "我收到的文件"提示
        var showChangeTips = function() {
            $(view.thumbnailItems).each(function(index, thumbnailItem) {
                if (caiyun.judgement.isReceiveShareFolder(thumbnailItem.fileID)) {
                    thumbnailItem.isNew = true;
                    view.updateItem(thumbnailItem);
                }
            });
        };

        //“我收到的文件”目录下New标识的隐藏
        var hideChangeTips = function(contentID){
            $(view.thumbnailItems).each(function(index, thumbnailItem) {
                if (thumbnailItem.fileID == contentID) {
                    thumbnailItem.isNew = false;
                    view.updateItem(thumbnailItem);
                }
            });
        }

        fileOperator.onListen('changeRecNew', hideChangeTips);
        // 数据加载完成
        fileOperator.onListen('loadData', addData);

        // 监听加载“我收到的文件”事件
        fileOperator.onListen('loadReceiveData', addData);

        // 数据加载完成
        //fileOperator.onListen('loadSearchData', addData);
        
        // 监听加载文件列表事件
        fileOperator.onListen('loadSearchData', function(data) {
            if (!visible) {
                return;
            }
            
            if(data.count == 0){
                // 设置空文件提示
                view.setEmptyStyle(utils.getEmptyHtmlStr("没有符合条件的文件哦，换个词试试吧~").html());
                return;
            }

            // 记录当前窗口滚动条位置
            var  scrollTop = utils.getScrollTop();

            // 添加文件
            self.addFiles(data.contentList ,data.keyWord);
            // 还原滚动条位置
            window.scrollTo(0,scrollTop);            
            // 如果选中全选文件(夹)checkbox，加载新文件(夹)后，选中新加载的文件(夹)
            fileOperator.selectHandler(view.getSelectedItems(), view.thumbnailItems.length);
        });

        // 收到的分享里有新文件时显示提示icon
        fileOperator.onListen('changeNew', showChangeTips);

        // 视图切换
        fileOperator.onListen('viewSwitch', function(viewMode) {
            if (viewMode == constants.view.win) {
                self.show();
            } else {
                self.hide();
                // 清空提示，否侧每次viewSwitch时调用view.clear()后，会先显示空文件夹的提示，然后显示文件
                view.setEmptyStyle('');
                view.clear();
            }
        });
        
        // 监听播放MP3，itemId {String} 文件id
        fileOperator.onListen('mp3Player', function(itemId) {
            var i = 0;
            var itemsLength = 0;
            var thumbnailItem = null;
            if (!visible) {
                return;
            }
            for (i = 0, itemsLength = view.thumbnailItems.length; i < itemsLength; i++) {
                thumbnailItem = view.thumbnailItems[i];
                if (itemId === thumbnailItem.fileID) {
                    view.mp3PlayingItem ? view.mp3PlayingItem.playMusic('') : '';
                    view.mp3PlayingItem = thumbnailItem;
                    thumbnailItem.playMusic('thumbnail_music_color');
                    break;
                }
            }
        });
        
        // 监听关闭播放MP3，itemId {String} 文件id
        fileOperator.onListen('mp3PlayerClose', function(itemId){
            var i = 0;
            var itemsLength = 0;
            var thumbnailItem = null;
            if (!visible) {
                return;
            }
            for (i = 0, itemsLength = view.thumbnailItems.length; i < itemsLength; i++) {
                thumbnailItem = view.thumbnailItems[i];
                if (itemId === thumbnailItem.fileID) {
                    view.mp3PlayingItem ? view.mp3PlayingItem.playMusic('') : '';
                    view.mp3PlayingItem = null;
                    break;
                }
            }
        });
        
        // 监听创建 "分享链接"事件
        window.caiyun.fileShareOperate.onListen('creatFileShare', function(fileShareInfosSet){
            var i = 0,  
                length = fileShareInfosSet.length,
                itemsLength = view.thumbnailItems.length;
            var fileShareInfo = null,
                thumbnailItem = null;
            if (!visible) {
                return;
            }
           for (i = 0; i < length; i++) {
                fileShareInfo = fileShareInfosSet[i];
                thumbnailItem = view.getThumbnailItem(fileShareInfo.objID);                thumbnailItem.linkedFile = true;
                view.updateItem(thumbnailItem);                break;
           }
        });
        
        // 监听创建 "取消链接"事件
        window.caiyun.fileShareOperate.onListen('cancelFileShare', function(objID){
            var itemsLength = view.thumbnailItems.length;
            if (!visible) {
                return;
            }
            thumbnailItem = view.getThumbnailItem(objID);
            thumbnailItem.linkedFile = false;
            view.updateItem(thumbnailItem);
        });     
        
        //监听删除事件
        fileOperator.onListen('dropItems', function(ids){
          if (!visible) {
              return;
          }
          view.removeItems(ids);
        });
        
    };

    // 将自己的初始化方法加载到ui的initList中
    caiyun.ui.initList.push(self);
})();
