window.caiyun = parent.window.caiyun;
window.caiyun.ui = parent.window.caiyun.ui;
window.caiyun.util = parent.window.caiyun.util;
window.caiyun.tips = parent.window.caiyun.tips;
