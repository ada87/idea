
(function(){
	var offline_down = caiyun.biz.offline_downlod;
	offlinedowloadinit = function(){
		var ui = caiyun.ui;
		var util = caiyun.util;
		var menu;
		var menuShow = false;
		var currrentCatalogID = '';
	/************************************************************************添加离线下载事件相关*****************************************************************************/
		var addOfflineTaskParames = {
			defaultUrlVal : '输入或粘贴需要下载的文件链接',
            bindEvnet: function(defaultUrlVal){
                //绑定input框事件
                util.textAutoTips("#offLine_url", {
                    focusFun: function(){
                        if ($("#add_errorMsg").html() != "") {
                            $("#add_errorMsg").html('');
                            $("#offLine_url").val('');
                        }
                    },
                    blurFun: function(){
                        var urlVal = $("#offLine_url");
                        str_url = urlVal.val().toLowerCase();
                        if (str_url != defaultUrlVal) {
                            if (/^(http|ftp):\/{2}\w/.test(str_url)) {
                                urlVal.attr("isUrl", "1");
                            }
                            else {
                                urlVal.attr("isUrl", "0");
                                $("#add_errorMsg").html('链接格式错误，请检查后重新输入');
                            }
                        }
                        
                    }
                });
            },
            
            urlDownloadHtml: function(defaultUrlVal){
                var sb = new StringBuffer();
                sb.append('<div class="off_line_tips_new" style="height:80px;background:#FFF;padding:12px">').append('<p class="n1" style="color:gray;">支持下载http,ftp等资源;彩云将帮您自动下载文件(单个文件最大2G)到目标文件夹</p>').append('<p class="n3" style="margin:10px;"><input id="offLine_url" type="text" name="offLine_url" value="').append(defaultUrlVal).append('" style="width:450px;height:25px" isUrl="0"></p>').append('<p class="n4" id="add_errorMsg" style="margin:10px;color:red"></p>').append('</div>');
                return sb.toString();
            },
            
            checkOfflineURL: {
                show: function(){
                    var arrayMsg = ['.', '..', '...'];
                    var i = 0;
                    var $checkDiv = $('<div id="offlin_fileCheck" style="position: absolute; left: 570px; top: 355px;' +
                    'z-index:22" class="ing_cleck"><span class="fon">正在检测文件，请稍等</span><span class="point">.</span></div>');
                    $('body').append($checkDiv).append('<div class="ScreenCss" id="offlin_overlay" style="opacity:0;width: 100%; height: 100%; display: block;z-index:21"></div>');
                    var $span = $checkDiv.find('.point');
                    setInterval(function(){
                        i = i == 3 ? 0 : i;
                        $span.html(arrayMsg[i++]);
                    }, 1000);
                },
                hide: function(){
                    $("#offlin_fileCheck,#offlin_overlay").remove();
                }
            }
        };
		
		/**
		 * 添加离线下载弹出框
		 */
		var addOfflineTask = ui.msgBox({
            title: "新建离线下载任务",
            html: addOfflineTaskParames.urlDownloadHtml(addOfflineTaskParames.defaultUrlVal),
            okHandle: function(){
                var urlVal = $("#offLine_url");
                if (urlVal.attr("isUrl") == "1") {
                    offline_down.addOfflineTask({
                        type: 'post', 
                        url: '../offlineDownload!addOfflineTask.action',
                        data: {
                            url: urlVal.val(),
							catalogID : currrentCatalogID
                        }, //参数
                        succFun: function(post, data){
                            var obj = data.result;
                           	addOfflineTaskParames.checkOfflineURL.hide();
                            if (obj && obj.message) {
                                ui.iMsgTip.tip(obj.message,"error");
                                return;
                            }
                            offlineQueryList.show();
							offlinelist_Paramers.bindEvnet(offlineQueryList);
							offlinelist_Paramers.manageOfflineTaskAjax();
                        }, //成功回调函数
                        errFun: function(){
							addOfflineTaskParames.checkOfflineURL.hide();
                            ui.iMsgTip.tip("系统繁忙,请稍后再试！","error");
                        }, //失败回调函数
                        hideLoading : true
                        
                    },function(){
						addOfflineTask.close();
                    	addOfflineTaskParames.checkOfflineURL.show();
						urlVal.val(addOfflineTaskParames.defaultUrlVal);
					});
                }
            },
            cancelHandle: function(){
                addOfflineTask.close();
            }
        });
		
		addOfflineTaskInit = function(){
			$("#offLine_url").attr("isUrl", "0");
			$("#add_errorMsg").html('');
            $("#offLine_url").val('输入或粘贴需要下载的文件链接');
		};
		
	
  /********************************************************************************离线下载列表相关*********************************************************************/
	
        var offlinelist_Paramers = {
			lodingHtml : '<img id="thumbnailOnloading" src="../images/wda5/large-loading.gif" style="width: 32px; height: 32px; position: absolute; left: 301px"/>',
            bindEvnet: function(urlListBox){
                //新建任务
                $('#newOfflineUrl').unbind('click').bind('click', function(e){
                    urlListBox.close();
                    addOfflineTask.show();
					addOfflineTaskInit();
					addOfflineTaskParames.bindEvnet(addOfflineTaskParames.defaultUrlVal);
                });
				
				/**
				 * 绑定取消或删除事件
				 */
                $("#id_offlineData").delegate("li span[id^='offline_btn_']", 'click', function(){
                    var steId = this.id.substr(this.id.lastIndexOf('_')+1).split('.'); 
					var type = steId[0];
					var contentId = steId[1];
					var html = '<div class="" style="padding:38px 0 0 35px;height:90px;"><div class="tip-getlink"><span class="ico-sign"></span><h3>确定要取消离线下载所选文件吗?</h3><p>取消后将无法恢复下载进度</p></div></div>';
					if(type == 'CANCEL'){
						var tips = ui.msgBox({
							title: "提示",
				            width: 650,
				            html: html,
				            okHandle: function(){
								tips.close();
								updateOfflineUrl(contentId,type);
				            },
							 cancelHandle: function(){
            					tips.close();
        					}
						});
						tips.show();
					}
					else{
						updateOfflineUrl(contentId,type);
					}
                });
				
				/**
				 * 绑定重试下载事件
				 */
				$("#id_offlineData").delegate("li span[id^='offline_retry_']", 'click', function(){
					var steId = this.id.substr(this.id.lastIndexOf('_')+1).split('.'); 
					updateOfflineUrl(steId[0],steId[1]);
				});
				
				/**
				 * 打开文件所在目录事件
				 
				$("#id_offlineData").delegate("li span[id^='offline_open_']", 'click', function(){
					//var steId = this.id.substr(this.id.lastIndexOf('_')+1).split('.'); 
					urlListBox.close();
				});*/
				
				/**
				 * 请求后台操作删除或重试下载
				 * @param {Object} contentIdc
				 * @param {Object} type
				 */
				var updateOfflineUrl = function(contentId,type){
					if(type != "RETRY"){
						type = "DELETE";
					}
					offline_down.updateOfflineTask({
						type    : 'post', 
						url     : '../offlineDownload!updateOfflineTask.action', 
						data    : {status:type,contentID:contentId},
						succFun : function(post,data){
							var obj = data.result;
							$('#id_offlineData').html(offlinelist_Paramers.lodingHtml);
							if(obj && obj.message){
							    ui.iMsgTip.tip(obj.message, "error");
							}
							offlinelist_Paramers.manageOfflineTaskAjax();
					  },
					  errFun : function(){
						ui.iMsgTip.tip("系统繁忙，请稍后再试！", "error");   
					  }
					});
				}
            },
            
            offline_listHtml: function(){
                var html = new StringBuffer();
                html.append('<div style = "padding:12px 12px 10px 12px;height:40px; background:#fafcfe;">')
				//append('<span id="newOfflineUrl" style="width:117px;height:29px;line-height:29px; text-align:center; color:#333; display:block; float:left; cursor:pointer;background:url(../images/webdisk4fection/off_line_icon.gif) 0px -232px no-repeat;">新建离线任务</span>')
				.append('<span id="newOfflineUrl" class="all-button btn-gray"><i class="ico-btn i-new-down"></i><span>新建下载</span></span>')
				.append('</div>')
				.append('<div id="offlineUrl_list" class="pop_download_main" style="overflow-x:hidden; position: relative; padding: 0px;border-top: 1px dotted #dcdcdc;height:277px">')
				.append('<ul id="id_offlineData">')
				.append(offlinelist_Paramers.lodingHtml)
				.append('</ul>')
				.append('</div>');
                return html.toString();
            },
            
            manageOfflineTaskAjax: function(){
				
                offline_down.queryOfflineInfo({
                    type: 'post',
                    url: '../offlineDownload!queryOfflineInfo.action',
                    succFun: function(post, data){
                        var obj = data.result;
                        var $dataUl = $('#id_offlineData').html('');
                        if (obj && obj.message) {
                            ui.iMsgTip.tip(obj.message,"error");
                            return;
                        }
						if(obj.retCode==0){
                        	if (obj.retObj && obj.retObj.length > 0) {
                            	offlinTaskDataView(obj.retObj, $dataUl);
                        	}
						}else{
							ui.iMsgTip.tip("系统繁忙,请稍后再试!","error");
						}
                    },
                    errFun: function(){
                       ui.iMsgTip.tip("系统繁忙，请稍后再试！","error");
                    }
                });
				
				var offlinTaskDataView = function(data, $dataUl){
                    $.each(data, function(i, n){
                        var liClass = i % 2 == 0 ? '' : 'class="bg"';
                        var btn_text = n.state == 6 ? '删除' : '取消';
                        var stateTxt;
                        switch (n.state) {
                            case 1:
                                stateTxt = '等待下载';
                                break;
                            case 5:
                                stateTxt = '<span style="color:red">下载失败</span>';
                                break;
                            default:
                                stateTxt = Math.floor(n.revSize / n.originalTotalSize * 100) + '%';
                                //stateTxt = stateTxt == '0%' ?  '正在下载' : '正在下载';
                                stateTxt = stateTxt == '100%' ? '任务完成' : '正在下载';
                        }
                        
                        var dataStr = '<li ' + liClass + ' id="' + n.contentID + '">' +
                        '<span title=' +
                        n.ctnName +
                        ' class="m1">' +
                        n.ctnName.substringName(24) +
                        '</span>' +
                        '<span class="m2">' +
                        n.totalSize +
                        '</span>' +
                        '<span class="m3">' +
                        stateTxt +
                        '</span>' +
                        '<span class="t_nav" class="m4">' +
                        '<span  id="offline_btn_' +
                        (n.state == 6 ? 'DELETE' : 'CANCEL') +
                        '.' +
                        n.contentID +
                        '">' +
                        btn_text +
                        '</span>' +
                        //(n.state == 6 ? '<span id="offline_open_' + n.contentID + '" style="padding-left:13px">打开所在目录</span>' : '') +
                        (n.state == 5 ? '<span id="offline_retry_' + n.contentID + '">重试</span>' : '') +
                        '</span>' +
                        '</li>';
                        $dataUl.append(dataStr);
                    });
                }
            }
			
			
        };
        
        /**
         * 离线文件列表窗体
         */
       var offlineQueryList = caiyun.ui.msgBox({
	            title: '离线下载任务列表',
	            width: 650,
	            type: 'offLineBox',
	            html: offlinelist_Paramers.offline_listHtml(),
				closeBox : function(){offlineQueryList.close();},
	            leftBtnName: '',
	            btnName: ''
	        });
	    /**
	     * 新建离线任务
	     */
		var newOfflineTask = function(){
			setCatalogID();
			addOfflineTask.show();
			addOfflineTaskInit();
			addOfflineTaskParames.bindEvnet(addOfflineTaskParames.defaultUrlVal);
		};
		
		/**
		 * 管理离线任务
		 */
		var managerOffineTask = function(){
			setCatalogID();
//			var offQueryList = caiyun.ui.msgBox({
//	            title: '离线下载任务列表',
//	            width: 650,
//	            type: 'offLineBox',
//	            html: offlinelist_Paramers.offline_listHtml(),
//				closeBox : function(){offlineQueryList.close();},
//	            btnName: ''
//	        });
//			offQueryList.show();
			offlineQueryList.show();
			offlinelist_Paramers.bindEvnet(offlineQueryList);
			offlinelist_Paramers.manageOfflineTaskAjax();
		}
		//下拉菜单对象
		var menu = $('#offlinedown_managerId').CyDropDownMenu({			
				items : [{ 
							id: 'newOfflineTask', 	     		
							name: '新建离线任务',
							click:function(){
								menu.close();
								newOfflineTask();
							} 
						},
						{ 
							id: 'managerOfflineTask', 	     		
							name: '查看离线任务',
							click:function(){
								menu.close();
								managerOffineTask();
							} 
						}
						]
				
			})[0];
			
		var initMenu = function(){
			var $_munu = $('#offlinedown_managerId').children('div');
			$_munu.css({'width':112});
			$_munu.children('a').css({'padding-left':22});
			var position = $('#offlinedown_managerId').position();
			menu.locate({left:-2,top:position.top+32},false);
			menu.hover(function(){
				
			},function(){
				menuShow = false;
				menu.close();
			});
		};
		
		var setCatalogID = function(){
			var judgement = window.caiyun.judgement;
			var operate = window.caiyun.operate
			var constants = window.caiyun.constants;
			
			var stack = operate.getCatalogStack();
			var isInVideo  = judgement.isInVideo(stack);
			if(isInVideo){
				currrentCatalogID = constants.rootIds.myFolder;
			}else{
				currrentCatalogID = operate.getCurrentPathId();
			}
		}
				
  /*********************************************************************************绑定离线下载事件********************************************************************/
		//离线下载
		$("#offlinedown_managerId").unbind().bind('click',function(){
			if(menuShow){
				menu.close();
				menuShow = false;
			}else{
				initMenu();
	       		menu.open();
				menuShow = true;
			}
			return false;			
		});
		
		$("#offlinedown_managerId").hover(function(){
			
		},function(){
			menu.close();
			menuShow = false;
		});
		
		// 点击其他地方时隐藏下拉列表
		$('body').bind('click',function(){
			if(menuShow){
				menuShow = false;
				menu.close();
			}
		});
		
	}
  /*****************************************************************************************初始化执行init方法*****************************************************************/	
	offlinedowloadinit();
	
})();