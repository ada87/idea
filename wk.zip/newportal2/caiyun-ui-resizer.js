/**
 * 自动控制大小
 */
(function(){
	window.caiyun.ui.resizer = (function(){
		
		/**
		 * 重新设置文件区域大小
		 */
		var _resizeFileContent = function(){
			//  头部
			var header = $('#header');
			//  脚
			var footer = $('#footer');
			
			// 文件类型条
			var fileTypeNav = $('#fileTypeNav');
			
			// 左侧高度，用于控制左侧栏
			var leftHeight;
			var fileTypeNavVisible = fileTypeNav.css('display') != 'none';
			if(fileTypeNavVisible){
				leftHeight = footer.offset().top - fileTypeNav.offset().top - fileTypeNav.height() -12;
			}else{
				leftHeight = footer.offset().top - header.offset().top - header.height();
			}
			// 左边栏离脚5像素
			leftHeight -= 5;
			
			// IE6再缩短
			if($.browser.msie && $.browser.version == '6.0'){
					//leftHeight -= 15;
			}
			
			// 左边栏和脚需要间隙
			$('#leftNav').height((leftHeight - 5) + 'px');
			
			$('.right-main').height(leftHeight + 'px');
			// 右侧高度，用于控制列表和缩略图的高度
			var rightHeight = leftHeight - 20;
			var currentView = caiyun.ui.model.fileContent.getCurrentView();
			var modelList = currentView.modelList;
			
			// 判断右边的功能按钮是否存在
			var rightArea = $('.right-main-one');
			var rightAreaVisible = rightArea.css('display') != 'none';
			if(rightAreaVisible){
				rightHeight -= rightArea.height();
			}
			
			// 判断路径条是否存在
			var pathBar = $('#pathBar');
			var pathBarVisible = pathBar.css('display') != 'none';
			if(pathBarVisible){
				rightHeight -= pathBar.height();
			}
			
			// 搜索的路径条是否存在
			var searchBathBar = $('#searchResultBar');
			var searchBathBarVisible = searchBathBar.css('display') != 'none';
			if(searchBathBarVisible){
				rightHeight -= searchBathBar.height();
			} 
			
			// 回收站路径条
			var recycleBar = $('#recycleBar');
			var recycleBarVisible = recycleBar.css('display') != 'none';
			if(recycleBarVisible){
				rightHeight -= recycleBar.height();
			}
			
			//分享管理的Tab
			var sharefileTab = $('#shareTab');
			var shareFileTabVisible = sharefileTab.css('display') != 'none';
			if(shareFileTabVisible){
				rightHeight -= sharefileTab.height();
			}
			
			// 减去工具条的高度
			rightHeight -= $('.thumb-title').height();
			
			// 缩略图重新设置大小
			window.caiyun.ui.model.thumbnailView.resize(rightHeight);
			// 文件列表重新设置大小
			window.caiyun.ui.model.listView.resize(rightHeight);
			// 分享列表重新设置大小
			window.caiyun.ui.model.fileShareListView.resize(rightHeight + rightArea.height() - 12);
			//分享文件列表重新设置大小
			window.caiyun.ui.model.myFileShareListView.resize(rightHeight + rightArea.height() - 12);
			// 回收站列表视图设置大小
			window.caiyun.ui.model.recycleBinView.resize(rightHeight);
			
		};
		
		$(window).bind('resize',_resizeFileContent);
		
		return {
			resizeFileContent : _resizeFileContent
		}
	})();
}
)();