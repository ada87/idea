/**
 * 文件分享对话框
 */
;(function(){
	
	var self =window.caiyun.ui.model.sharefilebox;
	
	self.init = function(){
		var constants = window.caiyun.constants;
		var ui = window.caiyun.ui;
		var fileShareOperate = window.caiyun.fileShareOperate;
		var fileShare = window.caiyun.biz.fileShare;
        var myFileShare  = window.caiyun.myFileShareOperate;
		var fileOperate = window.caiyun.operate;
		var cache = window.caiyun.util.cache;
		var util = window.caiyun.util;
		var judgement = window.caiyun.judgement;
		var cytxl = window.caiyun.biz.cytxl;
				
		var clips = [];//复制flash数组
		var cpTimeout = null;
		var selectedData = null;
		
		//SNS分享URL
		var share139Url = "http://app.weibo.10086.cn/apps/share/share.php";
		var shareQspaceUrl = "http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey";
		var shareSinaUrl = "http://service.weibo.com/share/share.php";
		var shareQQUrl = "http://share.v.t.qq.com/index.php";
		//SNS分享key
		var keySina = "1291715101";
		var keyQQ = "801132619";
		var key139 = "c057c76f2d9248b4f8c946d260a83d17";
		//SNS分享139的src值
		var src139 = "0051044100000";
		
		var defVal_mobile = "输入手机号码或从下方选择分享对象";
		
		var maxMsgNum = 50;  //单次最大发送短信数
		var maxMailNum = 100;  //单次最大发送邮件地址数
		
		var isSettingPass = false;
		
		var fileLinkBox = null;
		
		
		//创建文件外链
		var creatFileShare = function(){
			var data
			var catalogIds=[];
			var contentIds=[];			
			$(selectedData).each(function(i) {
				// 如果是目录
				if (selectedData[i].catalogID) {
					catalogIds.push(selectedData[i].catalogID);
				}
				// 如果是文件
				else if (selectedData[i].contentID) {
					contentIds.push(selectedData[i].contentID);
				}
			});
			
			var params = {
				caIDLsts:catalogIds.toString(),
				coIDLsts:contentIds.toString()
			}
			
			if(judgement.isEnterprisePath())
			{
				var path = judgement.getPathForEnterprise();
				$.extend(params,{path:path});
			}
			
			if (centreLinkId != '') { //判断是否为站长外链，如果是则不生成提取码
		    	$.extend(params,{encrypt:0});
			}
			//调用文件外链模块创建文件外链
			fileShareOperate.creatShareFiles(params);
		};
		
		
		//绑定外链对话框事件
		var fileLinkBoxEventsHandler = function(){
					
			var l_id = $(".share-link-box").attr("linkid");
			var l_name = $(".share-link-box").attr("name");
			//var l_name = l_id;
			var l_url = $(".share-link-box input").val();
			
			
			//绑定移动\腾讯\新浪微博分享 _wmx
			$(".share_to_139").unbind().bind('click',function(e){
				var l_pass = $("#linkpass").val();
				l_pass = l_pass ? ("提取密码:" + l_pass) : "" ;
				shareToSNS(l_name,l_url,l_pass,"139");
				caiyun.pvlog('fileLink','wbshare',l_id,"","","","139"); 
				return util.stopDefault(e);
			});
			$(".share_to_sina").unbind().bind('click',function(e){
				var l_pass = $("#linkpass").val();
				l_pass = l_pass ? ("提取密码:" + l_pass) : "" ;
				shareToSNS(l_name,l_url,l_pass,"sina");
				caiyun.pvlog('fileLink','wbshare',l_id,"","","","sina"); 
				return util.stopDefault(e);
			});
			$(".share_to_qq").unbind().bind('click',function(e){
				var l_pass = $("#linkpass").val();
				l_pass = l_pass ? ("提取密码:" + l_pass) : "" ;
				shareToSNS(l_name,l_url,l_pass,"qq");
				caiyun.pvlog('fileLink','wbshare',l_id,"","","","qq"); 
				return util.stopDefault(e);
			});
			
			//绑定短信分享事件 _wmx
			$(".share_to_sms").unbind().bind('click',function(e){
				linkMsgBox(l_id,l_url);
				return util.stopDefault(e);
			});
					
			//绑定邮件分享事件 _wmx
			$(".share_to_mail").unbind().bind('click',function(e){
				var l_pass = $("#linkpass").val();
				l_pass = l_pass ? ("提取密码:" + l_pass) : "" ;
				linkMailBox(l_id,l_name,l_url,l_pass);
				return util.stopDefault(e);
			});
			
			//取消、生成提取密码
			$("#pass_li").delegate("#modpass","click",function(){
				$(".set_pass_tip").hide();
				if(isSettingPass)
				{
					return false;
				}
				isSettingPass = true;
				var linkid = $(".share-link-box").attr("linkid");
				var passwdOpr = $(this).attr("toset");
				var data = {linkID:linkid,passwdOpr:passwdOpr};
				fileShare.updateInfo(data,setLinkPassSucc,setLinkPassFail);
			});
			
			bindFlash();  //绑定flash
			
		};
		
		
		//生成、取消提取码成功
		var setLinkPassSucc = function(params, json)
		{
			if(json && json.modOutLinkRsp && json.modOutLinkRsp.resultCode == "0")
			{
				if(json.passwdOpr && json.passwdOpr == 2)
				{
					var pass = json.modOutLinkRsp.passwd;
					//$("#linkpass").text(pass).show();
					//$("#modpass").text('取消提取密码').attr("toset","1");
					$(".get-code-box").remove();
					$("#modpass").remove();
					
					var newHtml = '<input class="get-code-box" id="linkpass" readonly="true" value="'+ pass +'" />'
								+ '<span class="cancel-code-btn" toset="1" id="modpass">取消提取密码</span>';
								
					$("#pass_li").append(newHtml);
					
					$("#copyLink").text("复制链接及密码");
					
					bindFlash();  //重新绑定flash事件
				}
				else
				{
					//$("#linkpass").text("").hide();
					//$("#modpass").text('生成提取密码').attr("toset","2");
					$("#linkpass").remove();
					$("#modpass").remove();
					
					var newHtml = '<span class="cancel-code-btn" toset="2" id="modpass">生成提取密码</span>';
					
					$("#pass_li").append(newHtml);
					
					$("#copyLink").text("复制链接");
					
					bindFlash();  //重新绑定flash事件
				}
			}
			else
			{
				$(".set_pass_tip").text("操作失败,请稍后再试").show();
			}
			isSettingPass = false;
		};
		
		//生成、取消提取码失败
		var setLinkPassFail = function(params, json)
		{
			$(".set_pass_tip").text("操作失败,请稍后再试").show();
			isSettingPass = false;
		};
		
		
		//取消外链成功
		var cancelFileShareSuccCallBack = function(params, response)
		{
			if(null == response)
			{
				caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试！", "error");
				return false;
			}
			if(null != response.showMessage && "" != response.showMessage)
			{	
				caiyun.ui.iMsgTip.tip("取消分享失败","error");
				return false;
			}else {
				if(response.resultCode == "0")
				{
					caiyun.ui.iMsgTip.tip("取消分享成功！", "success",3);
					fileShareOperate.triggerCancelFileShareSucc(params.data.objID);
				}
				else{
					caiyun.ui.iMsgTip.tip("取消分享失败","error");
				}
			}
		}
		
		//取消外链失败
		var cancelFileShareFailCallBack = function(params, response)
		{
			caiyun.ui.iMsgTip.tip("系统繁忙,请稍后再试.","error");
		}
		
		
		
		
		//短信分享对话框
		var linkMsgBox = function(linkid,dataurl) {
			var msgContent = '<div class="msm_share">'
							+ '<div class="share_left">'
							+ '<div class="share_left_title">'
							+ '<input type="text" id="mobile_link_seach" class="txtBg_01" value="' + defVal_mobile + '">'
							+ '</div>'
							+ '<div class="share_left_m">'
							+ '<ul id="mainTree" class="share_twoTree"></ul>'
							+ '<ul id="searchTree" class="search_twoTree"></ul>'
							+ '</div>'
							+ '</div>'
							+ '<div class="share_right">'
							+ '<div class="share_right_title">'
							+ '<h1 class=""><span style="color:#999999;">选中的分享对象</span></h1><span class="share_people_num" id="select_people_num">(0/50)</span>'
							+ '<span class="s_delete" id="select_people_clear">清空</span>'
							+ '</div>'
							+ '<div class="share_right_m" id="toMsgList"></div>'
							+ '</div>'
							+ '</div>'
							+ '<div class="border_bottom"></div>';
			
							
			var sendMsgWin = caiyun.ui.msgBox({
						title : "短信分享",
						html : msgContent,
						btnName : ["确定","取消"],
						masked : false,
						width : 710,
						type : "sharelink_msg",
						okHandle : function() {
								$(".msg-noavail-tip").text("").hide();
								if($("#toMsgList").find(".sp_r").length>0)
								{
									//$(".msg-noavail-tip").text("短信分享目前仅支持中国移动号码").show();
									//支持支持异网短信下发
									$(".msg-noavail-tip").text("请输入正确的手机号码").show();
									return false;
								}
								else
								{	
									var mobiles = getMobiles();
									if(mobiles.length==0)
									{
		        						$(".msg-noavail-tip").text("还没有选择分享对象哦~").show();
		        						return false;
		        					}
									shareToMsg(linkid,mobiles.join(",").toString(),sendMsgWin);
		        					//caiyun.fileShareOperate.shareLinkByMsg(linkid,mobiles.join(",").toString());
	            					caiyun.pvlog('fileLink','msgShare',linkid);  //短信分享PV统计
	            					//sendMsgWin.close();
								}
						}
			});
			sendMsgWin.show();// 弹出询问窗口
			initContactData();//初始化通讯录数据
    	};
    	
    	
		//外链邮件分享对话框
		var linkMailBox = function(l_id,l_name,l_url,l_pass){
			
			l_url = l_url.split("&")[0];
			
			var tempLinkMailHtml = "";
			if(null != linkMailHtml && "" != linkMailHtml)
			{
				tempLinkMailHtml = linkMailHtml.replace(/\[0\]/g,ownerMSISDN).replace(/\[1\]/g,util.splitName({name:l_name,maxLen:35}))
						.replace(/\[2\]/g,(l_url + "  " + l_pass)).replace(/\[p\]/g,"<p>").replace(/\[\/p\]/g,"</p>");
			}
			
			var mailContent = '<div class="email-share-address">'
							+ '<ul>'
							+ '<div id="toMailList"></div>'
							+ '<li class="select-ok" id="inputMailCont">'
							+ '<span>'
							+ '<input type="text" class="select_input"/>'
							+ '<em id="addToMailList"></em>'
							+ '</span>'
							+ '</li>'
							+ '</ul>'
							+ '</div>'
							+ '<div class="email-share-detail">'
							+ '<div class="email-noavail-tip"></div>'
							//+ '<p>'
							+ tempLinkMailHtml
							//+ '</p>'
							+ '</div>';
			
			var linkMailDialog = ui.msgBox(
								{
									title : "邮件分享",
									html : mailContent,
									btnName : ["确定","取消"],
									masked : false,
									width : 710,
									okHandle : function(){
										var mailAddrList = getMails();
										if(mailAddrList.length==0)
										{
											$(".email-noavail-tip").text("还没有选择分享对象哦~").show();
											return false;
										}
										else
										{
											$(".email-noavail-tip").hide();
											shareToMail(l_id,mailAddrList,linkMailDialog);
										}
										return false;
									}
								});
								
			linkMailDialog.show();
			linkMailEventHandler();
		};
		
		//绑定邮件分享对话框事件
		var linkMailEventHandler = function()
		{
			$("#inputMailCont .select_input").focus(function(){
				$(".email-noavail-tip").hide();
			}).unbind('keydown').bind('keydown',function(e){
				if(e.keyCode == "13"){
					$("#addToMailList").click();
				}
			});
			
			$("#addToMailList").unbind().click(function(){
				var addMailAddr = $.trim($("#inputMailCont .select_input").val());
				
				if(checkMailAddr(addMailAddr))
				{
					var addMaillAddrHtml = '<li class="select-cancel">' 
									+ '<span title="' + addMailAddr + '">'
									+ util.subStringByLen(addMailAddr,20)
									+ '<em class="delMailAddr"></em>' 
									+ '</span>' 
									+ '</li>';
									
					$("#toMailList").append(addMaillAddrHtml);
					
					$("#inputMailCont .select_input").val("");
					
					if(getMails().length >= maxMailNum)
		    		{
		    			$(".email-noavail-tip").text("每次最多支持"+maxMailNum+"个地址。").show();
		    			$("#inputMailCont").hide();
		    			return false;
		    		}
		    		
				}
				
			});
			
			$(".delMailAddr").live("click",function(){
				$(this).parents(".select-cancel").remove();
				if(getMails().length < maxMailNum)
				{
					$("#inputMailCont").show();
					$(".email-noavail-tip").text("").hide();
				}
			});
		};
		
		
		
		
		
		
		/**********************************联系人树对话框操作start*****************************************/
		
		//(联系人树对话框)初始化通讯录数据
		var initContactData = function()
		{
			if(linkData._isOpenCytxl)
			{
			    var groups = linkData._all;
				var treeHtml = getGroupHtml(groups);
				$('#mainTree').html(treeHtml).show();
				//initContactTreeHandler();
			}
			else
			{
				//显示未开通彩云通讯录
				showCytxl();		
			}
			initContactTreeHandler();
		};
		
		
		//(联系人树对话框)获取分组信息
		var getGroupHtml = function(groups)
		{
			var gHtml = new StringBuffer();
			$.each(groups,function(i){
				gHtml.append('<li class="group_li" name="')
				.append(groups[i].groupId)
				.append('"flag="group" load="true">')
				.append('<div class="checkbox" flag="group"></div>')
				.append('<label flag="group">')
				.append(util.formatHTMLEncode(util.subStringByLen(groups[i].groupName,8)))
				.append('</label>')
				.append('<b class="arrow expanded" flag="group"></b>')
				.append(getGroupItemHtml(groups[i].groupId,groups[i].list))
				.append('</li>');
			});
			return gHtml.toString();
		};
		
		
		//(联系人树对话框)获取组下联系人html
		var getGroupItemHtml = function(groupId,lists)
		{
			var itemHtml = new StringBuffer();
			if(lists.length>0){
				itemHtml.append('<ul style="display:block" flag="group">');
				$.each(lists,function(i){
					var mobile = "";
					if(lists[i].mobile){
						mobile = lists[i].mobile[0]?lists[i].mobile[0]:'';
					}
					mobile = util.replace86(mobile);
//					itemHtml.append('<li py="')
//						.append(lists[i].py)
//						.append('" name="')
					itemHtml.append('<li name="')
						.append(groupId).append('_').append(lists[i].contactId)
						.append('" nickname="')
						.append(lists[i].name ? util.formatHTMLEncode(lists[i].name) : "")
						.append('" title="')
						.append(mobile ? mobile : "")
						.append('">')
						.append('<div class="arrow" ></div>')
						.append('<div class="checkbox" flag="0"></div>')
						.append('<label>')
						.append(util.formatHTMLEncode(util.subStringByLen(lists[i].name,8)))
						.append('</label></li>');
				});
				itemHtml.append('</ul>');
			}
			return itemHtml;
		};
		
		
		//(联系人树对话框)绑定联系人树事件
		var initContactTreeHandler = function()
		{
			//树的展开收起
			$('#mainTree').delegate('li','click',function(){
				var $this = $(this);
				var $liChild = $this.children('.arrow');
				var $ulChild = $this.children('ul');
				if($liChild.hasClass('collapsed')){
					$liChild.removeClass('collapsed'); 
					$liChild.addClass('expanded');
					$ulChild.show();
				}else if($liChild.hasClass('expanded')){
					$liChild.removeClass('expanded');
					$liChild.addClass('collapsed');
					$ulChild.hide();
				}
				return false;
			});
			
			
			//联系人树群组选中、反选事件
			$('#mainTree').delegate('.group_li > .checkbox','click',function(){
				var arr = getMobiles();
				numCount = arr.length;
				var $this = $(this);
				var $ulChild = $this.next().next().next();
				if($this.hasClass('half_checked'))
				{
					$this.removeClass('half_checked');
					var $lis = $ulChild.children('li');
					$.each($lis,function(index,element){
						var nickName = $(element).attr('nickname');
						var id = $(element).attr('name');
						var title =$(element).attr('title');
						var data = {name:id,nickname:nickName,mobile:title};
						$(element).children('.checkbox').removeClass('checked');
						deletFromHtml(data);
					});
				}
				else
				{
					if (numCount < maxMsgNum) 
					{
						var $lis = $ulChild.children('li').slice(0,(maxMsgNum - numCount));
						$this.addClass('half_checked');
						$.each($lis, function(index, element){
							var nickName = $(element).attr('nickname');
							var id = $(element).attr('name');
							var title = $(element).attr('title');
							var data = {
								name: id,
								nickname: nickName,
								mobile: title
							};
							$(element).children('.checkbox').addClass('checked');
							appendConcactToHtml(data);
						});
					}
				}
				return false;
			});
			
			
			//联系人树单个人选中、反选事件
			$('#mainTree').delegate('.group_li > ul > li > .checkbox','click',function(){
				var arr = getMobiles();
				numCount = arr.length;
				var $this = $(this);
				var nickName = $this.parent('li').attr('nickname');
				var id = $this.parent('li').attr('name');
				var title = $this.parent('li').attr('title');
				var data = {name:id,nickname:nickName,mobile:title};
				if($this.hasClass('checked'))
				{
					$this.removeClass('checked');
					var $ul_li=$this.parent().parent().children('li');
					if(!hasSelected($ul_li))
					{
						$this.parent().parent().parent().children('.checkbox').removeClass('half_checked');
					}
					deletFromHtml(data);
				}
				else
				{
					if (numCount < maxMsgNum) 
					{
						$this.addClass('checked');
						$this.parent().parent().parent().children('.checkbox').addClass('half_checked');
						appendConcactToHtml(data);
					}
				}
				return false;
			});
			
			
			
			//右侧已选联系人全部清空
			$('#select_people_clear').unbind().bind('click',function(){
				$('#toMsgList').children('li').remove();
				var $checkbox = $('#mainTree').children('.group_li').children('.checkbox');
				$.each($checkbox,function(index,element){
					if($(element).hasClass('half_checked'))
					{
						$(element).click();
					}
				});
				var $search =$('#searchTree').children('li').children('.checkbox');
				if($search)
				{
					$.each($search,function(index,element){
						if($(element).hasClass('checked'))
						{
							$(element).click();
						}
					});
				}
				updateSelectNum();
			});
			
			
			//右侧已选联系人单个删除
			$('#toMsgList').delegate('li > span > em','click',function(){
				var $this = $(this);
				var $parent = $this.parent().parent();
				var name = $parent.attr('name');
				$parent.remove();
				updateSelectNum();
				deletFromTree({name:name});
			});
			
			
			//搜索框
			$("#mobile_link_seach").unbind().focus(function(){
				$(".msg-noavail-tip").hide();
				var $this = $(this);	
				var txt = $this.val();
				if(txt == defVal_mobile)
				{
					$this.val("");
					if(linkData._isOpenCytxl)
					{
						showContactsTree();
					}
				}
//				else
//				{
//					if(linkData._isOpenCytxl){
//						showSeachContact(txt);//显示搜索结果
//					}
//				}			
					
			}).blur(function(){
				var $this = $(this);
				var txt = $this.val();
				if(txt == "")
				{
					$this.val(defVal_mobile);
					if(linkData._isOpenCytxl)
					{
						showContactsTree();
					}
					else
					{
						showCytxl();
					}
				};
			}).keyup(function(){
				var $this = $(this);
				var txt = $this.val();
				if(txt == "")
				{
					$("#mainTree").show();
					$("#searchTree").hide();
				}
				else
				{
					if(linkData._isOpenCytxl)
					{
						showSeachContact(txt);//显示搜索结果
					}
					else
					{
						$("#mainTree").hide();
						var searchHtml = '<div class="share_font"><p>未找到相关联系人!!</p><p><a id="no_found_addContact"  href="javascript:void(0)" class="share_add_btn">添加</a></p></div>';
						$("#searchTree").html(searchHtml).show();
					}
				}
			});
			
			
			//从搜索结果中单个联系人选中、反选
			$('#searchTree').delegate('li .checkbox','click',function(){
				var arr = getMobiles();
				numCount = arr.length;
				var $this = $(this);
				var name = $this.parent().attr('name');
				var title = $this.parent().attr('title');
				var nickName = $this.parent().attr('nickname');
				var con = {name:name,nickname:nickName,mobile:title}
				var mobile = util.replace86(title);
				if(hasAlreadyExist(arr,mobile))
				{
					$(".msg-noavail-tip").text('号码已存在').show();
					return false;
				}
				if($this.hasClass('checked'))
				{
					$this.removeClass('checked');
					deletFromHtml(con);
				}
				else
				{
					if (numCount < maxMsgNum) 
					{
						$this.addClass('checked');
						appendConcactToHtml(con);
						selectToTree(con);
					}
				}
				return false;
			});
			
			
			//搜索无结果时点击添加按钮
			$('#searchTree').delegate('#no_found_addContact','click',function(){
				var arr = getMobiles();
				numCount = arr.length;
				if (numCount < maxMsgNum) 
				{
					var txt = $.trim($('#mobile_link_seach').val());
					if (txt !== defVal_mobile) 
					{
						if(hasAlreadyExist(arr,util.replace86(txt)))
						{
							$(".msg-noavail-tip").text('号码已存在').show();
							return false;
						}
						var data = {
							name: util.replace86(txt),
							nickname: util.replace86(txt),
							mobile: util.replace86(txt)
						};
						appendConcactToHtml(data);
						//重置搜索框
						$("#mobile_link_seach").val(defVal_mobile);
						$("#searchTree").hide();
						$("#mainTree").show();
					}
				}
				return false;
			});
		
		};
		
		
		
		//(联系人树对话框)显示搜索结果
		var showSeachContact = function(txt)
		{
			$("#mainTree").hide();
			$("#searchTree").children().remove();
			var lists = linkData.searchLinkers(txt);
			var conListHtml = '';
			if(lists.length == 0)
			{
				conListHtml = '<div class="share_font"><p>未找到相关联系人!!</p><p><a id="no_found_addContact"  href="javascript:void(0)" class="share_add_btn">添加</a></p></div>';
			}
			else
			{
				conListHtml = getSeachContactHtml(lists);
			}
			
			$("#searchTree").append(conListHtml).show();
		};
		
		
		//(联系人树对话框)获取搜索联系人treeHTML 
		var getSeachContactHtml = function(lists)
		{
			var html = new StringBuffer();
			$.each(lists,function(i,list){
				if(list.mobile && list.mobile[0])
				{
//					html.append('<li py="')
//						.append(list.py)
//						.append('" name="')
					html.append('<li name="')
						.append(list.groupId + "_" + list.contactId)
						.append('" alonetogroupid="" title="')
						.append(list.mobile[0]?list.mobile[0]:'')
						.append('" nickname="')
						.append(list.name)
						.append('">')
						.append('<div class="checkbox" flag="0"></div>')
						.append('<label style="cursor:default;">')
						.append(util.subStringByLen(list.name,8))
						.append('</label>')
						.append('</li>');
				}
			});
			return html.toString();			
		};
		
		
		//(联系人树对话框)显示联系人数目录
		var showContactsTree = function()
		{
			$('#searchTree').hide();
			$('#mainTree').show();
		};
		
		
		//(联系人树对话框)是否在联系人数中已选中
		var hasSelected = function(obj)
		{
			var result =false;
			$.each(obj,function(index,element){
				if($(element).children('.checkbox').hasClass('checked'))
				{
					result = true;
				}
			});
			return result;
		};
		
		
		//(联系人树对话框)向右边框加入联系人
		var appendConcactToHtml = function(data)
		{
			var mobile = util.replace86(data.mobile);
			var html = new StringBuffer();
			html.append('<li class="select-cancel" name="')
				.append(data.name)
				.append('" title="')
				.append(mobile)
				.append('">');
			
			//if(util.isChinaMobile(mobile))
			//支持异网短信下发
			if(util.isCellPhone(mobile))
			{
				html.append('<span>');
			}
			else
			{
				html.append('<span class="sp_r">');
			}
			
			html.append(util.subStringByLen(data.nickname,11) != null ? util.formatHTMLEncode(util.subStringByLen(data.nickname,11)) : "&nbsp;")
				.append('<em class="delMailAddr"></em>')
				.append('</span></li>');
				
			var contactHtml = html.toString(); 
			
			$("#toMsgList").append(contactHtml);
			
			var groups = $("mainTree").find(".group_li");
			$.each(groups,function(index,element){
				var lists = $(element).find("ul").find("li");
				$.each(lists,function(index,list){
					if($(list).attr("name") == (data.name))
					{
						$(list).find(".checkbox").addClass("checked");
					}
				});
			});
			
			
			updateSelectNum();
		};
		
		
		//(联系人树对话框)从左侧树勾选联系人（搜索结果中操作添加）
		var selectToTree = function(data,$grouptree)
		{
			var $lis = $("#mainTree").children('.group_li').children('ul').children('li');
			$.each($lis,function(index,element){
				var name = $(element).attr('name');
				if(data.name==name)
				{
					var $check = $(element).children('.checkbox');
					$check.addClass('checked');
					$check.parent().parent().parent().children('.checkbox').addClass('half_checked');
				}
			});
		};
		
		
		//(联系人树对话框)删除右边框已选联系人
		var deletFromHtml = function(data)
		{
			var $lis = $("#toMsgList").children('li');
			$.each($lis,function(index,element){
				var name = $(element).attr('name');
				if(data.name==name)
				{
					$(element).remove();
					updateSelectNum();
				}
			});
		};
		
		
		//(联系人树对话框)从左侧树删除（点右侧删除按钮）
		var deletFromTree = function(data)
		{
			var $lis = $("#mainTree").children('li');
			var $searchli = $("#searchTree").children('li');
			$.each($lis,function(index,element){
				var $ul_lis =$(element).children('ul').children('li');
				$.each($ul_lis,function(index,element){
					var name = $(element).attr('name');
					if(data.name==name)
					{
						$(element).children('.checkbox').click();
					}
				});
			});
			if($searchli)
			{
				$.each($searchli,function(index,element){
					var name = $(element).attr('name');
					if(data.name==name)
					{
						$(element).children('.checkbox').click();
					}
				});				
			}
		};
		
		
		//(联系人树对话框)更新右侧选中对象数
		var updateSelectNum = function()
		{
			var selectNum = $('#toMsgList').find("li").length;
			$("#select_people_num").text("(" + selectNum + "/" + maxMsgNum + ")");
		}
		
		
		//(联系人树对话框)未开通彩云通讯录
		var showCytxl = function(type)
		{
			var _html ='<div class="share_font">' 
					+ '<p><a href="javascript:void(0)"class="share_a1" id="active_user">导入彩云通讯录</a>，分享更轻松！</p>' 
					+ '</div>';
			$('#searchTree').hide();
			$('#mainTree').html(_html).show();
			
			$("#active_user").unbind().click(function(){
				$(".msg-noavail-tip").hide();
				cytxl.regAndSignIn(activeUserSuccCallBack,activeUserFailCallBack);
			});
		};
		
		
		
		//(联系人树对话框)导入通讯录成功
		var activeUserSuccCallBack = function(res,resp)
		{
			if(resp.message=="" && resp.st)
			{
				//initContactData();
				linkData.init(initContactData);
			}
			else if(resp.message=='error')
			{
				$(".msg-noavail-tip").text("开通彩云通讯录失败!").show();
			}
		};
		
		//(联系人树对话框)导入通讯录失败
		var activeUserFailCallBack = function(r)
		{
			$(".msg-noavail-tip").text("系统繁忙,请稍后再试!").show();
		};
		
		
		//(联系人树对话框)添加号码、联系人到右边
		var appendToRight = function(addname,mobile,nickname)
		{
			var addMsgHtml = '<li class="select-cancel" name="'+ addname +'"  title="' + mobile + '">'
							+ '<span>' 
							+ nickname 
							+ '<em class="delMailAddr"></em>'
							+ '</span></li>';
			
			$(".share_right_m").append(addMsgHtml);
			
		};
		
		
		//(联系人树对话框)从右边已选中号码中删除
		var delFromRight = function(delname)
		{
			list = $(".share_right_m").find(".select-cancel");
			$.each(list,function(i){
				var li_name = $(list[i]).attr("name");
				if(li_name == delname)
				{
					$(list[i]).remove();
				}
			});
			
		};
		
		
		/**********************************联系人树对话框操作end*****************************************/
		
		
		
		
		
		
		
		//绑定flash事件(复制按钮操作)
		var bindFlash = function()
		{
			
			destroyZeroClipboard();
			
			var linkID = $(".share-link-box").attr("linkid");
			var linkUrl = $(".share-link-box input").val();
			var pass = $("#linkpass").val();
			var copyStr = linkUrl;
			
			if(pass != null && pass != "")
			{
				copyStr += "  提取密码:" +  pass ;
			}
			
			clips[0]= new ZeroClipboard.Client();
			clips[0].setHandCursor(true);
			clips[0].setText(copyStr);
			clips[0].glue("copyLink","copyLink_p");
			clips[0].addEventListener("mousedown", function(){
				if(navigator.userAgent.toLowerCase().indexOf('maxthon') > -1 && window.clipboardData)
				{
					window.clipboardData.clearData();
				}
			});
			clips[0].addEventListener("complete", function(){
				
				clearTimeout(cpTimeout);
				$(".copy-success-tip").show();
				cpTimeout = setTimeout(function(){$(".copy-success-tip").hide();},3000);
				//统计复制文件外链
				caiyun.pvlog('fileLink','copyLink',linkID);
			});
			
		};
		
		//注销flash事件
		var destroyZeroClipboard = function()
		{
			if(clips.length<=0){
				return false;
			}
			if(null != clips[0])
			{
				clips[0].destroy();
			}
//			for(var n=0;n<clips.length;n++)
//			{
//				if(null != clips[n])
//				{
//					clips[n].destroy();
//				}
//			}
			clips = [];
		};
		
		
		
		//调SEAS接口进行短信分享
		var shareToMsg = function(linkid,mobileLst,msgbox)
		{
			caiyun.fileShareOperate.shareLinkByMsg(linkid,mobileLst.toString(),function(params,response){
				if(null == response)
				{
					$(".msg-noavail-tip").text("系统繁忙，请稍后再试！").show();
					return false;
				}
				if(null != response.showMessage && "" != response.showMessage)
				{
					$(".msg-noavail-tip").text("系统繁忙，请稍后再试！").show();
					return false;
				}
				else
				{
					var resultCode = response.resultCode;
					if(resultCode == "0")
					{
						msgbox.close();
						fileLinkBox.close();
						caiyun.ui.iMsgTip.tip('分享成功并可以去“<a href="javascript:void(0)" style="font-family:Applied Font' +
					    		';font-size:13px;font-weight:normal;font-style:normal;text-decoration:underli' +
					    		'ne;color:#0000CC;"  onclick="$(\'#toShare\').click();">分享管理</a>”里查看详情',"html",5);
						return false;
					}
					else if(resultCode == "208000402")
					{
						$(".msg-noavail-tip").text("每天分享短信数量不可超过50条").show();
						return false;
					}
					else
					{
						$(".msg-noavail-tip").text("短信分享不成功！").show();
						return false;
					}
				}
			},function(response){
				$(".msg-noavail-tip").text("短信分享不成功！").show();
			});
		};
		
		
		
		//调SEAS接口进行邮件分享
		var shareToMail = function(linkId,contents,mailbox)
		{
			caiyun.fileShareOperate.shareLinkByMail(linkId,contents.join(",").toString(),function(params,response){
				if(null == response)
				{
					$(".email-noavail-tip").text("系统繁忙，请稍后再试！").show();
					return false;
				}
				if(null != response.showMessage && "" != response.showMessage)
				{
					$(".email-noavail-tip").text("系统繁忙，请稍后再试！").show();
					return false;
				}
				else
				{
					var resultCode = response.resultCode;
					if(resultCode == "0")
					{
						mailbox.close();
						fileLinkBox.close();
						caiyun.ui.iMsgTip.tip('分享成功并可以去“<a href="javascript:void(0)" style="font-family:Applied Font' +
					    		';font-size:13px;font-weight:normal;font-style:normal;text-decoration:underli' +
					    		'ne;color:#0000CC;"  onclick="$(\'#toShare\').click();">分享管理</a>”里查看详情',"html",5);
						return false;
					}
					else if(resultCode == "208000402")
					{
						$(".email-noavail-tip").text("每天分享邮件数量不可超过5封。").show();
						return false;
					}
					else
					{
						$(".email-noavail-tip").text("分享失败，请稍后再试！").show();
						return false;
					}
				}
			},function(){
				$(".email-noavail-tip").text("系统繁忙，请稍后再试！").show();
			});
			
			caiyun.pvlog('fileLink','emailShare',linkId);  //邮件分享PV统计
    	};
		
		
		
    	//分享到各SNS平台的微博(公开平台api实现)
		var shareToSNS = function(dataname,dataurl,datapass,snsType) 
		{
    		if(rptMisson_switch)
    		{
    			rptInvitation();
    		}
    		
    		var shareContent = "";
    	
    		if(null != linkSNSHtml && "" != linkSNSHtml)
    		{
    			shareContent = linkSNSHtml.replace(/\[0\]/g,dataname) + "  " + datapass;
    		}
    	
    		var shareUrl = "";
    		if("139" == snsType)
    		{
    			shareUrl = share139Url + "?app_key=" + key139 + "&app_text=" + encodeURI(shareContent) + "&app_link=" + encodeURIComponent(dataurl) + "&src=" + src139;
    		}
    		else if("qq" == snsType)
    		{
    			shareUrl = shareQQUrl + "?c=share&a=index&title=" + encodeURI(shareContent) + "&url=" + encodeURIComponent(dataurl) + "&appkey=" + keyQQ;
    		}
    		else if("sina" == snsType)
    		{
    			shareUrl = shareSinaUrl + "?title=" + encodeURI(shareContent) + "&url=" + encodeURIComponent(dataurl) + "&appkey=" + keySina;
    		}
    		else if("qzone" == snsType)
    		{
    			shareUrl = shareQspaceUrl + "?url=" + encodeURIComponent(dataurl) + "&title=" + encodeURI(shareContent) + "&site=" + encodeURI("移动彩云") + "&fromurl=" + encodeURI("http://caiyun.feixin.10086.cn");
    		}
    		else
    		{
    			return false;
    		}
    		window.open(shareUrl);
    	};
		
		//触发上传新手任务完成情况
	    var rptInvitation = function()
	    {
	    	$.ajax({
				url : "getFree_expansion_Infos!rptMission.action?date="
						+ new Date().getTime(),
				type : "POST",
				data : {finishCount:1,missionId : 20006},
				dataType : "json",
				success : function(){}
			});
	    };
    	
    	//检查输入邮件地址是否有效
    	var checkMailAddr = function(addr)
    	{
    		if(addr == null || addr == "")
    		{
    			return false;
    		}
    		
    		var totalMail = getMails();
    		
    		if(totalMail.length >= maxMailNum)
    		{
    			$(".email-noavail-tip").text("每次最多支持"+maxMailNum+"个地址，请调整。").show();
    			return false;
    		}
    		
    		var isValidEmailAddr =util.isValidEmail(addr);
    		
    		if(isValidEmailAddr)
    		{
    			if(hasAlreadyExist(totalMail,addr))
    			{
					$(".email-noavail-tip").text("邮箱地址已存在！").show();
					return false;
				}
    			return true;
    		}
    		else
    		{
    			$(".email-noavail-tip").text("无效的邮箱地址！").show();
    			return false;    		
    		}
    		
    	};
    	
    	
    	
    	
    	
    	//已选中短信号码
		var getMobiles = function()
		{
			var lis = $('#toMsgList').children('li');
			var arr = [];
			if(lis){
				$.each(lis,function(index,element){
					var msgNum = $(element).attr('title');
					arr.push(msgNum);
				});
			}
			return arr;
		};
    	
    	
    	//已选中邮件地址
		var getMails = function()
		{
			var lis = $('#toMailList').children('li');
			var arr = [];
			if(lis){
				$.each(lis,function(index,element){
					var mailAddr = $(element).find("span").attr('title');
					arr.push(mailAddr);
				});
			}
			return arr;
		};
    	
    	
    	//是否已存在该值
    	var hasAlreadyExist = function(array,item)
    	{
			var flag = false;
			if(array){
				for(var i =0;i<array.length;i++)
				{
					if(array[i]==item)
					{
						flag = true;
						break;
					}
				}
				return flag;
			}
		};
    	
		//从缓存数据中取文件(夹)名
		var getFileName = function(id)
		{
			var cacheID = id;
			var fileName ='';
			$(selectedData).each(function(i){
				if(selectedData[i].catalogID==cacheID)
				{
					fileName = selectedData[i].catalogName;
				}
				if(selectedData[i].contentID==cacheID)
				{
					fileName =selectedData[i].contentName;
				}
			});
			return fileName;
		};
		
		//从缓存数据中取文件(夹)名
		var getFileNameByObj = function(obj)
		{
			var fileName ='';
			if(obj != undefined && typeof(obj)=="object")
			{
				if(obj.catalogName)
				{
					fileName = obj.catalogName;
				}
				else
				{
					fileName = obj.contentName;
				}
			}
			return fileName;
		};
		
		
		
		
		
		
		
		/***************************页面监听事件*******************************/
		
		//监听页面分享文件链接事件
		fileOperate.onListen('getFileLink',function(ids){
			var dataSet = [];
			$(ids).each(function(i,id) {
				data = cache.getFileCache(constants.FILE_LIST_CACHEGROUP,id);
				//分页以后找不到先前图片，如果找不到就在图片缓存中去取
				if(!data){
				    data = cache.getPictureCache(constants.PICTURE_LIST_CACHE_GROUP,id);
				}
				//视频播放从缓存里取
				if(!data){
				    data = cache.getVideoCache(constants.VIDEO_LIST_CACHE_GROUP,id);
				}
				if(data)
				{
					dataSet.push(data);
				}
			})
			selectedData = dataSet;
			
			if(dataSet.length > 0)
			{
				creatFileShare();
			}
		});
		
		
		
		//监听外链生成情况
		fileShareOperate.onListen('creatFileShare',function(fileShareInfosSet){
			if(fileShareInfosSet == null || fileShareInfosSet.length <= 0)
			{
				return false;
			}
			
			var objID = fileShareInfosSet[0].objID;
			var linkID = fileShareInfosSet[0].linkID;
			var linkUrl = centreLinkId==''?fileShareInfosSet[0].linkUrl:fileShareInfosSet[0].linkUrl + "&centreLinkId=" + centreLinkId;
			var pass = fileShareInfosSet[0].passwd;
			var linkName =getFileName(objID); 
			
			var shareLinkSuccHtml = '<div class="share_link">'
								+ '<ul>'
								+ '<li><span class="s1">链接已生成，现在就分享给朋友吧！</span></li>'
                           		+ '<li>'
                           		+ '<span class="s1">查看链接:</span>'
                           		+ '<div class="share-link-box" linkid="' + linkID + '" name="' + linkName + '">'
                              	+ '<input type="text" readOnly="true" value="' + linkUrl + '"/>'
                              	+ '</div>'
                                + '<div class="copyBtn-box" id="copyLink_p">';
			if(pass != null && pass != "")
			{
				shareLinkSuccHtml += '<span class="share_copy_btn" id="copyLink">复制链接及密码</span>';
			}
			else
			{
				shareLinkSuccHtml += '<span class="share_copy_btn" id="copyLink">复制链接</span>';
			}
                              	
                              	
                shareLinkSuccHtml += '<div class="copy-success-tip">复制成功<b></b></div>'
                                + '</div>' 
                                + '<span class="s1"><a href="' + linkUrl + '" target="_blank">查看</a></span>'
                                + '</li>' 
                                + '<li id="pass_li"><span class="s1">提取密码:</span>';
                                
            if(pass != null && pass != "")
            {
            	shareLinkSuccHtml += '<input class="get-code-box" id="linkpass" readonly="true" value="'+ pass +'" /><span class="cancel-code-btn" toset="1" id="modpass">取消提取密码</span></li>';
            }
            else
            {
            	shareLinkSuccHtml += '<span class="cancel-code-btn" toset="2" id="modpass">生成提取密码</span></li>';
            }
                                
	                              	
	            shareLinkSuccHtml += '<li><span class="set_pass_tip"></span></li>'
	            				+ '</ul>'
	                            
	                            + '<div class="share-style-box">' 
	                            + '<span>分享到:</span>' 
	                            + '<a href="javascript:void(0);" class="share_to_sms" title="短信分享">短信分享</a>'
	                            + '<a href="javascript:void(0);" class="share_to_mail" title="邮件分享">邮件分享</a>'
	                            + '<a href="javascript:void(0);" class="share_to_139" title="分享到移动微博">移动微博</a>' 
	                            + '<a href="javascript:void(0);" class="share_to_qq" title="分享到腾讯微博">腾讯微博</a>'
	                            + '<a href="javascript:void(0);" class="share_to_sina" title="分享到新浪微博">新浪微博</a>'
	                            + '</div>'
	                            
	                            + '</div>'
	                            
	                            + '<div class="border_bottom"></div>';
	                            
			
			fileLinkBox = caiyun.ui.msgBox({
									title : "分享链接",
									width : 705,
									iconType : "sharelink",
									type : "sharelink",
									cancelOnly : true,
									btnName : ["取消分享"],
									cancelHandle : function(){
														var params = {linkIDs:linkID,objID:objID};
														//fileShare.cancelFileShare(params,cancelFileShareSuccCallBack,cancelFileShareFailCallBack);
														fileShareOperate.delOutLink(params,cancelFileShareSuccCallBack,cancelFileShareFailCallBack);
														destroyZeroClipboard();  //窗口关闭前销毁flash
														fileLinkBox.close();
														caiyun.pvlog("fileLink",'unPublish',objID);
													},
									closeBox : function(){
														destroyZeroClipboard();  //窗口关闭前销毁flash 
														fileLinkBox.close();
													},
									html : shareLinkSuccHtml
								});
							
			fileLinkBox.show();
			
			fileLinkBoxEventsHandler();
			
		});
		
		

		self.creatFileShare = creatFileShare;
		
	};

	// 注册到页面初始化方法中
	caiyun.ui.initList.push(self);

})();
