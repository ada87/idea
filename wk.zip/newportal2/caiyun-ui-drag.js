/**
 * 拖拽文件（夹）
 * @author  xienan
 */
(function(){
	window.caiyun.ui.model.dragFile = dragFile();
		
	function dragFile(){
		
		/**
		 * 拖拽上传文件(夹)处理函数
		 * @param files {event.dataTransfer.files} 被拖拽的本地文件
		 * @param destinationFolderId {String} 要上传到的文件夹的id
		 */
		var upload = function(files, destinationFolderId){
			if(caiyun.operate.canExecute('upload')){
                WCFGH5.addFiles({   
                    files:files,
                    targetDirID:destinationFolderId,
                    isSafeBox: window.caiyun.judgement.isSafeBox(),
                    isFromDrag:true
                });
            }else{
                if(caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)){
                    window.caiyun.ui.iMsgTip.tip('收到的分享目录不支持拖拽移入文件或文件夹操作', 'loading', 1);
                    return;
                }if(caiyun.judgement.isInCurrentCatalogs(caiyun.constants.publisherAccountConstants.publisherDir)){
                	window.caiyun.ui.iMsgTip.tip('目标目录不支持拖拽移入文件或文件夹操作', 'loading', 1);
					return;
                }
               
            };
			
		};
		
		/**
		 * move的ajax数据发送
		 * @param dragItemIds {catalogIds: [], contentIds: []} 被拖拽的文件（夹）项的id  
		 * @param destinationFolderId {String} 要放置到的文件夹的id
		 */
		var move = function(dragItemIds, destinationFolderId){
			var url = "../webdisk2/moveAction.action";
			var type = 'move';
			var contentIDList = dragItemIds.contentIds;
			var catalogIDList = dragItemIds.catalogIds;
			var i = 0, j = 0;
			var contentIDListLength = contentIDList.length;
			var catalogIDListLength = catalogIDList.length;
			var path = caiyun.judgement.getPathForEnterprise();
			
			// 企业彩云文件(夹)要加上父目录路径
			if (caiyun.judgement.isEnterprisePath()) {
				for (i=0; i < contentIDListLength; i++) {
					contentIDList[i] = path + '/' + contentIDList[i];
				}
				for (j=0; j < catalogIDListLength; j++) {
					catalogIDList[j] = path + '/' + catalogIDList[j];
				}
			}
			
			window.caiyun.util.caiyunAjax.ajaxRequest({
				url      : url,
	            type     : 'post',
				dataType : 'json',
	            data     : {
	            			contentIDList : contentIDList.join(','),
				            catalogIDList : catalogIDList.join(','),
				            newCatalogID  : window.caiyun.judgement.getPath() + '/' + destinationFolderId
				           },
	            succFun  :    moveSuccCallBack,
				errFun   :    moveFailCallBack,
				bi       : ['fileOper',type,dragItemIds.contentIds,dragItemIds.catalogIds,true]//统计移动，复制文件操作
				
			});        
		};
		
		var moveSuccCallBack = function(reqParam,json){
			if(json.message){
	            //弹出error对话框
				window.caiyun.ui.iMsgTip.tip(json.message,"error");
	            return;
	        }
	        
	        window.caiyun.ui.iMsgTip.tip('移动成功');
			//当前页面数据重新加载 
        	window.caiyun.operate.reLoad();        	
		};
		
		var moveFailCallBack = function(request,textStatus,errorThrown,params){
		};
		
		return {
			dragUploadFiles : upload,
			dragMoveFiles : move
		};
	};
})();