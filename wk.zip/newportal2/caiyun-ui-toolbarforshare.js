/**
 * 分享工具栏
 */
(function(){
	
	var self = caiyun.ui.model.toolbarforshare;
	var $tool_bar = $('#links_bar');
	var $share_title = $('#links_title');
	var $share_title0 = $('#links_title0');
	var $share_title1 = $('#links_title1');
	var $share_title2 = $('#links_title2');
	var $share_title3 = $('#links_title3');
	var $selectLinksAll = $("#selectLinksAll");
	var disable = false;
	
	self.init = function(){
		
		var operate = caiyun.fileShareOperate;
		
		var commandList = [
			{
				id  		: 'cancelShare',
				name		: '取消分享',
				style :'look_all_btn l_share_cancel',
				click   	: function(){operate.delOutLinkForShare()},
				isDisable   : function(){return true;}
			}];
			
			// 工具栏内部对象
		var toolBar = window.caiyun.ui.CyNavBar({
			renderTo		:		'links_bar',
			items			:     	commandList
		});
	
		operate.onListen('selectData',toolBar.nvaBarShow);
		
		// 监听选择事件
		operate.onListen('selectData', function(ids,total) {
			if (disable) {
				return;
			}
			if (!ids || ids.length == 0) {
				//$share_title.show();
				$share_title0.show();
				$share_title1.show();
				$share_title2.show();
				$share_title3.show();
				
				$selectLinksAll.removeClass('input_first_on');
				$selectLinksAll.addClass('input_first');
			} else {
				//$share_title.hide();
				$share_title0.hide();
				$share_title1.hide();
				$share_title2.hide();
				$share_title3.hide();
			}
			if(ids.length < total){
				$selectLinksAll.removeClass('input_first_on');
				$selectLinksAll.addClass('input_first');
			}
		});
	};
	
	self.show = function() {
		$tool_bar.show();
		$share_title0.show();
		$share_title1.show();
		$share_title2.show();
		$share_title3.show();
		//$share_title.show();
	};

	self.hide = function() {
		$tool_bar.hide();
		//$share_title.hide();
		$share_title0.hide();
		$share_title1.hide();
		$share_title2.hide();
		$share_title3.hide();
	};

	self.enter = function() {
		disable = false;
	};

	self.leave = function() {
		disable = true;
		self.hide();
	};
	
	caiyun.ui.initList.push(self);
	
}
)();
