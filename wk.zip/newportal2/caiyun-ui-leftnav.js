caiyun.ui.model.leftNav = {};

(function() {
	var self = caiyun.ui.model.leftNav;

	self.init = function() {
		var ui = caiyun.ui;
		var fileOperator = caiyun.operate;
		var constants = caiyun.constants;
		var judgement = caiyun.judgement;
		var fileContent = caiyun.ui.model.fileContent;
		var myfileID = caiyun.constants.rootIds.myFolder;

		// 新建文件夹按钮
		$('#createFolderBtn').click(function() {
			fileOperator.userCreateFolder();
		});
		//免费扩容
		//	var $tofreeMission=$('#freeMission');
		// 左边所有栏目的tab
		var $leftNav = $('#cy_leftNav');
		var $leftTabs = $('.menu_list li');

		// 当前选中的
		var $current = null;

		// 彩云
		var $toCaiyun = $('#toCaiyun');

		// 分享管理
		var $toShare = $('#toShare');
		// 保险箱
		var $toSafeBox = $('#toSafeBox');
		// 回收站
		var $toRecycleBin = $('#toRecycleBin');

		$leftTabs.hover(function() {
			$(this).addClass('hover');
		}, function() {
			$(this).removeClass('hover');
		});

		$toCaiyun.click(function() {
			fileContent.switchToView(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW);
			fileOperator.enterDir(myfileID);
			$leftTabs.removeClass('current');
			$toCaiyun.addClass('current');
			//pv统计
			caiyun.pvlog('feature', 'mcloud');
			return false;
		});

		$toShare.click(function() {
			fileContent
				.switchToView(constants.SHARE_CONTENT_VIEW);
			//window.caiyun.myFileShareOperate.reload();
			window.caiyun.fileShareOperate.reload();
			caiyun.pvlog('feature', 'fileShare');
			$leftTabs.removeClass('current');
			$toShare.addClass('current');
			return false;
		});

		$toSafeBox.click(function() {
			fileContent
				.switchToView(constants.SAFEBOX_CONTENT_VIEW);
			caiyun.pvlog('feature', 'safeBox');
			$leftTabs.removeClass('current');
			$toSafeBox.addClass('current');
			return false;
		});

		$toRecycleBin.click(function() {
			fileContent
				.switchToView(constants.RECYCLEBIN_CONTENT_VIEW);
			window.caiyun.recycleBinOperate.loadRecycleBinInfos();
			caiyun.pvlog('feature', 'recycley');
			$leftTabs.removeClass('current');
			$toRecycleBin.addClass('current');
			return false;
		});
		//$tofreeMission.click(function(){
		//	fileContent
		//	.switchToView(constants.FREEMISSION_CONTENT_VIEW);
		///	return false;
		//});

		function showUploadAndNewFolder() {
			// 显示上传和新建文件夹
			$('#createFolderBtn').show();
			//$('#uploadBtn').css("visibility","visible").css('margin-left','0px');
			$('#uploadBtn').css("visibility", "visible").css('left', '0px');
			$toCaiyun.hide();
			$leftNav.removeClass('cy');
		}

		function hideUploadAndNewFolder() {
			// 隐藏上传和新建文件夹
			$('#createFolderBtn').hide();
			//$('#uploadBtn').css("visibility","hidden").css('margin-left','20000px');
			$('#uploadBtn').css("visibility", "hidden").css('left', '-1000px');
			$toCaiyun.show();
			$leftNav.addClass('cy');
		}

		// 监听内容切换事件
		fileOperator.onListen('fileContentSwitch', function(e) {
			var newView = e.newView;
			if (newView.name === constants.SHARE_CONTENT_VIEW) {
				$leftTabs.removeClass('current');
				$toShare.addClass('current');
				hideUploadAndNewFolder();
			} else if (newView.name === constants.SAFEBOX_FILE_CONTENT_VIEW) {
				$leftTabs.removeClass('current');
				$toSafeBox.addClass('current');
				// 显示上传和新建文件夹
				showUploadAndNewFolder();
			} else if (newView.name === constants.RECYCLEBIN_CONTENT_VIEW) {
				$leftTabs.removeClass('current');
				$toRecycleBin.addClass('current');
				// 隐藏上传和新建文件夹
				hideUploadAndNewFolder();
			} else if (newView.name === constants.DEFAULT_FILE_CONTENT_VIEW) {
				$leftTabs.removeClass('current');
				// 显示上传和新建文件夹
				showUploadAndNewFolder();
			} else {
				$leftTabs.removeClass('current');
				// 显示上传和新建文件夹
				hideUploadAndNewFolder();
			}
		});

		window.caiyun.myFileShareOperate.onListen('enterFileShare', function() {
			$('#createFolderBtn').hide();
			//$('#uploadBtn').css("visibility","hidden").css('margin-left','20000px');
			$('#uploadBtn').css("visibility", "hidden").css('left', '-1000px');
		});

		window.caiyun.operate.onListen('enterDir', function() {
			//上传，新建文件夹显示隐藏
			var canUpload = false;
			var canNewFolder = false;
			if (caiyun.operate.canExecute("newFolder", [])) {
				$('#createFolderBtn').show();
				canUpload = true;
			} else {
				$('#createFolderBtn').hide();
				canUpload = false;
			}
			if (caiyun.operate.canExecute('upload', [])) {
				$('#uploadBtn').css("visibility", "visible").css('left', '0px');
				canNewFolder = true;
			} else {
				$('#uploadBtn').css("visibility", "hidden").css('left', '-1000px');
				canNewFolder = false;
			}
			if (canUpload && canNewFolder) {
				$toCaiyun.hide();
				$leftNav.removeClass('cy');
			}
			if (!canUpload && !canNewFolder) {
				$toCaiyun.show();
				$leftNav.addClass('cy');
			}
		});


		window.onresize = function() {
			if ($.browser.msie && $.browser.version == '6.0') {
				var offsetH = document.documentElement.clientHeight;

				$("#cy_leftNav").css({
					"height": (offsetH - 77) + "px"
				});

				$("#sideBar_bottom").css({
					"bottom": 0 + "px",
					"_position": "absolute",
					"float": "none",
					"_left": 17 + "px",
					"background": "#F8F7F7",
					"width": 175 + "px"
				});

			}
		};

		window.onresize();

		// 显示更多列表
		var $moreMenu = $('#more_menu');
		$('#left_more,#more_menu').hover(function() {
			$moreMenu.show();
		}, function() {
			$moreMenu.hide();
		});

		//显示客户端下载更多
		$("#moreBtn,#moreAppDown").hover(function() {
			$("#moreAppDown").show();
		}, function() {
			$("#moreAppDown").hide();
		});
	};

	var $leftNav = $('#cy_leftNav');

	self.hide = function() {
		$leftNav.hide();
	};

	self.show = function() {
		$leftNav.show();
	};

	self.showByID = function(id) {
		$('#' + id).show();
	};

	self.hideByID = function(id) {
		$('#' + id).hide();
	};

	self.enter = function() {};

	self.leave = function() {

	};

	self.selectByID = function(id) {
		jVTab.selectByID(id);
	};

	// 添加到初始化列表
	caiyun.ui.initList.push(self);
})();