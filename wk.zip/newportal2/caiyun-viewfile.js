/**
 * 用于打开文件浏览
 */
(function() {
	window.caiyun.viewFile = (function() {
	    var canShare = false;
	    var canLink = false;
	    var judgement = caiyun.judgement;
	    var constants = window.caiyun.constants;
	    var util = caiyun.util;

		var errorCode = {
			TranscodingLater : "正在转码中，请稍后再试",
			TranscodingDefeated : "转码失败，不能播放",
			AuditingStatus : "该文件正在被审核，暂时不能播放",
			fileScreen : "该文件已被屏蔽，不能播放"
		};

		/**
		 * 验证文件的转码状态
		 */
		var validateTransferstate = function(transferstate) {
			if (transferstate == 0) {
				window.caiyun.ui.iMsgTip.tip(errorCode.TranscodingLater,
						'normal');
				return false;
			}
			if (transferstate == 1) {
				window.caiyun.ui.iMsgTip.tip(errorCode.TranscodingDefeated,
						'normal');
				return false;
			}
			if (transferstate == 2) {
				window.caiyun.ui.iMsgTip
						.tip(errorCode.AuditingStatus, 'normal');
				return false;
			}
			if (transferstate == 4) {
				window.caiyun.ui.iMsgTip.tip(errorCode.fileScreen, 'normal');
				return false;
			}
			return true;
		};

		/**
		 * 打开新窗口 _url:链接地址 _name:窗口的名称 _width:窗口的宽度 _height:窗口的高度
		 * _sroll:窗口是否有滚动条，1：有滚动条；0：没有滚动条
		 */
		var openWin = function(_url, _name, _width, _height, _sroll, resizable,
				_type) {
			var sb = _sroll == "1" ? "1" : "0";
			var l = (screen.width - _width) / 2;
			var t = (screen.height - _height) / 2;
			resizable = resizable || 'no';
			var sFeatures = "left=" + l + ",top=" + t + ",height=" + _height
					+ ",width=" + _width + ",center=1,scrollbars=" + sb
					+ ",status=0,directories=0,channelmode=0 resizable="
					+ resizable;
			if (_type) {
				var openwin = window.open(_url);
			} else {
				var openwin = window.open(_url, _name, sFeatures);
			}
			if (openwin && !openwin.opener) {
				openwin.opener = self;
			}
			openwin.focus();
			return openwin;
		};

		/**
		 * 打开视频窗口
		 */
		var playVideo = function(param) {
   /*
			var defaults = {
				contentID : param.contentID,
				entryShareCatalogID : param.entryShareCatalogID || '',
				donatorMSISDN : param.donatorMSISDN,
				sourceType : param.sourceType || '0',
				isShowPublishBtn : param.isShowPublishBtn || '1',
				isTagInfoNoShowed : (param.isTagInfoNoShowed === undefined
						? true
						: param.isTagInfoNoShowed),
				transferstate : param.transferstate
			};
			var params = "&contentID=" + defaults.contentID
					+ "&entryShareCatalogID=" + defaults.entryShareCatalogID
					+ "&donatorMSISDN=" + defaults.donatorMSISDN
					+ "&sourceType=" + defaults.sourceType
					+ "&isShowPublishBtn=" + defaults.isShowPublishBtn
					+ "&isTagInfoNoShowed=" + defaults.isTagInfoNoShowed;
			var _url = '../live139/vplayer4webdiskfection.jsp?src=' + source_mark
					+ '&date=' + new Date().getTime() + params;
			var _windName = "视频播放器";
			var _width = 1000;
			var _height = 840;
			var _sroll = 0;
			openWin(_url, _windName, _width, _height, _sroll, "yes", "y");
	    */  
	        //视频权限
	        canLink = !judgement.isSafeBox()&& !judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare);
            if(judgement.isEnterprisePath()){
                canLink = (enterpriseAuth ==0?true:false) || (enterpriseAuth ==8?true:false);
            }
            
            canShare = !judgement.isSafeBox()&& !judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)&& !judgement.isEnterprisePath();
            //TODO 测试用，上线取消
            //N5测试
            //if(judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)){
            //    param.presentURL = "http://221.226.48.130:3197/StorageWeb/servlet/GetFileByURLServlet?fileid=f6a8820f9d8783240b74f0002c4a21bd&ct=3&type=3&start=10";
            //}
	        
		    $.extend(param, {canShare:canShare,canLink:canLink});
			caiyun.lightbox4Video.init(param);
		};

		var playAudio = function(param) {
		    //TODO 测试用，上线取消
		    //N5测试
		    //if(judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)){
		    //    param.presentURL = "http://221.226.48.130:3197/StorageWeb/servlet/GetFileByURLServlet?fileid=6fcff5cabbf43d28b522ed1b11a373d4&ct=2&type=3&start=10";
		    //}
			// 构造播放列表
			var playlist = [{"id":param.contentID,"title":(param.contentName).substringName(25),"url":param.presentURL}];
			
			// 拉起播放器
			caiyun.ui.model.musicBox.startPlay(playlist);
		};

		/**
		 * 浏览文件
		 */
		var _viewFile = function(content) {
			var judgement = window.caiyun.judgement;

			// 判断转码状态
			if (!validateTransferstate(content.transferstate)) {
				return;
			}

			// 视频文件
			if (judgement.isVideo(content)) {
				playVideo(content);
                caiyun.pvlog('fileOper','viewVideo',content.contentID);
				return;
			}

			// 音频文件
			if (judgement.isAudio(content)) {
				playAudio(content);
				//监听音乐播放事件
			    window.caiyun.operate.mp3Player(content.contentID);
                caiyun.pvlog('fileOper','viewMusic',content.contentID);
			}
		};

		return {
			viewFile : _viewFile
		};
	})();
})();