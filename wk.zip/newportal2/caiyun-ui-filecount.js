/**
* 文件数显示lable
*/
(function(){
	var self = caiyun.ui.model.fileCount;
	
	self.init = function(){
		var $fileCount = $('#fileCount');
		var visible = false;
		var fileOperator = window.caiyun.operate;
		var constants = window.caiyun.constants;
		var judgement = window.caiyun.judgement;
		
		// 隐藏
		self.hide = function(){
			$fileCount.hide();
			visible = false;
		};
		
		// 显示
		self.show = function(){
			$fileCount.show();
			visible = true;
		};
		
		// 进入
		self.enter = function(){
			// 先清空自己
			$fileCount.text('');
		};
		
		var fileTypes = constants.fileTypes;
		
		// 根据类型查询
		var typeTipsMap = {}
		 	typeTipsMap[fileTypes.picture] = {prefix : '图片',suffix : '张'};					// 图片
			typeTipsMap[fileTypes.music] ={prefix : '音乐',suffix : '首'};											// 音频
			typeTipsMap[fileTypes.video] ={prefix : '视频',suffix : '部'};											// 视频
			typeTipsMap[fileTypes.document] = {prefix : '文档',suffix : '份'};									// 文档
			typeTipsMap[fileTypes.mobileSoftware] = {prefix : '手机软件',suffix : '个'};						// 手机软件
		
		// 根据手机os查询
		var osTipsMap = {
        	'IOS' : {prefix : 'IOS应用',suffix : '个'}	,
        	'Android' : {prefix : 'Android应用',suffix : '个'},
        	'Java' : {prefix : 'Java应用',suffix : '个'},
        	'BlackBerry' : {prefix : 'BlackBerry应用',suffix : '个'},
        	'WindowPhone7' : {prefix : 'WindowPhone7应用',suffix : '个'},
        	'MTK' : {prefix : 'MTK应用',suffix : '个'},
        	'Symbian' : {prefix : 'Symbian应用',suffix : '个'}
		};
		
		// 获取提示文字内容
		var getText = function(count){
			var type; 
			var typeTips; 
			
			if(judgement.isInQueryByType()){
				type= fileOperator.getCatalogStack()[0].catalogID.replace(constants.catalogIDPrefix.byType,'');
				typeTips= typeTipsMap[type];
			}else if(judgement.isInQueryByPhoneOS()){
				type= fileOperator.getCatalogStack()[0].catalogID.replace(constants.catalogIDPrefix.byPhoneOS,'');
				typeTips= osTipsMap[type];
			}else{
				return;
			}
			
			if(!typeTips){
				return null;
			}
			
			return '全部' + typeTips.prefix + ':共<span style="color:#007bbb">&nbsp;&nbsp;' + count + '&nbsp;&nbsp;</span>'+typeTips.suffix; 
		};
		
	 	// 注册加载事件
		fileOperator.onListen('loadData',function(data){
			if(visible){
				var text = getText(data.nodeCount);
				if(text){
					$fileCount.html(text);
				}else{
					$fileCount.html('');
				}
			}
		}
		);
	}
	
	// 将自己的初始化方法加载到ui的initList中
	caiyun.ui.initList.push(self);
}
)();