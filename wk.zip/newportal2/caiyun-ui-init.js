// 初始化彩云的UI对象


// 页面初始化方法
(function() {
	// 注册到此处的UI对象都需要提供init方法，由caiyun.ui.model.init方法执行所有初始化操作对页面元素进行绑定
	caiyun.ui.initList = $([]); 

	caiyun.ui.init = function() {
		caiyun.ui.initList.each(function() {
			this.init();
		});
	};
	
})();
