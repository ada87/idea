/**
 * 显示文件夹的子文件个数
 */
(function() {
	var self = window.caiyun.ui.model.nodeCount;
	var $nodeCountDiv = $('#nodeCount');
	var fileOperator = caiyun.operate;
	var visible = true;

	self.init = function() {
		var count = 0;
		var showNodeCount = function(nodeCount) {
			if (!visible) {
				return;
			}
			if (caiyun.judgement.isSafeBox()) {
				$nodeCountDiv.parent('.nodeCount').css('margin', '12px 120px 0px 0px');
			} else {
				$nodeCountDiv.parent('.nodeCount').css('margin', '12px 6px 0px 0px');
			}
			$nodeCountDiv.text('共 ' + nodeCount + '个文件（夹）');
			$nodeCountDiv.show();
			count = nodeCount;
		};

		fileOperator.onListen('loadData', function(obj, startPage) {
		    if (startPage != 1) { //显示非第一页内容时返回
                return;
            }
			var nodeCount =
				obj.parentid == window.caiyun.constants.rootIds.myFolder && obj.cataloginfos && obj.cataloginfos.length > 0 ? 
				    + obj.nodeCount + 1 : obj.nodeCount;
			showNodeCount(nodeCount);
		});

		fileOperator.onListen('loadReceiveData', function(obj) {
			showNodeCount(obj.nodeCount);
		});

		fileOperator.onListen('dropItems', function(ids) {
			if(ids && ids.length > 0){
				showNodeCount(count - ids.length);
			}
		});

		fileOperator.onListen('enterDir', function() {
			if (!visible) {
				return;
			}
			$nodeCountDiv.hide();
		});
	};

	self.show = function() {
		visible = true;
	};

	self.hide = function() {
		$nodeCountDiv.hide();
		$nodeCountDiv.parent('.nodeCount').css('margin','0px'); // 重置，否则从保险箱跳转到timeline页面，导致timeline页面的筛选按钮的位置变位
		visible = false;
	};
	// 注册初始化事件
	caiyun.ui.initList.push(self);
})();