//初始化互联网通行证
(function(){
    $().ready(function () {
        $("#closeMoveBox").click(function(){
	        $("#upgradePassDiv").hide();
	    });
	    
	    $("#upgradePass").click(function(){
	        var href = "http://www.cmpassport.com/umcsso/notify?optype=1&sourceid=5&mobilenumber=" 
	            + ownerMSISDN + "&backurl=" + upgredMobilePassUrl + "&check=" + updateMd5;
	        window.open(href);
	        $("#upgradePassDiv").hide();
	    });
        
        //console.log("passid=" + passid);
	    if (passid != "") {
	        $.ajax({url: "../sso/cmartifact.action",
	            dataType:"json", 
	            type:"POST", 
	            success:function (res) {
	                if (res.code == "0"){
	                    var h = 'http://www.cmpassport.com/umcsso/plugin?func=plug:init&ver=1.0&anchor=mobilePassBox&passid='+ passid  + '&artifact='+ res.auth +'&sourceid=5';
	                    //动态插入js脚本
	                    $.getScript(h, function(){
	                        $("#mobilePassBox").find("a").bind("click", function(){
	                            setTimeout(function(){
	                                $("#umcpassportplugin").hide();
                                    $("#umcpassportplugin").appendTo("#mobilePassBox");
                                    $("#txz_title .txz_tip").css("left", "100px");
                                    $("#umcpassportplugin").css("left", "-95px").css("top", "30px").show();
	                            }, 50);
                            }).html("<img class='userIcon' border='0' src='../images/newportal/s.gif'/>");
	                    }); 
	                }
	            }	              
	        });
	        
	    }
	    else {
	        //关闭用户升级引导，暂时不向用户弹出升级提示
	        //$("#upgradePassDiv").show();
	    }
    });

})()