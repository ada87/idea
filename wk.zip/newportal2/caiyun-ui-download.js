/**
 * 下载相关的对话框
 */

(function() {
	var self = caiyun.ui.model.downloadDialog;
	var ui = caiyun.ui;

	/**
	 * 创建下载确认框
	 *
	 * obj {Object} 字面对象量
	 * {fileTotalNum：下载文件(夹)总数，fileName：下载文件(夹)的第一个文件(夹)的名字，url：下载路径}
	 *
	 */
	self.createDialog = function(obj) {
		var html = '<div class="popContent">' +
			'<div class="system_main"></div>' +
			'<div class="off_line_tips_YN" style="padding: 0px; text-align: center;">' +
			'<span class="downloadTips_img" style="display: inline-block;float:none;zoom: 1;vertical-align: middle;"></span>';
		if (obj.fileTotalNum > 1) {
			html += window.caiyun.util.htmlEscape(obj.fileName) + '等（' + obj.fileTotalNum + '）个文件';
		} else {
			html += window.caiyun.util.htmlEscape(obj.fileName);
		}
		html += '</div>' +
			'</div>';

		// 创建对话框
		var dialog = ui.msgBox({
			title: "文件下载",
			width: 480,
			leftBtn: false, //左下角是否有按钮
			middleBtn: true, //底部按钮是否居中
			okOnly: true, // 是否只有一个确认按钮
			html: html,
			btnName: ["开始下载"],
			okHandle: function() {
				var elemIF = document.createElement("iframe");
				elemIF.src = obj.url;
				elemIF.style.display = "none";
				document.body.appendChild(elemIF);
				dialog.close();
				setTimeout(function() {
					document.body.removeChild(elemIF);
				}, 2000);
			}
		});
		dialog.show();
	};

	/*
	 * 获取下载确认框里要显示的内容
	 * obj {Object} 字面对象量 {catalogList：文件夹的信息，contentList：文件的信息}，例如：
	 * {
	 * catalogList:"Pb11Qlk2Q01400920130717000421JCG|@@@@|0#Pb11Qlk2Q01400920130717000421JCM|2013717第一轮测试|0",
	 * contentList:"Pb11Qlk2Q01400920130813142442JGQ|sy_3_20120302095302.gif#Pb11Qlk2Q01400920130813115139168|.新建.文本文档.jpg
	 * }
	 */
	self.getInfoForDialog = function(obj) {
		var item = null;
		var showNameLength = 25;
		var fileNameLength = 0;
		var fileTotal = 0;
		var fileName = '';
		var catalog = null;
		var content = null;
		var catalogList = null;
		var contentList = null;
		var hasCatalog = false;
		var constants = window.caiyun.constants;
		if (obj.catalogList) {
			catalogList = obj.catalogList.split('#');
		}
		if (obj.contentList) {
			contentList = obj.contentList.split('#');
		}
		if (obj.contentID) { // 只有一个文件的情况
			item = window.caiyun.util.cache.getFileCache(constants.FILE_LIST_CACHEGROUP, obj.contentID);
			//分页以后找不到先前图片，如果找不到就在图片缓存中去取
			if (!item) {
				item = window.caiyun.util.cache.getPictureCache(constants.PICTURE_LIST_CACHE_GROUP, obj.contentID);
			}
			if (!item) {
				item = window.caiyun.util.cache.getVideoCache(constants.VIDEO_LIST_CACHE_GROUP, obj.contentID);
			}
			fileName = item.contentName;
			fileTotal = 1;
		}
		if (Object.prototype.toString.call(catalogList) === '[object Array]') {
			fileTotal = catalogList.length;
			catalog = catalogList[0].split('|');
			catalog.length >= 2 ? fileName = catalog[1] : '';
			hasCatalog = true;
		}
		if (Object.prototype.toString.call(contentList) === '[object Array]') {
			fileTotal += contentList.length;
			content = contentList[0].split('|');
			content.length >= 2 && hasCatalog === false ? fileName = content[1] : '';
		}
		fileNameLength = fileName.length;
		if (fileNameLength > showNameLength) {
			fileName = fileName.substring(0, showNameLength - 10) + "...";
		}
		return {
			fileTotalNum: fileTotal,
			fileName: fileName,
			hasCatalog: hasCatalog
		};
	};

	self.init = function() {
		var fileOperator = caiyun.operate;
		var fileManager = caiyun.biz.fileManager;
		var tips = caiyun.ui.iMsgTip;

		// 下载用的iframe		
		var downloadFrame = $('#downloadFile');

		var _downloadUrl;

		// 监听用户下载事件
		fileOperator.onListen('userDownload', function(ids) {
			var downloadType, tips, dialogTips;

			downloadType = fileOperator.download(ids, function(params, result) {
				if ($.trim(result.message)) {
					window.caiyun.ui.iMsgTip.tip(result.message, 'error');
					return;
				}
				dialogTips = self.getInfoForDialog(params.data);
				// 如果是单文件下载，则直接弹出下载窗口
				if (downloadType == 'downloadFile') {
					downloadFrame.attr('src', result.downloadUrl);
				} else if (downloadType == 'downloadZip') {
					// 验证下载链接是否可用
					var checkCount = 0;
					tips = window.caiyun.ui.iMsgTip.tip('正在生成下载文件...', 'loading', 60);
					var checking = false;
					var hanlder = setInterval(function() {
						// 如果正在检查直接返回
						if (checking) {
							return;
						}
						fileManager.checkDownloadZipPkg({
							downloadUrl: result.downloadUrl
						}, function(params, result) {
							checking = false;
							if (result.message == "") {
								if (tips) {
									tips.close();
								}
								_downloadUrl = result.downloadUrl;
								clearInterval(hanlder);
								if ($.browser.msie) {
									dialogTips.url = _downloadUrl;
									self.createDialog(dialogTips);
								} else {
									downloadFrame.attr('src', result.downloadUrl);
								}
								return;
							}
							checkCount++;
							if (checkCount > 9) {
								if (tips) {
									tips.close();
								}
								clearInterval(hanlder);
								window.caiyun.tips.showErrorMsg('SYSTEM_ERROR');
							}
						}, function() {
							checking = false;
							checkCount++;
							if (checkCount > 9) {
								if (tips) {
									tips.close();
								}
								clearInterval(hanlder);
								window.caiyun.tips.showErrorMsg('SYSTEM_ERROR');
							}
						});
						checking = true;
					}, 5000);
				}
			});
		});

	};

	// 将自己的初始化方法加载到ui的initList中
	caiyun.ui.initList.push(self);
})();