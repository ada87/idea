/**
 * timeline列表
 */
(function() {
		// 记住自己是谁
		var self = caiyun.ui.model.timeLine;

		//顶部中间提示
		var iMsgTip = caiyun.ui.iMsgTip;

		var judgement = caiyun.judgement;

		self.init = function() {
			// 文件操作对象
			var fileOperator = caiyun.operate;

			// 工具类
			var utils = caiyun.util;

			// 常量
			var constants = caiyun.constants;

			// 由于用knockout实现，第一步就是绑定model和view
			var timelineManager = caiyun.biz.timeline;

			// 操作提示栏
			var tips = $('#imsg_tips');
            var pageNum = 50; //每页加载事件条数默认50
			//异步请求handler，用于视图切到其他页面，对异步请求进行中断abort
//			var ajaxSpaceReq = null;
			var ajaxEventReq = null;
			var ajaxUserInfo = null;
			var ajaxRegReq = null;
			var ajaxRestoreReq = null;
			var ajaxContentReq = null;
			var ajaxDiskReq = null;
			var scroll = null;
			var totopflag = true; //是否返回顶部
			//记录动态筛选框的选中情况，下拉框对应这个数组位置为1表示选中的，为0表示没选中
			var eventSortChecked = [1, 1, 1, 1, 1, 1, 1];	// 按顺序表示： 上传，删除，编辑，分享，下载，同步备份，其他
			var eventSortCheckedtxt = ["上传", "删除", "编辑", "分享", "下载", "同步备份", "其它"];
			var beginDate = '', endDate = '';

//			var sortByOpOptions = [true, true, true, true, true, true, true]; // 分别对应： 上传、下载、分享、删除、同步备份、其他
			var cnMonth = ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'];
			
			var totalheight = 0;
			var curEventNum = 0; //当前加载在页面的事件的个数，滚动到底部继续加载数据时用到
			var totalEventNum = 0;
			var timelineHtml = ""; //拼接timeline的html string
			var regHtml = "";
			var dayObj = {}; //该对象放timeline事件上的日期，多个相同日期的事件只能存在一个日期标签里面，故用对象属性来设置唯一性
			var callBackFlag = false; //控制滚动加载数据时，数据没加载进来期间，滚动条继续滚动也不发送请求
			var spaceOwnerChecked = "1|";
			var userDiskRank = ""; //用户网盘占用率在所有用户中的排位
			var diskUsedSum = ""; //用户网盘使用空间
			var orgToptxt = $('.opr-timeline-logo-txt').html(); // 原始头html代码
			var month = ""; //记录按月份查询选择月份
			var showYear =""; //记录按年查询年
			// 文件后缀名属于图片大类
			var suffixs = "bmp|iff|ilbm|tiff|tif|png|gif|jpeg|jpg|mng|xpm|psd|psp|xcf|pcx|ppm|dxf|cdr";
			//有中图标的输入参数
			var midpic = "|sms|pimg|padd|pcal|pvid|papp"+
			             "|mp3|folder|imgfolder|musicfolder|bookfolder|entfolder|filefolder|videofolder|syncfolder|sharefolder"+
			             "|goback|jpg|cdr|psd|dmp|iff|idlm|png|tif|tiff"+
			             "|recyclebin|gif|psp|ipa|apk|doc|docx|xls|xlsx"+
			             "|gift|ppt|pptx|pps|pdf|txt|csv|ods|sxc|odp"+
			             "|zip|rar|xml|log|exe|dvd|file|html|odt|rtf"+
			             "|unknown|wov|avi|apk|ipa|java|mp3|wav|wma|music"+
			             "|dat|rm|mp4|rmvb|flv|wmv|3gp|video|eml";
//			var allFileFmt = ",3gp,apk,avi,bmp,cdr,csv,dat,doc,docx,dvd,eps,exe,flv,gif,html," +
//				"iff,ilbm,ipa,java,jpg,log,mov,mp3,mp4,music,odp,ods,odt,pdf,png," +
//				"pps,ppt,pptx,psd,psp,rar,rm,rmvb,rtf,sxc,symbian,tif,tiff,ttf," +
//				"txt,wav,wma,wmv,wov,xcf,xls,xlsx,xml,zip,";

			self.initVar = function() {
				curEventNum = 0; //当前加载在页面的事件的个数，滚动到底部继续加载数据时用到
				totalEventNum = 0;
				timelineHtml = ""; //拼接timeline的html string
				dayObj = {}; //该对象放timeline事件上的日期，多个相同日期的事件只能存在一个日期标签里面，故用对象属性来设置唯一性
				callBackFlag = false; //控制滚动加载数据时，数据没加载进来期间，滚动条继续滚动也不发送请求
				totopflag = true ; //返回顶部
				//用户网盘使用量和排位信息在页面初始化时查一次保存window.caiyun.constants.diskUsedSize orgToptxt =$('.opr-timeline-logo-txt').html();	                	
                var sortflag = self.isSortBydateortype();
                if (!sortflag) {
                	$('.opr-timeline-logo-txt').html('数据存储信息');
                	self.initToptxt();  //初始化顶部文字;
                };
                
			};
			
			// 初始化使用概要
			self.initCurDay = function() {
				var today = new Date();
				$('#tl_usage_summary_day').html(today.getDate());
				$('#tl_usage_summary_month').html(cnMonth[today.getMonth()]);
			};
			
			//数据存储信息
			self.initToptxt = function(){

                if (userDiskRank == "") {
					ajaxUserInfo = timelineManager.qryUserInfo(						
						function(eventParams, userInfoRet) {
							  if (userInfoRet.showMessage !="") {
							  	iMsgTip.tip(userInfoRet.showMessage);
								return;
							  }else{
							  	userDiskRank = userInfoRet["qryUserinfo"].largeThan + "%";
							  	self.subinitToptxt();
							  }
						},
						function() {
							//alert("queryEvents error!");
						}
					);
				}else {
					 if (userDiskRank == null) 
					 	userDiskRank = "**";
						self.subinitToptxt();

				};

			};

			self.subinitToptxt = function(){
				if (window.caiyun.constants.diskUsedSize) {
							  		diskUsedSum = window.caiyun.constants.diskUsedSize;							  		
							  		if (userDiskRank == 'null%') {
							  			$('.opr-timeline-logo-txt').html('数据存储信息');
							  			return ;
							  		};
							  		if (diskUsedSum == '0') {
							  			$('.opr-timeline-logo-txt').html('彩云上还没有数据，空空如也');
							  			return ;
							  		};
							  		if (diskUsedSum > 1024 * 1024) {
						                    diskUsedSum = (diskUsedSum / (1024 * 1024)).toFixed(2) + "T";
						                } else if (diskUsedSum > 1024) {
						                    diskUsedSum = (diskUsedSum / 1024).toFixed(2) + "G";
						                } else {
						                    diskUsedSum = diskUsedSum + "M";
						                }	
							  		$('.opr-timeline-logo-txt').html(orgToptxt);					  		
							  	}
						        					        
						        $('#tl_usage_summary_percent').html(userDiskRank);
						        $('#tl_usage_summary_G').html(diskUsedSum);
			};

			self.initCurDay();

			self.isSortBydateortype = function(){
				var totalTmp = 0;
				for (var i = 0; i < eventSortChecked.length; i++) {					
					totalTmp += eventSortChecked[i];
					}
				if (totalTmp<7) return true;
				if (month)  return true;
				return false;
			};
			
			
			// 隐藏
			self.hide = function() {
				$('#innerTimeLineView').hide();
				$('#tl_usage_summary, #timeline_goTop').hide();				
				$('#tl_show_by_opType,#tl_show_by_time,#timeline_now').hide();
			};
			

			self.showContent = function(baseEventInfo) { //展示时间轴内容部分
				$('#innerTimeLineView').show();
				if (timelineHtml == "") {
					totalEventNum = baseEventInfo.count;
					
					var topHtml =   '<div class="right_noline_con">'+
					      			'<div class="opr-timeline-box">'+
					      				'<div style="height:88px;"></div>';
					
					timelineHtml += topHtml;
				}
				var sortflag = self.isSortBydateortype();
				if (baseEventInfo.count == 0|| sortflag) {
					var toptxt = "";
					var totalTmp = 0;
					var curEventSort = "0";
					for (var i = 0; i < eventSortChecked.length; i++) {
						curEventSort += eventSortChecked[i];
						totalTmp += eventSortChecked[i];
					}
					if (month) {
						showYear =$('#tl_show_by_time_year').text();
						toptxt+=(showYear+"年"+month+"月");
					};
                    
                    if (totalTmp==eventSortChecked.length && month !="") {
                    	toptxt +="全部操作记录";
                    };
                    
                    if (totalTmp==eventSortChecked.length && month =="") {
                    	toptxt +="欢迎使用彩云";
                    };
                    if (totalTmp<eventSortChecked.length && totalTmp>0) {
                    var count =2;
                    count = totalTmp==1?1:2;
                    for (var i = 0; i < eventSortChecked.length; i++) {
						if (eventSortChecked[i]&&count==2){
							toptxt+=(eventSortCheckedtxt[i]+"、");
						}
						if (eventSortChecked[i]&&count==1){
							toptxt+=(eventSortCheckedtxt[i]+(totalTmp<3?'':"等")+"操作记录");
						}
                       if (eventSortChecked[i])
                       	count-=1;
					}
                    };
                    if (totalTmp == 0) {
                    	toptxt +="没有选择任何事件筛选条件";
                    };                   					
					$('.opr-timeline-logo-txt').html(toptxt);	
					if (baseEventInfo.count == 0) {
						timelineHtml =  '<div class="right_noline_con">'+
					      			'<div class="opr-timeline-box" style="height:71px;overflow:hidden;">'+
					      			'</div>'+
					      				'<div style="padding: 55px 0px 0px 200px;">'+
										'<div class="cy_null_logo"></div>';
					if (totalTmp==eventSortChecked.length && month=="") {
					timelineHtml+='<p class="cy_null_txt">亲，您的时光中还没有记录哦</p>'+
								  '<p class="cy_null_txt">先去上传点东西再来看看吧！</p>';
					}else{
                     timelineHtml+='<p class="cy_null_txt">亲，没有筛选到任何相关记录哦！</p>';
					};				
										
					timelineHtml+='</div></div>';
					$('#innerTimeLineView').html(timelineHtml);
					return;
					};	
					
				}
				if (!sortflag) {
					 self.initToptxt(); 	
				};
				if (curEventNum >= totalEventNum){
					return;
				}
				
				curEventNum += baseEventInfo.eventInfolist.length;
				var html = "";
				
				if (curEventNum >= totalEventNum) { //滚动条滚动到事件全部加载完成后,即curEventNum==count后可以载入注册html
					html = self.createTimeLineModule(baseEventInfo) + regHtml;
				} else {
					html = self.createTimeLineModule(baseEventInfo);
				}
				timelineHtml += html;
				$('#innerTimeLineView').html(timelineHtml);
				callBackFlag = true;
				tips.hide();
			};
			
			self.createTimeLineModule = function(baseEventInfo) {
				if (baseEventInfo.count == 0){
					return "";
				}

				var html = "";
				var eventInfoArr = baseEventInfo.eventInfolist; //获取所有eventInfo
				eventInfoArr.sort(function(x, y) {
					return x["oprTime"] < y["oprTime"] ? 1 : -1;
				}); //eventInfoArr数组按时间进行降序排序
				for (var i = 0; i < baseEventInfo.length; i++) {

					var eventInfo = eventInfoArr[i];
					var oprTime = eventInfo.oprTime;		// 20130906170226
					var oprDay = oprTime.substring(0, 8);	// 20130917
					var desc = self.getEventDesc(eventInfo);
					if ( ! dayObj[oprDay] ) { //a里面没有这个时间属性，说明是第一次，需先建立opr-timeline-label
						dayObj[oprDay] = 1;
						html += '<div class="opr-timeline-label clearfix">' +
									'<div class="opr-timeline-newtime '+desc.css+'">' +
										'<div class="opr-timeline-day">'+
											'<i class="i1">'+oprTime.substring(6,8)+'</i>'+
											'<i class="i2">'+oprTime.substring(0,4)+'/'+oprTime.substring(4,6)+'</i>'+
										'</div>'+
										'<span>' + desc.opDesc + '</span>'+
									'</div>'+
								'</div>';
					} else {
						html += '<div class="opr-timeline-label sub clearfix">' +
									'<div class="opr-timeline-newtime '+desc.css+'">' +
										'<span>' + desc.opDesc + '</span>'+
									'</div>'+
								'</div>';
					}
					
					html += '<div class="opr-timeline-sub">'+
					            getThumbnailDiv(eventInfo, desc) + 
					            '<div class="opr-timeline-from"><p class="'+desc.clientTypeCss+'" title="' + desc.clientTypeTips + '" style = "width:5px;">'+oprTime.substring(8,10)+':'+oprTime.substring(10,12)+'</p></div>'+
					            '<div class="opr-timeline-line clearfix"><div>分隔线</div></div>'+
					        '</div>';
					
				}
				return html;
			};
			
			self.getClientType = function(eventInfo) {
				var sysnBakType = ",9,18,19,20,21,22,23,24,25,26,27,29,30,31,32,33,34,35,";
				if (sysnBakType.indexOf("," + eventInfo.eventType + ",") >= 0 && eventInfo.clientType) {
					return '通过' + eventInfo["clientType"];
				} else return "";
			};
			
			self.shieldOperate = function(eventInfo) { //屏蔽timeline左侧图标及文件名的点击事件
				var eventCss = 'class="dbclickPreview" style="cursor:pointer;" ';
				// 屏蔽不可撤销已撤销的修改事件
				if ((eventInfo["eventType"] == 4 && eventInfo["status"] != 1)) {
					eventCss = '';
				}
				//屏蔽企业空间的文件夹事件
				if (eventInfo["spaceContext"] == 3 && eventInfo["subObjects"] && eventInfo["subObjects"][0].split("|")[1] == 2) {
					eventCss = '';
				}
				return eventCss;
			};
			
			self.getThumbsPath = function(eventInfo) {
				var eventType = eventInfo["eventType"];
				if (eventType == 9 || eventType == 19) { //同步
					return 'src="../images/newportal2/web_ico/m_sync.png"';
				} else if (eventType == 18 || eventType == 20 || eventType == 21 || eventType == 22 || eventType == 23 || eventType == 24 || eventType == 25 || eventType == 26 || eventType == 27 || eventType == 34 || eventType == 35) { //备份
					return 'src="../images/newportal2/web_ico/m_backup.png"';
				} else if (eventType == 29 || eventType == 30 || eventType == 31 || eventType == 32 || eventType == 33) { //恢复
					return 'src="../images/newportal2/web_ico/m_recover.png"';
				}
				var subObjects = eventInfo["subObjects"];
				if (subObjects == undefined || subObjects == null || subObjects == "" || subObjects == "null") { //没有文件名称的
					return 'src="../images/newportal2/web_ico/m_no_file.png"';
				} else {
					var name = subObjects[0].split("|")[0];
					var objType = subObjects[0].split("|")[1];
					var fileType = subObjects[0].split("|")[4];
					if (objType == 2) { //目录
						return 'src="../images/newportal2/web_small/folder.gif"';
					} else if (objType == 1) { //文件
						var fmt = "";
						if (name.lastIndexOf(".") > 0)
							fmt = name.substring(name.lastIndexOf(".") + 1, name.length).toLowerCase();
						if (fmt != "") {
							if (subObjects[0].split("|")[7]) {
								return 'src="' + subObjects[0].split("|")[7] + '" onerror="javascript:this.src=\'' + utils.Icon.getIconByExtName(fmt, true) + '\'"';
							}
							if (fileType == 1 && subObjects[0].split("|")[7]) { //图片类型显示缩略图
								return 'src="' + subObjects[0].split("|")[7] + '" onerror="javascript:this.src=\'' + utils.Icon.getIconByExtName(fmt, true) + '\'"';
							} else if (fileType == 3 && subObjects[0].split("|")[7]) { //视频类型显示缩略图
								return 'src="' + subObjects[0].split("|")[7] + '" onerror="javascript:this.src=\'' + utils.Icon.getIconByExtName(fmt, true) + '\'"';
							} else {
								return 'src="' + utils.Icon.getIconByExtName(fmt, true) + '"';
							}
						} else {
							return 'src="../images/newportal2/web_small/none.png"';
						}
					}

				}
			};
						
			
			var getThumbnailDiv = function(eventInfo, desc) {
				var html = '';
				var subObjects = eventInfo.subObjects;
				var clickCss = self.shieldOperate(eventInfo);
                //文件同步和取消分享事件不展示缩略图
				if (eventInfo.eventType == '9'||eventInfo.eventType == '17') {
					return '';
				};
				if (eventInfo.eventType == '38') {
					if (eventInfo.spaceOwner && ownerMSISDN != eventInfo.spaceOwner.replace("+86", "").replace("E", "")) {
							return '';
						}
				};
				//||eventInfo.eventType == '17'||eventInfo.eventType == '38'
				if (desc.opSubDesc != '' && desc.opSubIcon != '') {
					var subInfo = '||||||||';
					if (eventInfo.eventType == '6' || eventInfo.eventType == '7' || eventInfo.eventType == '14') {
						var extInfo = desc.extInfo;
						if (!extInfo.ppath) {
							return '';
						};
						subInfo = extInfo.pname + '|2|' + extInfo.ppath.substring(extInfo.ppath.lastIndexOf('/')+1) + '|' + extInfo.ppath + '|||||';
					}
					var hiddenInput = self.getHiddenInput(eventInfo, subInfo);

					
					return '<div class="timeline_table_div clearfix">' +
								'<table width="100%" border="0">' + 
									'<tr>' +
											'<td width="45"><img width="39" height="38"  src="../images/newportal2/s.gif" class=" dbclickPreview ' + desc.opSubIcon + '" ' + clickCss + '>'+hiddenInput+'</td>' +
											'<td><span ' + clickCss + '>' + desc.opSubDesc + '</span>'+hiddenInput+'</td>' +
									'</tr>' +
								'</table>' + 
							'</div> ';
				}
				
				if (subObjects && subObjects.length > 0) {
					
					if (eventInfo.eventType == '2') {	// 删除事件，特殊处理。
						if (eventInfo.spaceOwner && ownerMSISDN != eventInfo.spaceOwner.replace("+86", "").replace("E", "")) {
							return '';
						}
						//return '<input type="hidden" value="' + eventInfo.eventType + "|" + eventInfo.eventOwner + "|" + eventInfo.spaceContext + "|" + eventInfo.spaceOwner + "|" + subObject + '"/>';
						//var hiddenInput = self.getHiddenInput(eventInfo, '||||||||');
						
						var zhexie = '这个';
						if (subObjects.length > 1) {
							zhexie = '这些';
						}
						
						var isAllDir = true;
						for (var i = 0; i < subObjects.length; i++) {
							if (subObjects[i].split('|')[1] == 1) {
								isAllDir = false;
							}
						}
						var wenjian = '文件';
						if (isAllDir) {
							wenjian = '文件夹';
						}
						
						hiddenInput = '<input type="hidden" value="' + eventInfo.eventType + "|" +
						            eventInfo.eventOwner + "|" + eventInfo.spaceContext + "|" + eventInfo.spaceOwner + "|"+ 
						            eventInfo.eventID + "|"+ eventInfo.status + "|" + subObjects[0] + (zhexie + wenjian) + '"/>';
						return '<div class="timeline_table_div clearfix">' +
									'<table width="100%" border="0">' + 
										'<tr>' +
												'<td width="45"><img width="39" height="38" src="../images/newportal2/s.gif"  class=" dbclickPreview ' + self.getClassByExtName('goback') + '" ' + clickCss + '>'+hiddenInput+'</td>' +
												'<td><span ' + clickCss + '>恢复'+(subObjects.length>1?'这些':'此')+'文件</span>'+hiddenInput+'</td>' +
										'</tr>' +
									'</table>' + 
								'</div> ';
								
					}
					var thumbnails = new Array();
					var nonThumb = new Array();
					var thumbShowCount = 0;		// 最多显示7个缩略图
					var fileShowCount = 0;		// 最多显示2个文件列表项



					for (var i = 0; i < subObjects.length; i++) {
						var meta = subObjects[i].split('|');
						var objType = meta[4];
						var isPhoto = false;
						//var reportType = thisQueue[i].ctype.toLowerCase() !=='' && suffixs.indexOf(thisQueue[i].ctype.toLowerCase()) != -1 ? '1' : '0';
						var name = meta[0], icon = self.getClassByExtName('unknown');
						if (name.lastIndexOf(".") > 0) {
							var fmt = name.substring(name.lastIndexOf(".") + 1).toLowerCase();
							if (fmt) 
							isPhoto = suffixs.indexOf(fmt)!=-1?true : false;
							icon = self.getClassByExtName(fmt);
						}
						if (meta[1] == 2) {	// 目录
							icon = self.getClassByExtName('folder');
						}
						
						var hiddenInput = self.getHiddenInput(eventInfo, subObjects[i]);
						var clickCss = self.shieldOperate(eventInfo);
						//objType != '3' && meta[7] && meta[7] != '' 
						if (((isPhoto &&meta[1]==1)|| objType == '1')  && thumbShowCount < 7) {	// 1：图片， 	// 最多显示7个缩略图  
							if (meta[7]== undefined) {
								meta[7] = "../images/newportal2/timeline_config_img.gif";
							};
							if (objType == '1' && meta[7] == '') {
								meta[7] = "../images/newportal2/timeline_config_img.gif";
							}
							icon = "../images/newportal2/timeline_config_img.gif";
							thumbnails.push('<li a="'+objType+'"><table border="0" width="100%" height="100%"><tr><td align="center" valign="middle" style="text-align:center;"><img  class=" dbclickPreview " '+
							' onload=\'javascript:if(this.width>=this.height&&this.width>95) this.width="95";  else if(this.height>95) this.height="95"; \'  '+ 
							'src="' + meta[7]+'" onerror=\'javascript:this.src="' + icon + '"\' ' + clickCss + '>'+hiddenInput+'</td></tr></table></li>');
							thumbShowCount++;
						} else if(thumbShowCount >= 7 && objType == '1') {
							continue;
						} else if (fileShowCount < 2) {
							nonThumb.push(  '<tr>' +
													'<td width="45"><img width="39" height="38" src="../images/newportal2/s.gif"  class=" dbclickPreview ' + icon + '" ' + clickCss + '>'+hiddenInput+'</td>' +
													'<td><span ' + clickCss + ' title="' + meta[0] + '">' + meta[0].substringName(25, meta[1] == '2') + '</span>'+hiddenInput+'</td>' +
											'</tr>');
							fileShowCount++;
						}
					}
					if (thumbnails.length > 0) {
						html += '<div class="timeline_table_div clearfix">' +
									'<ul class="timeline_pic_list">' + 
										thumbnails.join('') +
									'</ul>' +
								'</div> ';
					}
					
					if(nonThumb.length > 0) {
						html += '<div class="timeline_table_div clearfix">' +
									'<table width="100%" border="0">' + 
										nonThumb.join('') +
									'</table>' + 
								'</div> ';
					}
				}
				
				return html;
			};

			self.getHiddenInput = function(eventInfo, subObject) {
				//space取值用eventinfo节点的信息，替换subobject里面space
				var newsubObject = '';
				if (eventInfo.space) {
					var str = subObject.split('|');
					
					str[3] =eventInfo.space;
					for (var i = 0; i < str.length; i++) {
						 newsubObject +=str[i];
						 if (i<str.length-1) {
						 	newsubObject +='|';
						 };
					};
					subObject = newsubObject;
				};
				return '<input type="hidden" value="' + eventInfo.eventType + "|" + eventInfo.eventOwner + "|" + eventInfo.spaceContext + "|" + eventInfo.spaceOwner + "|" + subObject + '"/>';
			};
			
			self.getEventDesc = function(eventInfo) {
				var desc = {};
				var type = parseInt(eventInfo.eventType);
				desc.css = 'L-assignment';
				desc.opDesc = 'opType:' + type;
				desc.opSubDesc = '';
				desc.opSubIcon = '';
				
				var subObjects = eventInfo.subObjects;
				var fileType = '';
				var firstSubObjectName = '';
				var operator = "";
				if (eventInfo["operator"] && ownerMSISDN != eventInfo["operator"].replace("+86", "").replace("E", "")) {
					operator = eventInfo["operator"].replace("+86", "").replace("E", "");
					operator = linkData.getNameForPhoneMatch(operator).substringName(25) ;
				}

				if (subObjects && subObjects.length > 0) {
					var meta = subObjects[0].split('|');
					firstSubObjectName = meta[0].substringName(25, meta[1] == '2');
					
					// 文件后缀
					if (firstSubObjectName.lastIndexOf('.') == -1) {
						desc.fileExt = '';
					} else {
						desc.fileExt = firstSubObjectName.substring(firstSubObjectName.lastIndexOf('.') + 1);
					}
				}
				if(firstSubObjectName) {
					var hasFile = false, hasFolder = false;
					for (var i = 0; i < subObjects.length; i++) {
						var sps = subObjects[i].split('|');
						if (sps[1] == 1) {
							hasFile = true;
						} else if (sps[1] == 2) {
							hasFolder = true;
						}
					}
					
					if (hasFile && hasFolder) {
						fileType = '文件';
					} else if (hasFile) {
						fileType = '文件';
					} else if (hasFolder) { 
						fileType = '文件夹';
					}

				}
				
				switch (type) {	// 上传
					case 1:
						desc.css = 'L-upload';
						desc.opDesc = '上传了'+ (eventInfo.objectNum > 1 ? firstSubObjectName + '等'+eventInfo.objectNum+'个'+ fileType : fileType+firstSubObjectName ) ;
						break;
						
					case 2:		// 删除文件/文件夹
					    desc.css = 'L-delete';
						desc.opDesc = self.deleltFileOpr(eventInfo,fileType);
						break;
						
					case 3:		// 删除文件/文件夹（任意个）_撤销
						desc.css = 'L-renew';
						desc.opDesc = '恢复了'+ (eventInfo.objectNum > 1 ? firstSubObjectName + '等'+eventInfo.objectNum+'个'+ fileType : fileType+firstSubObjectName ) ;
						break;
						
					case 4:		// 文件编辑（包含上传同名覆盖/全量更新/差量更新）edit
						desc.css = 'L-edit';
						desc.opDesc = '编辑了'+ (eventInfo.objectNum > 1 ? firstSubObjectName + '等'+eventInfo.objectNum+'个'+ fileType : fileType+firstSubObjectName ) ;
						
						desc.opSubDesc = firstSubObjectName;
						//desc.opSubIcon = self.getClassByExtName(desc.fileExt);
						break;
						
					case 5:		// 文件修改_撤销undo_edit
						desc.css = 'L-edit';
						desc.opDesc = '撤销修改了'+ (eventInfo.objectNum > 1 ? firstSubObjectName + '等'+eventInfo.objectNum+'个'+ fileType : fileType+firstSubObjectName ) ;
						break;
						
					case 6:		// 移动文件/文件夹mov
						desc.css = 'L-move';
						desc.opDesc = '移动了'+ (eventInfo.objectNum > 1 ? firstSubObjectName + '等'+eventInfo.objectNum+'个'+ fileType : fileType+firstSubObjectName )+'到'+self.getFileEnterPath(eventInfo)+'目录下';						
						desc.extInfo = $.parseJSON(eventInfo.extInfo);
						if(!desc.extInfo)
						      desc.extInfo = "";
						desc.opSubDesc = desc.extInfo.pname;
						desc.opSubIcon = self.getClassByExtName('folder');
						break;
						
					case 7: 	// 复制文件/文件夹copy
						desc.css = 'L-copy';
						desc.opDesc = '复制了'+ (eventInfo.objectNum > 1 ? firstSubObjectName + '等'+eventInfo.objectNum+'个'+ fileType : fileType+firstSubObjectName )+'到'+self.getFileEnterPath(eventInfo)+'目录下' ; 
						
						desc.extInfo = $.parseJSON(eventInfo.extInfo);
						if(!desc.extInfo)
						      desc.extInfo = "";
						desc.opSubDesc = desc.extInfo.pname;
						desc.opSubIcon = self.getClassByExtName('folder');
						break;
					
					case 8: 	// 重命名文件/文件夹rename
						desc.css = 'L-rename';
						desc.opDesc = '重命名了' + fileType + firstSubObjectName;
						break;
						
					case 9:// 文件/文件夹自动同步（同步造成的版本更新不可撤销）sync
						desc.css = 'L-synchro';
						desc.opDesc = '同步了'+(eventInfo.objectNum > 1 ? firstSubObjectName + '等'+eventInfo.objectNum+'个'+ fileType : fileType+firstSubObjectName )  ;
						if(!eventInfo.objectNum || eventInfo.objectNum == "0" || firstSubObjectName =="")
						desc.opDesc = '同步了文件';
						break;
						
					case 10:	// 生成外链getouterlink
						desc.css = 'L-share'; 
						desc.opDesc = '生成了' + fileType+ firstSubObjectName  + '的外链分享';
						break;
						
					case 11:	// 取消外链delouterlink
						desc.css = 'L-breakLink'; 
						desc.opDesc = '取消了' + (eventInfo.objectNum > 1 ? firstSubObjectName + '等'+eventInfo.objectNum+'个'+ fileType : fileType+firstSubObjectName )   + '的外链分享';
						break;
						
					case 12:	// 下载download
						desc.css = 'L-download';
						desc.opDesc = '下载了' + (eventInfo.objectNum > 1 ? firstSubObjectName + '等'+eventInfo.objectNum+'个'+ fileType : fileType+firstSubObjectName );
						break;
						
//					case 13: desc.css = '';	 break;	// 没有13
						
					case 14:	// 转存savetodisk
						desc.css = 'L-unloading';
						desc.extInfo = $.parseJSON(eventInfo.extInfo);
						if (!desc.extInfo) {
							desc.extInfo = {};
						};
						desc.opSubDesc = desc.extInfo && desc.extInfo.pname ? desc.extInfo.pname.substringName(25, true):'';
						desc.opSubIcon = self.getClassByExtName('folder');
						desc.opDesc = '转存了'+ (desc.extInfo.sourcetype==='share'?"":"外链")+
						(eventInfo.objectNum > 1 ?firstSubObjectName+'等'+eventInfo.objectNum+'个'+ fileType : fileType + firstSubObjectName)+'到'+(desc.extInfo.pname?desc.extInfo.pname.substringName(25, true)+'目录下':'我的彩云');
						
						break;
						
					case 15:		// 共享发起sendshare
						desc.css = 'L-ishare';
						desc.opDesc = '分享了'+ fileType + firstSubObjectName +'给'+ self.getShareOpr(eventInfo);
						break;
						
					case 16:		// 收到共享receiveshare
						desc.css = 'L-receiveShare';
						desc.opDesc = '收到了来自'+operator+'的'+'分享'+fileType+firstSubObjectName;
						break;
						
					case 17:		// 取消共享cancelshare
						desc.css = 'L-deleteShare';
						desc.opDesc = self.cancelShareOpr(eventInfo,fileType);
						break;
						
					case 18:	// 照片自动备份autobackup_photo
						desc.css = 'L-synchro';
						desc.opDesc = '备份了手机图片';
						
						desc.opSubDesc = '成功备份了' + eventInfo.objectNum + '张手机图片';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功备份了手机图片';
						desc.opSubIcon = self.getClassByExtName('pimg');
						break;
						
					case 19:		// 通讯录自动同步autobackup_contacts
						desc.css = 'L-synchro';
						desc.opDesc = '同步了手机通讯录';
						
						desc.opSubDesc = '成功同步了' + eventInfo.objectNum + '个联系人';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功同步联系人';
						desc.opSubIcon = self.getClassByExtName('padd');
						break;
						
					case 20: 	// 短彩信自动备份autobackup_message
						desc.css = 'L-synchro';
						desc.opDesc = '备份了手机短彩信';
						desc.opSubDesc = '成功备份了' + eventInfo.objectNum + '条手机短彩信';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功备份了手机短彩信';
						desc.opSubIcon = self.getClassByExtName('sms');
						break;
						
					case 21: 	// 视频自动备份autobackup_message
						desc.css = 'L-synchro';
						desc.opDesc = '备份了手机视频';
						
						desc.opSubDesc = '成功备份了' + eventInfo.objectNum + '个手机视频';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功备份了手机视频';
						desc.opSubIcon = self.getClassByExtName('pvid');
						break;
						
					case 22:	// 应用自动备份autobackup_app
						desc.css = 'L-synchro';
						desc.opDesc = '备份了手机应用';
						desc.opSubIcon = self.getClassByExtName('papp');
						break;
						
					case 23:	// 日历自动备份autobackup_calendar
						desc.css = 'L-synchro';
						desc.opDesc = '同步了手机日历';
						desc.opSubDesc = '成功同步了' + eventInfo.objectNum + '条日历';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功同步了日历';
						desc.opSubIcon = self.getClassByExtName('pcal');
						break;
						
					case 24:	// 手动备份通讯录manualbackup_contacts
						desc.css = 'L-upload';
						desc.opDesc = '手动备份通讯录';
						
						desc.opSubDesc = '成功备份了' + eventInfo.objectNum + '个联系人';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功备份了联系人';
						desc.opSubIcon = self.getClassByExtName('padd');
						break;
						
					case 25:	// 手动备份短彩信manualbackup_message
						desc.css = 'L-upload';
						desc.opDesc = '备份了手机短彩信';
						desc.opSubDesc = '成功备份了' + eventInfo.objectNum + '条手机短彩信';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功备份了手机短彩信';
						desc.opSubIcon = self.getClassByExtName('sms');
						break;
						
					case 26:	// 手动备份应用manualbackup_app
						desc.css = 'L-upload';
						desc.opDesc = '备份了手机应用';
						desc.opSubDesc = '成功备份了' + eventInfo.objectNum + '个手机应用';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功备份了手机应用';
						desc.opSubIcon = self.getClassByExtName('papp');
						break;
						
					case 27:	// 手动备份日历manualbackup_calendar
						desc.css = 'L-upload';
						desc.opDesc = '同步了手机日历';
						desc.opSubDesc = '成功同步了' + eventInfo.objectNum + '条日历';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功备份了日历';
						desc.opSubIcon = self.getClassByExtName('pcal');
						break;
					
//					case 28: desc.css = ''; break;	// 注册
						
					case 29:	// 手机照片恢复
						desc.css = 'L-renew';
						desc.opDesc = '恢复了手机图片';
						
						desc.opSubDesc = '成功恢复了' + eventInfo.objectNum + '张云端手机图片到手机本地';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功恢复了云端手机图片到手机本地';
						desc.opSubIcon = self.getClassByExtName('pimg');
						break;
						
					case 30:	// 手机通讯录恢复
						desc.css = 'L-renew';
						desc.opDesc = '手机通讯录恢复';
						
						desc.opSubDesc = '成功恢复了' + eventInfo.objectNum + '个联系人';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功恢复了联系人';
						desc.opSubIcon = self.getClassByExtName('padd');
						break;
						
					case 31:	// 短彩信恢复
						desc.css = 'L-renew';
						desc.opDesc = '恢复了手机短彩信';
						desc.opSubDesc = '成功恢复了' + eventInfo.objectNum + '条云端手机短彩信到手机本地';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功恢复了云端手机短彩信到手机本地';
						desc.opSubIcon = self.getClassByExtName('sms');
						break;
						
					case 32:	// 视频恢复
						desc.css = 'L-renew';
						desc.opDesc = '恢复了手机视频';
						
						desc.opSubDesc = '成功恢复了' + eventInfo.objectNum + '个云端手机视频到手机本地';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功恢复了云端手机视频到手机本地';
						desc.opSubIcon = self.getClassByExtName('pvid');
						
					case 33:	// 应用恢复
						desc.css = 'L-renew';
						desc.opDesc = '恢复了手机应用';
						desc.opSubDesc = '成功恢复了' + eventInfo.objectNum + '个云端手机应用到手机本地';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功恢复了云端手机应用到手机本地';
						desc.opSubIcon = self.getClassByExtName('papp');
						break;
						
					case 34:	// 手动备份照片
						desc.css = 'L-upload';
						desc.opDesc = '备份了手机图片';
						
						desc.opSubDesc = '成功备份了' + eventInfo.objectNum + '张手机图片';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功备份了手机图片';
						desc.opSubIcon = self.getClassByExtName('pimg');
						break;
						
					case 35:	// 手动备份视频
						desc.css = 'L-upload';
						desc.opDesc = '备份了手机视频';
						
						desc.opSubDesc = '成功备份了' + eventInfo.objectNum + '个手机视频';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功备份了手机视频';
						desc.opSubIcon = self.getClassByExtName('pvid');
						break;
						
					case 36:	// 赠送空间
						var evtInfo = $.parseJSON( eventInfo.extInfo);	
						if(!evtInfo)
						    evtInfo = "";				
						desc.css = 'L-assignment';
						desc.opDesc ='完成了'+ evtInfo.taskname+'任务';
						// 礼物图标+获得NG的免费空间奖励
						desc.opSubDesc = '获得'+evtInfo.spaceamount+'的免费空间奖励';
						desc.opSubIcon = self.getClassByExtName('gift');
						break;
						
					case 37:	// 新建文件夹
						desc.css = 'L-newBuilt';
						desc.opDesc = '新建了文件夹' + firstSubObjectName;
						break;
						
					case 38:	// 退出共享
						desc.css = 'L-deleteShare';
						desc.opDesc = self.exitShareOpr(eventInfo,fileType);
						break;
						
					case 39:	// 删除消息
						desc.css = 'L-delete';
						desc.opDesc = '删除了云端手机短彩信';
						desc.opSubDesc = '成功删除了' + eventInfo.objectNum + '条云端手机短彩信';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功删除了云端手机短彩信';
						desc.opSubIcon = self.getClassByExtName('sms');
						break;
						
					case 40:	// 通讯录自动备份
						desc.css = 'L-upload';
						desc.opDesc = '通讯录自动备份';
						desc.opSubDesc = '成功备份了' + eventInfo.objectNum + '个联系人';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功备份了联系人';
						desc.opSubIcon = self.getClassByExtName('padd');
						break;
						
					case 41:	// 手动备份通讯录
						desc.css = 'L-upload';
						desc.opDesc = '手动备份通讯录';
						desc.opSubDesc = '成功备份了' + eventInfo.objectNum + '个联系人';
						if(!eventInfo.objectNum ||eventInfo.objectNum == "0" )
						 desc.opSubDesc = '成功备份了联系人';
						desc.opSubIcon = self.getClassByExtName('padd');
						break;
						
					case 42:	// 删除应用
						desc.css = 'L-delete';
						desc.opDesc = '删除了云端手机应用';
						desc.opSubIcon = self.getClassByExtName('papp');
						break;
				};					
								
				var clientType = eventInfo.clientType;
				desc.clientTypeCss = 'f-other';
				desc.clientTypeTips = '来自未知客户端';
				 if (clientType) {
				 	clientType = clientType.toLowerCase();
				
				switch (clientType) {
					case 'web': desc.clientTypeCss = 'f-ie'; desc.clientTypeTips = '来自web客户端';  break;
					case 'windows': desc.clientTypeCss = 'f-windows';desc.clientTypeTips = '来自windows客户端'; break;
					case 'pc': desc.clientTypeCss = 'f-pc'; desc.clientTypeTips = '来自pc客户端';break;
					case 'iphone': desc.clientTypeCss = 'f-ios';desc.clientTypeTips = '来自iPhone客户端'; break;
					case 'android': desc.clientTypeCss = 'f-android';desc.clientTypeTips = '来自android客户端'; break;
					case 'ipad': desc.clientTypeCss = 'f-ipad'; desc.clientTypeTips = '来自iPad客户端';break;
				}
			};
				
				return desc;
			};
			
			self.getClassByExtName = function(extName){
				var hasMidpic = midpic.indexOf(extName)!=-1?true : false;
				if (hasMidpic) 
					return "tl_icon_"+extName;
				else
					return  "tl_icon_unknown";

			};
			self.oprWithUndo = function(eventInfo, flag) {
				var opr = "";
				var buttonTip = "";
				if (flag == "del") {
					opr = "删除";
					buttonClass = "m_re";
				} else if (flag == "mod") {
					opr = "修改";
					buttonClass = "m_re_pre";
				}
				var operator = "";
				if (eventInfo["operator"] && ownerMSISDN != eventInfo["operator"].replace("+86", "").replace("E", "")) {
					operator = eventInfo["operator"].replace("+86", "").replace("E", "");
					operator = '<span title="' + linkData.getNameForPhoneMatch(operator) + '">' + linkData.getNameForPhoneMatch(operator).substringName(25) + "</span>&nbsp";
				}
				var ret = operator + opr;
				if (eventInfo["status"] == 1) {
					return '<span class="floatleft">' + ret + '</span>' + '<b class="' + buttonClass + '" style="cursor:pointer">' + buttonTip + '<input type="hidden" value="' + eventInfo["eventOwner"] + '|' + eventInfo["eventID"] + '"></b>';
				} else { //已恢复或者不可撤销的，不需要出现恢复按钮
					return "<span class='floatleft'><font color='gray'><s>" + ret + "</s></font></span>";
				}
			};
			
			self.getFileEnterPath = function(eventInfo) {
				var extInfo = eval('(' + eventInfo["extInfo"] + ')');
				if (!extInfo) {
					return "";
				}
				if (3 == eventInfo.spaceContext) { //企业空间的目录目前不支持跳转，先屏蔽
					return '<em title="' + extInfo["pname"] + '">' + extInfo["pname"].substringName(25, true) + '<input type="hidden" value="' + extInfo["ppath"] + '|' + extInfo["pname"] + '"></em>';
				}
				return   extInfo["pname"].substringName(25, true);
			};
			
			self.getShareOpr = function(eventInfo) {
				var ret = "";
				var extInfo = eval('(' + eventInfo["extInfo"] + ')');
				var rsharelst = extInfo["rsharelst"].split("|");
				if (rsharelst.length == 1) {
					if (ownerMSISDN == rsharelst[0].replace("+86", "")) {
						ret += '您';
					} else {
						ret += linkData.getNameForPhoneMatch(rsharelst[0].replace("+86", "")).substringName(25) ;
					}
	
				} else if (rsharelst.length > 1) {
					if (ownerMSISDN == rsharelst[0].replace("+86", "")) {
						ret += "您等" + rsharelst.length + "个好友";
					}else{
						ret +=  linkData.getNameForPhoneMatch(rsharelst[0].replace("+86", "")).substringName(25) + "等" + rsharelst.length + "个好友";
					
					}
	
				}
	
				return ret;
			};
		
			self.cancelShareOpr = function(eventInfo,fileType) {
				if (3 == eventInfo.spaceContext) {

						var extInfo = eval('(' + eventInfo["extInfo"] + ')');
						var rsharelst = extInfo["rsharelst"].split("|");
						var entpiesename = spaceOwnerChecked.split("|")[2];
						//var entpiesename = $("spaceOwnerDrop").find("a").html()
						if (rsharelst.length == 1) {
							if (ownerMSISDN == rsharelst[0].replace("+86", "")) {
                            return '您已退出'+entpiesename+'的企业空间分享';
							}else if (ownerMSISDN == eventInfo["operator"].replace("+86", "").replace("E", "")) {
                              return '<span title="' + linkData.getNameForPhoneMatch(rsharelst[0].replace("+86", "")) + '">' + linkData.getNameForPhoneMatch(rsharelst[0].replace("+86", "")).substringName(25) + '</span> 已经退出企业空间分享';
							}else{
								return '<span title="' + linkData.getNameForPhoneMatch(rsharelst[0].replace("+86", "")) + '">' + linkData.getNameForPhoneMatch(rsharelst[0].replace("+86", "")).substringName(25) + '</span> 已经退出'+entpiesename+'的企业空间分享';
							}
							
						} else if (rsharelst.length > 1) {
							if (ownerMSISDN == rsharelst[0].replace("+86", "")) {
                            return '您等'+rsharelst.length+'人已经退出'+entpiesename+'的企业空间分享';
							}else if (ownerMSISDN == eventInfo["operator"].replace("+86", "").replace("E", "")) {
                              return '<span title="' + linkData.getNameForPhoneMatch(rsharelst[0].replace("+86", "")) + '">' + linkData.getNameForPhoneMatch(rsharelst[0].replace("+86", "")).substringName(25) + '</span>等'+rsharelst.length+'人已经退出企业空间分享';
							}else{
								return '<span title="' + linkData.getNameForPhoneMatch(rsharelst[0].replace("+86", "")) + '">' + linkData.getNameForPhoneMatch(rsharelst[0].replace("+86", "")).substringName(25) + '</span>等'+rsharelst.length+'人已经退出'+entpiesename+'的企业空间分享';
							}
						}

					} else {

						var extInfo = eval('(' + eventInfo["extInfo"] + ')');
						var rsharelst = extInfo["rsharelst"].split("|");
						var firstSubObjectName = '';
						var subObjects = eventInfo.subObjects;
						var meta = subObjects[0].split('|');
						var isDir = meta[1] == '2';
						if (subObjects && subObjects.length > 0) {
					        firstSubObjectName = meta[0];
				        }
				         
						if (eventInfo["operator"] && ownerMSISDN == eventInfo["operator"].replace("+86", "").replace("E", "")) {
							return '取消了对'+linkData.getNameForPhoneMatch(rsharelst[0].replace("+86", "")).substringName(25) + (rsharelst.length>1?'等'+rsharelst.length+'个好友':'')+'的'+fileType+'分享'+firstSubObjectName.substringName(25, isDir);
						} else {
						       if(!eventInfo["operator"]) 
						          return   "取消了对我的"+fileType+"分享"+firstSubObjectName.substringName(25);
							return  linkData.getNameForPhoneMatch(eventInfo["operator"].replace("+86", "").replace("E", "")).substringName(25) + "取消了对我的"+fileType+"分享"+firstSubObjectName.substringName(25, isDir);
						}
					}

				};

				self.exitShareOpr = function(eventInfo,fileType){                       
						var firstSubObjectName = '';
						var subObjects = eventInfo.subObjects;
						var meta = subObjects[0].split('|');
						var isDir = meta[1] == '2';
						if (subObjects && subObjects.length > 0) {
					        firstSubObjectName = meta[0];
				        }
						if (eventInfo["operator"] && ownerMSISDN == eventInfo["operator"].replace("+86", "").replace("E", "")) {
							return '删除了来自'+linkData.getNameForPhoneMatch(eventInfo["spaceOwner"].replace("+86", "")).substringName(25) +'的'+fileType+'分享'+firstSubObjectName.substringName(25, isDir) ;
						} else {
						      if(!eventInfo["operator"]) 
						       return '删除了你的'+fileType+'分享'+firstSubObjectName.substringName(25) ; 
							return  linkData.getNameForPhoneMatch(eventInfo["operator"].replace("+86", "").replace("E", "")).substringName(25) + '删除了你的'+fileType+'分享'+firstSubObjectName.substringName(25, isDir) ;
						}
					
				};

				self.deleltFileOpr = function(eventInfo,fileType){
					var firstSubObjectName = '';
					var subObjects = eventInfo.subObjects;
					var meta = subObjects[0].split('|');
					var isDir = meta[1] == '2';
					if (subObjects && subObjects.length > 0) {
					     firstSubObjectName = meta[0];
				     }
				     if (eventInfo["operator"] && ownerMSISDN == eventInfo["operator"].replace("+86", "").replace("E", "")) {
				     	return '删除了'+ (eventInfo.objectNum > 1 ? firstSubObjectName.substringName(25, isDir) + '等'+eventInfo.objectNum+'个'+ fileType : fileType+firstSubObjectName.substringName(25, isDir) );
				     }else{
				         if(!eventInfo["operator"]) 
				          return '删除了你的'+(subObjects.length>1?firstSubObjectName.substringName(25, isDir)+'等'+subObjects.length+'个' + fileType:fileType+firstSubObjectName.substringName(25, isDir)); 
				     	return linkData.getNameForPhoneMatch(eventInfo["operator"].replace("+86", "").replace("E", "")).substringName(25) 
				     	+'删除了你的'+(subObjects.length>1?firstSubObjectName.substringName(25, isDir)+'等'+subObjects.length+'个' + fileType:fileType+firstSubObjectName.substringName(25, isDir));
				     };

				};
				
				$('#tl_usage_summary').find('.opr-timeline-logo').mousemove(function(){
					$('#tl_usage_summary').addClass('light');
				}).mouseout(function(){
					$('#tl_usage_summary').removeClass('light');
				});
				
				$('#tl_usage_summary_day, #tl_usage_summary_month').unbind('click').bind('click', function(){
					beginDate = '';
					endDate = '';
					month = '';
					showYear = '';
					showYearFilter(new Date().getFullYear());
					if ($('#tl_select_all_opType').hasClass('selected')) {
						self.reloadByFilter();
					} else {
						$('#tl_show_by_opType_menu').find('li.firstline').click();	// 全选操作类型
					}
				});
				
				$("#timeline_goTop").unbind('click').bind('click', function(e) {
					$('body').animate({
							scrollTop: 0
						}, 'fast');
					if (document.documentElement.scrollTop) {
							document.documentElement.scrollTop = 0;
					}
					return false;
				});
						
				self.show = function() {
					$("#enterpriseNum,#enterpriseRole").hide(); //从分享管理的企业空间直接跳到timeline会出现这两个div没隐藏掉，暂用次方法隐藏				
					$('#tl_usage_summary, #timeline_goTop').show();
					
					//用户网盘使用量和排位有值则显示
					$('#tl_show_by_opType,#tl_show_by_time,#timeline_now').show();
					if (userDiskRank !="") {
						$('#tl_usage_summary_percent').html(userDiskRank);
					};
					if (diskUsedSum != "") {
						$('#tl_usage_summary_G').html(diskUsedSum);
					};
					
					regHtml =   '<div class="opr-timeline-endtitle">' +
						            '<div class="opr-timeline-end"></div>' +
						            '<div class="opr-timeline-end_title"><b>欢迎来到彩云的精彩世界</b></div>' +
						        '</div>' + 
					        '</div>' +
				        '</div>';
					
					self.initVar();
					self.reload();
				};

				self.reload = function() {
					var totalTmp = 0;
					var curEventSort = "0";
					for (var i = 0; i < eventSortChecked.length; i++) {
						curEventSort += eventSortChecked[i];
						totalTmp += eventSortChecked[i];
					}
					if (totalTmp == eventSortChecked.length){
						curEventSort = "100000000000000000000000000000";
					} else {
						curEventSort += "0000000000000000000000";
					}
					
					var param = {};
					var _15DayBeforenow = new Date();
					_15DayBeforenow.setTime(new Date().getTime() - 1000 * 60 * 60 * 24 * 15);
					
					if (spaceOwnerChecked.split("|")[0] == 1) { //我的动态
						param = {
							//account: '18801230020',
							eventSort: curEventSort,
							spaceSort: '1',
							bNum: curEventNum + 1,
							eNum: curEventNum + pageNum, //一次加载50条事件
							bTime: beginDate,
							eTime: endDate
						};
					} else if (spaceOwnerChecked.split("|")[0] == 2) {
						param = {
							//account: '18801230020',
							eventSort: curEventSort,
							spaceSort: '2',
							spaceOwner: spaceOwnerChecked.split("|")[1],
							bNum: curEventNum + 1,
							eNum: curEventNum + pageNum, //一次加载50条事件
							bTime: beginDate,
							eTime: endDate
						};
					}
					ajaxEventReq = timelineManager.queryEvents(
						param,
						function(eventParams, eventRet) {
							self.showContent(eventRet["baseEventInfo"]);
							self.regEvent();
							return false;
						},
						function() {
							//alert("queryEvents error!");
						}
					);
				};

				self.regEvent = function() {
					if (totopflag) {
						self.toTopEvent();
					};					
					scroll = scrollHandler();
					self.eventSortEvent();
					//self.restoreEvents();
					self.fileDbClickEvent();
					self.enterDirEvent();
				}; //end regEvent
				
				self.toTopEvent = function() {
					$('body').animate({
							scrollTop: 0
						}, 'fast');
					if (document.documentElement.scrollTop) {
							document.documentElement.scrollTop = 0;
					}
					return false;
				};
				
				var showYearFilter = function(showYear) {
					if (showYear > curYear) {
						return ;
					}
					

					var today = new Date();
					var curYear = today.getFullYear();
					
					if(showYear >= curYear) {
						$('#tl_next_year').unbind('click').bind('click', function() {	// 下一年不能点击
							return false;
						}).removeClass('t-down').addClass('t-nodown');
					} else {
						$('#tl_next_year').unbind('click').bind('click', function() {	// 下一年能点击
							var showYear = parseInt($('#tl_show_by_time_year').html());	// 当前展示年份
							showYear = showYear + 1;
							showYearFilter(showYear);
							return false;
						}).removeClass('t-nodown').addClass('t-down');
					}
					
					if (showYear <= 2000) {
						$('#tl_pre_year').unbind('click').bind('click', function() {	// 上一年不能点击
							return false;
						}).removeClass('t-up').addClass('t-noup');
					} else {
						$('#tl_pre_year').unbind('click').bind('click', function() {	// 上一年能点击
							var showYear = parseInt($('#tl_show_by_time_year').html());	// 当前展示年份
							showYear = showYear - 1;
							showYearFilter(showYear);
							return false;
						}).removeClass('t-noup').addClass('t-up');
					}
					
					if (showYear == curYear) {
						var curMonth = today.getMonth();
						$('#tl_show_by_time_menu').find('ul li a').each(function(i, aTag) {
							if (i > curMonth) {
								$(aTag).addClass('wordGray');
							} else {
								$(aTag).removeClass('wordGray');
							}
						});
					} else if(showYear < curYear) {
						$('#tl_show_by_time_menu').find('ul li a').removeClass('wordGray');
					}
					
					$('#tl_show_by_time_year').html(showYear);
				};
				
				var checkOpTypeAllSelect = function() {
					var isAllSelected = true;
					$('#tl_show_by_opType_menu').find('li').each(function() {
						if(!$(this).hasClass('firstline') && !$(this).find('span').hasClass('selected')) {
							isAllSelected = false;
						}
					});
					
					if(isAllSelected) {
						$('#tl_show_by_opType_menu').find('li.firstline span').addClass('selected');
					} else {
						$('#tl_show_by_opType_menu').find('li.firstline span').removeClass('selected');
					}
				};

				var resetAllSelect = function() {
					$('#tl_show_by_opType_menu').find('li').each(function() {
						if(!$(this).find('span').hasClass('selected')) {
							$(this).find('span').addClass('selected');
						}
					});
					
					if(!$('#tl_show_by_opType_menu').find('li.firstline span').hasClass('selected')) {
						$('#tl_show_by_opType_menu').find('li.firstline span').addClass('selected');
					} 
				};

				
				var maintainEventSortCheckedByOp = function() {
					$('#tl_show_by_opType_menu').find('li').each(function() {
						var li = $(this);
						if(!li.hasClass('firstline')) {
							var index = li.find('a').attr('index');
							if (index && index != '') {
								index = parseInt(index);
								if(li.find('span').hasClass('selected')) {
									eventSortChecked[index] = 1;
								} else {
									eventSortChecked[index] = 0;
								}
							}
						}
					});
				};
				
				self.reloadByFilter = function() {
					if (ajaxEventReq) {
						ajaxEventReq.abort();
					}
					
				//	$('#tl_show_by_opType_menu, #tl_show_by_time_menu').hide();
					self.initVar();
					self.reload();
				};
				
				self.eventSortEvent = function() { //eventSort下拉框的事件注册
					if (showYear) {
						$('#tl_show_by_time_year').html(showYear);
					}else{
						$('#tl_show_by_time_year').html(new Date().getFullYear());
					};
	
					$('#tl_show_by_time').unbind('click').bind('click', function(e) {
						$('#tl_show_by_time_menu').toggle();
						$('#tl_show_by_opType_menu').hide();
						
						showYear = parseInt($('#tl_show_by_time_year').html());	// 当前展示年份
						showYearFilter(showYear);
						return false;
					});
					
					$('#tl_show_by_opType').unbind('click').bind('click', function(e) {
						$('#tl_show_by_opType_menu').toggle();
						$('#tl_show_by_time_menu').hide();
						return false;
					});
					
					$('#tl_show_by_opType_menu, #tl_show_by_time_menu').mouseleave(function(e) {
						$(this).hide();
					});
					
					
					$("#tl_show_by_opType_menu").undelegate().delegate('li', 'click', function(e) {
						var li = $(this);
						if (li.hasClass('firstline')) { 	// 全选复选框
							if (li.find('span').hasClass('selected')) {	// 取消全选
								$("#tl_show_by_opType").find('li span').removeClass('selected');
								eventSortChecked = [0, 0, 0, 0, 0, 0, 0];
							} else {	// 全选
								$("#tl_show_by_opType").find('li span').addClass('selected');
								eventSortChecked = [1, 1, 1, 1, 1, 1, 1];
							}
						} else {
							var span = li.find('span');
							if (span.hasClass('selected')) {	// 取消选
								span.removeClass('selected');
								$('#tl_select_all_opType').removeClass('selected');	// 全选复选框取消选中
							} else {	// 选
								span.addClass('selected');
								// 检测是否全选了
								checkOpTypeAllSelect();
							}
							maintainEventSortCheckedByOp();
						}
						
						self.reloadByFilter();	// 重新加载数据
						var yymm ="";
							if(month)
							    yymm = showYear + (month>9?month:("0"+month));
						caiyun.pvlog('timeline', 'filter', eventSortChecked.join(""),yymm);
						return false;
					});
					
					var doubleNumber = function(num) {
						return (num < 10 ? '0' : '') + num;
					};
					
					// 点击月份
					$('#tl_show_by_time_menu').undelegate().delegate('ul li a', 'click', function(e) {
						var aTag = $(this);
						if(aTag.hasClass('wordGray')) {	// 不能点击的月份
							return false;
						}
						
						var year = $('#tl_show_by_time_year').text();
						 month = aTag.text();
						month = parseInt(month.substring(0, month.length));
						var eDate = new Date();
						eDate.setFullYear(year, month, 1);
						eDate.setHours(0, 0, 0, 0);
						eDate.setTime(eDate.getTime() - 1000);
						
						beginDate = year + doubleNumber(month) + '01000000';
						endDate = year + doubleNumber(month) + eDate.getDate() + '235959';
						
						self.reloadByFilter();
						
						// 统计选择筛选动态类型
						var yymm = year+(month>9?month:("0"+month));
						caiyun.pvlog('timeline', 'filter', eventSortChecked.join(""),yymm);
						return false;
					});
					
					// 按时间过滤，显示所有
					$('#tl_show_by_time_all').unbind('click').bind('click', function(e) {
						beginDate = '';
						endDate = '';
						month = "";
						showYear = "";
						self.reloadByFilter();
						
						// 统计选择筛选动态类型
						caiyun.pvlog('timeline', 'filter', eventSortChecked.join(""));
					});
					
					$("#eventSortDrop").unbind('click').bind('click', function(e) {
						$("#eventSortDiv").find("li").each(function(index) {
							if (eventSortChecked[index] == 1 && $(this).find("span").attr("class").indexOf("ta_check") < 0)
								$(this).find("span").addClass("ta_check");
							else if (eventSortChecked[index] == 0 && $(this).find("span").attr("class").indexOf("ta_check") >= 0)
								$(this).find("span").removeClass("ta_check");
						});
						$("#eventSortDiv").toggle();
						return false;
					});
					
					$("#eventSortDiv").find("li").each(function(index) {
						$(this).unbind('click').bind('click', function(e) {
							if ($(this).find("span").attr("class").indexOf("ta_check") >= 0) {
								$(this).find("span").removeClass("ta_check");
								eventSortChecked[index] = 0;
							} else {
								$(this).find("span").addClass("ta_check");
								eventSortChecked[index] = 1;
							}
							if (ajaxEventReq) ajaxEventReq.abort();
							self.initVar();
							self.reload();
							// 统计选择筛选动态类型		
							var yymm ="";
							if(month)
							    yymm = showYear + (month>9?month:("0"+month));		 	
							caiyun.pvlog('timeline', 'filter', eventSortChecked.join(""),yymm);
							return false;
						});
					});
				}; //end eventSortEvent
				
				self.spaceOwnerEvent = function() { //spaceOwner下拉框的事件注册
					if ($("#spaceOwnerDiv").find("li").length > 1) { //如果该帐号没有所属企业(length==1)，则不监听点击事件，即这里没有下拉框
						$("#spaceOwnerDrop").unbind('click').bind('click', function(e) {
							$("#spaceOwnerDiv").toggle();
							return false;
						});
					}
					$("#spaceOwnerDiv").find("li").each(function(index) {
						$(this).unbind('click').bind('click', function(e) {
							var totalTmp = 0;
							var curEventSort = "0";
							for (var i = 0; i < eventSortChecked.length; i++) {
								curEventSort += eventSortChecked[i];
								totalTmp += eventSortChecked[i];
							}
							if (totalTmp == eventSortChecked.length) curEventSort = "100000000000000000000000000000";
							else curEventSort += "00000000000000000000000";
							if ($(this).find("a").html() == "我的动态") {
								spaceOwnerChecked = "1|";
							} else {
								spaceOwnerChecked = "2|" + $(this).find("input").val() + "|"+$(this).find("a").html();
							}
							$("#spaceOwnerDrop").html($(this).find("a").html());
							$("#spaceOwnerDiv").hide();
							self.initVar();
							self.reload();
							// 统计选择筛选动态类型				 	
							caiyun.pvlog('timeline', 'switch', spaceOwnerChecked.split("|")[0] - 1);
							//timeLineTaskAjax(param);
							return false;
						});
					});
					$("#spaceOwnerDiv").mouseleave(function() {
						$("#spaceOwnerDiv").hide();
					});
				}; //end spaceOwnerEvent
								
				self.undodeleteFiles = function(eventOwner,eventID,filetype) {
							ajaxRestoreReq = timelineManager.restoreEvents({
									eventOwner: eventOwner,
									eventID: eventID
								},
								function(restoreParam, restoreRet) {
									if (restoreRet.showMessage != "") {
										if(restoreRet.showMessage == "亲，这个文件已被删除了，无法再看啦" && filetype ==2){
										 iMsgTip.tip("亲，这个文件夹已被删除了，无法再看啦");
										 return;
										}
										iMsgTip.tip(restoreRet.showMessage);
										return;
									}
									self.initVar();
									self.reload();
								},
								function() {
									//alert("restoreEvents error!");
								}
							);
				};
				
				
				self.fileDbClickEvent = function() {
					$(".dbclickPreview").each(function() {
						//var cando=true;//用于避开两次单击时间果断，出现两次事件操作的标识
						$(this).unbind('click').bind('click', function(e) {
							//eventType|eventOwner|spaceContext|spaceOwner|文件或目录名|对象类型|文件或目录id|path|文件类型|time|大缩略图地址(播放地址)|小缩略图地址
							var valArr = $(this).siblings("input[type='hidden']").val().split("|");
							//同步备份恢复部分
							var eventType = valArr[0];
							if (eventType == 18 || eventType == 29 || eventType == 34) { //手机图片
								caiyun.ui.model.fileContent.switchToView(caiyun.constants.MY_PHONE_CONTENT_VIEW);
								caiyun.myPhoneOperate.switchTo('my_image');
								return;
							} else if (eventType == 19 || eventType == 24 || eventType == 30) { //通讯录
								caiyun.ui.model.fileContent.switchToView(caiyun.constants.MY_PHONE_CONTENT_VIEW);
								caiyun.myPhoneOperate.switchTo('contact');
								return;
							} else if (eventType == 20 || eventType == 25 || eventType == 31|| eventType == 39) { //短彩信
								caiyun.ui.model.fileContent.switchToView(caiyun.constants.MY_PHONE_CONTENT_VIEW);
								caiyun.myPhoneOperate.switchTo('sms');
								return;
							} else if (eventType == 21 || eventType == 32 || eventType == 35) { //视频
								caiyun.ui.model.fileContent.switchToView(caiyun.constants.MY_PHONE_CONTENT_VIEW);
								caiyun.myPhoneOperate.switchTo('my_video');
								return;
							} else if (eventType == 22 || eventType == 26 || eventType == 33) { //应用
								caiyun.ui.model.fileContent.switchToView(caiyun.constants.MY_PHONE_CONTENT_VIEW);
								caiyun.myPhoneOperate.switchTo('apps');
								return;
							} else if (eventType == 23 || eventType == 27) { //日历
								caiyun.ui.model.fileContent.switchToView(caiyun.constants.MY_PHONE_CONTENT_VIEW);
								caiyun.myPhoneOperate.switchTo('calendar');
								return;
							} else if (eventType == 2 ) {//删除
								//caiyun.constants.RECYCLEBIN_CONTENT_VIEW
								if (valArr) {
									var eventID = valArr[4];
									var eventOwner = valArr[1].replace("+86", "");
									var status = valArr[5];
									if (status == 2) {
										iMsgTip.tip("亲，" + valArr[11] + "已被恢复过，不能再点啦");
									}else if (status == 1) {
										 self.undodeleteFiles(eventOwner,eventID,valArr[7]);
									};
								};
								return ;
							} else if (eventType == 36 ) {
								return window.location.href = "index_freeMission.jsp";
							};
							if (2 == valArr[5]) {
								//iMsgTip.tip("目录");
								//if(3==valArr[2]){//企业空间的目录目前不支持跳转，先屏蔽
								//	return;
								//}
								self.enterDir(valArr[6], valArr[4], valArr[0], valArr[7],valArr[2], valArr[3]); //cataID,cataName,eventType,path,spacecontext, spaceOwner
								//return;
							} else {
								var p = {};
								var suffix = valArr[4].substring(valArr[4].lastIndexOf(".") + 1, valArr[4].length);
								if (judgement.isDocPrev(suffix)) { //文档类预览
									p.contentInfo = {};
									p.contentInfo.contentName = valArr[4];
									p.contentInfo.contentID = valArr[6];
									p.contentInfo.contentSuffix = valArr[4].substring(valArr[4].lastIndexOf(".") + 1, valArr[4].length);
									p.contentInfo.ownerMSISDN = valArr[1].replace("+86", "");
									//p.contentInfo.path=valArr[7].substring(0,valArr[7].lastIndexOf("/"));
									p.contentInfo.path = valArr[7];
									if (valArr[2] == 3) { //企业空间
										p.contentInfo.spaceOwner4Timeline = valArr[3];
									}
									if (valArr[2] == 1 && valArr[1].indexOf("E") == 0) { //兼容预览后重新生成的下载事件出现了spaceowner=null和spacecontext=1的错误
										p.contentInfo.spaceOwner4Timeline = valArr[1];
									}
									fileOperator.dbclickHandler4Timeline(p, spaceOwnerChecked.split("|")[1] ? spaceOwnerChecked.split("|")[1] : "");
								} else {
									var contentID = valArr[6];
									var qryCntInfoparam = {
										contentID: contentID,
										entryShareCatalogID: "",
										//path:""
										path: valArr[7]
										//path:valArr[7].substring(0,valArr[7].lastIndexOf("/"))
									};
									if (valArr[2] == 2) {
										//qryCntInfoparam.entryShareCatalogID = valArr[7];
									}
									if (valArr[2] == 3 || (valArr[2] == 1 && valArr[1].indexOf("E") == 0)) { //兼容预览后重新生成的下载事件出现了spaceowner=null和spacecontext=1的错误
										qryCntInfoparam.spaceOwner = valArr[1].replace("+86", "");
									}
									//if(!cando)return;
									//cando=false;
									if (ajaxContentReq) ajaxContentReq.abort();
									ajaxContentReq = timelineManager.queryContentInfo(
										qryCntInfoparam,
										function(cntParam, cntRet) {
											if (cntRet.showMessage != "") {
												iMsgTip.tip(cntRet.showMessage);
												//cando=true;
												return;
											}
											p.id = [];
											p.id.push(contentID);
											p.contentInfo = cntRet.contentInfoObj;
											if (valArr[2] == 2) { //共享空间，下载文件时需要提供path，ownerMSISDN
												p.path = valArr[7];
												p.ownerMSISDN = valArr[3].replace("+86", "");
											}
											if (valArr[2] == 3) { //企业空间，下载文件时需要提供path
												p.path = valArr[7];
												p.ownerMSISDN = valArr[3];
												//p.timelineFlag=true;
											}
											fileOperator.dbclickHandler4Timeline(p, spaceOwnerChecked.split("|")[1] ? spaceOwnerChecked.split("|")[1] : "");
											//cando=true;
										},
										function() {
											//cando=true;
										}
									); //end timelineManager.queryContentInfo
								}
							}
						}); //end click event
					}); //end each
				};
				
				self.enterDirEvent = function() {
					$(".clickEnterDir").each(function() {
						$(this).unbind('click').bind('click', function(e) {
							var valArr = $(this).find("input[type='hidden']").val().split("|");
							var cataID = valArr[0].substring(valArr[0].lastIndexOf("/") + 1, valArr[0].length);
							self.enterDir(cataID, valArr[1]);
						});
					});
				};
				
				self.enterDir = function(cataID, cataName, eventType, path,spacecontext, spaceOwner) { //目录id,目录名字,事件类型,绝对路径，操作空间类型
					var dp = {
						contentID: cataID,
						startNumber: 1,
						endNumber: 40,
						//entryShareCatalogID:cataID,
						sortDirection: 1
					};
					if (eventType == 16 || eventType == 14 || spacecontext == 2) { //接收到共享的情况下要多传入的参数path
						dp.path = path;
					}
					if (cataID == constants.rootIds.myFolder) {
						$('#toFile').click();
					} else {
						ajaxDiskReq = timelineManager.queryDisk(
								dp,
								function(diskParam, diskRet) {
									if (diskRet.showMessage != "") {
										if (diskRet.dci.resultcode == "OSE_200000409" ) {
											iMsgTip.tip("亲，这个文件夹已被删除了，无法再看啦");
											return;
										};
										iMsgTip.tip(diskRet.showMessage);
										return;
									}
									if (diskRet["dci"]["resultcode"] == 0) {
										var p = {};
										p.cataID = cataID;
										p.name = cataName;
										caiyun.ui.model.fileContent.switchToView(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW);
										if (spaceOwner.match(/^\+86/)) {
											spaceOwner = spaceOwner.substring(3);
										}
										if (eventType == 16 || (spacecontext == 2 && (eventType != 3||eventType != 38) && spaceOwner != ownerMSISDN))
											fileOperator.enterDir4Timeline(p, diskRet["dci"], {
												cataID: constants.cannotModifyIDs.root_receiveShare,
												name: "收到的分享"
											}, path);
										else
											fileOperator.enterDir4Timeline(p, diskRet["dci"], null, path);
									}
								},
								function() {
									//console.log("disk fail...");
								}
						);
					}
				};
				
				self.leave = function() {
//					if (ajaxSpaceReq) ajaxSpaceReq.abort();
					if (ajaxRegReq) ajaxRegReq.abort();
					if (ajaxEventReq) ajaxEventReq.abort();
					if (ajaxRestoreReq) ajaxRestoreReq.abort();
					if (ajaxContentReq) ajaxContentReq.abort();
					if (ajaxDiskReq) ajaxDiskReq.abort();
					if (ajaxUserInfo) ajaxUserInfo.abort();
					callBackFlag = false;
					//清空筛选条件
					resetAllSelect();
					eventSortChecked = [1, 1, 1, 1, 1, 1, 1];
					month = '';
					showYear = '';
					beginDate = '';
					endDate = '';
					$(window).unbind("scroll", self.scroll);
				};
				
				self.scroll = function() {
					//console.log("滚动条到: "+$(document).scrollTop()); 
					//console.log("页面的文档高度 ："+$(document).height());
					//console.log('浏览器的高度：'+$(window).height());
					totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop());
					//console.log(callBackFlag);
					if ($(document).height() <= totalheight + 3 && callBackFlag && curEventNum < totalEventNum) {
						//console.log("-----load----");
						callBackFlag = false;
						totopflag = false;
						//加载数据
						self.reload();
					}
				};
				
				var scrollHandler = function() {
					$(window).bind("scroll", self.scroll);
				};
				
				changeTimeFormat = function(time) {
					return time.substring(6, 8) + "/" + time.substring(4, 6) + "/" + time.substring(0, 4);
				};
			}; //end self.init
			
			// 注册到页面初始化方法中
			caiyun.ui.initList.push(self);

			
			
			setvalue = function(key, value) {
				key = value;
				return key;
			};
		})();