/*
 * 定义彩云用到的种种常量，新增常量之前，请先检查此文件，看看是否该常量已存在
 */
(function() {
	window.caiyun.constants = {
		DEFAULT_FILE_CONTENT_VIEW: 'MY_FILE',
		PICTURES_CONTENT_VIEW: 'PICTURES',
		FILES_CONTENT_VIEW: 'FILES',
		MUSICS_CONTENT_VIEW: 'MUSICS',
		VIDEOS_CONTENT_VIEW: 'VIDEOS',
		SOFTWARES_CONTENT_VIEW: 'SOFTWARES',
		SHARE_CONTENT_VIEW: 'SHARE',
		SAFEBOX_CONTENT_VIEW: 'SAFE_BOX',
		SAFEBOX_FILE_CONTENT_VIEW: 'SAFE_BOX_FILE',
		RECYCLEBIN_CONTENT_VIEW: 'RECYCLEBIN',
		SEARCH_CONTENT_VIEW: 'SEARCH',
		TIMELINE_CONTENT_VIEW: 'TIMELINE',
		MY_PHONE_CONTENT_VIEW: 'MY_PHONE',
		FREEMISSION_CONTENT_VIEW: 'FREEMISSOPN',

		//查询文件数据缓存group
		FILE_LIST_CACHEGROUP: 'grid_list_cache_group',
		//查询来源数据缓存group
		FILE_SRC_CACHEGROUP: 'file_src_cache_group',
		//查询文件分享数据缓存group
		FILE_SHARE_LIST_CACHEGROUP: 'file_share_list_cache_group',
		//查询回收站文件数据缓存group
		FILE_RECYCLEBIN_LIST_CACHEGROUP: 'file_recyclebin_list_cache_group',
		//查询我的分享文件数据缓存group
		FILE_MY_FILE_SHARE_LIST_CACHEGROUP: 'file_my_file_share_list_cache_group',
		//保存用户企业权限数据缓存group
		ENTERPRISE_AUTH_CACHEGROUP: 'enterprise_auth_cache_group',
		//图片浏览数据缓存group
		PICTURE_LIST_CACHE_GROUP: 'picture_list_cache_group',
		//视频播放数据缓存group
		VIDEO_LIST_CACHE_GROUP: 'video_list_cache_group',

		//要中止的ajax发送对象
		abortAjaxs: null,
		//要中止的ajax发送对象(仅供共享管理使用)
		abortAjaxs_share: null,
		abortShareAjaxs: null,
		//移动复制时选中同步文件夹是否提示，默认1提示
		hint_syncAdd: 1,
		//保险箱要销的窗口对象
		safeboxCloseWin: {},
		//是否是保险箱用户
		isSafeBoxUser: null,
		//右边菜单栏按钮样式
		leftNavCss: ["i1", "i2", "i5", "i6"],

		receiveFolderName: "收到的分享",

		//磁盘使用量
		diskUsedSize: null,

		regs: {
			//移动用户
			msisdnReg: /^((134[0-8]{1})|(13[5-9]\d)|(15[0,1,2,7,8,9]\d)|(18[2378]\d)|(14\d\d))\d{7}$/,
			//safebox密码规则
			safeboxPwdReg: /^(([a-zA-Z]+[0-9]+)|([0-9]+[a-zA-Z]+))[a-zA-Z0-9]*$/i
		},

		rootIds: {
			myFolder: '00019700101000000001', // 本应页面上获取
			myFolderWithUserID: wdUserId + '00019700101000000001',
			mySafeBox: '00019700101000000040', // 保险箱
			mySafeBoxWithUserID : wdUserId + '00019700101000000040',  // 保险箱
			mySdBak: '00019700101000000042', // SD卡备份
			myRecycleBin: '00019700101000000054', // 回收站ID
			share: 'share' //文件分享
		},

		fileTypes: {
			picture: '1', // 图片，类型码为1
			music: '2', // 音频，类型码为2
			video: '3', // 视频，类型码为3
			document: '99', // 文档，类型码为4
			mobileSoftware: '12', // 手机软件，类型码为12
			typed: 'TYPEDFILES' // 资源文件虚拟目录(1-4的集合)
		},

		fileTypesName: {
			'1': '图片', // 图片，类型码为1
			'2': '音乐', // 音频，类型码为2
			'3': '视频', // 视频，类型码为3
			'99': '文档', // 文档，类型码为4
			'12': '手机软件' // 手机软件，类型码为12
		},

		rootIdsName: {
			'00019700101000000001': '彩云',
			'00019700101000000040': '保险箱',
			'00019700101000000042': 'SD卡备份',
			'00019700101000000054': '回收站'
		},

		//手机软件的类型
		phoneSoftType: {
			IOS: ['pxl', 'ipa', 'deb'],
			Android: ['apk'],
			Symbian: ['sis', 'sisx'],
			Java: ['jar', 'jad'],
			BlackBerry: ['alx', 'cod', 'ota'],
			WindowPhone7: ['xap'],
			MTK: ['mrp', 'met', 'app', 'meg', 'vre', 'mor']
		},

		// 手机操作系统
		phoneOS: {
			all: 'all',
			IOS: 'IOS',
			Android: 'Android',
			Java: 'Java',
			BlackBerry: 'BlackBerry',
			WindowPhone7: 'WindowPhone7',
			MTK: 'MTK',
			Symbian: 'Symbian'
		},

		view: {
			web: 'web',
			win: 'window'
		},

		// 类型查询、后缀查询的ID前缀
		catalogIDPrefix: {
			byType: 'type_',
			byPhoneOS: 'phoneos_',
			bySearch: 'search'
		},

		// 搜索结果的虚拟目录名称
		searchCatalogName: '搜索到的文件',

		gridInitConfig: {
			startNum: 1,
			endNum: 40,
			catalogSortType: 0,
			contentSortType: 0,
			fileShareSrt: 1, //外链的排序方式：0 更新时间,1 创建时间,2 下载次数.
			myFileShareSrt: 0, //我的分享文件排序方式： 0 更新时间（默认）
			fileShareSndRcv: 0 //查询我的分享文件，默认显示发送共享
		},

		// 最大下载体积 B
		maxDownloadsize: 100 * 1024 * 1024,

		// 空文件夹类型提示
		emptyTypeFolderTips: {
			'PICTURES': '我们提供在线图片浏览，上传视频到彩云可随时随地欣赏、分享图片！',
			'VIDEOS': '我们提供在线视频播放，上传视频到彩云可随时随地欣赏、分享视频！',
			'MUSICS': '我们提供在线音乐播放，上传视频到彩云可随时随地欣赏、分享音乐！'
		},

		// 不能移动复制重命名的文件夹ID
		cannotModifyIDs: {
			root_phonePhoto: wdUserId + "00019700101000000043", //手机文件夹图片id
			root_phoneVideo: wdUserId + "00019700101000000044", //手机文件夹视频id
			root_phoneDoc: wdUserId + "00019700101000000046", //手机文件夹文档id
			root_syncMobile: wdUserId + '00019700101000000062', //新增预设同步目录'手机文档'
			root_syncGalary: wdUserId + '00019700101000000061', //新增预设同步目录'手机相册'
			root_syncVideo: wdUserId + '00019700101000000065', //新增预设同步目录'手机视频'
			root_receiveShare: wdUserId + "00019700101000000067" //我收到的文件
		},
		//进入首页跳转
		menuStatus: {
			fileShare: 19, // 文件分享管理
			recyclebin: 11, //回收站
			safebox: 12, //保险箱
			myphone: 2, // myphone
			timeline: 3 // timeline
		},

		//支持文档预览格式
		canPrevSuffix: ["DOC", "DOCX", "XLS", "XLSX", "PPT", "PPTX", "RTF", "CSV", "PPS", "ODT", "ODP", "ODS", "TXT", "XML", "PDF" ,"EML"], //HTML

		//支持文档在线编辑的格式
		canEditSuffix: ["DOC", "DOCX", "XLS", "XLSX", "PPT", "PPTX", "RTF", "TXT"],

		//支持冲印的图片
		canPrintImageSuffix: "JPG",

		//企业彩云用户权限
		enterpriseAuth: {
			downloadAndUpload: "downloadAndUpload", //上传和下载权限
			download: "download", //下载权限
			upload: "upload", //上传权限
			admin: "admin", //管理员权限
			edit: "edit", //编辑权限
			view: "view" //查看权限
		},

		// 公共账号常量
		publisherAccountConstants : {
			// 正式发布目录
			publisherDir : wdUserId + '00019700101000000500',
			// 草稿箱
			draftBox : wdUserId + '00019700101000000502',
			// 收到的分享，公共目录后缀
			publisherDirSuffix : '00019700101000000503'
		}
	};
})();