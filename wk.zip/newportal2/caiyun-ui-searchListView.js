/**
 * 搜索的文件列表视图
 */
(function() {
    var constants = window.caiyun.constants;
    var judgement = window.caiyun.judgement;
    var util = window.caiyun.util;
    var self = window.caiyun.ui.model.searchListView;


    // 打开文件夹列
    window.caiyun.ui.CyGridColumns.OpenFolderColumn = function(columnType, valign, align, width){
        var args = [];
        args[0] = 'OpenFolderColumn';
        args[1] = valign;
        args[2] = align;
        args[3] = width ? width : '20%';
        window.caiyun.ui.CyGridColumns.BaseColumn.apply(this, args);
    };

    window.caiyun.ui.CyGridColumns.OpenFolderColumn.prototype = new window.caiyun.ui.CyGridColumns.BaseColumn();

    window.caiyun.ui.CyGridColumns.OpenFolderColumn.prototype.template = template.compile(
        '<td id="openFolder_<%=grid.getId()%>_<%=rowItem.id%>"valign="<%=valign %>" align="<%=align %>" class="openFolderColumn" style="cursor: pointer;"><h2></h2>' +
            '<span style="float: left; _margin-top: 3px">打开所在文件夹</span>' +
        '</td>'
    );

    window.caiyun.ui.CyGridColumns.OpenFolderColumn.prototype.render = function(grid, item, rowItem) {
        var context = {
            valign: this.valign,
            align: this.align,
            grid: grid,
            item: item,
            rowItem: rowItem,
            column : this
        };
        if(this.hide){
            return '';
        }
        return this.template(context);
    };

    window.caiyun.ui.CyGridColumns.OpenFolderColumn.prototype.ons = [{
        events : 'click',
        selector : 'td.openFolderColumn',
        handler : function(event){
            var itemId = $(this).attr('id').split('_')[2];
            window.caiyun.ui.model.fileContent.switchToView(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW);
            caiyun.operate.enterDirLocate({contID : itemId});
            event.stopPropagation();
            return false;
        }
    },{
        events : 'mouseenter mouseleave',
        selector : 'td.openFolderColumn',
        handler : function(event){
            var span = this.childNodes[1];
            if(event.type === 'mouseenter'){
                $(span).css('text-decoration','underline');
            }else{
                $(span).css('text-decoration','none');
            }
        }
    }];

    self.init = function() {
        var operate = window.caiyun.operate;
        var visible = false;
        var disable = true;
        var $listView = $('#searchlistView');

        var checkBoxCol = new caiyun.ui.CyGridColumns.SelectCheckBox();
        checkBoxCol.width = '5%';
        var fileInfoCol = new caiyun.ui.CyGridColumns.FileInfo();
        fileInfoCol.width = '52%';
        var openCol = new caiyun.ui.CyGridColumns.OpenFolderColumn();
        openCol.width = '18%';
        var sizeCol = new caiyun.ui.CyGridColumns.Words();
        sizeCol.width = '10%';

        var dateCol = new caiyun.ui.CyGridColumns.Words();
        dateCol.width = '15%';
        var fileGrid = window.caiyun.ui.CyDefaultGrid({
            renderId: 'searchlistView',
            row: new caiyun.ui.CyGridRows.SelectedRow(),
            columns: [checkBoxCol, fileInfoCol, openCol,sizeCol,dateCol]
        });


        //判断是否可以显示图标的缩略图
        var isImagePreview = function(contentType) {
            return 1 == contentType || 3 == contentType ? true : false;

        };

        //判断是否是外链文件
        var isLink = function(shareType) {
            return 1 == shareType || 3 == shareType ? true : false;

        };

        //判断是否是外链文件
        var isShare = function(shareType) {
            return shareType == 2 || 3 == shareType ? true : false;

        };

        // 增加数据
        var addDatas = function(data) {
            if (data && visible) {
                // 添加文件
                self.addFiles(data.contentList, data.keyWord);
            }
        };

        // 设置相关处理器 =============================================================
        fileGrid.setSelectedHandler(function(items, total) {
            var ids = [];
            $(items).each(function() {
                ids.push(this.id);
            });
            operate.selectHandler(ids, total);
        });

        fileGrid.setOpenHandler(function(id) {
            operate.dbclickHandler({
                id: id
            });
        });

        fileGrid.setContextmenuHandler(function(e) {
            var menu = window.caiyun.ui.model.fileRightClickMenu;
            menu.openAndLocate(e);
        });

        fileGrid.setConfirmRenameSelectedItemHandler(function(param) {
            var updateItem = param.item;
            operate.rename(updateItem.id, param.newName,
                function(params, result) {
                    //返回成功状态
                    if (result.result.retCode == "0") {
                        updateItem.name = result.result.retObj;
                        updateItem.time = util.formateLifeTime(util.simpleDateformat());
                        var item = fileGrid.getItemById(updateItem.id);
                        item.colItems[1].fileName = updateItem.name;
                        item.colItems[1].showName = updateItem.name.substringName(25);
                        item.colItems[3].value = util.formateLifeTime(util.simpleDateformat());
                        fileGrid.updateItem(updateItem);
                    } else {
                        //显示系统错误，重试
                        window.caiyun.ui.iMsgTip.tip('系统繁忙,请重试！', "error");
                    }
                },
                function() {

                });
        });

        fileGrid.setLinkHandler(function(item) {
            operate.creatFileLink([item.id]);
        });
        fileGrid.setDownLoadHandler(function(item) {
            operate.userDownload([item.id]);
        });
        fileGrid.setShareHandler(function(item) {
            operate.createShareFile([item.id]);
        });

        // 设置相关处理器 =============================================================

        // 注册文件操作监听事件=========================================================

        // 滚动加载更多
        // 绑定滚动事件触发加载文件
        $(window).bind('scroll', function() {
            if (visible && util.isScrollToBottom()) {
                operate.scrollLoadData();
            }
        });

        // 监听视图切换
        operate.onListen('viewSwitch', function(viewMode) {
            if (disable) {
                return;
            }
            if (viewMode == constants.view.web) {
                self.show();
                self.enter();
            } else {
                self.hide();
                fileGrid.clear();
            }
        });

        // 监听刷新数据
        operate.onListen('reload', function() {
            if (disable || !visible) {
                return;
            }
            fileGrid.clear();
        });


        // 监听重命名
        operate.onListen('userRename', function(selected) {
            if (disable || !visible) {
                return;
            }
            fileGrid.renameSelectedItem();
        });

        // 监听加载文件列表事件
        operate.onListen('loadSearchData', function(data) {
            if (disable || visible) {
                addDatas(data);
                if (data.count == 0) {
                    fileGrid.setEmptyStyle(util.getEmptyHtmlStr("没有符合条件的文件哦，换个词试试吧~"));
                } else {
                    fileGrid.show();
                }
            }
        });

        // 监听全选命令
        operate.onListen('selectAll', function() {
            if (disable || !visible) {
                return;
            }
            fileGrid.selectAll();
        });

        // 监听取消全选命令
        operate.onListen('unSelectAll', function() {
            if (disable || !visible) {
                return;
            }
            fileGrid.unSelectAll();
        });


        // END 注册文件操作监听事件===================================================

        // 添加文件，将彩云的文件信息转化为视图要显示的格式
        self.addFiles = function(files, keyWord, inFront) {
            var items = [],
                toolbarShow = true;
            var isNotEnterprise = true;
            // 如果是企业文件加下搜索结果不出现悬浮
            if (judgement.isEnterprisePath()) {
                isNotEnterprise = false;
                openCol.hide = true;
            } else {
                isNotEnterprise = true;
                openCol.hide = false;
            }
            $(files).each(function() {

                var data = new window.caiyun.ui.CyGridItem(this.contentID);
                data.hasShare = isShare(this.shareType);
                data.type = 'file';
                data.hasVirus = this.safestate == 2;
                // 第一列空对象
                data.colItems.push({});
                // 第二列文件信息
                // 缩略图
                var thumbnail = window.caiyun.util.Icon.getIcon(this, true);
                var bigThumbnail = null;
                // 是否需要显示大缩略图
                if (isImagePreview(this.contentType)) {
                    data.bigThumbnail = thumbnail;
                }
                data.colItems.push({
                    fileName: this.contentName,
                    htmlName : util.strBound(this.contentName.substringName(25),keyWord),
                    thumbnail: thumbnail,
                    fromPath: operate.getFileSrc(this),
                    hasHoverTool: toolbarShow && isNotEnterprise
                });
                // 第三列打开文件夹
                data.colItems.push({
                   
                });
                // 第四列文件大小
                data.colItems.push({
                    str: util.formateSize(this.contentSize)
                });
                // 第五列文件时间
                data.colItems.push({
                    str: util.formateLifeTime(this.updateTime),
                    hasLink: isLink(this.shareType)
                });
                items.push(data);
            });
            if (items.length > 0) {
                if (inFront) {
                    fileGrid.unshiftItems(items);
                } else {
                    fileGrid.pushItems(items);
                }
            }
        };

        self.show = function() {
            visible = true;
            fileGrid.show();
            $listView.show();
        };

        self.hide = function() {
            visible = false;
            fileGrid.hide();
            $listView.hide();
            operate.selectHandler([]);
        };

        self.enter = function() {
            $('.t_w60.file_sort_col').attr("style", "width:70%");
            $('#sort_by_size').attr("style", "display: table-cell;width:10%");
            $('#sort_by_size').find(".floatleft").attr("style", "text-decoration:none");
            $('#sort_by_size').find(".floatleft").removeAttr("href");
            $('#sort_by_time').attr("style", "display: table-cell;width:15%");
            $('#sort_by_time').find(".floatleft").attr("style", "text-decoration:none");
            $('#sort_by_time').find(".floatleft").removeAttr("href");

            disable = false;
        };

        self.leave = function() {
            $('.t_w60.file_sort_col').attr("style", "");
            $('#sort_by_size').attr("style", "display: table-cell;");
            $('#sort_by_size').find(".floatleft").removeAttr("style");
            $('#sort_by_size').find(".floatleft").attr("href", "javascript:void(0);");
            $('#sort_by_time').attr("style", "display: table-cell;");
            $('#sort_by_time').find(".floatleft").attr("href", "javascript:void(0);");
            $('#sort_by_time').find(".floatleft").removeAttr("style");
            disable = true;
            fileGrid.clear();
        };
    };

    // 注册到页面初始化方法中
    window.caiyun.ui.initList.push(self);
})();