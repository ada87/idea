//用户容量UI
(function() {
    var self = caiyun.ui.model.diskCapability;

    self.init = function() {
        var fileOperator = caiyun.operate;
        var ajax = window.caiyun.util.caiyunAjax.ajaxRequest;

        //查询并修改容量条显示数据
        var setDiskSize = function() {
            ajax({
                type: 'post',
                url: '../webdisk/personInfoAction!queryDiskInfo.action',
                succFun: getDiskSizeSucc,
                hideLoading: true
            });
        };
        var CyDiskCapability;
        var getDiskSizeSucc = function(params, json) {
            if (!json.userDiskInfo) {
                return;
            }
            var disk = json.userDiskInfo;
            var diskSize = disk.diskSize;
            var userDiskSize = disk.userDiskSize;
            window.caiyun.constants.diskUsedSize = disk.userDiskSize;
            //用户容量对象
            CyDiskCapability = window.caiyun.ui.CyDiskCapability({
                renderTo: 'capacity_bar',
                userDiskSize: userDiskSize,
                diskSize: diskSize
            });
        };
        setDiskSize();

        //更新容量条数据
        var reloadDiskSize = function(json) {
            if (!json.userDiskInfo) {
                setDiskSize();
            } else {
                CyDiskCapability.cysetDiskSize({
                    renderTo: 'capacity_bar',
                    userDiskSize: json.userDiskInfo.userDiskSize,
                    diskSize: json.userDiskInfo.diskSize
                });
            }
        };

        //监听 改变容量   ------------待修改监听事件
        fileOperator.onListen('userDelete', reloadDiskSize);

        self.hide = function() {
            CyDiskCapability.cyDiskCapabilityHide();
        };
        self.show = function() {
            CyDiskCapability.cyDiskCapabilityShow();
        };

    };

    // 将自己的初始化方法加载到ui的initList中
    caiyun.ui.initList.push(self);
})();