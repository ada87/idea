function log_loginout(){
//	if(loginTime){
//		var time = (new Date()).getTime()-parseInt(loginTime);
//		window.caiyun.util.sendPvlog('login','out',time);
//	} 
}
