caiyun.ui.model.searchBar = {};

/**
 * 路径导航条，由knockout实现
 * 
 * 由一个个目录项组成的目录导航条
 */
(function(){
	
	var self = caiyun.ui.model.searchBar;
	var pathBarModel;
	var $pathBar;
	
	self.init = function(){
		
		// 文件操作控制器
		var fileOperator = caiyun.operate;
		
		var element = document.getElementById('searchResultBar');
		
		// jquery对象
		$pathBar = $(element);
		
		self.show = function(){
			$pathBar.show();
		};
		
		self.hide = function(){
			$pathBar.hide();
		};
		
		self.enter = function(){
			
		};
		
		self.leave = function(){
			
		};
		
		// 点击事件
		var _clickItem = function(pathItem){
		    alert(123);
		    caiyun.ui.model.fileContent.switchToView(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW);
			fileOperator.enterDir(pathItem.pathId());
		};
		
		// 注册事件
		fileOperator.onListen('enterDir',function(pathStack){
			$(pathStack).each(function(){
				var pathItem = new caiyun.ui.CyPathItem(self,{id:this.catalogID,name:this.catalogName,data:this},null,{click:_clickItem}); 
			});
		}
		);
	};
	
	caiyun.ui.initList.push(self);
})();
