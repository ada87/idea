/**
 * 排序器列表按钮
 */
(function() {

	var self = caiyun.ui.model.sortorButton;
	var $sortorButton = $('#sortor_button');

	self.init = function() {
		var fileOperate = caiyun.operate;

		// 创建一个排序列表
		var $sortList = $sortorButton.CySortDropMenu({
			id : '', // 菜单ID号
			items : [ { // 下拉菜单选项列表
				id : 'sortByType', // 选项的ID , 必须传，一个下拉菜单中的id不能重复
				name : '按文件类型', // 选项显示名称
				click : function() { // 被点击时的回调函数
					fileOperate.sortHandler({
						sortField : 'type',
						sortType : 'asc'
					});
				}
			}, { // 下拉菜单选项列表
				id : 'sortByName', // 选项的ID , 必须传，一个下拉菜单中的id不能重复
				name : '按文件名称', // 选项显示名称
				click : function() { // 被点击时的回调函数
					fileOperate.sortHandler({
						sortField : 'name',
						sortType : 'desc'
					});
				}
			}, { // 下拉菜单选项列表
				id : 'sortByTimeDesc', // 选项的ID , 必须传，一个下拉菜单中的id不能重复
				name : '时间从新到旧', // 选项显示名称
				click : function() { // 被点击时的回调函数
					fileOperate.sortHandler({
						sortField : 'time',
						sortType : 'desc'
					});
				}
			}, { // 下拉菜单选项列表
				id : 'sortByTimeAsc', // 选项的ID , 必须传，一个下拉菜单中的id不能重复
				name : '时间从旧到新', // 选项显示名称
				click : function() { // 被点击时的回调函数
					fileOperate.sortHandler({
						sortField : 'time',
						sortType : 'asc'
					});
				}
			}, { // 下拉菜单选项列表
				id : 'sortBySizeDesc', // 选项的ID , 必须传，一个下拉菜单中的id不能重复
				name : '大小从大到小', // 选项显示名称
				click : function() { // 被点击时的回调函数
					fileOperate.sortHandler({
						sortField : 'size',
						sortType : 'desc'
					});
				}
			}, { // 下拉菜单选项列表
				id : 'sortBySizeAsc', // 选项的ID , 必须传，一个下拉菜单中的id不能重复
				name : '大小从小到大', // 选项显示名称
				click : function() { // 被点击时的回调函数
					fileOperate.sortHandler({
						sortField : 'size',
						sortType : 'asc'
					});
				}
			} ]
		})[0];

		var visible = false;
		// 绑定隐藏和显示事件
		$sortorButton.click(function() {
			if (!visible) {
				$sortList.open();
			} else {
				$sortList.close();
			}
			visible = !visible;
			return false;
		});

		// 绑定菜单上的hover事件
		$sortList.hover(function() {
		}, function() {
			$sortList.close();
			visible = false;
		});
	};

	self.show = function() {
		$sortorButton.show();
	};

	self.hide = function() {
		$sortorButton.hide();
	};

	caiyun.ui.initList.push(self);
})();