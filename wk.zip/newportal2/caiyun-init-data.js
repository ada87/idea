;
(function() {
	window.caiyun.initdata = function() {
		var ajax = window.caiyun.util.caiyunAjax.ajaxRequest;
		var nav = caiyun.hashnav;
		var setDiskSize = function() {
			ajax({
				type: 'post',
				url: '../webdisk/personInfoAction!queryDiskInfo.action',
				succFun: diskSizeSucc,
				hideLoading: true
			});
		};

		var capacityBar = caiyun.ui.CyDiskCapability();

		var diskSizeSucc = function(params, json) {
			if (!json.userDiskInfo) {
				return;
			}
			var disk = json.userDiskInfo;
			var diskSize = disk.diskSize;
			var userDiskSize = disk.userDiskSize;
			var percent;
			window.caiyun.constants.diskUsedSize = disk.userDiskSize;
			capacityBar.cysetDiskSize({
				renderTo: 'capacity_bar',
				diskSize: diskSize,
				userDiskSize: userDiskSize
			});
		};

		var queryChannelInfo = function() {
			ajax({
				type: "post",
				url: "../webdisk/queryUserFunAction!querySysInfo.action",
				dataType: "json",
				data: {
					sysInfoFlag: 1
				},
				succFun: queryChannelInfoSucc,
				errFun: function() {},
				hideLoading: true
			});
		};

		var queryChannelInfoSucc = function(params, json) {
			if (json.sysInfos && json.sysInfos.chnlInfo) {
				var cache = window.caiyun.util.cache
					.getInstanceCache(window.caiyun.constants.FILE_SRC_CACHEGROUP);
				$.each(json.sysInfos.chnlInfo, function(i, data) {
					cache.putValue(data.channel, data.description.replace(
						/^来自/, ''));
				});
			}
		};

		var queryIsSafeboxUser = function() {
			ajax({
				type: 'post',
				dataType: 'jsonp',
				url: address + '/safebox/safeBoxAction!safeBoxStatus.action',
				succFun: function(post, data) {
					if(!data.result)return;
					var obj = data.result.retObj;
					var constants = window.caiyun.constants;
					if (obj && obj.status != "3") {
						constants.isSafeBoxUser = true;
					} else {
						constants.isSafeBoxUser = false;
					}

					//sunzhengchun：其他客户端跳转保险箱，查询请求返回后再切换视图
					//9月份版本联通电信也有保险箱的话，注意修改
					if (menuStatus == caiyun.constants.menuStatus.safebox || location.hash.indexOf('#' + nav.getHashByContentName(caiyun.constants.SAFEBOX_FILE_CONTENT_VIEW)) === 0) {
						location.hash = nav.getHashByContentName(caiyun.constants.SAFEBOX_FILE_CONTENT_VIEW);
						nav.switchContent();
					}
				},
				errFun: function() {},
				hideLoading: true
			});
		};

		var getCommConfig = function(version) {
			ajax({
				type: "post",
				url: "../webdisk2/getCommConfigAction.action",
				dataType: "json",
				data: {
					version: version
				},
				succFun: function(params, resp) {
					if (resp && resp.configInfo && resp.configInfo.retCode == "0") {
						var list = resp.configInfo.pairsItemList;
						$.each(list, function(i, data) {
							if (data.key == "common.sharePageNums") {
								maxShareNumber = parseInt(data.value, 10) > 0 ? parseInt(data.value, 10) : 20;
							}
						});
					}
				},
				errFun: function() {},
				hideLoading: true
			});
		};

		var init = function() {
			setDiskSize();
			queryChannelInfo();
			queryIsSafeboxUser();
			getCommConfig(); //获取客户端配置数据（包含分享最大人数）
			linkData.init(); // 初始化通讯录数据
			entryPriseInfoData.init(); //初始化企业信息
		};

		return {
			init: init,
			setDiskSize: setDiskSize,
			queryIsSafeboxUser: queryIsSafeboxUser
		};
	}();
	// 注册初始化事件
})();