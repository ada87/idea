caiyun.ui.webnd = {}
;var log = {}
;var invoke_history = []
;var invoke_result = {}
;log.debug = function(m) {	
//console.log(m);
}
;nd={
	debug:false,
	log:function(m){},
	history:function(){
		//console.log(JSON.stringify(invoke_history));
	}
}
;log.info = function(m) {
	if($.browser.msie) return;
    switch(arguments.length){
        case 1:
        default:
        console.log(m);
        break;
        case 2:
        console.log(arguments[0],arguments[1]);
        break;
        case 3:
        console.log(arguments[0],arguments[1],arguments[2]);
        break;
        case 4:
        console.log(arguments[0],arguments[1],arguments[2],arguments[3]);
        break;
        case 5:
        console.log(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4]);
        break;
    }
}
/**
 * 彩云上传插件
 */
;(function(){
	var webnd = caiyun.ui.webnd;
	
	var util = window.caiyun.util;
	
	var _WebNDPlugin = {};

	var NDCache = {}
	/**
	 * 是否成功加载控件
	 */
	var isLoadPlugin = false;

	/**
	 * 插件版本号
	 */
	var pluginVer = '0.0.0.0';
	/**
	 * 插件最低版本，低于此版本需提示升级
	 */
	var minVer = '1.0.7.0';

	var ndSupport = false;

	var isHtml5Support =false;
	/**
	 * 是否强制升级
	 */
	var force = true;
	
	var rootCatalog = '';
	//标示拖拽上传
	var globaldragFlag=false;

	var bigDataFlag=false;//大数据量标志
	var bigDataNum = 50;//测试20 ，200，500,1000

	var $WebNDPlugin=$('#WebNDPlugin');
	/**
	 * 默认设置信息
	 */
	var _default = {
		account:window.ownerMSISDN.toString(),
		token:window.rcsToken,
		http:window.ndHttpAddr,
		https:window.ndHttpsAddr,
		rootCatalog :'NUL',
		rootCatalogName:'彩云',
		rootSatetyCatalogID:'NUL',
		version:'0.0.0.0'
	};
	var xw_default = {
		account:window.ownerMSISDN.toString(),
		token:window.rcsToken,
		http:window.ndHttpAddr,
		https:window.ndHttpsAddr,
		rootCatalog :'NUL',
		rootCatalogName:'彩云',
		rootSatetyCatalogID:'NUL',
		version:'0.0.0.0'
	};
	var webndStatus={
		0:'未知',
		1:'上传中',
		2:'已暂停',
		3:'已暂停（被动）',
		4:'排队中',
		5:'成功',
		6:'上传失败',
		flash:'秒传成功'
	};
	
	var webndOption={
		1:'暂停当前任务',
		2:'恢复任务',
		3:'恢复任务',
		6:'重试',
		'default':'成功'
	};
	var getWebNdPluginInfo=function(){
		$.ajax({
			url:'../webndAct!getVersion.action',
			async:false,
			success:function(res){
			if(res&&res.message=='0'){
				var cv = res.clientVersion;
				minVer = cv.name;
				webNdPluginDownloadUrl = cv.url;
				}
			}
		});
	};
	var downloadWebNdPlugin=function(){
		$('#installPlugin').show();
		$('#overlay_upload').show();
	};
	var installPluginTip=function(){
		var val = ajaxTip()||'';
		var htm = '<div id="installPlugin" class="installPluginSt">\
				       <div class="uploadBox">\
				           <span class="close_btn"></span>\
				            <div class="sy-content"></div>\
				            <a href="'+pluginDownloadURL+'"  class="sy-btn">快速安装体验</a></div>\
				            <div class="overlay_img"><span></span></div>\
				            </div><div id="overlay_upload" class="overlay" style="display:none;"></div>';

		$('body').prepend(htm);
		if(val.split('@')[0]!='NOTIP'){
			$('#installPlugin').show();
			$('#overlay_upload').show();
		}
		$('#installPlugin').find('.close_btn:eq(0)').bind('click',function(){
			$('#installPlugin').hide();
			$('#overlay_upload').hide();
			// var nowday = new Date().getTime();
			// val = 'NOTIP@'+nowday;
			if($.browser.msie && $.browser.version == '6.0'){
				$("html").css("overflow-y","auto");//还原IE6垂直滚动条
			}
			ajaxTip('NOTIP@0');//初始化插件升级的值0
		});
		if(!$('#overlay_upload').is(':hidden')){
			if($.browser.msie && $.browser.version == '6.0'){
	           $("#overlay_upload").css({"top":document.documentElement.scrollTop+"px","height":document.documentElement.clientHeight+"px"}); 
	           $("html").css("overflow-y","hidden"); 
	        }	
		}
		
		$('#installPlugin').find('.sy-btn:eq(0)').bind('click',function(){
			caiyun.pvlog('clientDL','CP','','','','','','','','');
		});
	};
	var installAndUpgrade = '@';
	/*一天只提示一次，取消，则明天提示，勾选取消，则下个月提示
	 flag :true 返回30天的毫秒，false 返回明天  
	*/
	var dateVal = function(flag){
		/*var nowday = new Date();
		var nowdate = nowday.getFullYear() +'-'+ (nowday.getUTCMonth()+1)+'-'+(nowday.getUTCDate()+1);

		if(nowday.getUTCMonth()==11){
			nextyear = nowday.getFullYear() +1;
			nextmon = nowday.getUTCMonth()+2
			nextday = nowday.getUTCDate();
		}else{
			nextyear = nowday.getFullYear();
			nextmon = nowday.getUTCMonth()+2;
			nextday = nowday.getUTCDate()+1;
		}
		var next = nextyear +'-'+ nextmon +'-'+nextday;
		return installAndUpgrade.split('@')[0]+'@'+(flag?next:nowdate);*/
		var s, d, t, t2;
	 	t = new Date().getTime();
		var	n = flag?30:1;
	    t2 = n * 1000 * 3600 * 24;
	    t+= t2;
	    d = new Date(t);
	    s = d.getUTCFullYear() + "-";
	    s += ("00"+(d.getUTCMonth()+1)).slice(-2) + "-";
	    s += ("00"+d.getUTCDate()).slice(-2);
	    return "NOTIP@"+s;
		
	};
	
	function DateDiff(d1,d2){
	    var day = 24 * 60 * 60 *1000;
		try{    
			var dateArr = d1.split("-");
			var checkDate = new Date();
			checkDate.setFullYear(dateArr[0], dateArr[1]-1, dateArr[2]);
			var checkTime = checkDate.getTime();

			var dateArr2 = d2.split("-");
			var checkDate2 = new Date();
			checkDate2.setFullYear(dateArr2[0], dateArr2[1]-1, dateArr2[2]);
			//checkDate2.setFullYear('2013', '11', '1');
			var checkTime2 = checkDate2.getTime();

			var cha = (checkTime2 - checkTime)/day;  
        	return cha;
	    }catch(e){
	    	return false;
		}
	}
	var ajaxTip=function(value){
		var key = 'webndtips';
		//TODO userfun  key:webndtips value:日期#月份 ex:30#3  cooken   1:""     2:NOTIP@2013-12-2   >30 <0
		//规则：每天提示一次，不再提醒的刻度为一个月
		//console.log('invoke ajaxTip %s,%s,%s',key,!value?'get':'set',value);
		var t = new Date().getTime();
		if(value){
			$.getJSON('../webndAct!saveClientValue.action?val='+value+'&_='+t,function(res){
				if(res&&res.message=='0'){
					value = res.value;
				}
			});
		}else{
			$.ajax({
				url:'../webndAct!clientValue.action',
				async:false,
				cache:false,
				success:function(res){
					if(res&&res.message=='0'){
						if(!res.value||res.value==''){
							res.value='@';
						}else{
							value = res.value;
							installAndUpgrade = value;
						}
					}
				}
			});
		}
		return value;
	}
	var getUpgradePluginTip=function(){
		//TODO userfun  key:webndtips value:日期@月份 ex:30@131313131313@
		//规则：每天提示一次，不再提醒的刻度为一个月
		var nowday = new Date();
		var nowdate = nowday.getFullYear() +'-'+ (nowday.getUTCMonth()+1)+'-'+nowday.getUTCDate();
		var tipStr = ajaxTip()||'';
		var lastTime = tipStr.indexOf('@')==-1?nowdate:tipStr.split('@')[1] == 0?nowdate:tipStr.split('@')[1];
		//var val = lastTime!=''&&/^[0-9]*$/g.test(lastTime)?parseInt(lastTime):0;
		//var tempdate =  formatDate(new Date(val));
		var day = DateDiff(nowdate,lastTime);
		return day<1||day>30;
	};
	/**
	强制升级
	*/
	var forceUpgradePluginTip=function(){
		var htm= '<div id="forceUpgradePlugin" class="upgradePlugin_box" style="position:fixed;right:0px;bottom:0px;z-index:999999;">\
				       <div class="popBox" style="width:382px;">\
				            <div class="popTitle uploadTitle_bg" style="height:30px;">\
				                <div class="floatleft t_01" style="margin:6px 0 0 9px;"><span>彩云上传控件版本更新</span></div>\
				                <div class="floatright t_02" style="margin:6px 7px 0 0;"><span class="cloBtn"></span></div>\
				            </div>\
				            <div class="popContent">\
				                <p class="uploadTip">彩云上传控件有新版本咯，赶紧去升级体验吧！</p>\
				                <div class="uploadBottom">\
				                    <p><span class=""></span>下次不再提示</p><!--选取时写入noprompt样式--->\
				                    <div class="proBtn"><a href="'+pluginDownloadURL+'"  class="b1"></a>\
				                    <a href="javascript:void(0)" class="b2"></a></div>\
				                </div></div></div></div>'
		$('body').prepend(htm);
		$('#forceUpgradePlugin').find('.cloBtn:eq(0)').hide();//隐藏关闭按钮
		//$('#upgradePlugin').find('.cloBtn:eq(0)').bind('click',function(){$('#upgradePlugin').remove();});
		// $('#upgradePlugin').find('.uploadBottom span:eq(0)').bind('click',function(){
		// 		if($(this).hasClass('noprompt')){
		// 			$(this).removeClass('noprompt');
		// 		}else{
		// 			$(this).addClass('noprompt');
		// 		}
		// 	});
		// $('#upgradePlugin').find('.proBtn .b1:eq(0)').bind('click',function(){
		// 	invoke('InstallWebND');
		// });
		// $('#upgradePlugin').find('.proBtn .b2:eq(0)').bind('click',function(){
		// 	if($('#upgradePlugin').find('.uploadBottom span:eq(0)').hasClass('noprompt')){//打钩表示本月不再显示
		// 		ajaxTip(dateVal(true));
		// 	}else{
		// 		ajaxTip(dateVal());
		// 	}
		// 	$('#upgradePlugin').remove();
		// });
	};
	/**
	普通升级
	*/
	var upgradePluginTip=function(){
		if(!getUpgradePluginTip()){//今天已经提示，或本月不再提示
			return;
		}
		var htm= '<div id="upgradePlugin" class="upgradePlugin_box">\
				       <div class="popBox" style="width:382px;">\
				            <div class="popTitle uploadTitle_bg" style="height:30px;">\
				                <div class="floatleft t_01" style="margin:6px 0 0 9px;"><span>彩云上传控件版本更新</span></div>\
				                <div class="floatright t_02" style="margin:6px 7px 0 0;"><span class="cloBtn"></span></div>\
				            </div>\
				            <div class="popContent">\
				                <div class="uploadTipOut">\
				                <p class="uploadTip">彩云上传控件有新版本咯，赶紧去升级体验吧！</p>\
				                </div>\
				                <div class="uploadBottom">\
				                    <p><span class=""></span>下次不再提示</p><!--选取时写入noprompt样式--->\
				                    <div class="proBtn"><a href="javascript:void(0);"  class="b1"></a><a href="javascript:void(0)" class="b2"></a></div>\
				                </div></div></div></div>'
		$('body').prepend(htm);
		$('#upgradePlugin').find('.cloBtn:eq(0)').bind('click',function(){
			if($('#upgradePlugin').find('.uploadBottom span:eq(0)').hasClass('noprompt')){//点击X并且打钩表示本月不再显示
				ajaxTip(dateVal(true));
			}
			$('#upgradePlugin').remove();
		});
		$('#upgradePlugin').find('.uploadBottom span:eq(0)').bind('click',function(){
				if($(this).hasClass('noprompt')){
					$(this).removeClass('noprompt');
				}else{
					$(this).addClass('noprompt');
				}
			});
		//点击立即升级
		$('#upgradePlugin').find('.proBtn .b1:eq(0)').bind('click',function(){
			invoke('InstallWebND');//安装下载的插件，增量更新
			$('#upgradePlugin').remove();
			ajaxTip(dateVal(false));
			
		});
		//点击稍后升级
		$('#upgradePlugin').find('.proBtn .b2:eq(0)').bind('click',function(){
			if($('#upgradePlugin').find('.uploadBottom span:eq(0)').hasClass('noprompt')){//打钩表示本月不再显示
				ajaxTip(dateVal(true));
			}else{
				ajaxTip(dateVal(false));
			}
			$('#upgradePlugin').remove();
		});
	};
	var ndState={
		noinstall:'未安装控件',
		upgrade:'提示升级控件',
		ok:'ok'
	};
	var errorTip={
		'-1':'页面调用putFile/putFolder时，该任务重复',
		'-2':'文件大小为0',
		'-3':'文件超过4G',
		'-4':'本地文件不存在',
		'-5':'任务不存在',
		'-6':'网络不可用',
		'-7':'网盘容量已满',
		'-8':'任务状态为排队中，无法开始',
		'-9':'Token为空',
		'-10':'Token值不正确',
		'-11':'文件夹为空',
		'-12':'本地目录深度超过10',
		'-13':'文件在云端目录深度超过10',
		'-14':'任务不是处于运行状态',
		'-15':'任务不是处于暂停状态',
		'-16':'服务器异常',
		'-17':'文件夹中存在未上传成功的子文件夹或文件',
		'-18':'云端存在同名文件夹',
		'-19':'本地文件被锁定',
		'-20':'云端创建文件夹失败（其他原因，如文件夹名称含敏感词汇、文件夹名称长度超长等）',
		'-21':'HTTP请求超时',
		'-22':'文件夹内文件个数超出限制',
		'-23':'一次上传操作的文件/文件夹个数超出限制',
		'-24':'保险箱sessionID无效（为空或错误），需重新登录保险箱',
		'-25':'父目录不存在',
		'-26':'上传的文件/文件夹名称含敏感词汇',
		'-27':'文件夹名称长度超长',
		'0':'正常',
		'default':'系统异常'
	};
	var isRetrySupport =function(state){
		switch(state){
			case '-6':
			case '-7':
			case '-16':
			case '-21':
			case '-18':
			case '-17':
			case 'default':
			default:
			return true;
			break;
			case '-1':
			case '-2':
			case '-3':
			case '-4':
			case '-5':
			case '-1':
			case '-12':
			case '-9':
			case '-10':
			case '-11':
			case '-22':
			case '-23':
			case '-24':
			case '-25':
			return false;
			break;
		}
	}
	//产品组提供的错误提示
	var errorTip_cp={
		'-2':'不支持空文件（夹）上传',
		'-3':'单个文件大小不能超过4G',
		'-4':'待上传的文件（夹）已被移动、修改、删除',
		'-7':'网盘空间不足',
		'-9':'系统异常',
		'-10':'系统异常',
		'-11':'不支持空文件（夹）上传',
		'-12':'待上传的目录超过10级',
		'-13':'云端目录超过10级',
		'-16':'系统异常',
		'-18':'云端存在同名文件夹',
		'-21':'系统异常',
		'-20':'文件（夹）名称过长',//TODO 其中包含敏感字
		//'09_':'读取文件(夹)异常@读取文件异常',//待存在
		'default':'系统异常'
	};
	webnd.errorTip = errorTip;
	var IEHtml5Support = function(){
		return $.browser.msie&&$.browser.version>'8.0';
	}
	var check=function(){
		var state;
		var html5Support = Html5Util&&Html5Util.isHtml5Support();
		isHtml5Support = IEHtml5Support() || html5Support;
		try{
			if(WebNDPlugin){
				pluginVer = WebNDPlugin.getVersion();
				state = ndState['ok'];
			}else{
				state = ndState['noinstall'];
				pluginVer = '0.0.0.0';
			}
		}catch(e){
			state = ndState['noinstall'];
			pluginVer = '0.0.0.0';
		}
		return state;
	};
	var parse=function(str){
		if(typeof str == 'string')
		eval('str='+str);
		return str;
	};
	
	/**
	 * 封装插件调用方法
	 * method:pauseTask,resumeTask,delTask,retryTask,clearAllTask,getTaskInfo，pauseAllTask，resumeAllTask，getVertion
	 * taskId：任务ID，可不传
	 * return:json对象
	 */
	var invoke_safe=function(method,taskId,args2){
		var strJson='{}',invokeId = new Date().getTime()+'-'+method;;
		try{
			switch(arguments.length){
		        case 1:
		        	if(method==='getTaskList'){
		        		if(invoke_result[invokeId]){
		        			strJson = invoke_result[invokeId];
		        		}else{
		        			strJson = WebNDPlugin[method]();
		        		}
		        	}else{
			        	strJson = WebNDPlugin[method]();
			        }
			        break;
			    case 3:
			        strJson = WebNDPlugin[method](taskId,args2);
			        break;
		        case 2:
			        if(typeof taskId =='number'){
			        	//if(taskId!=0){
			        		if(method==='getTaskInfo'){
			        			if(invoke_result[invokeId]){
				        			strJson = invoke_result[invokeId];
				        		}else{
				        			strJson = WebNDPlugin[method](taskId);
				        		}
			        		}else{
			        			strJson = WebNDPlugin[method](taskId);
						}
			        	//}
			        }else if(/^[0-9]*$/g.test(taskId)&&taskId.length<6){
		        		taskId = parseInt(taskId);
			        	strJson = WebNDPlugin[method](taskId);
			        }else{
			        	strJson = WebNDPlugin[method](taskId);
			        }
			        break;
	    	}
	    	if(nd.debug){
	    		invoke_history.push({time:invokeId,args:[taskId,args2]});
	    		invoke_result[invokeId]=strJson;
	    	}
		}catch(e){
			if(nd.debug){
	    		invoke_history.push({time:invokeId,args:[taskId,args2],err:e});
	    		invoke_result[invokeId]=e;
	    	}
		}
    	return parse(strJson);
    };
	var invoke=function(method,taskId){
		if(caiyun.ui.webndflag){
			var retStr,args = taskId?taskId:'';
			if(/^[0-9]*$/g.test(taskId)&&taskId<100000){
				args = 'parseInt('+taskId+')';
       	 	}else{
       	 		args = (taskId?('\''+taskId+'\''):'');
       	 	}
			log.debug('invoke '+method);
			log.debug(taskId);
			eval('retStr=WebNDPlugin.'+method+'('+args+')');
			//resStr = WebNDPlugin[method](args);
			log.debug('invoke return '+method);
			log.debug(retStr);
			return parse(retStr);
		}else
			return "";
	};
	invoke=invoke_safe;
	webnd.pauseAll=function(){
		return invoke('pauseAllTask');
	};
	
	webnd.resumeAll=function(){
		return invoke('resumeAllTask');
	};
	
	webnd.clearAll=function(){
		//$.each([0,1,2,3,4,5,6],function(i,state){
		invoke('clearAllTask',0);
		//})
	};

	webnd.clearFinishUpload=function(){
		//$.each([0,1,2,3,4,5,6],function(i,state){
		invoke('clearAllTask',5);
		//})
	};
	
	webnd.clearUploads=function(){
		$.each([4,3,2,1],function(i,state){
			invoke('clearAllTask',state);
		})
	};
	
	var change2=function(obj,json){
		$.extend(obj,json);
		return obj;
	};
	
	var change=function(obj,json){
		var uploadInfo = {};
    	uploadInfo.number = obj.number;
    	uploadInfo.name = obj.name;
    	uploadInfo.size = obj.size;
    	uploadInfo.status = obj.code;
    	
    	uploadInfo.showName = util.splitName({"name":obj.name,"maxLen":24});
    	uploadInfo.showSize = util.formateSize(obj.size) || "0KB";
    	uploadInfo.statusText = webndStatus[obj.code];
    	uploadInfo.statusInfo = "上传状态";
    	uploadInfo.optionText = webndOption[obj.code] || webndOption['default'];
    	uploadInfo.percent = "0%";
    	uploadInfo.speed = "0KB";
    	uploadInfo.completeSize = 0;
    	uploadInfo.fileSpeed = 0;
    	uploadInfo.path = '';//TODO path是什么
    	
    	$.extend(uploadInfo,json);
    	return uploadInfo;
	};
	webnd.Queue = queue = {};
	
	webnd.updateQueue=updateQueue=function(){
		var t1= new Date().getTime();
		var json = invoke('getTaskList');
		webnd.Queue = queue = {};//每次必须重置
		if(json){
			$.each(json,function(i,file){
				if(!queue[file.TaskState]){
					queue[file.TaskState]=[];
				}
				queue[file.TaskState].push(file.TaskId);
			})
		}
		var t2= new Date().getTime();
		//console.log('%s-%s=%s',t1,t2,(t2-t1));
	};
	/**
	根据TASKLIST判断GLOBAL事件
	*/
	var globalView=function(){
		var list = invoke('getTaskList');
		var totalFiles =0,totalSize=0,endFiles =0,endSize=0,finished=false;//完成的状态
		$.each(list,function(i,info){
			if(info.TaskType=='1'){
				var file = info.FileInfo;
				if(file.UploadedSize==file.Size){
					totalSize += file.Size;
					endSize+=file.UploadedSize;
					totalFiles++;	
					endFiles++;
				}else{
					if(file.ErrorCode==0){
						finished =true;
						return;//未完成
					}else{
						totalSize += file.Size;
						endSize+=file.UploadedSize;
						totalFiles++;	
						endFiles++;
					}
				}
			}else{
				var folder = info.FolderInfo;
				if((folder.SucFiles+folder.FailedFiles)==folder.TotalFiles){
					totalSize += folder.DealedFileSize;
					totalFiles += folder.TotalFiles;	
					endFiles +=(folder.SucFiles+folder.FailedFiles);
					endSize += folder.DealedFileSize;
				}else{
					if(folder.ErrorCode==0){
						finished = true;
						return ;//未完成
					}else{
						totalSize += folder.DealedFileSize;
						totalFiles += folder.TotalFiles;	
						endFiles +=(folder.SucFiles+folder.FailedFiles);
						endSize += folder.DealedFileSize;
					}
				}
			}
		});
		return {finished:!finished,totalFiles:totalFiles,totalSize:totalSize,endSize:endSize,endFiles:endFiles};
	}
	webnd.globalView = globalView;
	var taskInfoById=function(taskId){
		var json = invoke('getTaskInfo',taskId);
		
		if(json.ErrorCode==-5){
			//TODO 任务不存在
		}else if(json.ErrorCode==0){

		}
	}
	/**
	 * 获取文件后缀
	 */
	var getFileType=function(file){
		if(!file){
			return '';
		}
		if(file&&file.indexOf('.')!=-1){
			return file.substring(file.lastIndexOf('.')+1,file.length);
		}
		return '';
	};
	webnd.upload =function(strRemote){
		window.onbeforeunload =null;
		invoke('openFile');
	};

	waitTaskList=[];
	waitTaskCatalogName={};
	/**
	 * 上传文件
	 */
	var uploadFinish =function(strRemote){
		strRemote = window.caiyun.operate.getCurrentPathId();
		var catalogName = window.caiyun.operate.getCurrentCatalog().catalogName;
		var jstr ,json;
		if(caiyun.judgement.isSafeBox()) {
    		log.debug("SafeBox");
    		if(_default.rootSatetyCatalogID=='NUL'){
    			_default.rootSatetyCatalogID=caiyun.ui.webnd.safeBoxPathId;
    		}
    		invoke('setSafetyInfo',caiyun.ui.webnd.safeBoxSessionId);
    		jstr = invoke('putSafetyFile',strRemote);
    	}else{
    		if(caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)){
    			if(caiyun.operate.canExecute('upload')){
    				var path = window.caiyun.operate.getCurrentCatalog().path;
    				jstr = invoke('putShareFile',strRemote,path);	//
    			}else{
    				//收到分享文件夹中，提示不能上传
    			}
    		}else{
    			jstr = invoke('putFile',strRemote);	
    		}
    	}
		json = parse(jstr);
		
		if(json.PutFileList&&json.PutFileList.length){
			bigDataHandler(json.PutFileList,catalogName);
			reg.startUpload.call();
			// }
		}else{
			// json.ResultCode==-1 未选择任何文件
			if(json.ResultCode==-23){
				//文件数量超过限制
				window.caiyun.ui.iMsgTip.tip('文件数量超过限制(50)', 'loading', 1);
			}
		}
	};
	var bigDataHandler=function(list,catalogName){
		if(list.length>bigDataNum){
			webnd.bigDataFlag = true;
			// waitTaskList =  list.slice(bigDataNum);
			// list = list.slice(0,bigDataNum);
		}else{
			webnd.bigDataFlag = webnd.bigDataFlag;
		}
		$.each(list,function(i,file){
			if(i==0&&file.SessionTaskId!=''&&!waitTaskCatalogName[file.SessionTaskId])
				waitTaskCatalogName[file.SessionTaskId] = catalogName;//缓存
			if(!catalogName)
				catalogName = waitTaskCatalogName[file.SessionTaskId];
			fileHandler(file,catalogName,false,false);
		});
		reg.closeBrowseEnd.call();
	}
	webnd.waitQueue =  [];
	var addWaitQueue=function(id){
		var index = indexOfObjArray(id,webnd.waitQueue);
		if(index==-1){
			webnd.waitQueue.push(id);
		}
	}
	var updateWaitQueue=function(id){
		var waitQueue = webnd.waitQueue;
		if(/^[0-9]*$/g.test(id)&&id.length<6)id = parseInt(id);
		var index = indexOfObjArray(id,webnd.waitQueue);
		switch(index){
			case -1:
			return waitQueue;
			break;
			case waitQueue.length:
			return waitQueue.slice(0,waitQueue.length-1);
			break;
			case 0:
			return waitQueue.slice(1,waitQueue.length);
			break;
			default:
			return waitQueue.slice(0,index).concat(waitQueue.slice(index+1,waitQueue.length));
		}
	};
	var fileHandler=function(file,catalogName,isQueueLast,dropflag){
		
		var type = getFileType(file.LocalName),tsize = '';
		NDCache[file.TaskId]={lastUploadPercent:0,lastUploadRatio:0,isQueueLast:isQueueLast,catalogName:catalogName,name:file.LocalName,type:type,dropflag:dropflag};
		addWaitQueue(file.TaskId);
		var param = {isQueueLast:isQueueLast,catalogName:catalogName,code:'0', name:file.LocalName, size:tsize, number:file.TaskId, type:type};//不调用TASKINFO
		param = change2(param,file);
		reg.reportState.call(null,param);
		
		//上报文件错误
		if(file.RetValue!=0){
			var param = {size:tsize,isQueueLast:isQueueLast,catalogName:catalogName,code:file.RetValue,number:file.TaskId}
			webnd.waitQueue = updateWaitQueue(file.TaskId);
			if(file.RetValue=='-1'||file.RetValue=='-2'||file.RetValue=='-3'||file.RetValue=='-11'||file.RetValue=='-22'){
				param = getFolderErrorInfo(file.TaskId,file.RetValue,param);
			}
			reg.reportError.call(null,param);
			reg.loadDone.call(null,{noReload:true});
		}
	};
	var folderTxt=function(s,t,f){
		s = s||0, t = t||0, f=f||0;
		var txt1 = f!=0 ? '('+f+'个失败)':'';
		txt = (s==t||t - s == f ? t + '个文件' : (s + f) +'/'+t+'个文件' )+txt1;
		return txt;
	};
	webnd.uploadFolder =function(strRemote){
		window.onbeforeunload =null;
		invoke('openFolder');
	};
	/**
	 * 上传文件夹
	 */
	var uploadFolderFinish =function(strRemote){
		strRemote = window.caiyun.operate.getCurrentPathId();
		var catalogName =window.caiyun.operate.getCurrentCatalog().catalogName;
		var jstr ,json;
		if(caiyun.judgement.isSafeBox()) {
    		log.debug("SafeBox putSafetyFolder");
    		//缓存保险箱的根目录ID
    		if(_default.rootSatetyCatalogID=='NUL'){
    			_default.rootSatetyCatalogID=caiyun.ui.webnd.safeBoxPathId;
    		}
    		invoke('setSafetyInfo',caiyun.ui.webnd.safeBoxSessionId);
    		jstr = invoke('putSafetyFolder',strRemote);
    	}else{
    		if(caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)){
    			if(caiyun.operate.canExecute('upload')){
    				var path = window.caiyun.operate.getCurrentCatalog().path||'';
    				jstr = invoke('putShareFolder',strRemote,path);	//
    			}else{
    				//收到分享文件夹中，提示不能上传//putShareFile，putShareFolder，putShareDragDropItem。
    			}
    		}else{
				jstr = invoke('putFolder',strRemote);
			}
    	}
		json = parse(jstr);
		
		folderHandler(json,catalogName,true,false);
	};
	var folderHandler=function(json,catalogName,isQueueLast,dropflag){
		var type = 'folder';
		NDCache[json.TaskId]={lastUploadPercent:0,lastUploadRatio:0,isQueueLast:isQueueLast,name:json.LocalName,catalogName:catalogName,type:type,dropflag:dropflag};//文件上传一个，默认true	
		addWaitQueue(json.TaskId);
		if(json.RetValue==0){
			var param = {catalogName:catalogName,code:json.RetValue, name:json.LocalName,size:'', number:json.TaskId, type:'folder'};
			param = change2(param,json);
			reg.reportState.call(null,param);
			reg.closeBrowseEnd.call();
			reg.startUpload.call();
		}else{
			var id = 'folder_'+new Date().getTime(),taskInfo ={};
			var param = {isQueueLast:isQueueLast,catalogName:catalogName,code:json.RetValue, name:json.LocalName, size:folderTxt(1,1,1), number:id, type:type};
			if(json.RetValue=='-1'||json.RetValue=='-2'||json.RetValue=='-3'||json.RetValue=='-11'||json.RetValue=='-22'){
				param = getFolderErrorInfo(json.TaskId,json.RetValue,param);
			}
			webnd.waitQueue = updateWaitQueue(json.TaskId);
			param = change2(param,json);
			reg.reportState.call(null,param);
			reg.closeBrowseEnd.call();
			reg.reportError.call(null,param);
			reg.loadDone.call(null,{noReload:true});
		}
	}
	var getFolderErrorInfo=function(taskId,errCode,param){
		var taskInfo  = invoke('getTaskInfo',taskId);
		param = change2(param,taskInfo);
		switch(errCode.toString()){//选择文件立即失败的错误码
			case '-1':
			ffsize = '重复任务';
			break;
			case '-2':
			ffsize = '0KB';
			break;
			case '-3':
			ffsize = '文件大小超过4G';
			break;
			case '-11':
			ffsize = '空文件夹';
			break;
			case '-22':
			ffsize = '文件夹内文件个数超出限制5000';
			break;
		}
		param.size = ffsize;
		return param;
	}
	//可以直接删除的状态
	var del= [2,3,4,5,6,0];
	/**
	 * 上传任务列表删除任务
	 * 1：正在上传中必须停止上传才能删除
	 */
	var delFun =function(taskId){
		//caiyun.pvlog('fileOper','uploadCancel','','','','','','',pluginVer);
		webnd.waitQueue = updateWaitQueue(taskId);
		ndpvlog2('uploadCancel',{},taskId);
		json =invoke('delTask',taskId);
		return json;
	};
	/**
	 * 无需暂停再删除，直接删除
	 */
	var delFun2 =function(taskId){
		var json = invoke('getTaskInfo',taskId);
		
		if(json.ErrorCode==0){
			json =invoke('delTask',taskId)
			return json;
		}
		return {RetValue:0,TaskId:taskId,TaskState:0};	
	};
	webnd.delFun = delFun;
	globalViewFlag=false;
	/**
	 * 上传任务列表下一步操作
	 * taskId 任务ID
	 */
	webnd.nextFun = function(taskId){
		//var t1 = new Date().getTime();
		var json = invoke('getTaskInfo',taskId);
		//var t2 = new Date().getTime();
		//console.log(' id:%s nextFun %s-%s=耗时%s',taskId,t2,t1,(t2-t1));
		switch(json.TaskState){
			case 1:
        	//caiyun.pvlog('fileOper','uploadPause','','','','','','',pluginVer);
        	ndpvlog2('uploadPause',json,taskId);
        	json = invoke('pauseTask',taskId);
			break;
			case 2:
			case 3:
			ndpvlog2('uploadContinue',json,taskId);
			json = invoke('resumeTask',taskId);
			//caiyun.pvlog('fileOper','uploadContinue','','','','','','',pluginVer);
			break;
			case 6:
			//部分错误码不可重试，隐藏重试按钮
			if(isRetrySupport(json.ErrorCode.toString())){
				json.isRetry=true;
				json = invoke('retryTask',taskId);
			}else{
				json.isRetry=false;
			}
			// if(globalView().finished){
			// 	reg.loadDone.call(null,{noReload:true});
			// 	globalViewFlag=true;
			// }
			break;
		}
		return json;
	};
	
	/*
	 * PV统计  pmodule:fileOper  
		 pkey  
		uploadPass：秒传
		uploadCancel：取消上传
		uploadPause：暂停上传
		uploadContinue：继续上传

日期|IP|号码|fileOper|uploadPass|portal|浏览器|文件ID|1|文件大小（byte）|文件后缀||拖拽方式，则传true否则为空|上传插件版本号||
*/
	var ndpvlog =function(type,taskInfo,taskId,dropflag){
		//if(!taskInfo)
			taskInfo = invoke('getTaskInfo',taskId);
		var id = taskInfo.TaskType==2?taskInfo.FolderInfo.CatalogID:taskInfo.FileInfo.ContentId; //文件ID
		var contentType= taskInfo.TaskType==2?'-1':'1';//1文件 -1文件夹
		var ftype = taskInfo.TaskType==2?'':getFileType(taskInfo.FileInfo.LocalName);//后缀
		var noin = '';
		var size = taskInfo.TaskType==2?taskInfo.FolderInfo.Size:taskInfo.FileInfo.Size; 
		var drop=(NDCache[taskId]&&NDCache[taskId].dropflag)?'true':'';//拖拽
		var version = pluginVer;//插件版本号
		caiyun.pvlog('fileOper',type,id,contentType,size,ftype,noin,drop,version);
	};
	var ndpvlog2 =function(type,taskInfo,taskId,dropflag){
		taskInfo = invoke('getTaskInfo',taskId);
		try{
			var id = taskInfo.TaskType==2?taskInfo.FolderInfo.CatalogID:taskInfo.FileInfo.ContentId; 
			var contentType= taskInfo.TaskType==2?'-1':'1';
			var ftype = taskInfo.TaskType==2?'':getFileType(taskInfo.FileInfo.LocalName);
			var noin = '';
			var size = taskInfo.TaskType==2?taskInfo.FolderInfo.DealedFileSize:taskInfo.FileInfo.Size; 
			var drop=(NDCache[taskId]&&NDCache[taskId].dropflag)?'true':'';
			var version = pluginVer;
			//console.log('fileOper,type=%s,id=%s,contentType=%s,size=%s,ftype=%s,noin=%s,drop=%s,version=%s',type,id,contentType,size,ftype,noin,drop,version);
			caiyun.pvlog('fileOper',type,id,contentType,size,ftype,noin,drop,version);
		}catch(e){
			//异常情况
			caiyun.pvlog('fileOper',type,'','','','','','',version);
		}
	};
	webnd.pvlog=ndpvlog2;
	webnd.ndstatus={
		error:'<span class="info-fail">上传失败</span>',
		flash:'<span class="flash-succ">秒传成功</span>',
		ok:'<span class="info-succ"></span>',
		pause:'<span>已暂停</span>',
		wait:'<span>排队中</span>',
		8:'<span class="info-fail">上传失败</span>',
		7:'<span class="flash-succ">秒传成功</span>',
		6:'<span class="info-fail">上传失败</span>',
		5:'<span class="info-succ"></span>',
		4:'<span>排队中</span>',
		3:'<span>已暂停</span>',
		2:'<span>已暂停</span>',
		0:'<span>排队中</span>',
		ready:'<span>准备中</span>'
	}
	var lastUploadRatio=0;
	
	var lastUploadPercent=0;

	var lastGlobalLeftTime=0;
	
	var lastGlobalPercent=0;
	/**
	 * 页面监听插件事件回调触发页面处理事件
	 * @method listenEventTrigger
	 * @param {Any} fun 回调方法
	 * @param {Any} [string] strJson 插件回调对象需将字符JSON转化成对象
	 * @return {Any} 无
	 */
	webnd.listenEventTrigger=function(fun,strJson){
		//eval('listenEvent.'+fun+'('+strJson+')')
		nd.log(fun);
		nd.log(strJson);
		listenEvent[fun](parse(strJson));
	};
	var showChildfailedInfo=function(json){
		var txt = '';
		if(json.ErrorCode==-17&&json.FolderInfo&&json.FolderInfo.FailedFileList&&json.FolderInfo.FailedFileList.length>=1){
			var errArr = json.FolderInfo.FailedFileList;
			txt = errArr[0].LocalName +':'+ errArr[0].FailReason.toString() +'|'+(errorTip[errArr[0].FailReason.toString()]||errorTip['default'])
			+ (errArr.length==1?'':'等');
		}
		return txt;
	};
	var listenEvent ={
		npWebNDTaskPauseEvent:function(StrJson) { 
			//TODO 暂停回调  进度条暂停
			var json = parse(StrJson);
			log.debug(json);
			json = invoke('getTaskInfo',json.TaskId);
			//NDCache[json.TaskId].state=json.TaskState;
			//TODO taskState=3 被动暂停，提示暂停  断开网络连接
			var param = change2({number:json.TaskId},json);
			reg.pauseListen.call(null,param);
		},
		npWebNDTaskStartEvent:function (StrJson) { 
			modifyDragArea();
			var json = parse(StrJson);
			
			//json = invoke('getTaskInfo',json.TaskId);
			//重试任务的会触发start事件report.percent = obj.filePercent+"%";
			//var param = change2({number:json.TaskId,filePercent:json.UploadPercent},json);
			/*if(waitTaskList.length!=0){
				// console.log('npWebNDTaskStartEvent');
				// console.log(waitTaskList);
				if(json.TaskId == waitTaskList[0].TaskId){
					// console.log('npWebNDTaskStartEvent waitTaskList');
					bigDataHandler(waitTaskList);
				}
			}*/
			NDCache[json.TaskId].lastUploadRatio=0;
			NDCache[json.TaskId].lastUploadPercent=json.UploadPercent||0;
			reg.startFileUpload.call(null,{ndtype:'start',number:json.TaskId,filePercent:json.UploadPercent});
		},
		npWebNDMultiTaskEndEvent:function (StrJson) { 
			var json = parse(StrJson);
			reg.reportTimeLine.call(null,StrJson.SessionTaskId);
			//reg.reportTimeLine.call(null,json.SessionTaskId);
			reg.loadDone.call(null);
		},
		npWebNDGlobalViewPercentEvent:function (StrJson) { 
			// if(globalViewFlag){
			// 	globalViewFlag=false;
			// 	return;
			// }
			//log.info('npWebNDGlobalViewPercentEvent:'+JSON.stringify(StrJson));
			var json = parse(StrJson);
			//log.info('全局进度 %s,%s',JSON.stringify(json),(Math.floor(json.EndSize/json.TotalSize*100) +'%'));
			//log.info('全局进度条： %s/%s个文件，%s,剩余%s',json.EndFiles,json.TotalFiles,json.TotalSize,json.LeftTime);
			if(json.LeftTime!=0){
				lastGlobalLeftTime = json.LeftTime;//缓存上一次的剩余时间
			}else{
				json.LeftTime = lastGlobalLeftTime;
			}
			//默认剩余1分钟
			if(json.LeftTime<=0){
				json.LeftTime = 60;
			}
			reg.globalViewListen.call(null,json);
			updateQueue();
			if(json.EndSize==json.TotalSize&&json.TotalFiles!=0){
				//console.log('上传完成了%s个文件(文件夹)',json.EndFiles,json.TotalFiles==json.EndFiles?'':','+json.TotalFiles-json.EndFiles+'个文件上传失败,查看详情');
				reg.loadDone.call(null);
			}
		},
		npWebNDTaskEndEvent:function (StrJson) { 
			//log.info('npWebNDTaskEndEvent:'+JSON.stringify(StrJson));
			var json = parse(StrJson);
			json = invoke('getTaskInfo',json.TaskId);
			var isQueueLast = NDCache[json.TaskId].isQueueLast||false;
			var fsize = NDCache[json.TaskId].fsize||'';//默认文件的大小，避免秒传大小为0
			var ftype= NDCache[json.TaskId].type;
			var dropflag = NDCache[json.TaskId].dropflag||false;
			webnd.waitQueue = updateWaitQueue(json.TaskId);
			if(json.TaskType==1){
				var param = {
					id:json.FileInfo.ContentId,
					catalogId:json.FileInfo.ParentCatalogId,
					number:json.TaskId,
					code:json.ErrorCode,
					isRetry:isRetrySupport(json.ErrorCode.toString()),
					filePercent:json.FileInfo.UploadPercent,
					errorTip:json.ErrorCode+'|'+(errorTip[json.ErrorCode.toString()]||errorTip['default']),
					FlashUpload:json.FileInfo.FlashUpload,//提示秒传成功
					size:fsize==''?json.FileInfo.Size:fsize,//
					actionTag:json.SessionTaskId,
					isQueueLast:isQueueLast,
					ndtype:'end',
					type:ftype
				};
				//日志统计
				if(json.FileInfo.FlashUpload){
					ndpvlog2('uploadPass',json,json.TaskId,dropflag);
				}
				param = change2(param,json);
				reg.reportFile.call(null,param);
				if(json.SessionTaskId===''){
					//选择单个文件上传，非批量任务
					reg.loadDone.call(null,{noReload:!(json.ErrorCode===0)});
				}
			}else{
				var rootError = NDCache[json.TaskId].rootError;
				var param = {
					id:json.FolderInfo.CatalogID,
					catalogId:json.FolderInfo.ParentCatalogID,
					number:json.TaskId,
					code:json.ErrorCode,
					size:fsize,
					type:ftype,
					filePercent:json.FolderInfo.UploadPercent,
					isRetry:isRetrySupport(json.ErrorCode.toString()),
					errorTip:showChildfailedInfo(json),//子文件夹失败信息
					FlashUpload:false,
					actionTag:json.SessionTaskId===''?new Date().getTime():json.SessionTaskId,
					rootError:rootError,
					ndtype:'end',
					isQueueLast:isQueueLast
				};
				NDCache[json.TaskId].lastUploadPercent=0;
				param = change2(param,json);
				// reg.reportTimeLine.call(null,'',json.taskId)
				reg.reportFile.call(null,param);
				if(json.SessionTaskId===''){
					//选择单个文件上传，非批量任务
					reg.loadDone.call(null,{noReload:!(json.ErrorCode===0)});
				}
			}
		},
		npWebNDTaskPercentEvent:function (StrJson) { //暂停时，有无效返回
			var json = parse(StrJson);
			
			if(json.TaskState==1){//等于1（正在上传中） 才更新进度条，摈弃暂停时返回的碎片无效值，无法实时暂停
				//console.log('实时更新进度条 state:%s,id:%s,Ratio:%s,Percent:%s',json.TaskState,json.TaskId,lastUploadRatio,lastUploadPercent)
				
				var bean,fileCompleted,remainTime,param;
				
				if(json.TaskType==1){//文件
					
					bean = json.FileInfo;
					var lastUploadPercent = NDCache[json.TaskId].lastUploadPercent;
					var lastUploadRatio = NDCache[json.TaskId].lastUploadRatio;
					if(bean.UploadPercent==100||lastUploadPercent==100){
						lastUploadPercent = 0;
					}
					
					//防止上传速度为0
					if(bean.UploadRatio!=0){
						lastUploadRatio = bean.UploadRatio;
					}
					//防止进度条回滚
					if(bean.UploadPercent>=lastUploadPercent){
						lastUploadPercent = bean.UploadPercent;
					}
					fileCompleted = bean.UploadedSize;
					
					remainTime= (bean.Size-bean.UploadedSize)/(lastUploadRatio);
					param = {
						number:json.TaskId,
						filePercent:lastUploadPercent, 
						fileCompleted:fileCompleted,
						speed:lastUploadRatio, /**kb/秒*/
						remainTime : (remainTime<=0?60:remainTime),   /**单位秒*/ 
						state: json.TaskState,
						ndtype:'percent',
						size : json.FileInfo.Size
					}
					NDCache[json.TaskId].fsize = json.FileInfo.Size;
				}else{
					
					bean = json.FolderInfo;
					var lastUploadPercent = NDCache[json.TaskId].lastUploadPercent;
					var lastUploadRatio = NDCache[json.TaskId].lastUploadRatio;
					if(bean.UploadPercent==100){
						lastUploadPercent = 0;
					}
					//防止上传速度为0
					if(bean.UploadRatio!=0){
						lastUploadRatio = bean.UploadRatio;
					}
					//防止进度条回滚
					if(bean.UploadPercent>=lastUploadPercent){
						lastUploadPercent = Math.floor(bean.UploadPercent);
					}
					//文件夹内的文件 无这两个参数
					fileCompleted = 0;
					remainTime = 0;
					var folderTmp = folderTxt(bean.SucFiles,bean.TotalFiles,bean.FailedFiles);

					//FailedFileList[0].LocalName
					
					//解决云端同名文件
					// var childfolderCode = 0;
					// try{
					// 	var failList = json.FolderInfo.FailedFileList||[];
					// 	if(failList&&failList[0]&&failList[0].FailReason&&(failList[0].FailReason==-18)){
					// 		lastUploadPercent=0;
					// 		childfolderCode = failList[0].FailReason;
					// 		folderTmp = folderTxt(bean.SucFiles,bean.TotalFiles,bean.TotalFiles);
					// 	}	
					// }catch(e){

					// }
					var rootErr  = rootCatalogError(json.FolderInfo.FailedFileList,json.FolderInfo.LocalName);
					param = {
						number:json.TaskId,
						filePercent:lastUploadPercent, 
						fileCompleted:fileCompleted,
						speed:lastUploadRatio, /**kb/秒*/
						remainTime : (remainTime<=0?60:remainTime),   /**单位秒*/
						state: json.TaskState ,
						size : folderTmp,
						type:'folder',
						ndtype:'percent',
						rootError:rootErr
						//childfolderCode:childfolderCode
					};
					NDCache[json.TaskId].fsize = folderTmp;
					NDCache[json.TaskId].rootError = rootErr;//根目录失败
				}
				param = change2(param,json);
				reg.uploadListen.call(null,param);
				log.info('实时更新进度条 state:%s,id:%s,Ratio:%s,Percent:%s',param.state,param.number,lastUploadRatio,lastUploadPercent);
				
			}else{
				log.debug('摈弃暂停时返回的碎片无效值  state:'+json.TaskState+" id:"+json.TaskId);
			}
		},
		npWebNDNetRecoverEvent:function (){
		},
		npWebNDNetFaultEvent:function (){
		},
		npWebNDNeedForceupdateEvent:function(){
			forceUpgradePluginTip();//只提示
		},
		npWebNDExistNewVersionEvent:function(){
			//alert('npWebNDExistNewVersionEvent')
			upgradePluginTip();
		},
		npWebNDOpenFileFinishEvent:function(StrJson){
			if(StrJson&&StrJson.RetCode==0){
				uploadFinish();
			}
		},
		npWebNDOpenFolderFinishEvent:function(StrJson){
			if(StrJson&&StrJson.RetCode==0){
				uploadFolderFinish();
			}
		},
		npWebNDDragdropFileDetectEvent:function(){
			//还原拖拽上传区域
			modifyDragArea();
			var catalogName,strRemote = $('#dragRemote').val();
			var catalog = window.caiyun.util.cache.getFileCache(window.caiyun.constants.FILE_LIST_CACHEGROUP,strRemote);

			
			if(!catalog||!catalog.catalogID){//拖拽的对象非目录
				catalog = window.caiyun.operate.getCurrentCatalog()||_default.rootCatalog;
			}else{
				/*if(window.caiyun.judgement.isInCurrentCatalogs(window.caiyun.constants.publisherAccountConstants.publisherDir)){
					window.caiyun.ui.iMsgTip.tip('公共账号不能拖拽上传', 'loading', 1);
					return;
				}*/
				if(window.caiyun.judgement.isInReceivedPublishDir() || window.caiyun.judgement.isInPublisherDir()){
					window.caiyun.ui.iMsgTip.tip('目标目录不支持拖拽移入文件或文件夹操作', 'loading', 1);
					return;
				}
				if(strRemote == caiyun.constants.cannotModifyIDs.root_receiveShare){
					window.caiyun.ui.iMsgTip.tip('收到的分享目录不支持拖拽移入文件或文件夹操作', 'loading', 1);
					return;
				}
				if(strRemote == caiyun.constants.publisherAccountConstants.publisherDir){
					window.caiyun.ui.iMsgTip.tip('目标目录不支持拖拽移入文件或文件夹操作', 'loading', 1);
					return;
				}
			}
			if(caiyun.judgement.isSafeBox()){
				catalogName = '';//保险箱不显示目录名称
				if(_default.rootSatetyCatalogID=='NUL'){
	    			_default.rootSatetyCatalogID=caiyun.ui.webnd.safeBoxPathId;
	    		}
	    		if(catalog){
	    			strRemote = catalog.catalogID;
	    		}else{
	    			strRemote = _default.rootSatetyCatalogID;
	    		}
			}else{
				catalogName = catalog.catalogName;
				strRemote = catalog.catalogID;

			}
		
			if(caiyun.judgement.isSafeBox()) {
	    			invoke('setSafetyInfo',caiyun.ui.webnd.safeBoxSessionId);
	    			jstr = invoke('putSafetyDragDropItem',strRemote);
		    }else{
	    		if(caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)){
    				if(caiyun.operate.canExecute('upload')){
	    				jstr = invoke('putShareDragDropItem',strRemote,catalog.path||'');	//
	    			}else{
	    				//|| window.caiyun.judgement.isInPublisherDir()
	    				if(window.caiyun.judgement.isInReceivedPublishDir() || window.caiyun.judgement.isInPublisherDir()){
							window.caiyun.ui.iMsgTip.tip('目标目录不支持拖拽移入文件或文件夹操作', 'loading', 1);
							return;
						}else{
							window.caiyun.ui.iMsgTip.tip('收到的分享目录不支持拖拽移入文件或文件夹操作', 'loading', 1);
		    				return;
						}
	    			}
	    		}else{
	    			if(caiyun.operate.canExecute('upload')){
	    				jstr = invoke('putDragDropItem',strRemote);	
	    			}if(window.caiyun.judgement.isInPublisherDir()){
	    				window.caiyun.ui.iMsgTip.tip('目标目录不支持拖拽移入文件或文件夹操作', 'loading', 1);
						return;
	    			}
	    			
	    		}
		    }
			var json = parse(jstr);
			if(json.PutFileList&&json.PutFileList.length){
				var isQueueLast=false;
				if(json.PutFileList.length==1){
					isQueueLast=true;
				}
				$.each(json.PutFileList,function(i,file){
					if(file.TaskType==1){//文件
						fileHandler(file,catalogName,false,true);
					}else{
						folderHandler(file,catalogName,isQueueLast,true);
					}
				});
				reg.closeBrowseEnd.call();
				reg.startUpload.call();
			}else{
				// json.ResultCode==-1 未选择任何文件
			}
			//还原拖拽的目标目录
			$('#dragRemote').val('')
		}
	};
	//处理根目录失败的情况
	rootCatalogError=function(errlist,lName){
		if(errlist&&errlist[0]){
			return errlist[0].LocalName===lName;
		}else{
			return false;
		}
	};
	webnd.pauseAllListen=function(){
		updateQueue();
		reg.pauseAllListen.call(null);
	} ;
	webnd.resumeAllListen=function(){
		updateQueue();
		reg.resumeAllListen.call(null);
	} ;
	var reg={
			//n个文件调N次
            reportState     : function(obj){
            	log.debug('nd reportState:'+obj);
        	},    // falsh将文件放入队列时的回调，状态码非0为不正常文件
            //遍历完通知
			closeBrowseEnd  : function(obj){log.debug('nd closeBrowseEnd:'+obj);},// flash弹出的浏览窗口关闭时的事件
			//开始上传标示
            startUpload     : function(obj){log.debug('nd startUpload:'+obj);},    // flash开始上传回调
            //上传第一个
            startFileUpload : function(obj){log.debug('nd startFileUpload:'+obj);},    // flash单个文件开始上传回调
            //每秒监听
            uploadListen    : function(obj){log.debug('nd uploadListen:'+obj);},   // 上传监听
            //上报错误
            reportError     : function(obj){log.debug('nd reportError:'+obj);},        // 单文件上传异常回调
            //每个上传成功
            reportFile      : function(obj){log.debug('nd reportFile:'+obj);},     // 单文件上传成功回调
            //全部成功
            loadDone        : function(obj){log.debug('nd loadDone:'+obj);} , 
            globalViewListen        : function(obj){log.debug('globalViewListen:'+obj);} ,
            pauseListen: function(obj){log.debug('pauseListen:'+obj);} ,
            pauseAllListen: function(obj){log.debug('pauseAllListen:'+obj);} ,
            resumeAllListen: function(obj){log.debug('resumeAllListen:'+obj);} ,
            reportTimeLine: function(obj){log.debug('reportTimeLine:'+obj);} 
	};
	webnd.taskChangeViewHandler = function(report) {
    	log.debug('webnd taskChangeViewHandler:'+report.number);
    	log.debug(report);
    };
	webnd.replaceTaskView = function(uploadInfo) {
    	log.debug('webnd replaceTaskView:'+uploadInfo.number);
    	log.debug(uploadInfo);
    };
    clearTaskQueue=function(){
    	invoke('clearAllTask',0);//0代表全部情况
    };
    var ndlogout=function(){
    	invoke('logout');
    };
    onbeforeunload = function(event) {
		if(caiyun.ui.webndflag)
			clearTaskQueue();
	};
	webnd.reg=function(cb){
		reg = cb
	};
	webnd.listViewdragEvent=function(event,itemId){
		if(!ndSupport)return;
	        try{
	        	modifyDragArea(event);
        		$('#dragRemote').val(itemId);
	        }catch(e){
        	modifyDragArea();
	        }
	};
	testArea=function(a,b){
		var dragArea = document.getElementById('WebNDPlugin');
		dragArea.style.visibility='visible';
        dragArea.style.left=a+'px';
        dragArea.style.top=b+'px';
        dragArea.style.width='50px';
        dragArea.style.height='50px';
	};
	modifyDragArea=function(event){
		if(!ndSupport)return;
		var scrollTop = 0,clientX=0,clientY=0,onepix='1px',len=30,dragArea = document.getElementById('WebNDPlugin');
		if($.browser.msie){
			scrollTop = document.documentElement.scrollTop;
		}else{
			scrollTop = document.body.scrollTop;
		}
        if(event){
        	try{
	        	if(!event.clientX){
		            $.event.fix(event);
		            clientX = event.originalEvent.clientX;
		            clientY = event.originalEvent.clientY;
		        }else{
		            clientX = event.clientX;
		            clientY = event.clientY;
		        }
		        if((clientX-len)<0||(clientY-len)<0){
		        	modifyDragArea();
		        }else{
		        	dragArea.style.visibility='visible';
			        dragArea.style.left=(clientX-len)+'px';
			        dragArea.style.top=(clientY-len+scrollTop)+'px';
			        dragArea.style.width='50px';
			        dragArea.style.height='50px';
		        }
		    }catch(e){
		    	modifyDragArea();
		    }
        }else{
        	dragArea.style.visibility='hidden';
	        dragArea.style.left=onepix;
	        dragArea.style.top=onepix;
	        dragArea.style.width=onepix;
	        dragArea.style.height=onepix;
	    }
	};
	webnd.modifyDragArea = modifyDragArea;
	modifyDragAreajq=function(event){
		var clientX=0,clientY=0,onepix='1px',len=30;dragArea = document.getElementById('WebNDPlugin');
        if(event){
        	try{
	        	if(!event.clientX){
		            $.event.fix(event);
		            clientX = event.originalEvent.clientX;
		            clientY = event.originalEvent.clientY;
		        }else{
		        	
		            clientX = event.clientX;
		            clientY = event.clientY;
		        }
		        // console.log('%s,%s',clientX,clientY);
		        $WebNDPlugin.css({'width':'50px','height':'50px','visibility':'visible'}).offset({left:clientX-len,top:clientY-len})
		        //console.log(document.getElementById('WebNDPlugin'));
		    }catch(e){
		    	//console.log('还原本身%s',e);
		    	modifyDragArea();//还原本身
		    }
        }else{
        	// console.log('还原本身');
	        $WebNDPlugin.css({'width':onepix,'height':onepix,'visibility':'hidden'}).offset({left:1,top:1});
	        // console.log(document.getElementById('WebNDPlugin'));
        }
	};
	//modifyDragArea = modifyDragAreajq;	
	mouseoverListen = function(event){
		EventUtil.preventDefault(event);
		EventUtil.stopPropagation(event);
		if(!ndSupport)return;
		try{
			if(caiyun.constants.abortAjaxs.readyState==1){
			window.caiyun.ui.iMsgTip.tip('亲，您操作得太快了，请稍候', 'loading', 1);
				modifyDragArea();
			}else{
				if(caiyun.ui.webndflag){
		        	modifyDragArea(event);
				}
			}
		}catch(e){
			window.caiyun.ui.iMsgTip.tip('亲，您操作得太快了，请稍候', 'loading', 1);
			modifyDragArea();
		}
	};
	webnd.mouseoverListen = mouseoverListen;
	var EventUtil = {
        addHandler: function (element, type, handler) {
            if (element.addEventListener) {
                element.addEventListener(type, handler, false);
            } else if (element.attachEvent) {
                element.attachEvent("on" + type, handler);
            } else {
                element["on" + type] = handler;
            }
        },
        removeHandler: function (element, type, handler) {
        	if(element.removeEventListener){//for DOM;
		       element.removeEventListener(type,handler, false);
		    }else if(element.detachEvent){
		      	element.detachEvent("on"+type,handler);
		   	} else{ 
		   		element["on"+type]=null;
		   	}
        },
        preventDefault: function (event) {
            if (event.preventDefault) {
                event.preventDefault();
            } else {
                event.returnValue = false;
            }
        },
        stopPropagation: function (event) {
            if (event.stopPropagation) {
                event.stopPropagation();
            } 
        }
    };
    var handleEvent = function (event) {
    	console.log("handleEvent:"+event.type);
    	modifyDragArea(event);
    };
	var globalDragEvent=function(){
		if(isHtml5Support){//必须增加HTML5Util依赖
			EventUtil.addHandler(document, "dragenter", mouseoverListen);
			EventUtil.addHandler(document, "dragover", mouseoverListen);
			EventUtil.addHandler(document, "drop", function(){
				modifyDragArea();//还原
			});
			EventUtil.addHandler(document, "mouseup", function(){
				modifyDragArea();//还原
			});
			 
			/*EventUtil.addHandler(document, "dragleave", function(event){
				return;
		        try{
		        	console.log('dragleave');
					var clientX=0,clientY=0;
					if(!event.clientX){
			            $.event.fix(event);
			            clientX = event.originalEvent.clientX;
			            clientY = event.originalEvent.clientY;
			        }else{
			        	
			            clientX = event.clientX;
			            clientY = event.clientY;
			        }
		        }catch(e){

		        }
		        console.log('%s,%s',clientX,clientY);
			});*/
		}
	};
	var restDrag = function(){
		EventUtil.removeHandler(document, "dragenter", mouseoverListen);
		EventUtil.removeHandler(document, "dragover", mouseoverListen);
		EventUtil.removeHandler(document, "drop", function(){
			modifyDragArea();//还原
		});
		EventUtil.removeHandler(document, "mouseup", function(){
			modifyDragArea();//还原
		});
	}
	webnd.restdrag = restDrag;
	webnd.globalDragEvent=globalDragEvent;
	//webnd.globalDragEvent=globalDragEvent;
	var globalDragEvent2=function(){
		if(isHtml5Support){
			EventUtil.addHandler(document, "dragenter", handleEvent);
		    EventUtil.addHandler(document, "dragover", handleEvent);
		    EventUtil.addHandler(document, "dragleave", handleEvent);
		    EventUtil.addHandler(document, "drop", handleEvent);
		    EventUtil.addHandler(document, "dragstart", handleEvent);
		}
	};
	var install = function(){
		if($.browser.msie) {
	        $('body').prepend('<object id="WebNDPlugin" classid="CLSID:AB65B096-CF4F-4AAA-8D71-5E1498C48903" style="width: 1px; height: 1px; position: absolute; left: 1px; top: 1px; visibility: visible;"></object>');
		} else{
	        $('body').prepend('<object id="WebNDPlugin" type="application/x-webND-plugin" style="width: 1px; height: 1px; position: absolute; left: 1px; top: 1px; visibility: visible;" ></object>');
		}
	};
	var bindNOWebUploadFun=function(){
		$WebNDPlugin.remove();
		$('#uploadBtndiv').hover(function(){$('#webNdUpload').show();},function(){$('#webNdUpload').hide();});
		//未安装控件
		$('#uploadBtn').attr('onclick','javascript:return false;').attr('href','javascript:void(0);');
		$('#webNdUpload li:eq(0) a').attr('onclick','javascript:return false;').attr('href','javascript:void(0);');
		//$('#webNdUpload li:eq(1) a').attr('onclick','javascript:void(0);').attr('href','javascript:void(0);').attr('target','_blank');
		$('#webNdUpload li:eq(1) a').attr('href','javascript:void(0);').bind('click',function(){
			downloadWebNdPlugin();//点击文件夹下载插件
		});
		//提示new
		$('#webNdUpload li:eq(1)').addClass('noselected');
		if(!Html5Util.isHtml5Support()){//去掉&&$.browser.version<'9.0'
			$('#webNdUpload .uploadDropMenu').addClass('uploadDropMenu-2');
		}
		$('#webNdUpload .newtips-icon').show();
	};
	var bindWebUploadFun=function(){
		$('#uploadBtn').bind('click',caiyun.ui.webnd.upload).attr('href','javascript:;');
        	$('#webNdUpload li:eq(0) a').bind('click',caiyun.ui.webnd.upload).attr('href','javascript:;');
        	$('#webNdUpload li:eq(1) a').bind('click',caiyun.ui.webnd.uploadFolder).attr('href','javascript:;');
		$('#uploadBtndiv').hover(function(){$('#webNdUpload').show();},function(){$('#webNdUpload').hide();});
		//隐藏new
		$('#webNdUpload li:eq(1)').removeClass('noselected');
		$('#webNdUpload .newtips-icon').hide();
		$('#uploadInput').remove();
		invoke('setToken',_default.account,_default.token);
		invoke('setNDServerAddr',_default.http,_default.https);
		invoke('setUpdateServerUrl',aasAddrWebnd||'');
		invoke('setMaxFileNum',1000);//最大选择1000个文件
		// if($.browser.msie){
			//&& ($.browser.version == '6.0'||$.browser.version == '7.0'||$.browser.version == '8.0')){
			//WebNDPlugin.setMaxFileNum(50)//ie低版本下限制同时上传文件数量
		// }
		globalDragEvent(); //绑定全局拖拽上传事件
	};
	webnd.installPluginTip=installPluginTip;
	webnd.isRetrySupport=isRetrySupport;
	webnd.bigDataFlag = bigDataFlag;
	/**
	* 功能描述：初始化入口
	*/
	webnd.isWebNdSupport=function(options){
		//step 1 检测上传控件是否安装
		//Step 2 控件没安装使用旧的
		//step 3 若安装检测是否为最新版本控件
		//step 4 若安装
		install();
		$.extend(_default,options);
		var state = check();
		//插件版本
		webnd.version = pluginVer;
		ndSupport = false;//默认是安装插件版本上传，false表示未安装插件，使用旧版本的上传
		switch(state){
			/*case ndState['upgrade']:
			//提示升级
			upgradePluginTip();
			bindWebUploadFun();
			break;
			*/
			case ndState['ok']:
			bindWebUploadFun();
			ndSupport = true;
			break;
			case ndState['noinstall']:
			default:
			bindNOWebUploadFun();
			installPluginTip();
			//提示安装
			ndSupport = false;
			break;
		}
		return ndSupport;
	};
	webnd.init=function(){
		if(_default.rootCatalog=='NUL'){
			_default.rootCatalog = window.caiyun.operate.getCurrentCatalog();
		}
		$('#userMenu_out a').bind('click',function(){
			ndlogout();//绑定退出按钮动作
		
		})
		//setTimeout("window.caiyun.ui.webnd.upgradePluginTip();",3000);
	}
	// 添加上传框体到ui列表
	caiyun.ui.initList.push(webnd);
})(this);