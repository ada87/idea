/**
 *  打开页面时，根据HASH值进行栏目切换
 *  HASH规则：
 *  栏目/[下级栏目或者查询参数]...
 *
 *  打开某个文件夹：
 *  http://caiyun.feixin.10086.cn/portail/index.jsp#file/catalogID
 *
 */
(function() {
	caiyun.hashnav = {};
	var self = caiyun.hashnav;
	var fileOperate = caiyun.operate;
	var constants = caiyun.constants;
	var fileContent = caiyun.ui.model.fileContent;
	var SEPARATOR = '/';
	var isInCurrentCatalogs = caiyun.judgement.isInCurrentCatalogs;
	var judgement = caiyun.judgement;
	var myPhoneOperate = caiyun.myPhoneOperate;

	// 记录一个旧的Hash值，用于IE不支持hashchange事件时，知道hash改变
	var oldHash = location.hash;
	// 记录一个原标题，用于解决IE标题会添加hash的bug
	var originalTitle = document.title.split("#")[0];

	var hashMap = {};
	var contentNameMap = {};

	// 是否存在模拟iframe
	var fadeFrame = null;
	var frameWin = null;
	var null_url = 'javascript:0';

	// 例外的几个hash
	var RECEIVE_SHARE_HASH = 'receivedShare';

	registContentNameHash(constants.DEFAULT_FILE_CONTENT_VIEW, 'myfile');
	registContentNameHash(constants.SAFEBOX_CONTENT_VIEW, 'safebox');
	registContentNameHash(constants.SAFEBOX_FILE_CONTENT_VIEW, 'safebox');
	registContentNameHash(constants.SHARE_CONTENT_VIEW, 'share');
	registContentNameHash(constants.RECYCLEBIN_CONTENT_VIEW, 'recyclebin');
	registContentNameHash(constants.MY_PHONE_CONTENT_VIEW, 'myphone');
	registContentNameHash(constants.TIMELINE_CONTENT_VIEW, 'timeline');


	var baseTitle = document.title;

	// myphone下的子栏目
	var myPhoneContents = {
		my_image: 'my_image',
		my_video: 'my_video',
		calendar: 'calendar',
		contact: 'contact',
		sms: 'sms',
		mms: 'mms',
		apps: 'apps'
	};

	var titleMap = {};
	titleMap[constants.SAFEBOX_CONTENT_VIEW] = '保险箱';
	titleMap[constants.SAFEBOX_FILE_CONTENT_VIEW] = '保险箱';
	titleMap[constants.SHARE_CONTENT_VIEW] = '分享管理';
	titleMap[constants.RECYCLEBIN_CONTENT_VIEW] = '回收站';
	titleMap[constants.MY_PHONE_CONTENT_VIEW] = '我的手机';
	titleMap[constants.TIMELINE_CONTENT_VIEW] = '时光';
	titleMap[constants.cannotModifyIDs.root_receiveShare] = '收到的分享';
	titleMap[myPhoneContents.my_image] = '手机图片';
	titleMap[myPhoneContents.my_video] = '手机视频';
	titleMap[myPhoneContents.calendar] = '日历';
	titleMap[myPhoneContents.contact] = '通信录';
	titleMap[myPhoneContents.sms] = '短信';
	titleMap[myPhoneContents.mms] = '彩信';
	titleMap[myPhoneContents.apps] = '手机应用';

	/**
	 * 注册栏目名和Hash值的映射
	 */

	function registContentNameHash(contentName, hash) {
		hashMap[hash] = contentName;
		contentNameMap[contentName] = hash;
	}

	/**
	 * 根据栏目名获取hash
	 */

	function getHashByContentName(contentName) {
		return contentNameMap[contentName];
	}

	/**
	 * 根据Hash获取栏目名
	 */

	function getContentNameByHash(hash) {
		if (!hash) {
			return null;
		}
		var temp = hash[0] === '#' ? hash.substr(1) : hash;
		return hashMap[hash.split(SEPARATOR)[0]];
	}

	self.getHashByContentName = getHashByContentName;

	/**
	 * 根据当前hash切换栏目
	 */
	self.switchContent = function(force) {
		var hash = location.hash;
		if (!hash || hash === '#') {
			fileContent.switchToView(constants.DEFAULT_FILE_CONTENT_VIEW);
			fileOperate.enterDir(constants.rootIds.myFolder);
			return;
		}
		hash = hash.substr(1);
		var parts = hash.split('/');
		var contentName = getContentNameByHash(parts[0]);
		var catalogId;
		if (parts[0] === RECEIVE_SHARE_HASH) {
			contentName = constants.DEFAULT_FILE_CONTENT_VIEW;
			// 如果parts的长度等于2，则进入到收到的分享目录下
			if (parts.length === 2) {
				catalogId = constants.cannotModifyIDs.root_receiveShare;
			} else if(parts.length === 3){
				catalogId = parts[parts.length - 1];
				// 如果此目录不在当前目录栈内
				if(!isInCurrentCatalogs(catalogId)){
					// 判断有没有包含公共账号的ID后缀，如果有就跳到收到的分享下
					for(var j = 0,len = parts.length ; j < len ; j ++){
						if(parts[j].indexOf(constants.publisherAccountConstants.publisherDirSuffix) !== -1){
							catalogId = constants.cannotModifyIDs.root_receiveShare;
							break;
						}
					}
				}
			}
			else {
				catalogId = parts[parts.length - 1];
			}
		} else {
			catalogId = parts[1];
		}
		if (!contentName) {
			fileContent.switchToView(constants.DEFAULT_FILE_CONTENT_VIEW);
			fileOperate.enterDir(constants.rootIds.myFolder);
			return;
		}
		var currentView = fileContent.getCurrentView();
		// 如果不是当前栏目才切换
		if (force || !currentView || currentView.name !== contentName) {
			if (!currentView || currentView.name !== contentName) {
				fileContent.switchToView(contentName);
			}
			if (contentName === constants.DEFAULT_FILE_CONTENT_VIEW || contentName === constants.SAFEBOX_FILE_CONTENT_VIEW) {
				if (contentName === constants.SAFEBOX_FILE_CONTENT_VIEW && (!constants.safeboxLogined || !catalogId)) {
					// 如果没有登录，跳转到登录页面
					fileContent.switchToView(constants.SAFEBOX_CONTENT_VIEW);
					return;
				}

				if (catalogId) {
					// 如果是收到的分享，直接搞之
					if (catalogId === constants.cannotModifyIDs.root_receiveShare) {
						fileOperate.clearSetCatalogStack({
							catalogID: constants.rootIds.myFolder,
							catalogName: constants.rootIdsName[constants.rootIds.myFolder]
						});
						fileOperate.enterDir(constants.cannotModifyIDs.root_receiveShare, {
							catalogID: constants.cannotModifyIDs.root_receiveShare,
							catalogName: constants.receiveFolderName
						});
						return;
					} else if (isInCurrentCatalogs(catalogId)) {
						if (parts[0] !== RECEIVE_SHARE_HASH) {
							fileOperate.enterDir(catalogId);
						} else {
							fileOperate.enterDir(catalogId, null, judgement.getPath(fileOperate.getCatalogStack()));
						}
					} else {
						if (parts[0] !== RECEIVE_SHARE_HASH) {
							fileOperate.enterCopyDirLocate({
								cataID: catalogId
							});
						} else {
							// 整一个part构造成完整路径
							var path = parts.slice(1);
							// 用于进入收到的分享目录
							fileOperate.enterCopyDirLocate({
								cataID: catalogId,
								path: path.join('/'),
								isShare: true
							});
						}
					}
				} else {
					fileOperate.enterDir(constants.rootIds.myFolder);
				}
			}
			// 我的手机栏目
			if (contentName === constants.MY_PHONE_CONTENT_VIEW) {
				if (!parts[1]) {
					myPhoneOperate.switchTo('my_phone');
				}
				// 如果存在下级菜单，跳到下级菜单
				if (parts[1] !== myPhoneOperate.getCurrentId()) {
					myPhoneOperate.switchTo(parts[1]);
				}
			}
			// 回收站
			if (contentName === constants.RECYCLEBIN_CONTENT_VIEW) {
				caiyun.recycleBinOperate.loadRecycleBinInfos();
			}
			// 分享管理
			if (contentName === constants.SHARE_CONTENT_VIEW) {
				window.caiyun.fileShareOperate.reload();
			}
		}

	};

	// 监听hashChange事件
	if (window.onhashchange === null && (document.documentMode === undefined || document.documentMode >= 8)) {
		window.onhashchange = function() {
			if (oldHash !== location.hash) {
				self.switchContent(true);
				oldHash = location.hash;
			}
		};
	} else {
		/** 不支持的浏览器创建一个iframe模拟前进后退 **/
		setInterval(function() {
			if (frameWin && frameWin.location.hash.length > 1 && frameWin.location.hash !== location.hash) {
				location.hash = frameWin.location.hash;
			}
			if (oldHash !== location.hash) {
				self.switchContent(true);
				oldHash = location.hash;
			}
		}, 500);

		fadeFrame = $(document.createElement('iframe')).hide().attr({
			tabindex: '-1',
			src: null_url,
			id: 'fade',
			width: 0,
			height: 0
		}).appendTo('body');
		frameWin = fadeFrame[0].contentWindow;
	}

	// 如果是IE需要检查标题是否正常并恢复文档标题
	if ($.browser.msie) {
		document.attachEvent('onpropertychange', function(evt) {
			if (evt.propertyName === 'title' && document.title !== originalTitle) {
				setTimeout(function() {
					document.title = originalTitle;
				}, 1);
			}
		});
	}

	self.changeHash = function(hash) {
		location.hash = hash;
		oldHash = location.hash;
		if (frameWin) {
			var frameDoc = frameWin.document;
			frameDoc.open();
			frameDoc.close();
			frameWin.location.hash = hash;
		}
	};

	self.changeTitle = function(title) {
		if (title) {
			originalTitle = baseTitle + SEPARATOR + title;
		} else {
			originalTitle = baseTitle;
		}
		document.title = originalTitle;
		if (frameWin) {
			var frameDoc = frameWin.document;
			frameDoc.title = originalTitle;
		}
	};

	// 监听栏目切换事件，修改hash
	fileOperate.onListen('fileContentSwitch', function(e) {
		// 忽略第一次进入默认视图
		if (!e.oldView) {
			return;
		}
		var newView = e.newView;
		var name = newView.name;
		// 进入我的文件都通过enterDir来切换，防止两次切换，导致浏览器中的历史记录不对
		if (name === constants.DEFAULT_FILE_CONTENT_VIEW) {
			return;
		}
		var newHash = getHashByContentName(name);
		if (newHash) {
			self.changeTitle(titleMap[name]);
			self.changeHash(newHash);
		}
	});

	// 监听目录切换事件，修改hash
	fileOperate.onListen('enterDir', function(catalogStack) {
		var top = catalogStack[catalogStack.length - 1];
		var newHash = null;
		if (top.catalogID !== constants.rootIds.myFolder && top.catalogID !== constants.rootIds.myFolderWithUserID) {
			// 是否在收到的分享下
			if (judgement.isInCurrentCatalogs(constants.cannotModifyIDs.root_receiveShare)) {
				newHash = RECEIVE_SHARE_HASH + SEPARATOR + judgement.getPath(fileOperate.getCatalogStack());
				self.changeTitle(top.catalogName);
				self.changeHash(newHash);
				return;
			}
			if (!judgement.isSafeBox()) {
				newHash = getHashByContentName(constants.DEFAULT_FILE_CONTENT_VIEW) + SEPARATOR + top.catalogID;
				self.changeTitle(top.catalogName);
			} else {
				newHash = getHashByContentName(constants.SAFEBOX_FILE_CONTENT_VIEW) + SEPARATOR + top.catalogID;
				self.changeTitle('保险箱' + SEPARATOR + top.catalogName);
			}
		} else {
			newHash = getHashByContentName(constants.DEFAULT_FILE_CONTENT_VIEW);
			self.changeTitle('');
		}
		// hash会在后退时自动变化，因此如果hash没有改变就不要去变他
		if ('#' + newHash !== location.hash) {
			self.changeHash(newHash);
		}

	});

	// 监听手机栏目切换事件
	myPhoneOperate.addListen('switchTo', function(data) {
		var id = data.id;
		var subTitle = null;
		var hash = location.hash;
		if (id) {
			subTitle = titleMap[id];
		}
		if (subTitle) {
			self.changeTitle(titleMap[constants.MY_PHONE_CONTENT_VIEW] + SEPARATOR + subTitle);
			self.changeHash(getHashByContentName(constants.MY_PHONE_CONTENT_VIEW) + SEPARATOR + id);
		}
	});

	// 监听短彩栏目切换事件
	myPhoneOperate.addListen('triggerSmsContent', function(data) {
		var id = data.id;
		var subTitle = null;
		var hash = location.hash;
		if (id) {
			subTitle = titleMap[id];
		}
		if (subTitle) {
			self.changeTitle(titleMap[constants.MY_PHONE_CONTENT_VIEW] + SEPARATOR + subTitle);
			self.changeHash(getHashByContentName(constants.MY_PHONE_CONTENT_VIEW) + SEPARATOR + id);
		}
	});
})();