caiyun.ui.model.fileContent = {};

/**
 * fileContent，负责管理UI视图的切换，比如：所有文件 切换到 图片pictures 文档files 音乐musics 视频videos 软件softwares
 */
(function(){
	var self = caiyun.ui.model.fileContent ;
	var $self;
	
	var constants = caiyun.constants;
	var contentViewMap = {};
	var currentContentView;
	
	// 初始化自己
	self.init = function(){
		// 包括右侧头部和右侧内容区
		$self = $('.cy_container');
	};
	
	// 增加一个内容视图
	self.addContentView = function(contentView){
		contentViewMap[contentView.name] = contentView;
	};
	
	// 切换到该内容视图
	self.switchToView = function(name,data){
		var  newView = contentViewMap[name];
		var  oldView = currentContentView;
		if(newView){
			if(oldView){
				// 删除旧视图的样式
				if(oldView.className){
					$self.removeClass(oldView.className);
				}
				if(oldView.leave){
					oldView.leave();
				}
				// 触发旧视图的离开方法
				$(currentContentView.modelList).each(function(){
					if(this.model.leave){
						this.model.leave(currentContentView,data);
					}
					if(this.model.hide){
						this.model.hide();
					}
				});
			}
			// 获取newView的Class值，如果没有class值则清空控制view的class
			if(newView.className){
				$self.addClass(newView.className);
			}
			
			$(newView.modelList).each(function(){
				if(this.model.enter){
					this.model.enter(newView,oldView,data);
				}
				if(this.model.show){
					this.model.show();
				}
			});
			currentContentView = newView;

			// 触发新视图的初始化方法
			if(newView.after){
				newView.after();
			}
			
			window.caiyun.operate.triggerFileContentSwitch(oldView,newView);
		}
	};
	
	/**
	 * 获取当前视图
	 */
	self.getCurrentView = function(){
		return currentContentView;
	};
	
	// 注册到页面初始化方法中
	caiyun.ui.initList.push(self);
})();

