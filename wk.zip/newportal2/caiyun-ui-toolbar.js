/**
* 工具栏
*/
(function(){
	var self = caiyun.ui.model.toolbar;
	
	self.init = function(){
		
	};
	
	// 将自己的初始化方法加载到ui的initList中
	caiyun.ui.initList.push(self);
}
)();