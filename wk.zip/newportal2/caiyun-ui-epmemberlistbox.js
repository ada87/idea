//企业成员列表box
var enterpriseAuth;
(function() {
    var self = caiyun.ui.model.epmemberlistbox;

    self.init = function() {
        var operate = caiyun.operate;
        // 文件操作对象
        var params = {
            account: '', //个人账号
            enterpriseaccnt: '', //企业账号
            enterpriseID: '', //企业ID
            startnum: 1, //查询开始
            endnum: 2 //查询结束
        };

        var flag = false; //判断当前列表显示类型

        var memberinfos; //企业成员列表信息
        //获取企业成员列表4管理员html
        var getEPlistHtml4Admin = function(data) {
            var contentHtml = getContentHtml("admin", data);
            var EPlistBox = caiyun.ui.msgBox({
                id: 'EPlist4Admin',
                width: 706,
                html: contentHtml,
                hasBottomHtml: true,
                title: "企业成员列表"
            });
            EPlistBox.show();
            $("#addMemBtn").unbind().bind('click', function() {
                window.location.href = '../enterprise/getEnterpriseMember.action';
            });
        };

        //需要判断当前用户是否为管理员
        var type = "admin";
        //获取列表4管理员html
        var getContentHtml = function(type, data) {
            var $_content = $('<div class="popContent" style="padding: 12px;"></div>');
            var $_addBtn = $('<div class="add_member_btn_box"><span class="add_member_btn" id="addMemBtn"><i></i>添加成员</span></div>');
            var $_listContent = "";
            var $_listTitle = "";
            var $_getList = $('<div class="memberCon"></div>');
            if (type == "admin") {
                var $_memberPage = $('<div class="member-pages"></div>');
                $_listContent = $('<div class="get-share-manager"></div>');
                $_listTitle = $('<div class="memberTitle"><span class="memberName">姓名</span><span class="memberNum">手机号码</span><span class="memberStatus">状态</span><span class="memberAuth">权限</span></div>');
                var $_listUL = getListContent(type, data);
                $_memberPage.append($_listUL);
                $_getList.append($_memberPage);
                $_listContent.append($_listTitle).append($_getList);
                $_content.append($_addBtn).append($_listContent);
            } else {
                var $_memberPage = $('<div class="member-pages"></div>');
                $_listContent = $('<div class="get-share-common"></div>');
                $_listTitle = $('<div class="memberTitle"><span class="memberName">姓名</span><span class="memberNum">手机号码</span></div>');
                var $_listUL = getListContent(type, data);
                $_memberPage.append($_listUL);
                $_getList.append($_memberPage);
                $_listContent.append($_listTitle).append($_getList);
                $_content.append($_listContent);
            }
            return $_content.html();
        };

        //获取企业成员列表4普通成员html
        var getEPlistHtml4User = function(data) {
            var contentHtml = getContentHtml("", data);
            var EPlistBox = caiyun.ui.msgBox({
                id: 'EPlist4User',
                width: 356,
                html: contentHtml,
                hasBottomHtml: true,
                title: "企业成员列表"
            });
            EPlistBox.show();
        };

        //获取管理员的企业成员列表内容
        var getListContent = function(type, data) {
            var $_ul = $('<ul></ul>');
            $.each(data, function(i, n) {
                var $_li = $('<li></li>');
                var username = n.name ? window.caiyun.util.subStringByLen(n.name, 10) : '';
                var $_spanName = $('<span class="m-name">' + username + '</span>');
                var $_spanNum = $('<span class="m-num">' + n.msisdn + '</span>');
                //判断生成的列表类型
                if (type == 'admin') {
                    var $_spanStatus = $('<span class="m-status"></span>');
                    var status = "已激活";
                    var role = n.role;
                    var roleTitle = "";
                    if (n.memberID.indexOf('|') == 0) {
                        status = "未激活";
                        $_spanStatus.addClass('tb-1');
                    }
                    $_spanStatus.text(status);
                    switch (role) {
                        case 0:
                            roleTitle = "管理员"
                            break;
                        case 4:
                            roleTitle = "上传"
                            break;
                        case 5:
                            roleTitle = "下载"
                            break;
                        case 6:
                            roleTitle = "上传下载"
                            break;
                        case 7:
                            roleTitle = "查看"
                            break;
                        case 8:
                            roleTitle = "编辑"
                            break;
                    };
                    var $_spanAuth = $('<span class="m-auth">' + roleTitle + '</span>');
                    $_li.append($_spanName).append($_spanNum).append($_spanStatus).append($_spanAuth);
                } else {
                    $_li.append($_spanName).append($_spanNum);
                }
                $_ul.append($_li);
            });
            return $_ul;
        };

        //显示成员列表
        var showMemberList = function(data) {
            if (data) {
                if (flag) {
                    getEPlistHtml4Admin(data);
                } else {
                    getEPlistHtml4User(data);
                }
            } else {
                window.caiyun.ui.iMsgTip.tip("企业信息加载失败,请稍后重试!", "error");
            }
        };

        //监听打开"企业成员列表"事件
        caiyun.operate.onListen("enterDir", function(catalogStack) {
            //如果进入我收到的企业分享目录下
            var stackInfo = catalogStack;
            var eid = '';
            if (window.caiyun.judgement.isEnterprisePath()) {
                //如果进入的是收到的分享企业空间
                if (caiyun.judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)) {
                    flag = false;
                    eid = stackInfo[stackInfo.length - 1].sharer;
                } else { //进入的是共享管理下的企业空间
                    eid = entryPriseInfoData._qryInfo.myEnterprise.enterpriseInfo[0].enterpriseAccnt;
                    flag = true;
                }
                //如果进入企业空间一级目录，才去查询企业成员列表
                if (stackInfo[stackInfo.length - 1].shareType == '4') {
                    memberinfos = caiyun.util.cache.getEnterpriseAuthCache(caiyun.constants.ENTERPRISE_AUTH_CACHEGROUP, eid);
                    var roleTitle = "未知";
                    var roleNum = '';
                    var memberNum = "未知";
                    if (memberinfos) {
                        memberNum = memberinfos.length;
                        $.each(memberinfos, function(i, n) {
                            if (n.msisdn == ownerMSISDN || n.msisdn == ("+86" + ownerMSISDN)) {
                                enterpriseAuth = n.role;
                                switch (enterpriseAuth) {
                                    case 0:
                                        roleTitle = "管理员";
                                        roleNum = 0;
                                        break;
                                    case 4:
                                        roleTitle = "上传者";
                                        roleNum = 4;
                                        break;
                                    case 5:
                                        roleTitle = "下载者";
                                        roleNum = 5;
                                        break;
                                    case 6:
                                        roleTitle = "上传下载者";
                                        roleNum = 6;
                                        break;
                                    case 7:
                                        roleTitle = "查看者";
                                        roleNum = 7;
                                        break;
                                    case 8:
                                        roleTitle = "编辑者";
                                        roleNum = 8;
                                        break;
                                }
                            }
                        });
                    }
                    if (window.caiyun.judgement.isEnterprisePath()) {
                        $("#enterpriseRole span").text("权限:" + roleTitle);
                        $("#enterpriseNum a").text("(" + memberNum + ")");
                        $("#enterpriseRole").show();
                        $("#enterpriseNum").show();
                    }
                }
                $("#enterpriseNum").unbind().bind('click', function() {
                    showMemberList(memberinfos);
                    $('.popContent').css('padding', '12px');
                    $('.get-share-manager,.get-share-common').width('100%');
                });
            } else {
                $("#enterpriseRole").hide();
                $("#enterpriseNum").hide();
                enterpriseAuth = '';
            }
        });

        // 切换栏目时隐藏企业成员按钮和权限
        caiyun.operate.onListen("fileContentSwitch", function() {
            $("#enterpriseRole").hide();
            $("#enterpriseNum").hide();
        });

    };
    // 将自己的初始化方法加载到ui的initList中
    caiyun.ui.initList.push(self);
})();