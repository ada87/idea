/**
 * 加载中、以及操作结果提示条
 *
 * iMsgTip.tip(text,type,showtime,force); 显示普通提示，提示一段时间后自动消失 text:  当type为html的时候，text显示为html格式的 要提示的文字 type:
 * 提示类型，决定提示的样式，''：成功提示，'error'：错误提示，'loading' ： 加载提示 showtime :
 * 显示时间，传入正整数表示，显示多少秒后自动消失，传其他则，按照默认时间显示后消失 force : true
 * 表示该提示会取消当前提示，并且立刻显示新提示，默认false
 *
 * 返回值：{close : function} , 返回的是一个带关闭方法close的对象，用于立刻关闭提示
 *
 * 例如： iMsgTip.tip("我是一般提示");—— 打开一般提示，默认显示三秒 iMsgTip.tip("我是错误提示","error");——*
 * 打开错误提示，默认显示三秒 iMsgTip.tip("我是延时15秒消失的错误提示","error",15);—— 打开自定义延时15秒的错误提示
 * iMsgTip.tip("我是延时15秒消失的错误提示","error",3,true);—— 立刻打开显示3秒的错误提示
 *
 */
(function() {

    var self = caiyun.ui.iMsgTip;
    var DEFAULT_SHOW_TIME = 3;
    var DEFAULT_PENDING_SHOW_TIME = 30;

    // 提示队列
    var tipsQueue = [];

    // 当前提示
    var currentTips = null;

    function Tips() {
        this.date = new Date(); // 创建时间
        this.status = 0; // 0 等待显示 1 显示中 2 显示结束 3 被取消
        this.timeoutHandler = null; // 超时句柄
        this.timeout = DEFAULT_SHOW_TIME; // 显示时间
        this.text = null;
        this.type = null;
        this.force = false;
        this.html = null;
    }

    self.init = function() {
        var $tips = $('#imsg_tips');

        /**
         * 根据类型获取css class
         *
         * @param type
         *            {String} 类型
         */

        function getClassByType(type) {
            return type;
        }

        /**
         * 显示提示
         *
         * @param tips
         *            {Tips} 要显示的提示
         */

        function showTips(tips) {
            var typeCls = getClassByType(tips.type);
            if (!typeCls) {
                typeCls = '';
            }
            if (tips.type === "html") {
                $tips.removeClass().addClass('cy_all_tips').addClass(typeCls).html(
                    tips.html).css('display', 'block').css('margin-left', ((-$tips.width() - 70) / 2) + 'px').show();
            } else {
                $tips.removeClass().addClass('cy_all_tips').addClass(typeCls).text(
                    tips.text).css('display', 'block').css('margin-left', ((-$tips.width() - 70) / 2) + 'px').show();
            }

        }

        /**
         * 显示下一条
         */
        function showNext() {
            while (tipsQueue.length > 0) {
                var currentTips = tipsQueue.shift();
                var tips = currentTips;
                if (currentTips && currentTips.status === 0) {
                    // 关闭显示
                    closeTips();
                    currentTips.status = 1;
                    currentTips.timeoutHandler = setTimeout(function() {
                        // 关闭显示
                        closeTips();
                        // 清除当前提示
                        currentTips = null;
                        tips.status = 2;
                        tips.timeoutHandler = null;
                        // 显示下一个
                        showNext();
                    }, currentTips.timeout * 1000);
                    showTips(currentTips);
                    break;
                }
            }
        }

        /**
         * 关闭提示
         */

        function closeTips() {
            $tips.empty();
            $tips.attr('style', '');
            $tips.removeClass();
            $tips.addClass('cy_all_tips');
            $tips.hide();
        }

        self.tip = function(text, type, _showtime, force) {
            var _text = text ? text : '',
                showTime = 0,
                tips = null;

            if (typeof _showtime === 'number' && _showtime > 0) {
                showTime = _showtime;
            } else {
                showTime = DEFAULT_SHOW_TIME;
            }

            tips = new Tips();
            tips.text = _text;
            tips.type = type;
            if (type === "html") {
                tips.html = text;
            }
            tips.timeout = showTime;
            tips.force = (force === true);

            // 如果当前没有提示出现或者强制显示，则立刻显示
            if (!currentTips || tips.force) {
                // 如果有当前显示的提示
                if (currentTips) {
                    closeTips();
                    currentTips.status = 3;
                    if (currentTips.timeoutHandler) {
                        clearTimeout(currentTips.timeoutHandler);
                    }
                }

                currentTips = tips;
                showTips(tips);
                tips.timeoutHandler = setTimeout(function() {
                    // 关闭显示
                    closeTips();
                    // 清除当前提示
                    currentTips = null;
                    tips.status = 2;
                    tips.timeoutHandler = null;
                    // 显示下一个
                    showNext();
                }, tips.timeout * 1000);
                tips.status = 1;
            } else {
                tipsQueue.push(tips);
            }

            return {
                close: function() {
                    // 当前显示的提示等于关闭提示才关闭
                    if (currentTips === tips) {
                        currentTips = null;
                        closeTips();
                    }
                    tips.status = 3;
                    if (tips.timeoutHandler) {
                        clearTimeout(tips.timeoutHandler);
                    }
                    // 显示下一个
                    showNext();
                }
            };
        };

    };

    caiyun.ui.initList.push(self);
})();