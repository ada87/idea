/**
 * 手机路径条
 */
(function() {

	var self = caiyun.ui.model.myphonePath;

	self.init = function() {
		var constants = caiyun.constants;
		var pathBarModel;
		var $pathBar = $('#my_phone_path');
		var CyPathBar = caiyun.ui.CyPathBar;
		var CyPathItem = caiyun.ui.CyPathItem;
		var operate = caiyun.myPhoneOperate;
		var fileOperate = caiyun.operate;

		// 创建KO模型
		pathBarModel = new CyPathBar({
					totalPathLength : 80
				});

		var element = document.getElementById('my_phone_path');

		// 绑定模型
		ko.applyBindings(pathBarModel, element);

		// 点击事件
		function _clickItem(pathItem) {
			operate.switchTo(pathItem.fileInfo.id);
		};

		var root = new CyPathItem(self, {
					id : 'my_phone',
					name : '我的手机'
				}, null, {
					click : _clickItem
				});

		pathBarModel.pushPath(root);

		operate.addListen('switchTo', function(data) {
					pathBarModel.removeAll();
					pathBarModel.pushPath(root);
					if (data.id !== 'my_phone') {
						var item = new CyPathItem(self, {
									id : data.id,
									name : data.name
								}, null, {
									click : _clickItem
								});
						pathBarModel.pushPath(item);
					}
				});
		
		fileOperate.onListen('fileContentSwitch',function(e){
			if(e.newView.name === constants.MY_PHONE_CONTENT_VIEW){
				// 重置路径条
				pathBarModel.removeAll();
				pathBarModel.pushPath(root);
			}
		});
		
		self.show = function() {
			$pathBar.show();
		};

		self.hide = function() {
			$pathBar.hide();
		};

		self.enter = function() {
		};

		self.leave = function() {
			pathBarModel.removeAll();
			pathBarModel.pushPath(root);
		};

	};

	caiyun.ui.initList.push(self);

})();