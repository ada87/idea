/**
 * 默认的文件视图
 */
(function() {
	var view = {
		name: caiyun.constants.SAFEBOX_FILE_CONTENT_VIEW, //显示方式名字
		modelList: [ // 包含的UI对象
			{
				model: caiyun.ui.model.thumbnailView // 该显示类型下，会出现的对象，不管该对象是否显示，只要该对象有可能在该显示类型下出现都需要加到列表中
			}, {
				model: caiyun.ui.model.listView // 该显示类型下，会出现的对象，不管该对象是否显示，只要该对象有可能在该显示类型下出现都需要加到列表中
			}, {
				model: caiyun.ui.model.leftNav
			}, {
				model: caiyun.ui.model.fileTitle
			}, {
				model: caiyun.ui.model.pathBar
			}, {
				model: caiyun.ui.model.viewswitch
			}, {
				model: caiyun.ui.model.sortorButton
			}, {
				model: caiyun.ui.model.nodeCount
			}
		],
		data: {},
		after: function() {
			var fileOperator = caiyun.operate;
			var constants = caiyun.constants;
			// 根据文件视图模式显示之前用户切换的视图
			if (fileOperator.getCurrentView() == constants.view.web) {
				caiyun.ui.model.thumbnailView.hide();
				caiyun.ui.model.listView.show();
			} else if (fileOperator.getCurrentView() == constants.view.win) {
				caiyun.ui.model.thumbnailView.show();
				caiyun.ui.model.listView.hide();
			}
		},
		leave : function(){
			caiyun.constants.safeboxLogined = false;
			window.caiyun.operate.clearSetCatalogStack();
			$('#safeboxUpPwd').hide();
		}
	};
	// 注册到文件视图管理器下
	caiyun.ui.model.fileContent.addContentView(view);
})();