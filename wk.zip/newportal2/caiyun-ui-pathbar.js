caiyun.ui.model.pathBar = {};

/**
 * 路径导航条，由knockout实现
 *
 * 由一个个目录项组成的目录导航条
 */
(function() {

	var self = caiyun.ui.model.pathBar;
	var constants = caiyun.constants;
	var pathBarModel;
	var $pathBar = $('#path_bar');
	var CyPathBar = caiyun.ui.CyPathBar;
	var CyPathItem = caiyun.ui.CyPathItem;

	self.init = function() {

		// 文件操作控制器
		var fileOperator = caiyun.operate;
		// 判断类
		var judgement = caiyun.judgement;

		// 创建KO模型
		pathBarModel = new CyPathBar({
			totalPathLength: 60
		});

		var element = document.getElementById('path_bar');

		// 绑定模型
		ko.applyBindings(pathBarModel, element);

		// 点击事件
		function _clickItem(pathItem) {
			var path = "";
			if (pathItem && pathItem.fileInfo && pathItem.fileInfo.data && pathItem.fileInfo.data.path) {
				path = pathItem.fileInfo.data.path;
			}
			// 如果stack里面包含了收到的分享,并且点击的不是根目录
			if (path === '' && pathItem.fileInfo.data.catalogID !== constants.rootIds.myFolder && pathItem.fileInfo.data.catalogID !== constants.rootIds.myFolderWithUserID && judgement.isInCurrentCatalogs(caiyun.constants.cannotModifyIDs.root_receiveShare)) {
				path = judgement.getPath(caiyun.operate.getCatalogStack());
			}
			fileOperator.enterDir(pathItem.pathId(), {}, path);
		}

		// 注册事件
		fileOperator.onListen('enterDir', function(pathStack) {
			pathBarModel.removeAll();

			//首先，如果在企业空间下
			if (judgement.isEnterprisePath()) {

				$pathBar.removeClass('insure_icon');
				pathBarModel.modifyMaxPathLength(36);
			} else if (judgement.isInMyFile()) {
				$pathBar.removeClass('insure_icon');
				pathBarModel.modifyMaxPathLength(58);
			}
			// 如果在保险箱下修改图标
			else if (judgement.isSafeBox()) {
				$pathBar.addClass('insure_icon');
				// 保险箱只能显示
				pathBarModel.modifyMaxPathLength(38);
			}

			$(pathStack).each(function() {
				var pathItem = new CyPathItem(self, {
					id: this.catalogID,
					name: this.catalogName,
					data: this
				}, null, {
					click: _clickItem
				});
				pathBarModel.pushPath(pathItem);
			});
		});


	};

	self.show = function() {
		$pathBar.show();
	};

	self.hide = function() {
		$pathBar.hide();
	};

	self.enter = function() {

	};

	self.leave = function() {
		pathBarModel.removeAll();
	};

	self.removeAll = function() {
		pathBarModel.removeAll();
	};

	caiyun.ui.initList.push(self);
})();