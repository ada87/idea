(function() {
	var util = window.caiyun.util;
	var ajax = util.caiyunAjax.ajaxRequest;
	var constants = window.caiyun.constants;
	var ui = window.caiyun.ui;
	var msgBox = ui.msgBox;
	var judgement = window.caiyun.judgement;

	constants.safeboxLogined = false;

	window.caiyun.ui.model.safebox = (function() {
		var isFirst = true;
		var safebox = $('#safebox');
		var safeboxUpPwd = $('#safeboxUpPwd');
		var safeboxPath = $('#safe_box_path');
		var pwdOnePlaceholder = null;
		var loginPwd = null;
		var iMsgTip = $('#safe_login_tips');
		// 是否初始化过
		var inited = false;

		var fileContent = caiyun.ui.model.fileContent;
		var myfileID = caiyun.constants.rootIds.myFolder;

		var init = function() {
			var operate = window.caiyun.operate;
			operate.clearSetCatalogStack({
				catalogName: constants.rootIdsName[constants.rootIds.mySafeBox],
				catalogID: constants.rootIds.mySafeBox
			});
			safeboxPath.show();
			isFirst = true;


			safeUiInit();
			resetUI();

			if (!inited) {
				// 登录密码框增加默认提示
				inited = true;
				pwdOnePlaceholder = $('#safebox_pwd_one').CyPlaceholder({
					className: 'defaultText'
				})[0];
				loginPwd = $('#safebox_login_pwd').CyPlaceholder({
					className: 'defaultText'
				})[0];
			}

			constants.safeboxLogined = false;
		};

		// 重置界面

		function resetUI() {
			// 密码输入框清空
			$('#safebox_login_pwd').attr('value', '');
			$("#safebox_pwd_one").attr('value', '');
			$("#safebox_pwd_two").attr('value', '');
			if (pwdOnePlaceholder) {
				pwdOnePlaceholder.showPlaceholder();
			}
			if (loginPwd) {
				loginPwd.showPlaceholder();
			}
			$('#set_pwd_msg').text('');
			$('#iMsgTip').text('');
			$('#safe_login_tips').text('');
		}

		//根据用户判断判断来绝定显示界面
		var safeUiInit = function() {
			safebox.show();
			pwdEventListener();

			if (constants.isSafeBoxUser) {
				$("#safebox_setPwd").hide();
				$("#safebox_login").show();
			} else {
				$("#safebox_login").hide();
				$("#safebox_setPwd").show();
			}

		};

		//用户设置初始密码
		var setUserPwd = function() {
			var _$one = $("#safebox_pwd_one");
			var _$two = $("#safebox_pwd_two");
			var password_one = $.trim(_$one.val());
			var password_two = $.trim(_$two.val());
			var $setPwdMsg = $('#set_pwd_msg');
			if (isBlank(password_one)) {
				$setPwdMsg.text("密码不能为空");
				$('#showtips').css('top', '225px');
				_$one.focus();
				return;
			} else if (isBlank(password_two)) {
				$setPwdMsg.text("重复密码不能为空");
				$('#showtips').css('top', '225px');
				_$two.focus();
				return;
			} else if (password_one.length < 4 || password_one.length > 16 || !constants.regs.safeboxPwdReg.test(password_one)) {
				$setPwdMsg.text("密码为4-16个字母加数字的组合，请重新输入");
				_$one.val("").focus();
				_$two.val("");
				return;
			} else if (password_one != password_two) {
				$setPwdMsg.text("两次密码输入不一致，请重新输入");
				$('#showtips').css('top', '225px');
				_$two.val("").focus();
				return;
			}

			var params = {
				type: 'post',
				url: '/safeBoxAction!safeBoxSetPwd.action',
				data: {
					password: password_one
				},
				succFun: function(post, data) {
					var obj = data.result.retObj;

					if (obj && obj.status == "0") {
						constants.isSafeBoxUser = true;
						caiyun.ui.iMsgTip.tip("密码设置成功");
					} else {
						if (data.result.message) {
							$setPwdMsg.text(data.result.message);
						}
					}

					safeUiInit();
				},
				errFun: function() {
					safeUiInit();
					$setPwdMsg.text("系统繁忙，请稍后再试！");
				}
			};

			ajax(params);
		};

		//用户修改密码
		var upUserPwd = function(updatePwdWin) {
			var _$one = $("#safebox_upPwd_one");
			var _$two = $("#safebox_upPwd_two");
			var password_one = $.trim(_$one.val());
			var password_two = $.trim(_$two.val());
			if (isBlank(password_one)) {
				$('#up_pwd_tips').css('color', 'red').text("新密码不能为空");
				_$one.focus();
				return;
			} else if (isBlank(password_two)) {
				$('#up_pwd_tips').css('color', 'red').text("重复密码不能为空");
				_$two.focus();
				return;
			} else if (password_one.length < 4 || password_one.length > 16 || !constants.regs.safeboxPwdReg.test(password_one)) {
				$('#up_pwd_tips').css('color', 'red').text("密码为4-16个字母加数字的组合，请重新输入");
				_$one.val("").focus();
				_$two.val("");
				return;
			} else if (password_one != password_two) {
				$('#up_pwd_tips').css('color', 'red').text("两次密码输入不一致，请重新输入");
				_$one.val("").focus();
				_$two.val("");
				return;
			}

			var params = {
				type: 'post',
				url: '/safeBoxAction!safeBoxUpdataPwd.action',
				data: {
					password: password_one
				},
				succFun: function(post, data) {
					var obj = data.result.retObj;

					if (obj && obj.status == "0") {
						caiyun.ui.iMsgTip.tip("新密码设置成功");
						updatePwdWin.close();
					} else {
						$('#up_pwd_tips').text(data.result.message);
					}
				},
				errFun: function() {
					safeUiInit();
					$('#up_pwd_tips').text("系统繁忙，请稍后再试！");
				}
			};

			ajax(params);
		};

		//用户短信密码
		var sendSmsPwd = function() {
			var _mark = false;
			var params = {
				type: 'post',
				url: '/safeBoxAction!safeBoxGetPwd.action',
				succFun: function(post, data) {
					var retCode = data.result.retCode;
					var obj = data.result.retObj;
					if (obj && obj.status == "0") {
						iMsgTip.text("密码发送成功，请注意查收");
						_mark = true;
					} else if (obj && obj.status == "8") {
						iMsgTip.text("使用短信密码的次数超过限制");
					} else if (retCode && retCode == "freeze") {
						iMsgTip.text("密码错误输入超过5次，帐号冻结2小时");
					} else {
						iMsgTip.text(data.result.message);
					}
					if (_mark) {
						var safe_sms = $("#safebox_getpwd");
						var time = 60;
						var timeId = setInterval(function() {
							safe_sms.html('<span>还剩<span>' + --time + "</span> 秒</span>");
						}, 1000);
						safe_sms.unbind('click');

						setTimeout(function() {
							time = 60;
							clearInterval(timeId);
							safe_sms.css({
								"color": "#2276BB"
							}).html("短信密码").unbind('click').bind('click', bindSafeboxsms);
						}, 60000);
					}
				},
				errFun: function() {
					iMsgTip.text("系统繁忙，请稍后再试！", "error");
				}
			};

			ajax(params);
		};

		//用户登录
		var userLogin = function() {
			var _$pwd = $("#safebox_login_pwd");
			var pwd = $.trim(_$pwd.val());

			if (isBlank(pwd)) {
				iMsgTip.text("密码不能为空");
				_$pwd.focus();
				return;
			}

			var params = {
				type: 'post',
				url: '/safeBoxAction!safeBoxLogin.action',
				data: {
					password: pwd
				},
				succFun: function(post, data) {
					var obj = data.result.retObj;
					var retCode = data.result.retCode;

					if (obj && (obj.status == "0" || obj.status == "1")) {
						//成功就进入保险箱目录 消失掉load图标
						safebox.hide();
						window.caiyun.ui.model.fileContent.switchToView(constants.SAFEBOX_FILE_CONTENT_VIEW);
						window.caiyun.operate.enterDir(constants.rootIds.mySafeBox);
						safeboxUpPwd.show().unbind('click').bind('click', function(e) {
							upPwdViewAndEvnListener();
							return util.stopDefault(e);
						});

						constants.safeboxLogined = true;

						//设置插件SESSIONID
						caiyun.ui.webnd.safeBoxSessionId = obj.appSessionID;
						//缓存保险箱的的根目录ID
						caiyun.ui.webnd.safeBoxPathId = window.caiyun.operate.getCurrentPathId();
						return;
					}

					safeUiInit();

					if (obj && obj.pwdValFailNum == "3") {
						iMsgTip.text("已经输错3次，再输错2次保险箱将会被冻结，请使用短信获取登陆密码登录");
					} else if (obj && obj.status == "2") {
						iMsgTip.text("密码输入有误，请重新输入");
					} else if (obj && obj.status == "5") {
						iMsgTip.text("密码错误输入超过5次，帐号冻结2小时");
					} else if (retCode && retCode == "0021") {
						iMsgTip.text("你的短信密码已失效，请重新获取");
					} else {
						if (data.result.message) {
							iMsgTip.text(data.result.message);
						}
					}
				},
				errFun: function() {
					safeUiInit();
					iMsgTip.text("系统繁忙，请稍后再试！");
				}
			};

			ajax(params);
		};

		//创建事件监听
		var pwdEventListener = function() {
			//取消反回到我的全部文件夹下
			$("#safebox_login_cancel").unbind('click').bind('click', function(e) {
				// 切换视图然后再重新加载数据
				fileContent.switchToView(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW);
				caiyun.operate.enterDir(myfileID);
				return util.stopDefault(e);
			});

			//设置密码
			$("#safebox_setPwd_sure").unbind('click').bind('click', function(e) {
				setUserPwd();
				return util.stopDefault(e);
			});

			// 取消设置密码
			$('#safebox_setPwd_cancel').unbind('click').bind('click', function(e) {
				// 切换视图然后再重新加载数据
				fileContent.switchToView(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW);
				caiyun.operate.enterDir(myfileID);
				return util.stopDefault(e);
			});

			//登录
			$("#safebox_login_sure").unbind('click').bind('click', function(e) {
				userLogin();
				return util.stopDefault(e);
			});

			bindSafeboxsms();

			//回车login提交
			$("#safebox_login_pwd").unbind('keydown').bind('keydown', function(e) {
				if (e.keyCode == "13") {
					userLogin();
				}
			});
			//回车setPwd提交
			$("#safebox_pwd_two").unbind('keydown').bind('keydown', function(e) {
				if (e.keyCode == "13") {
					setUserPwd();
				}
			});

		};

		var bindSafeboxsms = function() {
			$("#safebox_getpwd").unbind('click').bind('click', function(e) {
				sendSmsPwd();
				return util.stopDefault(e);
			});
		};

		//修改密码显示与事件监听
		var upPwdViewAndEvnListener = function() {
			var upPwdFrame = msgBox({
				title: "修改密码",
				html: createUpPwd(),
				width: 600,
				height: 330,
				autoClose: false,
				okHandle: function() {
					upUserPwd(upPwdFrame);
				}
			});

			upPwdFrame.show();

			// 创建默认提示的输入框
			$('#safebox_upPwd_one').CyPlaceholder({
				className: 'defaultText'
			});


			// 用于操作失效时，销毁弹出框
			constants.safeboxCloseWin["updataPwdFrame"] = upPwdFrame;
		};


		var safeboxLoginHide = function() {
			//load图标消失
			safebox.hide();
			safeboxUpPwd.hide();
			safeboxPath.hide();
			window.caiyun.operate.clearSetCatalogStack();
		};

		var createUpPwd = function() {
			var html = '<div class="cf-info">' +
				'<table border="0" width="500">' +
				'<tbody><tr>' +
				'<td height="40" align="right" width="141"><span class="cf_s1">设置新密码：</span></td>' +
				'<td width="343"><input title="密码为4-16个字母加数字的组合" placeholder="密码为4-16个字母加数字的组合"  type="password" id="safebox_upPwd_one" class="newfolder input_radius_gray" maxlength="32"></td>' +
				'</tr>' +
				'<tr>' +
				'<td height="40" align="right"><span class="cf_s1">确认新密码：</span></td>' +
				'  <td><input type="password" id="safebox_upPwd_two" class="newfolder input_radius_gray" maxlength="32"></td>' +
				'</tr>' +
				'<tr>' +
				'<td height="60" align="center" colspan="2">' +
				'<div id="up_pwd_tips" class="cf_txt"></div>' +
				'</td>' +
				'</tr>' +
				'</tbody></table>' +
				'</div>';
			return html;
		};

		/*
		 * 判断参数是否为空
		 */
		var isBlank = function(args) {
			if (args == null || args == "" || !args) {
				return true;
			} else {
				return false;
			}
		};

		return {
			enter: init,
			leave: safeboxLoginHide
		};
	})();

})();