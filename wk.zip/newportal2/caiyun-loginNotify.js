/*
 * 登录短信提醒
 */
(function(){
    var get_dina_passwd_success = $('#get_dina_passwd_success');
    var get_dina_passwd_fail = $('#get_dina_passwd_fail'); 
    
    $('#saveConf').bind("click", function(){
       setSvcSetting();        
    });
    
    //读取广告
	$.ajax({
	    type    : 'post', 
	    url     : '../marketplat/getAdvertAction.action?date=' + new Date().getTime(), 
	    dataType: 'json',
	    data    : {advertPos:'2007'}, 
	    success : function(respone){
		    if(respone != null && respone.showMessage == "")
			{
				var res = respone.getAdvertResult;
				if(res != null && res.resultCode == "0")
				{
					var advertImg = res.advertInfos;
					if(advertImg[0] && advertImg[0].linkUrl)
					{
					  $('.ad_box a').attr('href', advertImg[0].linkUrl + '&mssc=' + rcsToken).html(advertImg[0].title);
					}
				}
			}
		},
           error   : null
	});
    
    function setSvcSetting(){
        var notifyType = $(":radio:checked").val();
        var data = {loginNotify:notifyType};
        $.ajax({
            url:"svcSetting!setSvcSetting.action", 
            data:data, 
            dataType:"json", 
            type:"POST", 
            success:function (res) {
                if (res.message != "")
                {
                //展示错误信息
                get_dina_passwd_fail.find('p').html('系统繁忙，请稍后再试！').end().show();
                setTimeout(function(){
                    get_dina_passwd_success.hide();
                }, 2000);
                }
                else{
                //展示错误信息
                get_dina_passwd_success.find('p').html('设置成功').end().show();
                setTimeout(function(){
                    get_dina_passwd_success.hide();
                }, 2000);
                }
            }
        });
    };
    
    function getSvcSetting(){
    
        $.ajax({
            url:"svcSetting!toGetSvcSetting.action", 
            dataType:"json", 
            type:"POST", 
            success:function (res) {
                if (res.message != "")
                {
                  //展示错误信息
                get_dina_passwd_fail.find('p').html('系统繁忙，请稍后再试！').end().show();
                setTimeout(function(){
                    get_dina_passwd_success.hide();
                }, 2000);
                }
                else {
                  $('[name="remind"]:radio').each(function() {
                    if (this.value == res.loginNotify)
                    {
                        this.checked = true;
                    }
                  }); 
                }
            }
        });
    };
    
    $().ready(function(){
        var heights = Math.max(document.documentElement.clientHeight,document.body.clientHeight)-150 + "px";
        $("#set_notifiacation").height(heights);
        $("#notifyResultDiv").height(heights);
        getSvcSetting();
       /* cySetDiskSize();*/
    });
    
 })();