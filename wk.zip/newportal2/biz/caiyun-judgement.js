﻿/**
 * 判断工具集合 
 */
(function(){
	var judgement = window.caiyun.judgement;
	var constants = window.caiyun.constants;
	var validate = caiyun.util.Validate;
	
	// 是否同步目录
	judgement.isSyncCatalog = function(catalog){
		catalog = catalog || {}; 
		return  catalog.catalogType == 7;
	};
	// 是否固定目录
	judgement.isFixedCatalog = function(catalog){
		return  catalog.isFixedDir == 1;
	};
	// 是否保险箱目录
	judgement.isSafeBox = function(){
		return isInCatalogStack(constants.rootIds.mySafeBox) || isInCatalogStack(constants.rootIds.mySafeBoxWithUserID);
	};
	
	// 是否是分类文件目录type:caiyun.constants.fileTypes
	judgement.isFileTyped = function(type){
		return isInCatalogStack(constants.catalogIDPrefix.byType + type);
	};
	
	// 指定目录是否在当前目录层级中
	judgement.isInCurrentCatalogs = function(catalogId){
		return isInCatalogStack(catalogId);
	};
	
	// 是否在搜索结果的根目录下
	judgement.isSearchCatalog = function(){
		var catalogStack = window.caiyun.operate.getCatalogStack();
		if(catalogStack){
			return catalogStack[0].catalogID == constants.catalogIDPrefix.bySearch;
		}
		return false;
	};
	
	var isInCatalogStack = function(catalogId){
		if(window.caiyun.operate.getCatalogStack){//判断对象是否存在
			var catalogStack = window.caiyun.operate.getCatalogStack();
			if(!catalogStack){
				return false;
			}
			for (var i in catalogStack) {
				if(!catalogStack[i]){
					continue;
				}
				if (catalogStack[i].catalogID == catalogId) {
					return true;
				}
			}
		}
		return false;
	};
	
	/**
	 * 文件名是否合法
	 * 
	 * 检查通过返回空，如果检查不通过返回对应的错误码
	 */ 
	judgement.isValidFolderName = function(folderName){
		// 文件名是否为空
		if(!$.trim(folderName)){
			return 'FOLDER_NAME_EMPTY';
		}
		// 文件名是否超长
		if(folderName.length > 32){
			return 'FOLDER_NAME_TOO_LONG';
		}
		// 文件名是否含有特殊字符
		if(validate.isContainIllegalFolder(folderName)){
			return 'FOLDER_NAME_INVALID_CHARACTER';
		}
		
		return null;
	};
	
	/**
	 * 文件名是否合法
	 * 
	 * 检查通过返回空，如果检查不通过返回对应的错误码
	 */ 
	judgement.isValidFileName = function(fileName){
		// 文件名是否为空
		if(!$.trim(fileName)){
			return 'FILE_NAME_EMPTY';
		}
		// 文件名是否超长
		if(fileName.length > 32){
			return 'FILE_NAME_TOO_LONG';
		}
		// 文件名不能以.开头
		if(fileName.indexOf('.') == 0){
			return 'FILE_NAME_STARTBY_POINT';			
		}
		// 文件名是否含有特殊字符
		if(validate.isContainIllegalFolder(fileName)){
			return 'FILE_NAME_INVALID_CHARACTER';
		}
		
		return null;
	};
	
	/**
	 * 是否视频
	 */
	judgement.isVideo = function(content){
		if(!content){
			return false;
		}
		return content.contentType  == 3;
	};
	
	/**
	 * 是否图片
	 */
	judgement.isPicture = function(content){
		if(!content){
			return false;
		}
		return content.contentType == 1;
	};
	
	/**
	 * 是否音频
	 */
	judgement.isAudio = function(content){
		if(!content){
			return false;
		}
		return content.contentType == 2;
	};
	
	/**
	 * 是否转码完成
	 */
	judgement.isTransfered = function(content){
		return transferstate  == 3;
	};
	
	/**
	 * 是否在类型查询下
	 */
	judgement.isInQueryByType = function(catalogStack){
		var stack = catalogStack || window.caiyun.operate.getCatalogStack();
		return stack[0].catalogID.indexOf(window.caiyun.constants.catalogIDPrefix.byType) == 0;
	};
	
	/**
	 * 是否在手机软件查询下
	 */
	judgement.isInQueryByPhoneOS = function(catalogStack){
		var stack = catalogStack || window.caiyun.operate.getCatalogStack();
		return stack[0].catalogID.indexOf(window.caiyun.constants.catalogIDPrefix.byPhoneOS) == 0;
	};
	
	/**
	 * 判断是否在我的文件下
	 */
	judgement.isInMyFile = function(catalogStack){
		var stack = catalogStack || window.caiyun.operate.getCatalogStack();
		
		return stack[0].catalogID == window.caiyun.constants.rootIds['myFolder'] || stack[0].catalogID == window.caiyun.constants.rootIds.myFolderWithUserID;
	};
	
	/**
	 * 判断是否在图片目录下
	 */
	judgement.isInPicture = function(catalogStack){
		var constants = window.caiyun.constants;
		return catalogStack[0].catalogID == constants.catalogIDPrefix.byType + constants.fileTypes.picture;
	};
	
	/**
	 * 判断是否在音乐目录下
	 */
	judgement.isInAudio = function(catalogStack){
		var constants = window.caiyun.constants;
		return catalogStack[0].catalogID == constants.catalogIDPrefix.byType + constants.fileTypes.audio;
	};
	
	/**
	 * 判断是否在文档目录下
	 */
	judgement.isInDocument = function(catalogStack){
		var constants = window.caiyun.constants;
		return catalogStack[0].catalogID == constants.catalogIDPrefix.byType + constants.fileTypes.document;
	};
	
	/**
	 * 判断是否在视频目录下
	 */
	judgement.isInVideo = function(catalogStack){
		var constants = window.caiyun.constants;
		return catalogStack[0].catalogID == constants.catalogIDPrefix.byType + constants.fileTypes.video;
	};
	
	/**
	 * 判断是否在手机软件目录下
	 */
	judgement.isInMobileSoftware = function(catalogStack){
		var constants = window.caiyun.constants;
		return catalogStack[0].catalogID == constants.catalogIDPrefix.byType + constants.fileTypes.mobileSoftware;
	};
	
	/**
	 * 判断是否在我收到的文件一级目录下
	 */
	judgement.isReceviteDir = function(catalogStack){
		var len = 0;
		var constants = window.caiyun.constants;
	    if(catalogStack){
			len = catalogStack.length;
		}
		//timeline引用后报错，修改--add by huangyonghao
		if(!catalogStack[len-1])return false;
		return catalogStack[len-1].catalogID == constants.cannotModifyIDs.root_receiveShare;
	};
	
	/**
	 * 目录是否不可移动、复制、重命名
	 */
	judgement.notModify = function(catalog){
		if(!catalog){
			return false;
		}
		for(var i in constants.cannotModifyIDs){
			if(catalog.catalogID == constants.cannotModifyIDs[i]||catalog.shareType=="4"){//是否是企业分享文件夹
				return true;
			}
		}
		return false;
	};
	
	/**
	 * 判断文档是否可以预览
	 */
	judgement.isDocPrev = function(suffix){
		if(!suffix){
			return false;
		}
		for(var i = 0 ,length = constants.canPrevSuffix.length ; i<length ; i++){
			if(suffix.toUpperCase() == constants.canPrevSuffix[i]){
				return true;
			}
		}
		return false;
	};
	
	/**
	 * 判断文档是否可以编辑
	 */
	judgement.isDocEdit = function(suffix){
		if(!suffix){
			return false;
		}
		for(var i = 0 ,length = constants.canEditSuffix.length; i<length ; i++){
			if(suffix.toUpperCase()  == constants.canEditSuffix[i]){
				return true;
			}
		}
		return false;
	};
	
	/**
	 * 判断图片是否可以冲印
	 */
	 judgement.isPrintImage = function(suffix){
	 	if(!suffix){
			return false;
		}
		
		return suffix.toUpperCase() == constants.canPrintImageSuffix ? true : false ;
	 };
	 
	 /**
	  * 获取点对点共享全路径
	  */
	 judgement.getPath = function(catalogStack){
	 	var path = [];
	 	var stack = catalogStack || window.caiyun.operate.getCatalogStack();
		$.each(stack,function(i){
			if( i!= 1){
				path.push(stack[i].catalogID);
			}
		});
		return path.join('/');
	 };

	/**
	 * 获取公共账号路径
	 */
	judgement.getPathInPublishDir = function(parentCatalogId,targetId) {
		var path = [];
		var isGobal = parentCatalogId.indexOf(constants.rootIds.myFolder) === -1;
		var stack = window.caiyun.operate.getCatalogStack();
		$.each(stack, function(i) {
			if (i !== 1  ) {
				// 公开目录下的指定分享，忽略公共文件夹
				if(this.shareType === '5' && !isGobal){
					
				}else{
					path.push(stack[i].catalogID);
				}
			}
		});
		// 如果指定分享需要补上目标ID到path上
		if(targetId && !isGobal){
			path.push(targetId);
		}
		return path.join('/');
	};

    /**
	  * 获取当前位置全路径
	  */
	 judgement.normalgetPath = function(catalogStack){
	 	var path = [];
	 	var stack = catalogStack || window.caiyun.operate.getCatalogStack();
		$.each(stack,function(i){		
				path.push(stack[i].catalogID);			
		});
		return path.toString().replace(/,/g,'/');
	 };
    /**
     * 获取企业彩云空间（企业管理员）path路径
     */
    judgement.getPathForEnterprise = function(catalogStack){
        var path = [];
        var stack = catalogStack || window.caiyun.operate.getCatalogStack();
        return stack[stack.length-1].path;
    };
	 
	 /**
	  * 判断该文件夹是否为"收到的分享"
	  */
	 judgement.isReceiveShareFolder = function(contentID){
	 	if(contentID){
	 		return  contentID.indexOf("00019700101000000067") != -1;
	 	}else{
	 		return false;
	 	}
	 };

	 /**
	  * 是否为企业文件夹及以下路径
	  * */
	 judgement.isEnterprisePath = function(){
		 var enterFlag = false;
		 var stack = caiyun.operate.getCatalogStack();
         if(stack){
         	for(var t = 0; t < stack.length; t ++){
         		if(stack[t].hasOwnProperty("shareType") && stack[t].shareType == "4"){
         			enterFlag = true;
         			break;
         		}
         	}
         }
         return enterFlag;
	 };

     //获取企业彩云用户权限
	 judgement.getEnterpriseAuth = function(){
        var auth = "";
        if(judgement.isEnterprisePath())
        {
            if(entryPriseInfoData._isAdmin){
                auth = caiyun.constants.enterpriseAuth.admin;
            }else{
                switch (enterpriseAuth){
                    case 0:
                        auth = caiyun.constants.enterpriseAuth.admin;
                        break;
                    case 4:
                        auth = caiyun.constants.enterpriseAuth.upload;
                        break;
                    case 5:
                        auth = caiyun.constants.enterpriseAuth.download;
                        break;
                    case 6:
                        auth = caiyun.constants.enterpriseAuth.downloadAndUpload;
                        break;
                    case 7:
                        auth = caiyun.constants.enterpriseAuth.view;
                        break;
                    case 8:
                        auth = caiyun.constants.enterpriseAuth.edit;
                        break;
                }
            }
        }
        return auth;
     };

 /**
     * 判断是否是系统默认文件夹
     */

     judgement.isSystemItem=function(id){
        var cannotModifyIDs = caiyun.constants.cannotModifyIDs;
        var publisherAccountConstants = caiyun.constants.publisherAccountConstants;
        var result=false;
         switch (id) {
                    // 图片
                    case cannotModifyIDs.root_phonePhoto:
                    	result=true;
                    	break;
                    case cannotModifyIDs.root_syncGalary:
                    	result=true;
                    	break;
                    // 视频
                    case cannotModifyIDs.root_phoneVideo:
                    	result=true;
                    	break;
                    case cannotModifyIDs.root_syncVideo:
                    	result=true;
                    	break;
                    // 文档
                    case cannotModifyIDs.root_phoneDoc:
                    	result=true;
                    	break;
                    case cannotModifyIDs.root_syncMobile:
                    	result=true;
                    	break;
                    // 收到的分享
                    case cannotModifyIDs.root_receiveShare:
                        result=true;
                    	break;
                   	// 公共账号
                    case publisherAccountConstants.publisherDir:
                    	 result=true;
                    	break;
                    // 草稿箱
                    case publisherAccountConstants.draftBox:
                    	 result=true;
                    	break;
                }
                return result;
        
        
        };

    /**
     * 获取当前进入的企业的企业id
     */
    judgement.getCurrentEnterpriseID = function(){
        var stack = caiyun.operate.getCatalogStack();
        var eid = '';
        var accId = '';
        if(stack){
            accId = stack[stack.length-1].sharer?stack[stack.length-1].sharer:stack[stack.length-1].owner;
        }
        eid = entryPriseInfoData.getEidByAcc(accId);
        return eid;
    }

    /**
     * 是否在公共账号的公开目录下
     */
    judgement.isInPublisherDir = function(path){
    	if(!path){
    		return judgement.isInCurrentCatalogs(constants.publisherAccountConstants.publisherDir);	
    	}else{
    		if(typeof path === "string"){
    			return path.indexOf(constants.publisherAccountConstants.publisherDir) !== -1;
    		}else if(path instanceof Array){
    			return path.join().indexOf(constants.publisherAccountConstants.publisherDir) !== -1;
    		}
    	}
    	return false;
    }

    /**
     * 公开目录下允许的操作
     */
    judgement.canExecuteInPublisherDir = function(operation,catalogs,contents){
    	switch (operation) {
    		case 'open' : return true;
    		case 'play' : return true;
    		case 'browse' : return true;
    		case 'download' : return true;
    		case 'delete' : return true;
    		default : return false;
    	}
    }

    /**
     * 可以对公开目录允许的操作
     */
     judgement.canExecuteWithPublisherDir  = function(operation,catalogs,contents){
    	switch (operation) {
    		case 'open': return true;
    		default : return false;
    	}
    }

    /**
     * 是否在收到的公开目录下
     */
    judgement.isInReceivedPublishDir = function(){
    	var stack = caiyun.operate.getCatalogStack();
    	var i = 0,length = stack.length;
    	for (; i<length ; i++){
    		if(stack[i].shareType === '5'){
    			return true;
    		}
    	}
    	return false;
    }

    /**
     * 可以对收到的公开目录下执行的操作
     */
     judgement.canExecuteInReceivedPublishDir = function(operation,catalogs,contents){
     	var stack = caiyun.operate.getCatalogStack();
		switch (operation) {
			case 'open':
				return true;
			case 'play':
				return true;
			case 'browse':
				return true;
			// 公开目录下的文件只支持单个下载
			case 'download':
				return stack.length !== 3 || catalogs.length + contents.length === 1;
			case 'reCopy':
				return stack.length !== 3 || catalogs.length + contents.length === 1;
			default:
				return false;
		}
     }

     /**
      * 是否在草稿箱目录下
      */
     judgement.isInDraftBox = function(){
     	return judgement.isInCurrentCatalogs(constants.publisherAccountConstants.draftBox);	
     }

     /**
      * 草稿箱目录下允许的操作
      */
      judgement.canExecuteInDraftBox = function(operation){
     	switch (operation) {
			case 'share':
				return false;
			case 'link':
				return false;
			default:
				return true;
		}
     }

     /**
      * 可以对草稿箱执行的操作
      **/
     judgement.canExecuteWithDraftBox = function(operation){
     	switch (operation) {
			case 'open': return true;
    		default : return false;
		}
     }
}
)();