// 管理文件的js对象
// 定义命名空间
caiyun.biz.offline_downlod = {};

(function(){
    var offline_downlod = caiyun.biz.offline_downlod;
    var ajax = caiyun.util.caiyunAjax;
    
    /**
     * 调用后台添加离线下载链接（../offlineDownload!addOfflineTask.action）
     *
     * @param {Object} params ajax 请求参数
     * params{
     *       type     : '', get/post
     *       url      : '', 请求URL
     *       dataType : '', json或其他
     *       data     : {}, 参数
     *       succFun  : function(){}, 成功回调函数
     *       errFun   : function(){}  失败回调函数
     *    }
     *
     * @param {Object} callback 执行ajax请求过程中的回调函数
     */
    offline_downlod.addOfflineTask = function(params, callback){
        ajax.ajaxRequest(params);
        if (typeof(callback) == "function") {
            callback.call();
        }
    }
    
    /**
     * 查询后台离线链接显示列表（../offlineDownload!queryOfflineInfo.action）
     * @param {Object} params ajax请求参数
     * params{
     *       type     : '', get/post
     *       url      : '', 请求URL
     *       dataType : '', json或其他
     *       data     : {}, 参数
     *       succFun  : function(){}, 成功回调函数
     *       errFun   : function(){}  失败回调函数
     *    }
     * @param {Object} callbacks 回调函数
     */
    offline_downlod.queryOfflineInfo = function(params, callback){
        ajax.ajaxRequest(params);
        if (typeof(callback) == "function") {
            callback.call();
        }
    }
    
    /**
     * 对现在链接编辑操作 报错【重试，删除，取消下载】（../offlineDownload!updateOfflineTask.action）
     * @param {Object} params
     * params{
     *       type     : '', get/post
     *       url      : '', 请求URL
     *       dataType : '', json或其他
     *       data     : {}, 参数
     *       succFun  : function(){}, 成功回调函数
     *       errFun   : function(){}  失败回调函数
     *    }
     * @param {Object} callbacks 回调函数
     */
    offline_downlod.updateOfflineTask = function(params, callback){
        ajax.ajaxRequest(params);
        if (typeof(callback) == "function") {
            callback.call();
        }
    }
    
    
})();
