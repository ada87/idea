caiyun.biz.versionManager = {};

// 好习惯不要忘
(function(){
   var versionManager = caiyun.biz.versionManager;
   var ajax = caiyun.util.caiyunAjax;
   
      /**
	  * 获取文件历史版本详细信息
	  * 
	  * 参数列表
	  * params{
	  * 	contentID				文件ID
	  * }
	  * 
	  * 结果
	  * showMessage 错误信息
	  * versionInfoObj{ 
	  * 	resultcode  返回码，0表示正常处理，其余表示后台处理错误
	  * }
	  * 
	  * 文件信息的描述请见OSE文档versionInfo
	  */
	 versionManager.getVersionList = function(params,successCallback,errorCallback){
	 	var baseParams = {
            type    : 'post', 
            url     : './getFileVerInfo.action', 
            dataType: 'json', 
            succFun : successCallback,
            errFun  : errorCallback,
			hideLoading : true
        };
        baseParams.data = params;        
        ajax.ajaxRequest(baseParams);
	 	
	 };	
	 
	 /**
	  * 删除文件历史版本详细信息
	  * 
	  * 参数列表
	  * params{
	  * 	vision				版本ID
	  *     contentID           文件ID
	  * }
	  * 
	  * 结果
	  * showMessage 错误信息
	  * resultcodeObj{ 
	  * 	resultcode  返回码，0表示正常处理，其余表示后台处理错误
	  * }
	  * 
	  * 文件信息的描述请见OSE文档resultcode
	  */
	 versionManager.histvisionClear = function(params,successCallback,errorCallback){
	 	var baseParams = {
            type    : 'post', 
            url     : '../deleteFileVersion.action', 
            dataType: 'json', 
            succFun : successCallback,
            errFun  : errorCallback,
			hideLoading : true
        };
        baseParams.data = params;        
        ajax.ajaxRequest(baseParams);
	 	
	 };	
	 
	 	 /**
	  * 恢复文件历史版本详细信息
	  * 
	  * 参数列表
	  * params{
	  * 	vision				版本ID
	  *     contentID           文件ID
	  * }
	  * 
	  * 结果
	  * showMessage 错误信息
	  * resultcodeObj{ 
	  * 	resultcode  返回码，0表示正常处理，其余表示后台处理错误
	  * }
	  * 
	  * 文件信息的描述请见OSE文档resultcode
	  */
	 versionManager.histvisionRecv = function(params,successCallback,errorCallback){
	 	var baseParams = {
            type    : 'post', 
            url     : '../recoverFileVersion.action', 
            dataType: 'json', 
            succFun : successCallback,
            errFun  : errorCallback,
			hideLoading : true
        };
        baseParams.data = params;        
        ajax.ajaxRequest(baseParams);
	 	
	 };	
 
})();
