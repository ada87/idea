/**
 * 使用时注意先要赋值
 * _all,_allLinkers,_allGroups
 */
var linkData ={
	_all : {},//所有组和联系人数据
	_allLinkers : {},//联系人所有数据
    _allGroups : {},//联系人所有组数据
    _isLoadSucc : false,//加载数据是否成功
    _isOpenCytxl : null,//是否开通彩云通讯录
	
	init : function(callBack){
		linkData.getAll(callBack);
	},
	//获取所有组和联系人数据
	getAll : function(callBack){
		var baseParams = {
            type    : 'get', 
            url     : '../cytxl/allgroupitems.action', 
            dataType: 'json', 
            succFun :  function(r,json){
				if(json){
					if(json.message == ""){
						var AllGroups = json.groups;
						linkData._all = AllGroups;
						for(var i = 0;i < AllGroups.length; i++){
							var group = AllGroups[i];
							linkData._allGroups[group.groupId] = group;
							for(var j = 0;j < group.list.length; j++){
								var list = $.extend(group.list[j],{groupId:group.groupId});
								linkData._allLinkers[list.contactId] = list;
							}
						}
						linkData._isLoadSucc = true;
						linkData._isOpenCytxl = true;
					}else if(json.message == "error"){
						linkData._isOpenCytxl = false;
						linkData._isLoadSucc = false;
					}
				}
				if(typeof(callBack) == "function"){
					callBack.call();
				}
			},
            errFun  : function(){
				//caiyun.ui.iMsgTip.tip("系统繁忙,请稍后再试!", "error");
				linkData._isLoadSucc = false;
				linkData_isOpenCytxl = false;
				if(typeof(callBack) == "function"){
					callBack.call();
				}
			},
			hideLoading : true
        };
        window.caiyun.util.caiyunAjax.ajaxRequest(baseParams);
	},
	/**
	 * 简单搜索联系人
	 * @param {Object} str
	 * @param {Object} number
	 */
    searchLinkers: function(str, number){
        var tmpArray = null;
        tmpArray = linkData._allLinkers;
        str = str.toLowerCase(); //转成小写
        str = $.trim(str); //去掉开头和结尾的空格
        var arr = [];
        var count = 0;
        if (number == undefined){
            number = 99;
        }
        for (var i in tmpArray){
            if(count >= number){break;}
            var link = tmpArray[i];
            var pys = link.py.split(" ");
            var connpy = "";
			var moblie = "";
			if(link.mobile){
				moblie = link.mobile[0];
			}
            $.each(pys, function(j, onepy){
                connpy = connpy + onepy;
            });
            if(link.name != null && moblie != null)
            {
            	if (link.name.indexOf(str) != -1
	             	|| moblie.indexOf(str) != -1
	             		|| connpy.indexOf(str) != -1
	             			|| linkData.checkpy(pys, str)) {
	                arr.push(link);
	                count++;
            	}
            }
            
        }
        return arr;
        
    },
    
    
    /**
	 * 通过电话号码完全匹配联系人
	 * @param {Object} number
	 */
    searchLinkersMatch: function(num){
        var tmpArray = null;
        tmpArray = linkData._allLinkers;
        var seachObj = null;
        var count = 0;
        if (num == undefined){
            return false;
        }
        for (var i in tmpArray){
            
            var link = tmpArray[i];
			var moblie = "";
			if(link.mobile){
				moblie = link.mobile[0];
			}
            if(link.name != null && moblie != null)
            {
            	if (linkData.replace86(num) == linkData.replace86(moblie)) 
            	{
	                seachObj = link;
	                break;
            	}
            }
            
        }
        return seachObj;
        
    },
    
    
    
	/**
     * 拼音的首字母是大写，替小写字母
     * @param {Object} ary
     * @param {Object} str
     */
    checkpy: function(ary, str){
        var length = str.length;
        if (ary.length < length){return false;}
        var ispp = true;
        for (var i = 0; i < length; i++){
            var indexStr = str.charAt(i);
            if (ary[i].charAt(0) != indexStr){
                ispp = false;
                break;
            }
        }
        return ispp;
    },
	/**
     * 替换电话号码前缀+86 86
     * chenjunwei	
     */
    replace86:function(mobile){
    	mobile = mobile+'';
    	if(mobile.indexOf('86')!=-1&&mobile.substring(0,2)=='86'){
    		return mobile.substring(2,mobile.length);
    	}
    	if(mobile.indexOf('+86')!=-1&&mobile.substring(0,3)=='+86'){
    		return mobile.substring(3,mobile.length);
    	}
		return mobile;	
    },
    
    subStringByLen:function (str,len){
	    if (str ==""){
	        return "";
	    }
	    else if(str.length <= len){
	        return str;
	    }
	    else
	    {
	        return str.substring(0,len) + '...';
	    }
	},
	
	getNameForPhone: function(m){
        var temp_name = m;
        if(m == null || m == "")
        {
        	return "";
        }
        var linker_obj = linkData.searchLinkers(linkData.replace86(m));
        
        if(linker_obj != undefined && linker_obj.length > 0)
        {
        	var name = linker_obj[0].name;
        	if(name != null && name != "")
        	{
        		temp_name = name;
        	}
        }
        return temp_name;
    },
    
    //返回号码对应联系人名字（去86）
    getNameForPhoneMatch: function(m){
        var temp_name = m;
        if(m == null || m == "")
        {
        	return "";
        }
        var linker_obj = linkData.searchLinkersMatch(m);
        if(linker_obj != null && linker_obj.name != null)
        {
        	temp_name = linker_obj.name;
        }
        return temp_name;
    },
    
		//判断是否是彩云通讯录号码
	isCytxlNum : function(num,cytxlData){
		var temp_data = cytxlData||linkData._allLinkers
		var flag = false;
		if(temp_data){
			for (var i in temp_data){
				var mobile = "";
				if(temp_data[i].mobile){
					mobile = linkData.replace86(temp_data[i].mobile[0]);
				}
				if(num == mobile)
				{
					flag = true;
					break;
				}
			}
			return flag;
		}else
		{
			return false;
		}
	}
}
