
/**
 * 企业彩云
 */
caiyun.biz.enterprise = {};
(function(){
    var ajax = caiyun.util.caiyunAjax;
    var enterprise = caiyun.biz.enterprise;

    /**
     * 查询企业成员
     */
    enterprise.getEnterpriseMember = function(params,getEnterpriseMemberSuccessCallBack,getEnterpriseMemberFailCallBack){
        var baseParams = {
            type    : 'post',
            data    :  params ,
            url     : '../enterprise/getJsonEnterpriseMember.action',
            dataType: 'json',
            hideLoading : true,
            succFun : getEnterpriseMemberSuccessCallBack,
            errFun  : getEnterpriseMemberFailCallBack
        };
        return ajax.ajaxRequest(baseParams);
    };

    /**
     *查询企业空间入口目录
     */
    enterprise.qryEntEntry = function(params,qryEntEntrySuccessCallBack,qryEntEntryFailCallBack){
        var baseParams = {
            type    : 'post',
            data    :  params ,
            url     : '../enterprise/queryEntEntry.action',
            dataType: 'json',
            succFun : qryEntEntrySuccessCallBack,
            errFun  : qryEntEntryFailCallBack
        };
         return ajax.ajaxRequest(baseParams);
    };
    }
    )();

