;(function(){
	 var util = window.caiyun.util;
	 var ajax = util.caiyunAjax.ajaxRequest;
	 var constants = window.caiyun.constants;
	 var ui = window.caiyun.ui;
	 var iMsgTip = ui.iMsgTip;
	 var msgBox = ui.msgBox;
	 var judgement = window.caiyun.judgement;
	 
	 window.caiyun.ui.model.safebox = (function(){
	 	var isFirst = true;        
	 	var safebox = $('#safebox');
	 	var safeboxUpPwd = $('#safeboxUpPwd');
	 	var safeboxPath = $('#safe_box_path');
	 	var tool = $('.right-main-one');
		
		var init = function(){
			var operate = window.caiyun.operate;
			operate.clearSetCatalogStack({ 
				catalogName:constants.rootIdsName[constants.rootIds.mySafeBox],  
				catalogID:constants.rootIds.mySafeBox
				});
			safeboxPath.show();
			isFirst = true;
			safeUiInit();
	    };
	    
	    //根据用户判断判断来绝定显示界面
	    var safeUiInit =  function(){
	    	var str = createPwdAndLoginUi();
	    	//插入数据div中
	    	safebox.html(str).show();      
	    	pwdEventListener();
	    	
	    	if(constants.isSafeBoxUser){
	    		$("#safebox_setPwd").hide();
	    		$("#safebox_login").show();
	    	}else{
	    		$("#safebox_login").hide();
	    		$("#safebox_setPwd").show();
	    	}
	    	
	    };
	    
	    //用户设置初始密码
	    var setUserPwd =  function(){
	    	var _$one = $("#safebox_pwd_one");
	    	var _$two = $("#safebox_pwd_two");
	    	var password_one = $.trim(_$one.val());
	    	var password_two = $.trim(_$two.val());
	    	
	    	if(isBlank(password_one)){
	    		iMsgTip.tip("密码不能为空", "error"); 
	    		$('#showtips').css('top','225px');
	    		_$one.focus();
	    		return;  
	    	}else if(isBlank(password_two)){
	    		iMsgTip.tip("重复密码不能为空", "error"); 
	    		$('#showtips').css('top','225px');
	    		_$two.focus();
	    		return;  
	    	}else if(password_one.length < 4 || password_one.length > 16 || !constants.regs.safeboxPwdReg.test(password_one)){
	    		iMsgTip.tip("密码为长度不能小于4个字符且大于16个字符的数字加字母组合，请重新输入", "error",5); 
	    		_$one.val("").focus();
	    		_$two.val("");
	    		return; 
	    	}else if(password_one != password_two){
	    		iMsgTip.tip("两次密码输入不一致，请重新输入", "error"); 
	    		$('#showtips').css('top','225px');
	    		_$two.val("").focus();
	    		return;  
	    	}
	    	//等待load图片显示，清空原有内容
	    	safebox.html('');
	    	
	    	var params = {
		    	type    : 'post', 
	            url     : '/safeBoxAction!safeBoxSetPwd.action', 
	            data    : {password:password_one}, 
	            succFun : function(post,data){
	            	            var obj = data.result.retObj;
	            	            
				            	if(obj && obj.status =="0"){
				            	    constants.isSafeBoxUser = true;
				            	}else{
				            		iMsgTip.tip(data.result.message, "error");
				            	}
				            	
				            	safeUiInit();
				          },
	            errFun  : function(){
	            	          safeUiInit();
	            	          iMsgTip.tip("系统繁忙，请稍后再试！", "error");   
	                      }
	    	}

	    	ajax(params);
	    };
	    
	     //用户修改密码
	    var upUserPwd =  function(updatePwdWin){
	    	var _$one = $("#safebox_upPwd_one");
	    	var _$two = $("#safebox_upPwd_two");
	    	var password_one = $.trim(_$one.val());
	    	var password_two = $.trim(_$two.val());
	    	
	    	if(isBlank(password_one)){
	    		iMsgTip.tip("新密码不能为空", "error"); 
	    		_$one.focus();
	    		return;  
	    	}else if(isBlank(password_two)){
	    		iMsgTip.tip("重复密码不能为空", "error"); 
	    		_$two.focus();
	    		return;  
	    	}else if(password_one.length < 4 || password_one.length > 16 || !constants.regs.safeboxPwdReg.test(password_one)){
	    		iMsgTip.tip("密码为长度不能小于4个字符且大于16个字符的数字加字母组合，请重新输入", "error",5); 
	    		_$one.val("").focus();
	    		_$two.val("");
	    		return; 
	    	}else if(password_one != password_two){
	    		iMsgTip.tip("两次密码输入不一致，请重新输入", "error"); 
	    		_$one.val("").focus();
	    		_$two.val("");
	    		return;  
	    	}
	    	
	    	var params = {
		    	type    : 'post', 
	            url     : '/safeBoxAction!safeBoxUpdataPwd.action', 
	            data    : {password:password_one}, 
	            succFun : function(post,data){
	            	            var obj = data.result.retObj;
	            	            
				            	if(obj && obj.status =="0"){
				            	    iMsgTip.tip("新密码设置成功");
				            	    updatePwdWin.close();
				            	}else{
				            		iMsgTip.tip(data.result.message, "error");
				            	}
				          },
	            errFun  : function(){
	            	          safeUiInit();
	            	          iMsgTip.tip("系统繁忙，请稍后再试！", "error");   
	                      }
	    	}

	    	ajax(params);
	    };
	    
	    //用户短信密码
	    var sendSmsPwd = function(){
	    	var _mark = false;
	    	var params = {
		    	type    : 'post', 
	            url     : '/safeBoxAction!safeBoxGetPwd.action', 
	            succFun : function(post,data){
	            	           var retCode = data.result.retCode
	            	           var obj = data.result.retObj;
				               if(obj && obj.status =="0"){
				            		iMsgTip.tip("密码发送成功，请注意查收");
				            		_mark = true;
				            	}else if(obj && obj.status =="8"){
				            		iMsgTip.tip("使用短信密码的次数超过限制", "error");
				            	}else if(retCode && retCode == "freeze"){
				            		iMsgTip.tip("密码错误输入超过5次，帐号冻结2小时", "error");
				            	}else{
				            		iMsgTip.tip(data.result.message, "error");   
				            	}
				            	
								if(_mark){
									    var safe_sms = $("#safebox_getpwd");
										var time = 60;
										var timeId = setInterval(function(){
											safe_sms.html('<span>还剩<span>'+ --time + "</span> 秒</span>");
										},1000)
										safe_sms.unbind('click');
										
										setTimeout(function(){
											time = 60;
											clearInterval(timeId);
											safe_sms.css({"color":"#2276BB"}).html("短信密码").unbind('click').bind('click',bindSafeboxsms);
										},60000);
								}
				          },
	            errFun  : function(){
	            	          iMsgTip.tip("系统繁忙，请稍后再试！", "error"); 
	                      }
	    	}
	    	
	    	ajax(params);
	    };
	    
	    //用户登录
	    var userLogin = function(){
	    	var _$pwd = $("#safebox_login_pwd");
	    	var pwd = $.trim(_$pwd.val());
	    	
	    	if(isBlank(pwd)){
	    		iMsgTip.tip("密码不能为空", "error"); 
	    		_$pwd.focus();
	    		return;  
	    	}
	    	
	    	var params = {
		    	type    : 'post', 
	            url     : '/safeBoxAction!safeBoxLogin.action', 
	            data    : {password:pwd},
	            succFun : function(post,data){
	                           var obj = data.result.retObj;
	                           var retCode = data.result.retCode
	                           
	            	           if(obj && (obj.status =="0" || obj.status =="1")){
	            	           	  //成功就进入保险箱目录 消失掉load图标
	            	           	  safebox.hide();
	            	           	  window.caiyun.ui.model.fileContent.switchToView(constants.SAFEBOX_FILE_CONTENT_VIEW);
	            	           	  window.caiyun.operate.enterDir(constants.rootIds.mySafeBox);
	            	           	  safeboxUpPwd.show().unbind('click').bind('click',function(e){
							    	    upPwdViewAndEvnListener();
										return util.stopDefault(e);
								  });
	            	           	  return;
	            	           }
	            	           
	            	           safeUiInit();
	            	           
	            	           if(obj && obj.pwdValFailNum == "3"){
	            	             	iMsgTip.tip("已经输错3次，再输错2次保险箱将会被冻结，请使用短信获取登陆密码登录","error");
	            	           }else if(obj && obj.status =="2"){
	            	           		iMsgTip.tip("密码输入有误，请重新输入", "error");
	            	           }else if(obj && obj.status =="5"){
	            	           		iMsgTip.tip("密码错误输入超过5次，帐号冻结2小时", "error");
	            	           }else if(retCode && retCode == "0021"){
	            	             	iMsgTip.tip("你的短信密码已失效，请重新获取", "error");
	            	           }else{
				            		iMsgTip.tip(data.result.message, "error");
				               }
				          },
	            errFun  : function(){
	            	          safeUiInit();
	            	          iMsgTip.tip("系统繁忙，请稍后再试！", "error");   
	                      }
	    	}
	    	
	    	ajax(params);
	    };
	    
	    //创建事件监听
	    var pwdEventListener = function(){
	    	//取消反回到我的全部文件夹下
	    	$("#safebox_login_cancel").unbind('click').bind('click',function(e){
	    	    window.caiyun.ui.model.leftNav.clickChannel(constants.rootIds.myFolder);
				return util.stopDefault(e);
			});
			
			//设置密码
			$("#safebox_setPwd_sure").unbind('click').bind('click',function(e){
				setUserPwd();
				return util.stopDefault(e);
			});
			
			//登录
			$("#safebox_login_sure").unbind('click').bind('click',function(e){
				userLogin();
				return util.stopDefault(e);
			});
			
			bindSafeboxsms();
			
			//回车login提交
			$("#safebox_login_pwd").unbind('keydown').bind('keydown',function(e){
				if(e.keyCode == "13"){
					userLogin();
				}
			}).focus(function(){
	    		$(this).parent().attr('class','inputDiv hover');
			    $('#safebox_login_sure').attr('class','pop_btn btn-right btn-blue');
			}).blur(function(){ 
				$(this).parent().attr('class','inputDiv currtent');
				$('#safebox_login_sure').attr('class','pop_btn btn-right'); 
			});
			
			$("#safebox_pwd_one").focus(function(){
	    		$(this).parent().attr('class','inputDiv hover');
			}).blur(function(){ 
				$(this).parent().attr('class','inputDiv currtent');
			});
			
			//回车setPwd提交
			$("#safebox_pwd_two").unbind('keydown').bind('keydown',function(e){
				if(e.keyCode == "13"){
					setUserPwd();
				}
			}).focus(function(){
	    		$(this).parent().attr('class','inputDiv hover');
			    $('#safebox_setPwd_sure').attr('class','pop_btn btn-right btn-blue');
			}).blur(function(){ 
				$(this).parent().attr('class','inputDiv currtent');
				$('#safebox_setPwd_sure').attr('class','pop_btn btn-right'); 
			});
			
	    };
	    
	    var bindSafeboxsms = function(){
	    	$("#safebox_getpwd").unbind('click').bind('click',function(e){
				sendSmsPwd();
				return util.stopDefault(e);
			});
	    };
	    
	    //修改密码显示与事件监听
	    var upPwdViewAndEvnListener = function(){
				var upPwdFrame = msgBox({
		            title       : "修改密码",
		            html        : createUpPwd(),
		            width       : 548,
		            height      : 250,
		            autoClose   : false,
		            okHandle    : function(){
										upUserPwd(upPwdFrame);
								}
		        });
		        
	       	    upPwdFrame.show(); 
	       	    // 用于操作失效时，销毁弹出框
	       	    constants.safeboxCloseWin["updataPwdFrame"] = upPwdFrame;
	    };
	    
	    
	    var safeboxLoginHide = function(){
	    	//load图标消失
	    	safebox.hide();
	    	safeboxUpPwd.hide();
	    	
	    	window.caiyun.operate.clearSetCatalogStack({});
	    };
	    
	    
	    var createUpPwd = function(){
	    	var html =  '<div style="padding:38px 0 0 45px;height:130px;" class=""> '+
						'      <div class="cf-info"> '+
						'          <table width="500" border="0"> '+
						'            <tbody><tr> '+
						'              <td height="40" width="141" align="right"><span style="font-size:14px;font-weight:bold;display:block;">设置保险箱密码：</span></td> '+
						'              <td width="343"><input type="password"  class="wh" maxlength="32" id="safebox_upPwd_one" /></td> '+
						'            </tr> '+
						'            <tr> '+
						'              <td height="40" align="right"><span style="font-size:14px;font-weight:bold;display:block;">重输密码：</span></td> '+
						'              <td><input type="password" class="wh" maxlength="32" id="safebox_upPwd_two"></td> '+
						'            </tr> '+
						'            <tr> '+
						'              <td height="32" align="center" colspan="2">(设置密码后，下次登录进入"保险箱"需要此密码验证。)</td> '+
						'              </tr> '+
						'                </tbody></table> '+
						'            </div><!--cf-info END--> '+
						'      </div> ';
	    	
	    	return html;
	    };
	    
	    
	    //创建safe box密码找回和登录ui
	    var createPwdAndLoginUi = function(){
			var html =  '<div id="safebox_setPwd"  style="width:650px; position:absolute;left:100px;top:65px;" class="pop_box"> '+
						'     <div class="safe_box_bg"></div>'+
						'     <div class="title"> '+
						'          <span class="floatleft t_01">设置密码 </span> '+
						'     </div> '+
						'     <div style="padding:20px 0 0 45px;height:130px;" class="">'+
						'           <div class="cf-info"> '+
						'               <table width="500" border="0"> '+
						'                 <tbody><tr> '+
						'                   <td height="52" width="141" align="right"><span style="font-size:14px;font-weight:bold;display:block;">设置保险箱密码：</span></td> '+
						'                   <td width="355"><div class="inputDiv currtent"><input id="safebox_pwd_one" type="password" class="newfolder" maxlength="32"></div></td> '+
						'                 </tr> '+
						'                 <tr> '+
						'                   <td height="52" align="right"><span style="font-size:14px;font-weight:bold;display:block;">重输密码：</span></td> '+
						'                   <td><div class="inputDiv currtent"><input  id="safebox_pwd_two" type="password" class="newfolder" maxlength="32"></div></td> '+
						'                 </tr> '+
						'                 <tr> '+
						'                   <td height="32" align="center" colspan="2">(设置密码后，下次登录进入"保险箱"需要此密码验证。)</td> '+
						'                   </tr> '+
						'               </tbody></table> '+
						'           </div><!--cf-info END--> '+
						'     </div> '+
						'     <div class="pop_footer pop_footer2"> '+
						'         <a id="safebox_setPwd_sure" class="pop_btn btn-right" href="javascript:void(0)">确 定</a> '+
						'     </div> '+
						' </div> '+
						' <div id="safebox_login" style="width:650px; position:absolute;left:100px;top:65px;" class="pop_box"> '+
						'    <div class="safe_box_bg"></div>'+
						'    <div class="title"> '+
						'         <span class="floatleft t_01">保险箱已设置加密保护，进入保险箱需要密码验证</span> '+
						'    </div> '+
						'    <div style="padding:38px 0 0 45px;height:80px;" class=""> '+
						'          <div class="cf-info"> '+
						'              <table width="605" border="0"> '+
						'                <tbody><tr> '+
						'                  <td height="40" width="140" align="right"><span style="font-size:14px;font-weight:bold;display:block;">请输入密码：</span></td> '+
						'                  <td width="355"><div class="inputDiv currtent"><input type="password" class="newfolder" id="safebox_login_pwd" type="password" maxlength="32"></div></td> '+
						'                  <td width="110px"><a id="safebox_getpwd" href="javascript:void(0)">短信密码</a></td> '+
						'                </tr> '+
						'              </tbody></table><!--cf-info END--> '+
						'          </div> '+
						'    </div> '+
						'    <div class="pop_footer pop_footer2"> '+
						'        <a id="safebox_login_sure"  class="pop_btn btn-right" href="javascript:void(0)">确 定</a> '+
						'        <a id="safebox_login_cancel"  class="pop_btn btn-right" href="javascript:void(0)">取 消</a> '+
						' 				      </div> ' +
						'  	 </div>';
	    	
	    	return html;
	    };
	    
		/*
     	 * 判断参数是否为空
     	 */
     	 var isBlank = function(args){
     	 	if(args == null || args == "" || !args ){
     	 		return true;
     	 	}else{
     	 		return false;
     	 	}
     	 };
		
		return {
     		enter 	    	: 	init,
     		leave 			: 	safeboxLoginHide
     	};
	})();
    
})();