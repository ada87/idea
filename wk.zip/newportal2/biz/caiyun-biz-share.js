/**
 * 文件分享
 */
caiyun.biz.fileShare = {};
(function(){

    var fileShare = caiyun.biz.fileShare;
    var topics = caiyun.topics;
    var ajax = caiyun.util.caiyunAjax;
	var constants = caiyun.constants;
	
	/**
	 * 
	 * 浏览自己发出的所有外链列表
	 * 
	 * 参数列表
	 * 
	 * linkType :  外链类型 （0：文件外链 1 ：直链 2：所有）
	 * srt ：外链排序方式 (0:更新时间 默认 1：创建时间，2：下载次数)
	 * srtDr : 排序方向  (0:降序，1：升序)
	 * bNnm : 返回结果的起始编号(注：当为－1时，eNum忽略，返回前200条消息。当大于0时，从该标号开始返回，截止到eNum，如果总数超过200，则默认只返回200条。)
	 * eNum :返回结果的结束编号 (返回结果的结束编号不能小于bNum，否则返回参数错误，当实际条数没有eNum多时，返回实际条数。)
	 * bTime : 查询记录的起始时间（指的是外链的创建时间），精确到秒，含该时间点，可以为空，为空表示无起始时间条件。(可选)
	 * eTime : 查询记录的结束时间（指的是外链的创建时间），精确到秒，含该时间点，可以为空，为空表示无结束时间条件。(可选)
	 * 
	 * @param {Object} parm
	 * 
	 * 			
	 * @param {Object} successCallback
	 * @param {Object} errorCallback
	 */
	fileShare.getAllShare = function(parm,successCallback,errorCallback,hideLoading){
		
		var baseParm = {
			type    : 'post',
			data    : parm, 
            url     : '../filelink/getOutLinkLstAction.action', 
            dataType: 'json', 
            succFun : successCallback,
            errFun  : errorCallback,
            loadingTips : "正在加载，请稍候..."
		};
		return ajax.ajaxRequest(baseParm);
	};
	
	

	/**
	 * 创建文件外链
	 * 
	 * 
	 * @param {Object} parm
	 * {
	 * 	linkType 外链类型
	 * 	coIDLsts 文件IDs
	 *  caIDLsts 目录IDs
	 * }
	 * 
	 * @param {Object} successCallback
	 * @param {Object} errorCallback
	 */
	fileShare.creatFileShare = function(parm,successCallback,errorCallback){
		var baseParm ={
			type    : 'post',
			data    : parm, 
            url     : '../filelink/getOutLinkAction.action', 
            dataType: 'json', 
            succFun : successCallback,
            errFun  : errorCallback,
			hideLoading : true,
//			loadingTips : "正在生成分享链接...",
			bi      :['fileLink','publish',parm.coIDLsts,parm.caIDLsts]//统计发布文件分享操作
		};
		return ajax.ajaxRequest(baseParm);
	};
	
	/**
	 * 取消分享
	 * 
	 * 参数列表
	 * 
	 * LinkIds : [文件外链IDs]
	 *  
	 * @param {Object} parm
	 * @param {Object} successCallback
	 * @param {Object} errorCallback
	 */
	fileShare.cancelFileShare = function(parm,successCallback,errorCallback){
		var baseParm ={
			type    :'post',
			data    :parm,
			url     : '../filelink/delOutLinkAction.action',
			dataType:'json',
			succFun :successCallback,
			errFun  :errorCallback
		};
		return ajax.ajaxRequest(baseParm);
	};
	
	//下载分享（文件外链）文件
	fileShare.downLoadFile = function(parm,successCallback,errorCallback){
		
	};
	
	//更新分享（文件外链）元数据(修改描述)
	fileShare.updateInfo = function(parm,successCallback,errorCallback){
		var baseParm ={
			type    : 'post',
			data    : parm, 
            url     : '../filelink/modOutLinkAction.action', 
            dataType: 'json', 
            succFun : successCallback,
            errFun  : errorCallback,
			hideLoading : true
		};
		return ajax.ajaxRequest(baseParm);
	};
	
	//举报非法信息
	fileShare.reportIllegalMsg = function(parm,successCallback,errorCallback){
		
	};
	
	//下发分享链接信息
	// parm.mobiles
	// parm.linkName
	// parm.linkURL 
	fileShare.shareLinkByMsg = function(parm,successCallback,errorCallback){
		var baseParm ={
			type    :'post',
			data    :parm,
			url     : '../filelink/sendNotifySMSAction.action',
			dataType:'json',
			succFun :successCallback,
			errFun  :errorCallback
		};
		return ajax.ajaxRequest(baseParm);
	};
	
	fileShare.shareLinkByMail = function(parm,successCallback,errorCallback){
		var baseParm ={
			type    :'post',
			data    :parm,
			url     : '../filelink/sendNotifyEmailAction.action',
			dataType:'json',
			succFun :successCallback,
			errFun  :errorCallback
		};
		return ajax.ajaxRequest(baseParm);
	};
	
	/**
	 * 邀请共享
	 * parm.account 发送共享着的账号
	 * parm.shareeInfos 接收共享者列表
	 * parm.dirFileIDs 共享资源列表
	 * 
	 */
	fileShare.inviteShare = function(parm,successCallback,errorCallback){
		
		var baseParm ={
			type    :'post',
			data    : parm,
			url     : '../fileshare/inviteShareAction.action',
			dataType:'json',
			succFun :successCallback,
			errFun  :errorCallback
		};
		return ajax.ajaxRequest(baseParm);
	};
	
	/**
	 * 取消共享
	 * parm.sharer 发送共享者账号
	 * parm.objID 文件、目录ID
	 * parm.objType 文件、目录类型:1 文件，2 目录
	 * parm.name 文件、目录名,对于共享请求，该字段必填
	 */
	fileShare.cancelShare = function(parm,successCallback,errorCallback){
		var baseParm ={
			type    :'post',
			data    :parm,
			url     : '../fileshare/cancelShareAction.action',
			dataType:'json',
			succFun :successCallback,
			errFun  :errorCallback
		};
		return ajax.ajaxRequest(baseParm);
	};
	
	/**
	 * 浏览发送共享和接收共享列表
	 * parm.account 发送、接收共享者的账号
	 * parm.sndRcv 发送/接收共享   0、发送共享  1 、接收共享
	 * parm.order 查询顺序
	 * parm.orderField 查询域
	 * parm.startRange 开始范围 默认是-1 表示不分页查询
	 * parm.endRange 结束范围 默认是-1 表示查询最大分页数
	 * parm.status 接收拒绝状态
	 * 
	 */
	fileShare.getShareList = function(parm,successCallback,errorCallback){
        //查询企业
        var shareType ={
        //屏蔽企业
//            shrType:parm.shrType || "10",
            shrType:2,
            status:2
        }
        $.extend(parm,shareType);
		var baseParm ={
			type    :'post',
			data    :parm,
			url     : '../fileshare/getShareListAction.action',
			dataType:'json',
			succFun :successCallback,
			errFun  :errorCallback,
			loadingTips : "正在加载，请稍候..."
		};
		return ajax.ajaxRequest(baseParm);
	};
	
	/**
	 * 浏览共享详情
	 * parm.account 发送、接收共享者的账号
	 * parm.objID 文件、目录ID
	 * parm.objType 文件、目录类型:1 文件，2 目录
	 * parm.name 文件、目录名,对于共享请求，该字段必填
	 */
	fileShare.getShareInfo = function(parm,successCallback,errorCallback){
		var baseParm ={
			type    :'post',
			data    :parm,
			url     : '../fileshare/getShareInfoAction.action',
			dataType:'json',
			succFun :successCallback,
			errFun  :errorCallback
		};
		 return ajax.ajaxRequest(baseParm);
	};
	
	/**
	 * 退出共享
	 * parm.account 发送、接收共享者的账号
	 * parm.catalogIDList 目录ID列表，目前仅支持200个目录
	 * parm.contentIDList 文件内容ID列表，目前仅支持200个文件
	 */
	fileShare.leaveShare = function(parm,successCallback,errorCallback){
		var baseParm ={
			type    :'post',
			data    :parm,
			url     : '../fileshare/leaveShareAction.action',
			dataType:'json',
			succFun :successCallback,
			errFun  :errorCallback
		};
		return ajax.ajaxRequest(baseParm);
	};
	
	
	/**
	 * 应答共享
	 * parm.account 发送、接收共享者的账号，目前仅支持接收共享者
	 * parm.catalogIDList 目录ID列表，目前仅支持200个目录
	 * parm.contentIDList 文件内容ID列表，目前仅支持200个文件
	 * parm.status 接收拒绝状态 0 无意义 1 PENDING 2 Acception  3
	 * parm.readStatus 已读/未读状态 0 – 无操作1 – 已读2 – 未读
	 * parm.replyAllFlag 应答所有接收共享记录 0 – 非应答所有1 – 表示应答所有
	 * 
	 * 
	 */
	fileShare.replyShare = function(parm,successCallback,errorCallback){
		var baseParm ={
			type    :'post',
			data    :parm,
			url     : '../fileshare/replyShareAction.action',
			dataType:'json',
			succFun :successCallback,
			errFun  :errorCallback,
			hideLoading : true
		};
		return ajax.ajaxRequest(baseParm);
	} 
    
})();
