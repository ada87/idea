
/**
 * 彩云通讯录
 */
caiyun.biz.cytxl = {};
(function(){
	var ajax = caiyun.util.caiyunAjax;
	var cytxl = caiyun.biz.cytxl;
	
	/**
	 * 彩云平台注册并登陆
	 */
	cytxl.regAndSignIn = function(activeUserSuccCallBack,activeUserFailCallBack){
		var params = {async : false};
		var baseParams = {
            type    : 'get',
			data    :  params ,
            url     : '../cytxl/activeuser.action',
            dataType: 'json',
            succFun : activeUserSuccCallBack,
            errFun  : activeUserFailCallBack
        };
		 ajax.ajaxRequest(baseParams);
	};
	
	/**
	 * 添加彩云通讯录联系人
	 * parm:
	 * {
	 * name
	 * msisdn
	 * aloneToGroupId
	 * }
	 */
	cytxl.addContacts = function(parm,successCallback,errorCallback){
		
		var baseParams = {
            type    : 'post', 
			data    :  parm,
            url     : '../cytxl/additem.action', 
            dataType: 'json', 
            succFun : successCallback,
            errFun  : errorCallback
        };
        
        ajax.ajaxRequest(baseParams);
	};
	
}
)();
