// 管理文件的js对象
// 定义命名空间
caiyun.biz = caiyun.biz ? caiyun.biz : {};
caiyun.biz.fileManager = {};

// 好习惯不要忘
(function() {
	var fileManager = caiyun.biz.fileManager;
	var topics = caiyun.topics;
	var ajax = caiyun.util.caiyunAjax;
	var constants = caiyun.constants;

	/**
	  * 获取目录下的文件和子目录列表（进入目录，切换目录……）
	  * 
	  * 参数列表	
	  * params{
			catalogSortType			目录的排序方式，默认按创建时间。支持修改时间、名称。支持正、反序。0：修改时间；1：名称
			contentID				目录ID
			contentSortType			文件列表的排序方式，默认按创建时间。支持修改时间、名称。支持正、反序。0：修改时间；1：名称；2：类型；3：大小
			endNumber				返回结果的结束编号。startNumber和endNumber两个参数是为了客户端实现分页显示，每次返回指定数目的结果，当startNumber大于0时，不能小于startNumber,否则返回错误，当实际条数没有endNumber,返回实际条数
			entryShareCatalogID		入口目录ID，查询自己的彩云时，该字段为空；当查询共享目录的子目录时，为必填
			filtertype				过滤类型，返回的信息种类。0：目录和内容一起返回；1：只返回目录信息；2：只返回内容信息
			sortDirection			目录/文件的排序方式，默认按正序。0：正序；1：反序
			startNumber	    		返回结果的起始编号，默认为－1。当为－1时，endNumber忽略，返回全部列表。当大于0时，从实际开始的标号返回，当为0时，作为错误处理
	  * }
	  * 
	  * 结果
	  * showMessage 错误信息
	  * dci { // 返回结果
	  * 	nodeCount    节点总数
	  * 	cataloginfos 目录信息列表
	  * 	contents 	 文件信息列表
	  * 	parentid     父目录ID
	  * 	resultcode   返回码，0表示正常处理，其余表示后台处理错误
	  * }
	  * 
	  * 目录和文件信息的描述请见OSE文档CatalogInfo和ContentInfo
	  */
	fileManager.getDisk = function(params, successCallback, errorCallback) {

	};

	/**
	  * 获取文件详细信息
	  * 
	  * 参数列表
	  * params{
	  * 	contentID				文件ID
			entryShareCatalogID	  	共享目录ID
	  * }
	  * 
	  * 结果
	  * showMessage 错误信息
	  * contentInfoObj{ 
	  * 	resultcode  返回码，0表示正常处理，其余表示后台处理错误
	  * }
	  * 
	  * 文件信息的描述请见OSE文档ContentInfo
	  */
	fileManager.getContentInfo = function(params, successCallback, errorCallback) {

	};

	/**
	  * 创建文件夹
	  * 
	  * 参数列表
	  * params{
	  * 	catalogName		  目录名称 	
			catalogType		  目录类型  0：未分类 1：图片 2：音频 3：视频 4：消息 5：文档 
			parentcatalogID	  新建子目录的父目录ID
	  * }
	  * 
	  * 结果
	  * catalogInfo           目录信息详见OSE文档CatalogInfo
	  * catalogName			  目录名称
	  * message				  信息
	  * parentcatalogID       父目录ID
	  */
	fileManager.createCatalog = function(params, successCallback, errorCallback) {
		var baseParams = {
			type: 'post',
			url: 'webdisk/createCatalog!createCatalog.action',
			dataType: 'json',
			succFun: successCallback,
			errFun: errorCallback
		};
		baseParams.data = $.extend({}, params);
		ajax.ajaxRequest(baseParams);
	};

	/**
	 * 单文件下载
	 *
	 * 参数列表
	 * params{
	 * 	contentID				下载文件ID
	 *     visionID                文件历史版本ID
	 * 	entryShareCatalogID		共享目录ID
	 * }
	 *
	 * 结果
	 * downloadUrl 下载地址
	 * message     信息
	 */
	fileManager.downloadFile = function(params, successCallback, errorCallback) {
		var baseParams = {
			type: 'post',
			url: 'webdisk2/downLoadAction!downloadToPC.action',
			dataType: 'json',
			succFun: successCallback,
			errFun: errorCallback,
			bi: ['fileOper', 'download', params.contentID]
		};
		baseParams.data = $.extend({}, params);
		baseParams.data.shareContentIDs = params.contentID;

		ajax.ajaxRequest(baseParams);
	};

	/**
	  * 打包下载
	  * 
	  * 参数列表
	  * params{
	  * 	catalogList 待下载的目录列表
	  * 	[{
	  * 		catalogID 目录ID
	  * 		name 	  目录名称
	  * 		type	  目录类型
	  * 	},..]	 
			contentList	待下载的内容列表
			[{
				contentID 文件ID
				name	  文件名称
			}..]
			recursive	0表示不递归下载目录下的子目录文件 1表示递归下载目录下的文件
			zipFileName	打包文件名
	  * }
	  * 
	  * 结果
	  * downloadUrl 下载地址
	  * message     信息
	  */
	fileManager.downloadZipPkg = function(params, successCallback, errorCallback) {
		var contentList = params.contentList;
		var catalogList = params.catalogList;
		var contentIDs = [];
		var catalogIDs = [];
		for (var i = 0, length = contentList.length; i < length; i++) {
			contentIDs.push(contentList[i].contentID);
		}
		for (var i = 0, length = catalogList.length; i < length; i++) {
			catalogIDs.push(catalogList[i].catalogID);
		}
		var baseParams = {
			type: 'post',
			url: 'webdisk2/downLoadAction!downLoadZipPackage.action',
			dataType: 'json',
			succFun: successCallback,
			errFun: errorCallback,
			bi: ['fileOper', 'download', contentIDs, catalogIDs]
		};
		baseParams.hideLoading = true;
		baseParams.data = $.extend({}, params);
		var catalogList = params.catalogList;
		var contentList = params.contentList;
		var catalogs = '';
		var contents = '';
		if (catalogList) {
			for (var i in catalogList) {
				if (i < catalogList.length - 1) {
					catalogs += (catalogList[i].catalogID + '|' + catalogList[i].name + '|' + catalogList[i].type + '#');
				} else {
					catalogs += (catalogList[i].catalogID + '|' + catalogList[i].name + '|' + catalogList[i].type);
				}
			}
		}
		if (contentList) {
			for (var i in contentList) {
				if (i < contentList.length - 1) {
					contents += (contentList[i].contentID + '|' + contentList[i].name + '#');
				} else {
					contents += (contentList[i].contentID + '|' + contentList[i].name);
				}
			}
		}
		baseParams.data.catalogList = catalogs;
		baseParams.data.contentList = contents;

		ajax.ajaxRequest(baseParams);
	};

	/**
	 * 检查打包下载的URL是否可用
	 *
	 * 参数列表
	 * params{
	 * 	downloadUrl  下载链接
	 * }
	 *
	 * 结果
	 * message   	信息为空表示检查成功，其他表示检查失败
	 */
	fileManager.checkDownloadZipPkg = function(params, successCallback, errorCallback) {
		var baseParams = {
			type: 'post',
			url: 'webdisk2/downLoadAction!checkDownLoadZipPackage.action',
			dataType: 'json',
			succFun: successCallback,
			errFun: errorCallback
		};
		baseParams.hideLoading = true;
		baseParams.data = $.extend({}, params);

		ajax.ajaxRequest(baseParams);
	};

	/**
	  * 修改文件信息，重命名，改描述，改标签
	  * 
	  * 参数列表
	  * params{
	  * 	contentDesc		文件描述信息
			contentID		文件ID
			contentName		新文件名
			tags['','']		文件标签列表，字符串数组
	  * }
	  * 
	  * 结果
	  * message	 	信息为空表示成功
	  */
	fileManager.updateContentInfo = function(params, successCallback, errorCallback) {
		var baseParams = {
			type: 'post',
			url: 'webdisk2/renamecontent.action',
			dataType: 'json',
			succFun: successCallback,
			errFun: errorCallback
		};
		baseParams.data = $.extend({}, params);
		if (params.tags) {
			baseParams.data.tags = params.tags.toString();
		} else {
			baseParams.data.tags = '';
		}

		ajax.ajaxRequest(baseParams);
	};

	/**
	  * 修改文件夹信息，重名
	  * 
	  * 参数列表
	  * params{
	  * 	catalogID	文件夹ID
			catalogName	新文件夹名称
		    catalogType 文件夹类型(文件夹取消同步用，0为取消同步)
	  * }
	  * 
	  * 结果
	  * message		信息为空表示成功
	  */
	fileManager.updateCatalogInfo = function(params, successCallback, errorCallback) {
		var baseParams = {
			type: 'post',
			url: 'webdisk2/renamecatalog.action',
			dataType: 'json',
			succFun: successCallback,
			errFun: errorCallback
		};
		baseParams.data = $.extend({}, params);

		ajax.ajaxRequest(baseParams);
	};

	/**
	 * 移动文件夹/文件
	 *
	 * 参数列表
	 * params{
	 * 	catalogIDList	['','',''] 要移动的文件夹ID列表
	 * 	contentIDList	['','',''] 要移动的文件ID列表
	 * 	newCatalogID			   目标文件夹ID
	 * }
	 *
	 * 结果
	 * message		信息为空表示成功
	 */
	fileManager.move = function(params, successCallback, errorCallback) {

	};

	/**
	 * 复制文件夹/文件
	 *
	 * 参数列表
	 * params{
	 * 	catalogIDList	['','',''] 要复制的文件夹ID列表
	 * 	contentIDList	['','',''] 要复制的文件ID列表
	 * 	newCatalogID			   目标文件夹ID
	 * }
	 *
	 * 结果
	 * message		信息为空表示成功
	 */
	fileManager.copy = function(params, successCallback, errorCallback) {

	};

	/**
	  * 移除文件夹/文件到回收站
	  * 
	  * 参数列表
	  * params{
	  * 	catalogIDs	['','',''] 要移除的文件夹ID列表
			contentIDs	['','',''] 要移除的文件ID列表
	  * }
	  */
	fileManager.removeToRecycleBin = function(params, successCallback, errorCallback) {
		var baseParams = {
			type: 'post',
			url: 'backRecoveryContentAndCatalog.action',
			dataType: 'json',
			succFun: successCallback,
			errFun: errorCallback,
			bi: ['fileOper', 'delete', params.contentIDs, params.catalogIDs] //统计删除文件操作
		};
		baseParams.data = $.extend({}, params);
		if (baseParams.data.catalogIDs) {
			baseParams.data.catalogIDs = baseParams.data.catalogIDs.toString();
		}
		if (baseParams.data.contentIDs) {
			baseParams.data.contentIDs = baseParams.data.contentIDs.toString();
		}
		baseParams.data.opr = 2;
		baseParams.data.virCatalogID = constants.rootIds.myRecycleBin;
		ajax.ajaxRequest(baseParams);
	};

	/**
	  * 还原回收站文件/文件夹
	  * 
	  * 参数列表
	  * params{
	  * 	catalogIDs	['','',''] 要还原的文件夹ID列表
			contentIDs	['','',''] 要还原的文件ID列表
	  * }
	  * 
	  * 结果
	  * returnCode			结果码，为0表示正常
	  * showMessage			消息
	  * diskInfo{			用户网盘信息
	  * 	diskSize		网盘容量
	  * 	freeDiskSize 	网盘可用容量
	  * }
	  */
	fileManager.recoverFromRecycleBin = function(params, successCallback, errorCallback) {
		var baseParams = {
			type: 'post',
			url: 'backRecoveryContentAndCatalog.action',
			dataType: 'json',
			succFun: successCallback,
			errFun: errorCallback
		};
		baseParams.data = $.extend({}, params);
		if (baseParams.data.catalogIDs) {
			baseParams.data.catalogIDs = baseParams.data.catalogIDs.toString();
		}
		if (baseParams.data.contentIDs) {
			baseParams.data.contentIDs = baseParams.data.contentIDs.toString();
		}
		baseParams.data.opr = 1;
		baseParams.data.virCatalogID = constants.rootIds.myRecycleBin;
		ajax.ajaxRequest(baseParams);
	};

	/**
	  * 查询回收站
	  * 
	  * 参数列表
	  * params{
			contentSortType		0： 删除时间 （默认值） 1：名称 2：大小 3：文件类型 	
			endNumber			结束记录数
			sortDirection		排序方向： 0：倒序 1：正序
			startNumber			开始记录数
	  * }
	  * 
	  * 结果
	  * showMessage 错误信息
	  * dci { // 返回结果
	  * 	resultcode   				返回码，0表示正常处理，其余表示后台处理错误
	  * 	vitem	[VirDirInfoItem,VirDirInfoItem,...] 	内容数组
	  * }
	  * 
	  * 目录和文件信息的描述请见OSE文档VirDirInfoItem
	  */
	fileManager.queryRecycleBin = function(params, successCallback, errorCallback, hideLoading) {
		var baseParams = {
			type: 'post',
			url: 'queryContentAndCatalog!queryVirDirInfo.action',
			dataType: 'json',
			succFun: successCallback,
			errFun: errorCallback,
			hideLoading: hideLoading
		};

		baseParams.data = $.extend({}, params);
		baseParams.data.contentID = constants.rootIds.myRecycleBin;
		return ajax.ajaxRequest(baseParams);

	};

	/**
	 * 彻底删除文件，从回收站中清除文件
	 *
	 * 结果
	 * returnCode			结果码，为0表示正常
	 * showMessage			消息
	 * diskInfo{			用户网盘信息
	 * 	diskSize		网盘容量
	 * 	freeDiskSize 	网盘可用容量
	 * }
	 */
	fileManager.drop = function(params, successCallback, errorCallback) {
		var baseParams = {
			type: 'post',
			url: '../delContentAndCatalog.action',
			dataType: 'json',
			succFun: successCallback,
			errFun: errorCallback
		};

		baseParams.data = $.extend({}, params);
		if (baseParams.data.catalogIDs) {
			baseParams.data.catalogIDs = baseParams.data.catalogIDs.toString();
		}
		if (baseParams.data.contentIDs) {
			baseParams.data.contentIDs = baseParams.data.contentIDs.toString();
		}
		ajax.ajaxRequest(baseParams);
	};

	/**
	 * 清空回收站
	 *
	 * 结果
	 * returnCode			结果码，为0表示正常
	 * showMessage			消息
	 * diskInfo{			用户网盘信息
	 * 	diskSize		网盘容量
	 * 	freeDiskSize 	网盘可用容量
	 * }
	 */
	fileManager.clearRecycleBin = function(params, successCallback, errorCallback) {
		var baseParams = {
			type: 'post',
			url: 'backRecoveryContentAndCatalog.action',
			dataType: 'json',
			succFun: successCallback,
			errFun: errorCallback
		};

		baseParams.data = {};
		baseParams.data.opr = 3;
		baseParams.data.virCatalogID = constants.rootIds.myRecycleBin;
		ajax.ajaxRequest(baseParams);
	};

	/**
	 * 统计文件夹下的每个后缀的文件数量
	 *
	 * 参数列表
	 * params{
	 * 	catalogID 文件夹ID，为空时表示查询所有文件
	 * }
	 * hideLoading 是否隐藏加载中提示
	 * 结果
	 * showMessage 		信息，正常为空
	 * cntNumGroup{		统计结果
	 * 	cntNumGroup{
	 * 		'.jpg' : 0 ,统计项
	 * 		...
	 * 	}
	 * }
	 */
	fileManager.queryFileNumberBySuffix = function(params, successCallback, errorCallback, hideLoading) {
		var baseParams = {
			type: 'post',
			url: 'webdisk2/queryContentAndCatalog!queryCntNumGroupBySuffix.action',
			dataType: 'json',
			succFun: successCallback,
			errFun: errorCallback
		};
		baseParams.data = $.extend({}, params);
		baseParams.hideLoading = hideLoading;
		ajax.ajaxRequest(baseParams);
	};

	/**
	 * 根据后缀查询文件
	 *
	 * 参数列表
	 * params{
	 * 	channelList			渠道列表
	 * 	contentSortType		排序方式，0：修改时间 1：名称 2：类型 3：大小
	 * 	contentSuffix		文件后缀名数组
	 * 	contentType			文件类型：0：全部类型 1：图片文件 2：音频文件 3：视频文件 4：文档文件 5：其他文件 7：表格 8：幻灯片 9/10/11：预留，暂时不用 12：手机软件文件
	 * 	endNumber			返回结果的结束编号
	 * 	isSumnum			是否返回该类型内容总数或数量
	 * 	sortDirection		文件的排序方向。默认按正序 0：正序 1：反序
	 * 	startNumber			返回结果的开始编号
	 * }
	 * 结果
	 * showMessage 		信息，正常为空
	 * dci{
	 * 	contents		内容列表
	 * 	nodeCount		节点数
	 * }
	 */
	fileManager.queryContentInfosBySuffix = function(params, successCallback, errorCallback, hideLoading) {
		var baseParams = {
			type: 'post',
			url: 'webdisk2/queryContentAndCatalog!queryAllContentInfosBySuffix.action',
			dataType: 'json',
			succFun: successCallback,
			errFun: errorCallback
		};
		baseParams.data = $.extend({}, params);
		baseParams.hideLoading = hideLoading;
		if (baseParams.data.channelList) {
			baseParams.data.channelList = baseParams.data.channelList.toString();
		}
		if (baseParams.data.contentSuffix) {
			baseParams.data.contentSuffix = baseParams.data.contentSuffix.join('|');
		}
		return ajax.ajaxRequest(baseParams);
	};

	/**
	  * 根据文件类型查询文件
	  * 
	  * 参数列表
	  * params{
	  * 	contentSortType		文件列表的排序方式，默认按修改时间。支持修改时间、名称、类型、大小。支持正反序。0：修改时间 1：名称 2：类型 3：大小 4: 上传时间
			contentType			目录下显示的文件类型，缺省显示全部类型的文件：	
								0：全部类型
								1：图片文件
								2：音频文件
								3：视频文件
								4：文档文件
								5：其他文件（非1/2/3/4/7/8类型的其他文件）
								7：表格
								8：幻灯片
								9：预留，暂时不用
								10：office文档集合（包含4、7、8三类）
								11：预留，暂时不用
								12：手机软件文件
								13~98：预留
								99：扩展的其他文件，作为5的扩展；（非1/2/3/12的其他所有内容，该取值目前仅限于139局点使用）
		
			endNumber			结束记录号
			isSumnum			是否返回该类型内容总数或内容 0：只返回内容，不返回数量 1：返回内容和数量 2：只返回数量，不返回内容
			sortDirection		文件的排序方向。默认按正序	0：正序	1：反序
			startNumber			开始记录号
	  * }
	  * 
	  * 结果
	  * showMessage	为空表示正常
	  * diskcataloginfo{	// 查询结果
	  * 	contents[ContentInfo,...]	文件信息列表
	  * }
	  */
	fileManager.queryContentInfosByType = function(params, successCallback, errorCallback) {

	};
})();