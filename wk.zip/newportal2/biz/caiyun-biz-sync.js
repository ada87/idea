// 同步推送命名空间
caiyun.biz = caiyun.biz ? caiyun.biz : {};
caiyun.biz.bosh = {};
;(function(){
	// 本地缓存全局变量
	var judgement = window.caiyun.judgement;
    var operate = window.caiyun.operate;
    var bosh = window.caiyun.biz.bosh;
    
    // 页面加载的随机bosh推送服务器地址
    var BOSH_SERVICE = '/bosh';
    // 当前创建的推送会话
    var BOSH_SID = "";
    // bosh连接对象
    var connection = null;
    
    // 自定义log
    var log = function(msg) 
	{
    	if(typeof(console)!=='undefined' && typeof(console.warn)!=='undefined') {
     		console.warn(msg);
     	}
	}
    // 输出回调
	var rawOutput = function(data)
	{
	    log('SENT: ' + data);
	}
	// 输入回调
	var rawInput = function(data)
	{
		log('RECV: ' + data);
		// 后台返回消息事件节点
		var evt = data.indexOf('<eventide>8</eventide>');
		var evtNew = data.indexOf('<eventid>8</eventid>');
		// 无消息直接返回
		if(evt + evtNew < 0) 
			return;
		// 截取同步操作的二级目录
		var affectRoot = data.substr(data.indexOf('<itemIDList>')+'<itemIDList>'.length,32);
		
		//推送时刷新当前视图
		if(judgement.isInCurrentCatalogs(affectRoot)) {
			operate.reLoad();
		}
	}
	// 同步连接状态变更回调
	var onConnect = function(status)
	{
	    if (status == Strophe.Status.CONNECTING) {
	    	log('Strophe is connecting.');
	    } else if (status == Strophe.Status.CONNFAIL) {
	    	log('Strophe failed to connect.');
	    } else if (status == Strophe.Status.DISCONNECTING) {
	    	log('Strophe is disconnecting.');
	    } else if (status == Strophe.Status.DISCONNECTED) {
	    	log('Strophe is disconnected.');
	    } else if (status == Strophe.Status.CONNECTED) {
	    	log('Strophe is connected.');
	    }
	}
	
	// 初始同步连接方法
	bosh.init = function(param) {
		 try {
			 // 构建参数
			 var conn_param = param || {} ;
			 // 发送连接请求
			 $.ajax({
			        url:basePath + "proxy/bosh.jsp",
			        data: {nonce:new Date().valueOf()},
			        dataType: 'json',
			        success: function(json){
			        	if(json && json.message == '') {
							 connection = new Strophe.Connection(conn_param.service || json.BS_SERVER);
							 connection.rawInput = conn_param.inputCallback || rawInput;
							 connection.rawOutput = conn_param.outputCallback || rawOutput;
							 connection.connect(json.BS_SID,'',conn_param.connCallback || onConnect); 
						 }else {
							 log("暂时未能连接同步服务器!");
						 }
			        },
			        error : function(r) {
			        	log("连接同步服务器失败:"+r);
					}
				});
		 }catch (e) {
	        log("同步服务器对接失败:"+e);
	     }
	}
})();