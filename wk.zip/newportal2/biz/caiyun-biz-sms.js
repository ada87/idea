caiyun.biz = caiyun.biz ? caiyun.biz : {};
caiyun.biz.smsManager = {};