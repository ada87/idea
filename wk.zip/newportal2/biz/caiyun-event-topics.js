/*
 * 保存所有事件的主题常量，便于管理事件
 */
caiyun.topics = {};
// ui事件
caiyun.topics.ui = {};
// 业务事件
caiyun.topics.biz = {};

// 保持良好习惯不要搞乱了全局，下面是定义文件事件主题
(function(){
	var biz = caiyun.topics.biz;
	biz.file = {};
	var file = biz.file;
	// 定义事件前序
	var filePrefix = 'BIZ_FILE_';
	// 定义file事件主题
	biz.file.LOAD_NEW_PAGE = filePrefix + 'LOAD_NEW_PAGE';
	
})
();

// 保持良好习惯不要搞乱了全局，下面是定义短彩事件主题
(function(){
	var biz = caiyun.topics.biz;
	biz.sms = {};
	var sms = biz.sms;
	// 定义事件前序
	var smsPrefix = 'BIZ_SMS_'
	// 定义SMS事件主题
})
();

// UI事件
(function(){
	var ui = caiyun.topics.ui;
	// 事件前缀
	var uiPrefix = "UI_";
	
	// 目录切换事件
	ui.SWITCH_FOLDER = uiPrefix + 'SWITCH_FOLDER';
	
	// 显示模式切换事件
	ui.SWITCH_LIST_VIEW = uiPrefix + 'SWITCH_LIST_VIEW';
	
	// 加载分页完成事件
	ui.ADDED_NEW_PAGE = uiPrefix + 'ADDED_NEW_PAGE';

	// fileContent大小变化事件
	ui.FILE_CONTENT_RESIZE = uiPrefix + 'FILE_CONTENT_RESIZE';
	
	// 文件被选中或取消选中事件
	ui.FILE_SELECT = uiPrefix + 'FILE_SELECT';
	
}
);