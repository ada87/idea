/**
 *查询企业信息，并缓存。
 */
var entryPriseInfoData ={
	_qryInfo : {},//根据账号查询企业信息
    _isAdmin : false,//是否为企业用户管理员
    _isEnterpriseUser: false,//是否是企业彩云普通用户（不包括管理员）
    _enterpriseAdminCataIds:[],//企业空间管理员文件夹id
    _enterpriseUserCataIds:[], //企业空间普通成员文件夹id

	
	init : function(params){
//			2013.10 屏蔽企业入口（首页）（后续不用应该移出相应代码）
//        entryPriseInfoData.qryInfo(params);
//        entryPriseInfoData.qryEnterpriseCataIDs4user();
	},
	//查询是否企业成员或者管理员并缓存
	qryInfo : function(callBack){
		var baseParams = {
            type    : 'post',
            url     : '../enterprise/qryEnterpriceInfo.action',
            data:{filter:1100},
            dataType: 'json', 
            succFun :  function(r,json){
				if(json){
					if(json.resultCode == "0"){
						var info = json.getEnterpriseInfoRes;
                        entryPriseInfoData._qryInfo = info;
						if(entryPriseInfoData._qryInfo.hasOwnProperty("myEnterprise") && entryPriseInfoData._qryInfo.myEnterprise.hasOwnProperty("enterpriseInfo")){
                            entryPriseInfoData._isAdmin = true;
							entryPriseInfoData.qryEnterpriseCataIDs4Admin();
                            var flag = true;
                            $("#userMenu_box").each(function(){
                            	if("userMenu_pri" == $.trim($(this).attr('id'))){
                            		flag = false;
                            	}
                            });
                            if(flag){
                            	date = new Date().getTime();
                            	//$("#mySetup").before('<a class="ua" href="../enterprise/getEnterpriceInfo.action?date='+date+'">企业管理台</a><em>|</em>');
                                $('#userMenu_box').prepend('<li id="userMenu_pri"><a href="../enterprise/getEnterpriceInfo.action?date='+date+'">企业管理台</a></li>');
                                $('#userMenu_pri').hover(function(){$(this).addClass('hover');},function(){$(this).removeClass('hover');});
                            }
						}
                        if(entryPriseInfoData._qryInfo.hasOwnProperty("me4Enterprise") && entryPriseInfoData._qryInfo.me4Enterprise.hasOwnProperty("enterpriseInfo")){
                            entryPriseInfoData._isEnterpriseUser = true;
                        }
					}
				}
			},
            errFun  : function(){
			},
			hideLoading : true
        };
        window.caiyun.util.caiyunAjax.ajaxRequest(baseParams);
	},
    //查询企业管理员企业空间文件夹id
    qryEnterpriseCataIDs4Admin : function(){
        var param ={
            account : ownerMSISDN,
            loginMsisdn : "",
            filter : "1100000000",
            startNumber:"1",
            endNumber:"10"
        };
        var baseParams = {
            type    : 'post',
            url     : '../enterprise/queryEntEntry.action',
            data    : param,
            dataType: 'json',
            succFun :  function(res,data){
                if(data.resultCode == "0" && data.entrys.entEntry!= null){
                    var entEntryInfos = data.entrys.entEntry;
                    $.each(entEntryInfos,function(i,n){
                        if(n.entry.catalogID){
                            entryPriseInfoData._enterpriseAdminCataIds.push(n.entry.catalogID);
                            entryPriseInfoData.qryEnterpriseAuth('',entryPriseInfoData._qryInfo.myEnterprise.enterpriseInfo[0].enterpriseID);//查询用户在每个企业下的信息并缓存起来
                        };
                    });
                };
            },
            errFun  : function(){
            },
            hideLoading : true
        };
        window.caiyun.util.caiyunAjax.ajaxRequest(baseParams);

    },
    //查询企业用户企业空间文件夹ids
    qryEnterpriseCataIDs4user :function(){
        var param = {
            account:ownerMSISDN,
            sndRcv: "1",
            orderField: "0",
            order: "0",
            startRange: -1,
            endRange: -1,
            readStatus:"0",
            retrievalItem:"0",
            status:"2",
            shrType:"10"
        };
        var baseParams = {
            type    : 'post',
            url     : '../fileshare/getShareListAction.action',
            data    : param,
            dataType: 'json',
            succFun :  function(res,data){
                if(data.resultCode == "0"){
                    var detailShareRspInfo = data.getShareListRsp.detailShareRspInfoList.detailShareRspInfo;
                    if(detailShareRspInfo){
                        $.each(detailShareRspInfo, function(i, data){
                            if (data.catalogInfo){
                                if(data.catalogInfo.shareType == "4"){
                                    entryPriseInfoData._enterpriseUserCataIds.push(data.catalogInfo.catalogID);
                                    entryPriseInfoData.qryEnterpriseAuth(data.shareInfo.sharer,'');//查询用户在每个企业下的信息并缓存起来
                                }
                            };
                        });
                    }
                }
            },
            errFun  : function(){
            },
            hideLoading : true
        };
        window.caiyun.util.caiyunAjax.ajaxRequest(baseParams);
    },

    //查询用户企业权限并缓存
    /**
     *
     * @param enterpriseaccnt  普通用户查询用
     * @param enterpriseID 企业管理员查询用
     */
    qryEnterpriseAuth : function(enterpriseaccnt,enterpriseID){
        var param = {
            account : ownerMSISDN,
            enterpriseaccnt : enterpriseaccnt || '',
            enterpriseID : enterpriseID || '',
            startnum : 0,
            endnum:0
        };
        caiyun.biz.enterprise.getEnterpriseMember(param,function(params,jsondata){
            var resultCode = jsondata.resultCode;
            if(resultCode == "0"){
                if(null != jsondata.getEnterpriseMemberRes){
                    var enterpriseMemberRes = jsondata.getEnterpriseMemberRes;
                    var epID = (params.data.enterpriseaccnt== ''? 'E'+params.data.account: params.data.enterpriseaccnt);
                    caiyun.util.cache.putEnterpriseAuthCache(caiyun.constants.ENTERPRISE_AUTH_CACHEGROUP,epID,enterpriseMemberRes);
                }
            }
        },function(){
            //window.caiyun.ui.iMsgTip.tip("企业信息加载失败,请稍后重试!","error");
        });
    },

    /**
     *返回当前企业账号所在企业ID
     * @param enterpriseAcc 企业账号
     */
    getEidByAcc : function(enterpriseAcc){
        var acc = enterpriseAcc;
        var eID = '';
        var infos = [];
        var userInfos;
        var admInfos;
        if(entryPriseInfoData._qryInfo.me4Enterprise){
            userInfos = entryPriseInfoData._qryInfo.me4Enterprise.enterpriseInfo;
            if(userInfos){
                $.each(userInfos,function(i,n){
                    infos.push(n);
                });
            }
        }
        if(entryPriseInfoData._qryInfo.myEnterprise){
            admInfos = entryPriseInfoData._qryInfo.myEnterprise.enterpriseInfo;
            if(admInfos){
                $.each(admInfos,function(i,n){
                    infos.push(n);
                });
            }
        }
        $.each(infos,function(i,n){
            if(acc == n.enterpriseAccnt){
                eID = n.enterpriseID;
                return false;
            }
        });
        return eID;
    }



};
