/*
 * 创建事件引擎
 */
caiyun.eventEngine = {};

// 初始化事件引擎
(function() {
	var ev = caiyun.eventEngine;
	// 事件主题与处理句柄的映射表
	var eventTopicHandlerMap = {};

	// 定义注册方法
	ev.subscribe = function(topic, handler) {
		if (topic && handler && $.type(topic) == 'string' && $.isFunction(handler)) {
			var list = eventTopicHandlerMap[topic];
			if (!list) {
				list = $([]);
				eventTopicHandlerMap[topic] = list;
			}
			list.push(handler);
		} else {
			throw new Error('注册事件参数错误：主题：' + topic + '事件：' + handler);
		}
	};

	// 发布事件
	ev.publish = function(event) {
		if (!event || !event.topic || !event.topic instanceof String) {
			throw new Error('发布事件参数错误：事件：' + event);
		}
		var list = eventTopicHandlerMap[event.topic];
		if (list) {
			list.each(function() {
				var handler = this;
				this(event);
			});
		}
	}
})();
