
/**
 * timeline
 */
caiyun.biz.timeline = {};
(function(){
	var ajax = caiyun.util.caiyunAjax;
	var timeline = caiyun.biz.timeline;
	
	/**
	 * timeline获取事件列表
	 */
	timeline.queryEvents = function(params,successCallback,errorCallback){
	 	var baseParams = {
            type    : 'post', 
            url     : '../webdisk2/timeLineAction!queryEvents.action', 
            dataType: 'json', 
            succFun : successCallback,
            errFun  : errorCallback
        };
        baseParams.data = params;        
        return ajax.ajaxRequest(baseParams);
	};
	
	/**
	 * 获取帐号的注册时间
	 */
	timeline.qryRegTime = function(successCallback,errorCallback){
	 	var baseParams = {
            type    : 'post', 
            url     : '../webdisk2/timeLineAction!qryRegTime.action', 
            dataType: 'json', 
            succFun : successCallback,
            errFun  : errorCallback
        };       
        return ajax.ajaxRequest(baseParams);
	};
	
	/**
	 * 获取帐号所属的企业
	 */
	timeline.getEnterpriceInfo = function(params,successCallback,errorCallback){
		var baseParams = {
            type    : 'post', 
            url     : '../enterprise/qryEnterpriceInfo.action', 
            dataType: 'json', 
            succFun : successCallback,
            errFun  : errorCallback,
			hideLoading : true
        };
        baseParams.data = params;        
        return ajax.ajaxRequest(baseParams);
	}
	
	/**
	 * timeline撤销事件
	 */
	timeline.restoreEvents = function(params,successCallback,errorCallback){
		var baseParams = {
            type    : 'get',
			//data    :  params ,
            url     : '../webdisk2/timeLineAction!restoreEvent.action',
            dataType: 'json',
            succFun : successCallback,
            errFun  : errorCallback
        };
        baseParams.data = params;
		return ajax.ajaxRequest(baseParams);
	};
	
	/**
	 * timeline查询文件信息
	 */
	timeline.queryContentInfo = function(params,successCallback,errorCallback){
		var baseParams = {
            type    : 'get',
			//data    :  params ,
            url     : '../webdisk2/getContentInfo!queryContentInfo.action',
            dataType: 'json',
            succFun : successCallback,
            errFun  : errorCallback
        };
        baseParams.data = params;
		return ajax.ajaxRequest(baseParams);
	};
	
	timeline.queryDisk = function(params,successCallback,errorCallback){
		var baseParams = {
            type    : 'post',
			//data    :  params ,
            url     : '../webdisk2/queryContentAndCatalog!disk.action',
            dataType: 'json',
            succFun : successCallback,
            errFun  : errorCallback
        };
        baseParams.data = params;
		return ajax.ajaxRequest(baseParams);
	};
		/**
	 * timeline查询用户网盘使用情况
	 */
	timeline.qryUserInfo = function(successCallback,errorCallback){
		var baseParams = {
            type    : 'post',			
            url     : '../webdisk2/timeLineAction!qryUserInfo.action',
            dataType: 'json',
            succFun : successCallback,
            errFun  : errorCallback
        };
        //baseParams.data = params;
		return ajax.ajaxRequest(baseParams);
	}
	
})();
