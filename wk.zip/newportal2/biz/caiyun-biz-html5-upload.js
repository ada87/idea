var Html5Util = {

	isHtml5Support : function() {
		return (typeof FormData != 'undefined') && (typeof File != 'undefined')
				&& (typeof FileList != 'undefined')
				&& (typeof XMLHttpRequest != 'undefined')
				&& (typeof new XMLHttpRequest().upload != 'undefined') 
				&& (navigator.userAgent.toLowerCase().indexOf('maxthon') ===-1);
	},

	/**
	 * @param dom
	 *            DOM element
	 * @param callBack
	 *            function(e) {}
	 */
	bindDragEnter : function(dom, callBack) {
		if (!dom) {
			return false;
		}

		dom.addEventListener("dragenter", function(e) {
			e.stopPropagation();
			e.preventDefault();

			if (typeof callBack == 'function') {
				callBack(e);
			}
		}, false); // false 表示使用冒泡事件处理
	},

	bindDragLeave : function(dom, callBack) {
		if (!dom) {
			return false;
		}

		dom.addEventListener("dragleave", function(e) {
			e.stopPropagation();
			e.preventDefault();

			if (typeof callBack == 'function') {
				callBack(e);
			}
		}, false);
	},

	bindDragOver : function(dom, callBack) {
		if (!dom) {
			return false;
		}

		dom.addEventListener("dragover", function(e) {
			e.stopPropagation();
			e.preventDefault();

			if (typeof callBack == 'function') {
				callBack(e);
			}
		}, false);
	},

	bindDrop : function(dom, callBack) {
		if (!dom) {
			return false;
		}

		dom.addEventListener("drop", function(e) {
			e.stopPropagation();
			e.preventDefault();

			if (typeof callBack == 'function') {
				callBack(e);
			}
		}, false);
	},

	getFileType : function(fileName) {
		var i = fileName.lastIndexOf('.');
		var type = '';
		if (i != -1) {
			type = fileName.substring(i + 1);
		} else {
			type = '';
		}

		return type;
	}
};

function UploadTask(file, targetDir, isSafeBox, index, actionTag, isQueueLast,isFromDrag) {
	this.file = file;
	this.targetDir = targetDir; // 上传的目标目录
	this.isSafeBox = isSafeBox; // 是否上传到保险箱

	this.name = file.name;
	this.size = file.size;
	this.type = Html5Util.getFileType(file.name); // 文件类型，后缀

	this.status = '0'; // 上传状态
	this.loaded = 0;// 已上传的大小
	this.lastUpdateTime = new Date().getTime(); // 上次更新进度的时间

	this.uploadUrl = null; // 文件上传的地址
	this.contentID = null; // 文件ID
	this.number = 'h5file_' + this.lastUpdateTime + '_' + index; // 文件序号，
	this.actionTag = actionTag;
	this.isQueueLast = isQueueLast;

	this.isCanceled = false; // 是否被取消
	this.isFromBrowser = isFromDrag; // 是否是HTML5上传操作，默认只记录拖拽
};

var Html5Upload = {
	maxByte : 4294967296, // 单个文件的最大字节数: 4GB

	ui : null, // 上传进度ui界面

	GlobalUploadTaskList : new Array(), // 待上传的文件队列

	isUploading : false, // 当前是否有文件正在上传

	currentTask : null, // 当前正在上传的文件所属的任务
	currentXHR : null, // 正在上传文件的XMLHttpRequest，用于取消操作
	
	scheduler : null,	// 定时器
	
	/**
	 * 定时调试方法
	 */
	quartzSendMsg : function(){
		if(window.caiyun.judgement.isSafeBox()){
			var param = {
                type    : "post", 
                url     : "/safeBoxAction.action", 
                dataType: 'json'
            };
       	    window.caiyun.util.caiyunAjax.ajaxRequest(param);           
		}
	},

	setCatalog : function(catalogID) { // 空方法，兼容flash
	},

	stop : function(fnumber) { // 停止上传文件fnumber，fnumber为null时退出整个上传

		var taskList = Html5Upload.GlobalUploadTaskList;
		if (!fnumber) { // 停止、移除所有的任务
			for (; taskList.length > 0;) {
				taskList.pop();
			}

			if (Html5Upload.currentTask && Html5Upload.currentXHR) {
				Html5Upload.currentXHR.abort();
			}
		} else {
			if (Html5Upload.currentTask && Html5Upload.currentXHR
					&& Html5Upload.currentTask.number == fnumber) {
				Html5Upload.currentXHR.abort();
			} else {
				var newArr = new Array();
				for (; taskList.length > 0;) {
					var task = taskList.shift();
					if (task.number != fnumber) {
						newArr.push(task);
					} else if (task.isQueueLast) { // 被删除任务，并且是最后一个任务，需要把前一个任务修改为最后一个
						var actionTag = task.actionTag;
						var pre = newArr[newArr.length - 1];
						if (pre && pre.actionTag == actionTag) { // 还有前驱任务在队列
							pre.isQueueLast = true;
						} else { // 前驱任务已出队列，看看当前任务是否是同一批
							var currentTask = Html5Upload.currentTask;
							if (currentTask.actionTag == actionTag) {
								currentTask.isQueueLast = true;
							}
						}
					}
				}

				Html5Upload.GlobalUploadTaskList = newArr;
			}

			Html5Upload.uploadRemain();
		}
	},

	submit : function() { // 由ui回调，开始上传
	},

	done : function() {
	},

	regUi : function(param) {
		var WebUpload = function(param) {
			// 复制配置参数
			for ( var i in param) {
				this[i] = param[i];
			}
		};
		Html5Upload.ui = new WebUpload(param);
	},

	/**
	 * 根据文件的大小、名称验证是否合法的
	 * 
	 * @param size
	 * @param name
	 * @returns {String}
	 */
	checkFile : function(size, name) {
		//提示语修改  去掉文件名包含的%#&
		var unallowedNameCharRegExp = /^.*[\\\/:\*\?\"\'<>\|]+.*$/;

		var type = Html5Util.getFileType(name);

		var code = '0';
		if (size < 1) {
			code = "5"; // 文件大小为0
		} else if (size > Html5Upload.maxByte) {
			code = "6"; // 文件过大
		} else if (type != null && type.length >= 11) { // 文件后缀过长
			code = "8";
		} else if (unallowedNameCharRegExp.test(name)) {// 文件名不符合
			code = "10";
		}

		return code;
	},

	/**
	 * @param param : {
	 *            files : FileList 对象，用户拖拽进来的文件。 
	 *            targetDirID : 上传的目标目录 
	 *            isSafeBox :true/false，是否上传到保险箱 
	 *            isFromDrag : true/false,是否属于拖拽操作
	 *            }
	 */
	addFiles : function(param) {
		var files = param.files;
		if (!files || files.length < 1) {
			return;
		}
		
		if(Html5Upload.GlobalUploadTaskList.length < 1) {
			Html5Upload.ui.startUpload();
		}

		var targetDirID = param.targetDirID;
		var isSafeBox = param.isSafeBox;
		var isFromDrag = param.isFromDrag;
		
		var actionTag = "0";
		if(files.length > 1 ){
			actionTag = new Date().getTime();
		}
		var lastOkTask = null;
		for ( var i = 0; i < files.length; i++) {
			var file = files[i];
			var task = new UploadTask(file, targetDirID, isSafeBox, i,
					actionTag, false,isFromDrag);

			task.code = Html5Upload.checkFile(file.size, file.name);
			Html5Upload.addTask2ui(task);

			if (task.code == '0') {
				lastOkTask = task;
				Html5Upload.GlobalUploadTaskList.push(task);
			}
		}

		if (lastOkTask) {
			lastOkTask.isQueueLast = true;
		}

		Html5Upload.ui.closeBrowseEnd();
		if(!Html5Upload.scheduler) {
			Html5Upload.scheduler = setInterval(Html5Upload.quartzSendMsg, 1000 * 30);
		}

		Html5Upload.uploadRemain();
	},

	addTask2ui : function(task) {
		// obj 格式:{code:'0', name:文件名, size:文件大小, number:文件编号, type:后缀}
		Html5Upload.ui.reportState({
			code : task.code,
			name : task.name,
			size : task.size,
			number : task.number,
			type : task.type,
			actionTag : task.actionTag
		}); // 添加任务到UI列表
	},

	// 开始上传队列里的任务
	uploadRemain : function() {
		var taskList = Html5Upload.GlobalUploadTaskList;
		if (taskList.length < 1) {
			Html5Upload.isUploading = false;
			Html5Upload.ui.loadDone(null);
			window.clearInterval(Html5Upload.scheduler);
			Html5Upload.scheduler = null;
			return;
		}
		
		if (Html5Upload.isUploading) {
			return;
		}
		var task = taskList.shift();
		Html5Upload.currentTask = task;
		Html5Upload.uploadFile();
	},

	/**
	 * 开始上传文件，执行step1，获取文件ID和上传路径
	 */
	uploadFile : function() {
		Html5Upload.isUploading = true;
		var task = Html5Upload.currentTask;

		var _data = {};
		_data['up[0].contentName'] = encodeURI(task.name);
		_data['up[0].contentSize'] = task.size;

		_data.param1 = task.targetDir; // 目标目录id
		_data.date = new Date().getTime();

		var _url = '', _jsonp = '';
		if (task.isSafeBox) {
			_url = address
					+ "/safebox/webdiskjsonp!webUploadFileRequest.action";
			_jsonp = "callback";
		} else {
			_url = "webdiskjsonp!webUploadFileRequest.action";
			_jsonp = "jsoncallback";
		}

		// 是否传递文件浏览所在目录的全路径，该path字段对共享协作有效
		_data.path = '';
		try {
            if(window.caiyun.judgement.isEnterprisePath()){
                var stackInfo  = window.caiyun.operate.getCatalogStack();
                _data.path = stackInfo[stackInfo.length-1].path;
            }else if (window.caiyun.judgement
					.isInCurrentCatalogs(window.caiyun.constants.cannotModifyIDs.root_receiveShare)) {
				_data.path = window.caiyun.judgement.getPath() || '';				
			}
            if (_data.path !== '') {
				_data.path = _data.path + '/' + task.targetDir;
			}
		} catch (e) {
		}

		// 是否使用ignore来表示该次上传属于多个上传中，通知后台忽略上报，由客户端统一处理
		if(task.actionTag !== '0') {
			_data.ignore = "true";
		}
		
		$.ajax({
			url : _url,
			data : _data,
			jsonp : _jsonp,
			dataType : "jsonp",
			type : "post",
			success : function(json) {
				// 保险箱超时处理
				if ((window.caiyun.judgement.isSafeBox() && json.isInvalid)) {
					window.caiyun.ui.iMsgTip.tip("上传操作超时，请您重新进入保险箱", "error");
					return false;
				}

				var r = json.result || json;
				if (r.code != "0") {
					Html5Upload.reportError(task.number, 'ajax', r.message);
					Html5Upload.uploadRemain(); // 开始上传文件数据
					return false;
				}

				if ($.trim(r.message) == "" && r.resultXml) {
					r.resultXml = r.resultXml.replace('</redirectionUrl>',
							'&oprChannel=9</redirectionUrl>');
				}

				var xml = $(r.resultXml);
				task.uploadUrl = xml.find('redirectionUrl').html();
				task.uploadUrl = task.uploadUrl.replace(/&amp;/g, '&');
				task.coderStr = Base64.encode(r.msisdn + ":"
						+ xml.find('uploadTaskID').html());
				task.contentID = xml.find('contentID').html();

				Html5Upload.doUpload(); // 开始上传文件数据
			},
			error : function(r) {
				Html5Upload.reportError(task.number, 'http', 'http error .');

				// 继续上传其余的
				Html5Upload.uploadRemain();
			}
		});
	},

	clearCurrentTask : function() {
		Html5Upload.currentTask = null;
		Html5Upload.currentXHR = null;
		Html5Upload.isUploading = false;
	},

	reportFileUploadOk : function(task) {
		Html5Upload.ui.reportFile({
			id : task.contentID,
			name : task.name,
			number : task.number,
			size : task.size,
			type : task.type,
			actionTag : task.actionTag,
			catalogId : task.targetDir,
			isQueueLast : task.isQueueLast,
			isFromBrowser : task.isFromBrowser
		});

		Html5Upload.clearCurrentTask();
	},

	setupUploadEventListener : function(xhrObj) {
		var task = Html5Upload.currentTask;

		xhrObj.upload.onload = function(evt) { // 传输成功完成。
			// console.log('upload ok :' + task.number + ', fname:' +
			// task.name);
			Html5Upload.reportFileUploadOk(task);
			Html5Upload.uploadRemain();
		};

		xhrObj.upload.onerror = function(evt) { // 传输中出现错误
			// console.log('error happend :' + task.number + ', fname:' +
			// task.name);
			Html5Upload.reportError(task.number, 'http', '');
			Html5Upload.uploadRemain();
		};

		xhrObj.upload.onabort = function(evt) { // 传输被用户取消
			// console.log('abort happend :' + task.number + ', fname:' +
			// task.name);
			Html5Upload.clearCurrentTask();
			Html5Upload.uploadRemain();
		};

		// xhrObj.upload.onprogress 上传进度
		// xhrObj.onprogress 下载进度
		xhrObj.upload.onprogress = function(evt) {
			if (evt.lengthComputable) {
				var curTime = new Date().getTime();
				var second = (curTime - task.lastUpdateTime) / 1000;
				if (second >= 1) { // 两次更新间隔至少一秒
					var byteSpeed = (evt.loaded - task.loaded) / second;
					Html5Upload.ui.uploadListen({
						number : task.number,
						filePercent : Math.round(evt.loaded / evt.total * 100),
						fileCompleted : evt.loaded,
						speed : byteSpeed, // X 字节/秒
						remainTime : Math.round((evt.total - evt.loaded)
								/ byteSpeed),
						state : 0
					});

					task.loaded = evt.loaded;
					task.lastUpdateTime = curTime;
				}
			}
		};
	},

	/**
	 * 上传文件的内容 至 根据 uploadFile 调用设置的上传路径
	 */
	doUpload : function() {
		var task = Html5Upload.currentTask;
		if (!task) {
			// console.log('task cancelled .');
			Html5Upload.uploadRemain();
			return false;
		}
		task.lastUpdateTime = new Date().getTime();

		// 通知ui要上传文件fnumber
		// console.log('start upload :' + task.number + ', fname:' + task.name);
		Html5Upload.ui.startFileUpload({
			number : task.number
		});

		var xhrObj = new XMLHttpRequest();
		xhrObj.dataType = 'json'; // 必须
		Html5Upload.currentXHR = xhrObj;

		Html5Upload.setupUploadEventListener(xhrObj);

		var formData = new FormData();
		task.file.name = encodeURIComponent(task.file.name);
		formData.append('file', task.file);
		formData.append('uploadCode', task.coderStr);

		xhrObj.open('POST', task.uploadUrl, true);

		xhrObj.send(formData);
	},

	reportError : function(fnumber, code, docs) {
		/**
		 * 监听事件，在文件上传过程发生异常时触发，异常不会中断上传过程，跳过发生异常的文件，继续下一个文件上传
		 * 
		 * @param {object}
		 *            obj 格式:{number:文件编号, code:异常类型[ajax, http, io, security],
		 *            docs:错误描述}
		 */
		Html5Upload.ui.reportError({
			"number" : fnumber,
			"code" : code,
			"docs" : docs
		});

		Html5Upload.clearCurrentTask();
	},

	startFileUpload : function(fnumber) {
		/**
		 * 监听事件，在startUpload之后，每个文件开始上传时触发，返回马上就要上传的文件编号。
		 * 
		 * @param {object}
		 *            obj 格式:{number:文件编号}
		 */
		Html5Upload.ui.startFileUpload({
			number : fnumber
		});
	}
};

var WCFGH5 = Html5Upload;
