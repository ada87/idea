 /**
  *封装了js与flash的交互(待整合HTML5上传初始化方法，以后统一成一份)
  */
;var upfiter=null
;(function($){
	$.fn.extend({
		ispaceUpload:function(param){
			upfiter=param.filter;
			caiyun.ui.model.schemeCache = {};
			var obj_temp = {
				width : 1,
				height : 1,
				background_over : "images/webdisk/s.gif",
				option : {
					wmode : "opaque",
					allowScriptAccess : "always"
				}
			};
			$.extend(obj_temp,param);
			//设置id,以便通过id来找到flash，如果使用jquery非id选择器渲染，自动创建一个id
			var id = this.attr('id');
			if (id){
				obj_temp.id = id;
			}else{
				obj_temp.id = 'ispace_upload_' + new Date().getTime();
				this.attr('id',obj_temp.id);
			}
			
			var WebUpload = function(obj){
				//复制配置参数
				for (var i in obj){
					this[i] = obj[i];
				}				
				//background_over为必须，判断图片是否绝对路径，相对路径为彩云服务器地址
				if (obj.background_over.indexOf('http://') == -1)
					obj.background_over = webuploadcfg.url + obj.background_over;
				
				//background_out和background_disabled没有时，取background_over图片
				if (obj.background_out){
					if (obj.background_out.indexOf('http://') == -1)
						obj.background_out = webuploadcfg.url + obj.background_out;
				}else
					obj.background_out = obj.background_over;
					
				if (obj.background_disabled){
					if (obj.background_disabled.indexOf('http://') == -1)
						obj.background_disabled = webuploadcfg.url + obj.background_disabled;
				}else
					obj.background_disabled = obj.background_over;
				if (obj.catalogId == undefined)
					obj.catalogId = "";
				this.background_over = obj.background_over;	
				this.background_out = obj.background_out;
				this.background_disabled = obj.background_disabled;
				this.catalogId = obj.catalogId;
				this.filter = obj.filter;
				var random = Math.random();
				swfobject.embedSWF('../flash/UpLoadComponent_purple.swf?s='+random, 
						obj.id, obj.width, obj.height, "9.0.0",	false, {}, obj.option);
				
			}
			webuploadcfg.target = new WebUpload(obj_temp);
			return this;
		}
	});
})(jQuery);

/**
 * @namespace 上传控制管理对象，全名webuploadcfg，简称WCFG <br/>(待整合HTML5上传回调方法，以后统一成一份)
 * 可配置参数<br/>
 * maxFile	一次上传文件个数限制<br/>
 * maxByte	单个文件大小限制<br/>
 * catalogId	上传指定的父目录id,默认空为根目录<br/>
 * background_over	flash上传按钮的背景，鼠标移入<br/>
 * background_out	flash上传按钮的背景，鼠标移出<br/>
 * background_disabled	flash正在上传按钮不可用的背景<br/>
 * width	flash 背景宽度<br/>
 * height	flash 背景高度<br/>
 * filter	文件过滤类型	
 */
var webuploadcfg = {
	url: null,
	userId: null,
	target: {},
	/**
	 * 上传管理对象的初始配置方法，指明加载flash和图片的路径
	 * @param {object} obj 格式:{basePath:服务器根目录地址，userId:统计用户id}
	 *  basePath是必须的，userId可以根据是否引用了statistics.js来给值
	 */
	init: function(obj){
		webuploadcfg.url = obj.basePath;
		if (obj.userId)
			webuploadcfg.userId = obj.userId;
		else
			webuploadcfg.userId = "";
	},
	/**
	 * 根据id取得flash对象，如果id不存在返回空方法对象
	 * @param {string} id
	 * @return {object}
	 */
	getSWF: function(id){
		var swf = null;
		if (id){
			if($.browser.msie){
				swf = window[id];
			}
			else{
				swf = document[id];
			}
			return swf;
		}else{
			//返回模拟flash调用，防止在渲染flash时异常，造成的没有调用方法
			return {
				version: webuploadcfg.NULL, 
				done: webuploadcfg.NULL, 
				queue: webuploadcfg.NULL,  
				list: webuploadcfg.NULL,  
				setCatalog: webuploadcfg.NULL, 
				getCatalog: webuploadcfg.NULL, 
				submit: webuploadcfg.NULL, 
				stop: webuploadcfg.NULL,
				isDone: webuploadcfg.NULL
			};
		}
	},
	/**
	 * @ignore
	 */
	NULL : function(){},
	//flash文件选择框关闭前，还没验证文件时调用
	/**
	 * 监听事件，在window文件选择框关闭后，flash对选择文件验证后触发，返回可上传文件个数
	 * @param {object} obj 格式:{passable:0}
	 */
	closeBrowseEnd: function(obj){
		if (webuploadcfg.target.closeBrowseEnd)
			webuploadcfg.target.closeBrowseEnd.call(null, obj);
	},
	/**
	 * 监听事件，在flash开始上传时发现异常触发
	 * @param {object} obj 格式:{code:'1'}
	 */
	noPassing: function(obj){
		if (webuploadcfg.target.noPassing)
			webuploadcfg.target.noPassing.call(null,obj);
	},
	/**
	 * 监听事件，在window文件选择框关闭后，flash验证文件时触发，返回文件信息。
	 * @param {object} obj 格式:{code:'0', name:文件名, size:文件大小, number:文件编号, type:后缀}	
	 */
	reportState: function(obj){
		if (webuploadcfg.target.reportState)
			webuploadcfg.target.reportState.call(null,obj);
	},
	/**
	 * 监听事件，在flash开始上传流程时触发，返回该批次上传信息
	 * @param {object} obj undefined
	 */
	startUpload: function(obj){
		if (webuploadcfg.target.startUpload){
			webuploadcfg.target.startUpload.call(null,obj);
		}
	},
	/**
	 * 监听事件，在startUpload之后，每个文件开始上传时触发，返回马上就要上传的文件编号。
	 * @param {object} obj 格式:{number:文件编号}
	 */
	startFileUpload: function(obj){
		if (webuploadcfg.target.startFileUpload){
			webuploadcfg.target.startFileUpload.call(null,obj);
		}
	},	
	/**
	 * 监听事件，监听上传进度
	 * @param {object} obj 
	 * 格式:{filePercent:文件进度百分比, fileCompleted:文件已上传大小,speed:上传速度, remainTime :剩余时间, 
	 * state:当前状态[1:上传第一步，0:上传中，2:大数据时转移数据中  ]}
	 */
	uploadListen: function(obj){
		if (webuploadcfg.target.uploadListen){
			webuploadcfg.target.uploadListen.call(null,obj);
		}
	},
	/**
	 * 监听事件，在文件上传过程发生异常时触发，异常不会中断上传过程，跳过发生异常的文件，继续下一个文件上传
	 * @param {object} obj 格式:{number:文件编号, code:异常类型[ajax, http, io, security], docs:错误描述}
	 */
	reportError: function(obj){
		if (webuploadcfg.target.reportError){
			//过滤IE和firefox异常描述的差异
			obj.docs = decodeURIComponent(obj.docs);
			var end = obj.docs.indexOf(":");
			if (end != -1)
				obj.docs = obj.docs.substring(0, end);
			webuploadcfg.target.reportError.call(null, obj);
		}
	},
	/**
	 * 监听事件，在单个文件上传完成后触发。
	 * @param {object} obj 格式:{id:文件id, name:文件名, number:文件编号, size:文件大小, type:文件后缀}
	 */
	reportFile: function(obj){
		if (webuploadcfg.target.reportFile){
			webuploadcfg.target.reportFile.call(null,obj);
		}
	},
	/**
	 * 监听事件，在上传流程完成后触发。
	 * @param {object} obj undefined 
	 */
	loadDone: function(obj){
		if (webuploadcfg.target.loadDone)
			webuploadcfg.target.loadDone.call(null,obj);		
	},
	/**
	 * 上传第一步请求
	 * @ignore
	 * @param {object} obj
	 * @param {string} number
	 */
	beforeHand: function(obj, number){
		var _url = null,_jsonp = null;
		var scheme = caiyun.ui.model.schemeCache[number];
		
		var data = new Object();
		data.param1 = obj.catalogId ;
		data.date = new Date().getTime();
		$.each(obj.uploadContentList, function(i,o){
			data['up[' + i + '].contentName'] = encodeURI(o.name);
			data['up[' + i + '].contentSize'] = o.size;
			data['up[' + i + '].contentTAG'] = o.tag;
			data['up[' + i + '].contentDescription'] = o.desc;
		});
		
		if(scheme === "https"){
			_url = address + "/safebox/webdiskjsonp!webUploadFileRequest.action";
			_jsonp = "callback";
		}else{
			_url = "webdiskjsonp!webUploadFileRequest.action";
			_jsonp = "jsoncallback";
		}
		
		// 是否传递文件浏览所在目录的全路径，该path字段对共享协作有效
		try {
			if(window.caiyun.judgement.isInCurrentCatalogs(window.caiyun.constants.cannotModifyIDs.root_receiveShare)) {
				data.path = window.caiyun.judgement.getPath() || '';
			}else if(window.caiyun.judgement.isEnterprisePath()){
                var stackInfo  = window.caiyun.operate.getCatalogStack();
                data.path = stackInfo[stackInfo.length-1].path;
            }
		} catch (e) {
			data.path = '';
		}
		
		// 是否使用ignore来表示该次上传属于多个上传中，通知后台忽略上报，由客户端统一处理
		if(obj.actionTag !== '0') {
			data.ignore = "true";
		}
		
		$.ajax({
			url: _url,
			data: data,
			jsonp:_jsonp,
			dataType: "jsonp",
			type: "post",
			success: function(json){
				//  保险箱超时处理
				if((window.caiyun.judgement.isSafeBox() && json.isInvalid)) {
					var res = {};
					res.code  =  "0";
					res.message = "SAFEBOX UPLOAD TIMEOUT";
					res.resultXml = "http://";
					webuploadcfg.doUpload(res);
					window.caiyun.ui.iMsgTip.tip("上传操作超时，请您重新进入保险箱","error");
					//window.caiyun.ui.model.leftNav.clickChannel(window.caiyun.constants.rootIds.mySafeBox);
					return false;
				}
				var r = json.result || json;
				if($.trim(r.message) == "" 
					&& r.resultXml){
					r.resultXml = r.resultXml.replace('</redirectionUrl>','&oprChannel=9</redirectionUrl>');
				}
				webuploadcfg.doUpload(r);
			},
			error: function(r){
				WCFG.reportError({
					"number" : number,
					"code" : 'http',
					"docs" : 'connection error:'+r.status
				});
				WCFG.stop(number);
			}
		});
	},
	/**
	 * 执行flash上传
	 */
	doUpload: function(r) {
		var swf = webuploadcfg.getSWF(webuploadcfg.target.id);
		try{
			swf.upload(r);
		}catch(e){

		}
	},
	/**
	 * 查看flash的版本号
	 * @return {string} 版本号
	 */
	version: function(){
		var swf = webuploadcfg.getSWF(webuploadcfg.target.id);
		try{
			return swf.showVersion();
		}catch(e){
			return "";
		}
	},
	/**
	 * 查看上传流程是否完成
	 * @return {boolean} false没有上传或上传结束  true正在上传
	 */
	done: function(){
		var swf = webuploadcfg.getSWF(webuploadcfg.target.id);
		try{
			return swf.isDone();
		}catch(e){
			return null;
		}
	},
	/**
	 * 查看flash中就绪的待上传文件信息
	 * @return {object}
	 */
	queue: function(){
		var swf = webuploadcfg.getSWF(webuploadcfg.target.id);
		try{
			return swf.showQueue();
		}catch(e){
			return null;
		}
	},
	/**
	 * 查看flash中已上传文件信息
	 * @return {object}
	 */
	list: function(){
		var swf = webuploadcfg.getSWF(webuploadcfg.target.id);
		try{
			return swf.showList();
		}catch(e){
			return null;
		}
	},
	/**
	 * 设置上传目录
	 * @param {} cid
	 */
	setCatalog: function(cid){
		var swf = webuploadcfg.getSWF(webuploadcfg.target.id);
		try{
			swf.setCatalog(cid);
		}catch(e){
			
		}
		
	},
	/**
	 * 取得上传目录
	 * @return {string} 目录id
	 */
	getCatalog: function(){
		var swf = webuploadcfg.getSWF(webuploadcfg.target.id);
		try{
			return swf.getCatalog();
		}catch(e){
			return null;
		}
	},
	
	setFilters: function(obj){
        var swf = webuploadcfg.getSWF(webuploadcfg.target.id);
        try{
        	return swf.setFilters(obj);		
        }catch(e){
        	return null;
        }
        
	},
	
	/**
	 * 执行上传流程
	 */
	submit: function(){
		var swf = webuploadcfg.getSWF(webuploadcfg.target.id);
		try{
			swf.startUp();
		}catch(e){
			
		}
		
	},
	
	/**
	 * 定时调试方法
	 */
	quartzSendMsg : function(){
		if(window.caiyun.judgement.isSafeBox()){
			var param = {
                type    : "post", 
                url     : "/safeBoxAction.action", 
                dataType: 'json'
            };
       	    window.caiyun.util.caiyunAjax.ajaxRequest(param);           
		}
	},
	
	/**
	 * 删除一个flash中的上传文件，文件可能是待上传文件或正在上传文件，如果是正在上传文件，将停上该文件上传，继续下一个文件上传
	 * @param {string} number 文件编号，如果不传，中止整个上传流程
	 * @return {bollean} false失败 true成功
	 */
	stop: function(number){
		var swf = webuploadcfg.getSWF(webuploadcfg.target.id);
		try{
			return swf.stopUp(number);
		}catch(e){
			return null;
		}
	},
	/**
	 * @ignore
	 */
	destory: function(){
		if($.browser.msie){
			var swf = webuploadcfg.getSWF(webuploadcfg.target.id);
			if (swf){	//IE下手动清除flash函数引用
				for (var i in swf){
					if (typeof (swf[i]) == "function")
						swf[i] = null;
				}
			}
		}
		webuploadcfg.target = {};
	},
	/**
	 * 测试用
	 * @ignore
	 */
	test: function(obj){
	}
};

var WCFG = webuploadcfg;

function newflexOnReady(){
	return {
		maxByte: webuploadcfg.target.maxSize.size,				//*单个文件大小限制
		background_over: webuploadcfg.target.background_over,	//*flash上传按钮的背景，鼠标移入	
		width: webuploadcfg.target.width,						//*flash 背景宽度
		height: webuploadcfg.target.height,						//*flash 背景高度
		filter: upfiter,						//文件选择过滤数组   filterTxt显示的名称  filterType过滤类型
		closeBrowseEnd: "webuploadcfg.closeBrowseEnd",			//文件选择框关闭，对所选文件已做验证分类，回调js的方法名
		reportState: "webuploadcfg.reportState",				//文件选择框关闭后，选中文件的情况，回调js的方法名
		noPassing: "webuploadcfg.noPassing", 					//开始上传前验证不通过，回调js的方法名
		startUpload: "webuploadcfg.startUpload",				//通知页面开始上传，回调js的方法名
		startFileUpload: "webuploadcfg.startFileUpload",		//通知页面单个文件开始上传，回调js的方法名
		uploadListen: "webuploadcfg.uploadListen",				//报告上传进度，回调js的方法名
		reportError: "webuploadcfg.reportError",				//上传出错时，回调js的方法名
		reportFile: "webuploadcfg.reportFile",					//单个文件上传完成后,回调js的方法名			
		loadDone: "webuploadcfg.loadDone",	 					//上传完成，回调js的方法名 
		beforeHand: "webuploadcfg.beforeHand",					//第一步请求，回调js的方法名
		quartzSendMsg : "webuploadcfg.quartzSendMsg",           //定时调用方法
		setFilters: "webuploadcfg.setFilters",
		test: "webuploadcfg.test",	
		time : 30000
	};
};