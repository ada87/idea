caiyun.biz = caiyun.biz ? caiyun.biz : {};
caiyun.biz.userManager = {};

/**
 * 定义跟用户相关的操作
 */
(function(){
	
	var userManager = caiyun.biz.userManager;
	
	/**
	 * 查询用户渠道信息
	 * 
	 * 结果
	 * message 			信息，为空表示正常
	 * channelInfos[{	渠道信息列表
	 * 		appName		应用来源，例如：飞信
	 * 		channel		渠道编号
     *		description	渠道描述，例如：来自飞信
	 * },...] 	
	 */
	userManager.queryChannelInfo = function(params,successCallback,errorCallback){
		
	};
	
	/**
	 * 查询用户配置信息
	 * 
	 * 参数列表
	 * params{
	 * 		key // 查询的配置项名称
	 * }
	 * 
	 * 结果
	 * message		信息，为空表示正常
	 * val			配置值
	 */
	userManager.queryUserConfig = function(params,successCallback,errorCallback){
		
	};
	
	/**
	 * 设置用户配置信息
	 * 
	 * 参数列表
	 * params{
	 * 		key		// 配置项名称
	 * 		value	// 配置项值
	 * }
	 * 
	 * 结果
	 * message 		消息，为空表示正常
	 */
	userManager.setUserConfig = function(params,successCallback,errorCallback){
		
	};
	
	/**
	 * 查询用户网盘信息
	 * 
	 * 参数列表
	 * 无
	 * 
	 * 结果
	 * showMessage	消息，为空表示正常
	 * userDiskInfo{
	 * 		diskSize		彩云空间总大小，MB
	 * 		freeDiskSize	可用空间大小，MB
	 * 		resultcode		错误码
	 * 		tipSwitch		空间利用率的提醒
	 * 		userDiskSize	已经使用的彩云空间，MB
	 * }
	 */
	userManager.queryDiskInfo = function(params,successCallback,errorCallback){
		
	};
	
	/**
	 * 查询用户应用信息
	 * 
	 * 参数列表
	 * 无
	 * 
	 * 结果
	 * showMessage	消息，为空表示正常
	 * appInfos{
	 * 		arrayLength		数组长度
	 * 		appInfoList[APPINFO,...]	应用信息数组
	 * 		resultCode		错误码
	 * }
	 * 
	 * APPINFO请见OSE接口文档
	 */
	userManager.queryAppInfos = function(params,successCallback,errorCallback){
	};
}
)();