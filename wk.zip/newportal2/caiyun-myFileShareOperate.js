/**
 * 文件分享视图
 */
(function(){
    window.caiyun.myFileShareOperate = (function(){
		var constants = window.caiyun.constants;
        var fileShare = caiyun.biz.fileShare;
        //查询数据初始参数，用于保存状态之用
        var queryParams = {
			account : ownerMSISDN,
			sndRcv : "0",
			status : "2",
			readStatus : "0",
			retrievalItem : "0"
		};
        //保存查询时参数
        var newQueryParams;
        //查询数据初页数
        var startPage = 1;
        //是否是滚动加载数据请求
        var isScrollLoad = false;
        //是否是否滚动中
        var scrolling = false;

		var listens = {};
		//文件总数
		var count = 0;
		//当前选中的Ids
		var selectedIDs =[];
		
		var sortType = {
			'asc' : '1',
			'desc' : '0'
		};
		var sortFields = {
			'time' : '0',   //更新时间
			'name' : '1',   //名称
			'type' : '2',   //类型
			'size' : '3',   //大小
			'sharer': '4'   //发送共享者
		};

        //存储企业管理员分享的数据
        var entEntryInfos;
		
		//操作的key
		var keys = {
			enterFileShare : 'enterFileShare',      //进入文件分享
			loadData : 'loadData',                  //加载分享数据成功事件
            inviteFileShare : 'inviteFileShare',    //邀请分享
			cancelFileShare :'cancelFileShare',     //取消分享
            leaveFileShare : 'leaveFileShare',      //退出文件分享
            entryEnteprise: 'entryEnteprise',
			getShareInfo : 'getShareInfo',          //获取文件分享详情
			memberManager : 'memberManager',        //成员管理
			selectData:'selectData'                 //当前选择数据
		};
        
        /**
         * @params
         *      params.sortField  排序字段
         *      params.sortType   排序顺序
         */
        var sortHandler = function(params){
			sortClear();
			queryParams["orderField"]= sortFields[params.sortField];
			queryParams["order"] = sortType[params.sortType];
			loadFileShareInfos();
		};
		
		var getFileSrc = function(key){
			return window.caiyun.util.cache.getInstanceCache(constants.FILE_SHARE_LIST_CACHEGROUP).getValue(key) || '';
		};
		
		var selectHandler = function(ids,total) {
			selectedIDs = ids;
			trigger(keys.selectData, ids,total);
		};
		
        
        var getQueryParams = function(param){
            return {
				account:ownerMSISDN,
				sndRcv: "0",
				readStatus:"0",
				retrievalItem:"0",
				status:"0",		
				shrType:"2",
                orderField: param.orderField || constants.gridInitConfig.myFileShareSrt,
                order: param.order || sortType.desc,
                startRange: param.bNum || constants.gridInitConfig.startNum,
                endRange: param.eNum || constants.gridInitConfig.endNum
            };
            
        };
		
		var reload = function(){
			var $sortBySize = $('#share_title1');
			var $sortByTime = $('#share_title3');
			var $sortByTimeArrow = $sortByTime.find('.arrow');
			var $sortBySizeArrow = $sortBySize.find('.arrow');
			if($sortBySizeArrow.is(':hidden') && $sortByTimeArrow.is(':hidden')) {
				$sortByTimeArrow.removeClass('m_time_up m_time_down').addClass('m_time_down').show();
        	}
			sortClear();
			loadFileShareInfos();
		}
		
		var loadFileShareInfos = function(){
			trigger(keys.enterFileShare,[]);
			window.caiyun.util.cache.clearFileCache(constants.FILE_SHARE_LIST_CACHEGROUP);
			getFileShareInfos(queryParams);
		};
       
		//加载我的文件分享
        var getFileShareInfos = function(param){
            if(constants.abortAjaxs){
                constants.abortAjaxs.abort();
            }
            if(constants.abortShareAjaxs){
       		 constants.abortShareAjaxs.abort();
            }
            newQueryParams = getQueryParams(param);
            
//			2013.10 屏蔽企业入口（首页-共享管理）
            /*
            var EpParam ={
                account : ownerMSISDN,
                loginMsisdn : "",
                filter : "1100000000",
                startNumber:"1",
                endNumber:"10"
            };
*/
            //分页时不加载企业管理
//            if(newQueryParams.startRange >40){
            	constants.abortShareAjaxs = fileShare.getShareList(newQueryParams, queryFileShareSuccCallBack, queryFileShareFailCallBack);
//            }else{
//            	constants.abortAjaxs = caiyun.biz.enterprise.qryEntEntry(EpParam,queryEntEntrySuccCallBack,queryEntEntryFailCallBack);
//            }
            
            scrolling = true;
            // 显示加载更多的提示栏
			$('#listLoading').fadeIn('fast');
        };

        var queryEntEntrySuccCallBack = function(param,data){
            if(data.resultCode == "0" && data.entrys!= null){
                entEntryInfos = data.entrys.entEntry;
            }
            constants.abortShareAjaxs = fileShare.getShareList(newQueryParams, queryFileShareSuccCallBack, queryFileShareFailCallBack);
        };

        var queryEntEntryFailCallBack = function(param,data){
        	constants.abortShareAjaxs = fileShare.getShareList(newQueryParams, queryFileShareSuccCallBack, queryFileShareFailCallBack);
        };

        var queryFileShareSuccCallBack = function(params, data){
			scrolling = false;
			$('#listLoading').fadeOut('slow');
			if (data.resultCode) {
				if(data.resultCode == "0"){
					scrollLoadSucc();
					//过滤数据
					var dci ={};
                    var cataInfos = [];
                    var conInfos = [];
                    var listRsp = data.getShareListRsp;
                    var detailShareRspInfo = listRsp.detailShareRspInfoList.detailShareRspInfo;
                    var shareType = "";
                    var updateTime = "";
                    var shareTime = "";
                    //如果有我分享的文件数据
                    if(detailShareRspInfo){
					    $.each(detailShareRspInfo, function(i, data){
                            //将企业分享加入
                            if(entEntryInfos){
                                $.each(entEntryInfos,function(i,data){
                                	var extCata = data.entry.extCatalogProps.item;
                                	if(extCata){
                                		$.each(extCata,function (j,extCata){
                                			if(extCata.key = "shareType"){
                                				shareType = extCata.value;
                                			}
                                			if(extCata.key = "updateTime"){
                                				updateTime = extCata.value;
                                			}
                                			if(extCata.key = "shareTime"){
                                				shareTime = extCata.value;
                                			}
                                		})
                                	}
                                    var epCataInfo ={
                                        catalogID : data.entry.catalogID,
                                        catalogName: data.entry.name,
                                        path:data.entry.path,
                                        shareType : shareType,
                                        owner:data.entAccnt,
                                        parentCatalogId:data.entry.parentCatalogID,
                                        updateTime:updateTime,
                                        shareTime:shareTime
                                    };
                                    cataInfos.push(epCataInfo);
                                });
                                //只添加一次企业数据到cataInfos中
                                entEntryInfos = null;
                            }
                            if (data.catalogInfo) {
						    	var cat_arrs = [];
						    	cat_arrs[0] = data.shareTime;
						    	cataInfos.push($.extend({},cat_arrs,data.catalogInfo));
						    };
						    if (data.contentInfo) {
						    	var con_arrs = [];
						    	con_arrs[0] = data.shareTime;
						    	conInfos.push($.extend({},con_arrs,data.contentInfo));
						    };
					    });
					    dci = {cataloginfos:cataInfos,contents:conInfos,totalNums:listRsp.totalNums};
				    }else{
                        if(entEntryInfos){
                        	var shareType = "";
                  			var updateTime = "";
                   			var shareTime = "";
                            $.each(entEntryInfos,function(i,data){
                            	var extCata = data.entry.extCatalogProps.item;
                                	if(extCata){
                                		$.each(extCata,function (j,extCata){
                                			if(extCata.key = "shareType"){
                                				shareType = extCata.value;
                                			}
                                			if(extCata.key = "updateTime"){
                                				updateTime = extCata.value;
                                			}
                                			if(extCata.key = "shareTime"){
                                				shareTime = extCata.value;
                                			}
                                		})
                                	}
                                var epCataInfo ={
                                    entAccnt : data.entAccnt,
                                    catalogID : data.entry.catalogID,
                                    catalogName: data.entry.name,
                                    shareType : shareType,
                                    path:data.entry.path,
                                    owner:data.entry.owner,
                                    parentCatalogId:data.entry.parentCatalogID,
                                    updateTime:updateTime,
                                    shareTime:shareTime
                                };
                                cataInfos.push(epCataInfo);
                            });
                            dci = {cataloginfos:cataInfos,contents:null,totalNums:entEntryInfos.strlength};
                        }
                    }
				    // 数据放入缓存
				    window.caiyun.util.cache.putMyFileShareCache(constants.FILE_MY_FILE_SHARE_LIST_CACHEGROUP,dci);
				    count = listRsp.totalNums;
				    // 列表添加数据
				    trigger(keys.loadData, dci);
				}
				else{
					caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试...","error");
				}
			}
			else{
				caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试...","error");
			}
        };
        
        var queryFileShareFailCallBack = function(request, textStatus, errorThrown, params){
            //弹出error对话框
			 scrolling = false;
			 if(!constants.abortAjaxs_share && !constants.abortShareAjaxs){
				 caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试...","error");
	         }
			 $('#listLoading').fadeOut('slow');
			 
        };

        //退出共享
        var leaveFileShare = function(params){
            var contentHtml = '<div class="system_main"></div><div class="off_line_tips_YN"><div class="tips_img"></div><div class="floatleft"><p>取消后，文件将不再公开</p><p>是否确定取消</p></div></div>';
            var dialog = caiyun.ui.msgBox({
            	width : 580,
                title:"退出分享",
                html:contentHtml,
                okHandle:function(){
                    fileShare.leaveShare(params,leaveFileShareSuccCallBack,leaveFileShareFailCallBack);
                    dialog.close();
                }
            });

        };
		
		var leaveFileShareSuccCallBack = function(data,response){
            if(null == response)
            {
                caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试...", "error");
                return false;
            }
            if(null != response.showMessage && "" != response.showMessage)
            {
                caiyun.ui.iMsgTip.tip("退出分享失败","error");
                return false;
            }else {
                if(response.resultCode == "0")
                {
                    caiyun.ui.iMsgTip.tip("退出分享成功！", "success",3);
                    reload();
                }
                else{
                    caiyun.ui.iMsgTip.tip("退出分享失败","error");
                }
            }
        };

        var leaveFileShareFailCallBack  = function(req,textStatus,errorThrown,params){
            caiyun.ui.iMsgTip.tip("系统繁忙,请稍后再试...","error");
        };
        
		//成员管理
		var memberManager = function(id){
            var seleId = id || selectedIDs[0];
            var data  = window.caiyun.util.cache.getMyFileShareCache(caiyun.constants.FILE_MY_FILE_SHARE_LIST_CACHEGROUP,seleId);
            //如果是点击企业空间的成员管理
            if(data.shareType == 4){
                window.location.href = '../enterprise/getEnterpriseMember.action';
            }else{
                trigger(keys.memberManager,[seleId]);
            }
		};

        //企业管理员进入企业空间
        var enterEnterpriseSpace = function(id){
            var  id = id || selectedIDs[0];
            var data = window.caiyun.util.cache.getFileShareCache(constants.FILE_MY_FILE_SHARE_LIST_CACHEGROUP,id);
            caiyun.ui.model.fileContent.switchToView(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW);
            caiyun.operate.enterDir(data.catalogID,data);
            trigger(keys.entryEnteprise,data);            
        };
		
		
		//获取分享信息，用于成员管理。通知sharememberbox
		var getShareInfo = function(ids){
			trigger(keys.getShareInfo,ids || selectedIDs);
		};
		
		//取消分享
		var cancelFileShare = function(id){
			var seleId = id || selectedIDs[0];
            var data  = window.caiyun.util.cache.getMyFileShareCache(caiyun.constants.FILE_MY_FILE_SHARE_LIST_CACHEGROUP,seleId);
            if(data == undefined){
            	data = window.caiyun.util.cache.getFileCache(caiyun.constants.FILE_LIST_CACHEGROUP,seleId);
            }
            var objType = "";
            var name = "";
            if(data.catalogID){
                objType = "2";
                name = data.catalogName;
            };
            if(data.contentID){
                objType = "1";
                name = data.contentName;
            };
			var dirFileID = {
				objID: seleId,
				objType: objType,
				name: name
			};
			var params = {sharer:ownerMSISDN,sharingRscID:dirFileID};
			var contentHtml = '<div class="system_main"></div><div class="off_line_tips_YN"><div class="tips_img"></div><div class="floatleft"><p style="line-height: 50px;_width:378px;">取消后，文件将不再公开，好友将无法再访问此文件（夹）。</p></div></div>';
			var dialog = caiyun.ui.msgBox({
				width : 580,
				title:"取消分享",
				html:contentHtml,
				okHandle:function(){
					fileShare.cancelShare(parseParam(params),cancelFileShareSuccCallBack,cancelFileShareFailCallBack);
					//取消分享pv统计
					caiyun.pvlog("fileShare","cancelShare",dirFileID.objID,data.contentType?data.contentType:"0",data.contentSize?data.contentSize:0,data.contentSuffix?data.contentSuffix:"");
					dialog.close();
				}
			});
			dialog.show();
			//统计取消分享操作
		};
		
		var cancelFileShareSuccCallBack = function(data,response){
			if(null == response)
			{
				caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试...", "error");
				return false;
			}
			if(null != response.showMessage && "" != response.showMessage)
			{	
				caiyun.ui.iMsgTip.tip("取消分享失败","error");
				return false;
			}else {
				if(response.resultCode == "0")
				{
					caiyun.ui.iMsgTip.tip("取消分享成功！", "success",3);
					if(caiyun.ui.model.fileContent.getCurrentView() === constants.DEFAULT_FILE_CONTENT_VIEW){//在mcloud目录下的刷新
						window.caiyun.operate.reLoad();
					}else{//在分享管理下的刷新
						reload();
					}
					
					trigger(keys.cancelFileShare,"");
					//排序样式重置
					var $sortBySize = $('#share_title1');
					var $sortByTime = $('#share_title3');
					var $sortByTimeArrow = $sortByTime.find('.arrow');
					var $sortBySizeArrow = $sortBySize.find('.arrow');
					$sortByTimeArrow.removeClass('m_time_up m_time_down').addClass('m_time_down').show();
					$sortBySizeArrow.removeClass('m_time_up m_time_down').addClass('m_time_down').hide();
				}
				else{
					caiyun.ui.iMsgTip.tip("取消分享失败","error");
				}
			}
		};
        
		var cancelFileShareFailCallBack = function(req,textStatus,errorThrown,params){
			
			caiyun.ui.iMsgTip.tip("系统繁忙,请稍后再试...","error");
		};
		
		//设置共享已读
		var replyShare = function(params){
			fileShare.replyShare(params,replyShareSuccCallBack,replyShareFailCallBack);
		}

        var replyShareSuccCallBack = function(){
            return false;
        };

        var replyShareFailCallBack = function(){
            return false;
        };
		
        //对外滚动条数据加载回调函数
        var scrollBottomLoadData = function(){

			// 超出页数不做查询
			count = count || 0;
			var curPage = Math.ceil(count/constants.gridInitConfig.endNum);
            // 处理中，不操作
            if (scrolling || startPage >= curPage) {
                return;
            }
			scrolling = true;
            isScrollLoad = true;
            var startNumber = startPage * constants.gridInitConfig.endNum + 1;
            var endNumber = (startPage + 1) * constants.gridInitConfig.endNum;
            
            getFileShareInfos($.extend(queryParams, {
                bNum: startNumber,
                eNum: endNumber
            }));
        };

		
		// 是否存在新数据
        var hasNewData = function(json){
            if (!json) {
                return false;
            }
            if (json.count > 0) {
                return true;
            }
        };
		
		//滚动数据查询中止或是失败时对于page的恢复
        var scrollLoadSucc = function(){
            if (isScrollLoad) {
                startPage++;
            }
        };
		
		//排序查询数据前的清理工作
        var sortClear = function(){
            //文件缓存清空
            window.caiyun.util.cache.clearFileCache(constants.FILE_SHARE_LIST_CACHEGROUP);
            startPage = 1;
			count = 0;
            isScrollLoad = false;
			queryParams = {
				linkType: 0
			}
        };
		
		//分享文件
		var  inivteShareFile = function(param){
			fileShare.inviteShare(param,inviteFileShareSuccCallBack,inviteShareFailCallBack);
		};
		
		var inviteFileShareSuccCallBack = function(req,resp){
		    var shareRspInfoArray = resp.inviteShareRes.shareRspInfoList.shareRspInfo;
		    var sensitiveFiles = []; // 文件名含有敏感字的文件
		    var shareSuccFiles = []; // 分享成功的文件
		    var shareFailFiles = []; // 其他原因分享失败的文件
		    var shareRspInfo = null;
		    for (var i = 0, length = shareRspInfoArray.length; i < length; i++) {
		        shareRspInfo = shareRspInfoArray[i]
		        if (shareRspInfo.result === "0") {
		          shareSuccFiles.push(shareRspInfo);
		        } else if (shareRspInfo.result === "9470") {
		          sensitiveFiles.push(shareRspInfo);
		        } else {
		          shareFailFiles.push(shareRspInfo);
		        }
		    }
			if(null != resp.showMessage && "" != resp.showMessage)
			{
				if("error_01" == resp.showMessage)
				{
					caiyun.ui.iMsgTip.tip("您尚未登录", "error");
				}
				else if("error_02" == resp.showMessage)
				{
					caiyun.ui.iMsgTip.tip("请求参数不正确", "error");
				}
				else if("error_03" == resp.showMessage)
				{
					caiyun.ui.iMsgTip.tip("系统异常，请稍后再试...", "error");
				}
				else if("error_04" == resp.showMessage)
				{
					caiyun.ui.iMsgTip.tip("请求文件数不能超过20", "error");
				}
				else if("error_05" == resp.showMessage)
				{
					caiyun.ui.iMsgTip.tip("请求文件夹数不能超过20", "error");
				}
				else if("error_06" == resp.showMessage)
				{
					caiyun.ui.iMsgTip.tip("共享人数不能超过50", "error");
				}
				return false;
			}
			if (sensitiveFiles.length > 0 && shareSuccFiles.length === 0 && shareFailFiles.length === 0) 
            {
                 caiyun.ui.iMsgTip.tip("文件名含有敏感词，请修改后重试", "error");
            } else if (sensitiveFiles.length === 0 && shareSuccFiles.length === 0 && shareFailFiles.length > 0) 
            {
                 caiyun.ui.iMsgTip.tip("分享失败，请稍后重试", "error");
            } else if (sensitiveFiles.length > 0 && shareSuccFiles.length === 0 && shareFailFiles.length > 0) 
            {
                 caiyun.ui.iMsgTip.tip("分享失败，请稍后重试", "error");
            } else if (shareSuccFiles.length > 0 && shareFailFiles.length > 0) 
            {
                 caiyun.ui.iMsgTip.tip("未全部分享成功，请查看分享记录", "error");
            } else if (resp.resultCode && resp.resultCode == "0") 
			{
				if(resp.inviteShareRes && resp.inviteShareRes.shareResult && resp.inviteShareRes.shareResult == "208000504")
				{
					caiyun.ui.iMsgTip.tip("您今天的50条免费分享短信已经用完，部分短信发送不成功", "success");
				}
				else
				{
					caiyun.ui.iMsgTip.tip("文件分享成功!", "success");
				}
				
			}
			else {
				caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试...", "error");
			}
			window.caiyun.operate.reLoad();//reload操作，修改共享后的文件状态
		};
		
		var inviteShareFailCallBack = function(req,textStatus,errorThrown,params){
			caiyun.ui.iMsgTip.tip("系统繁忙，请稍后再试...", "error");
		};
		
		//判断操作能否执行
		var canExecute = function(operation, ids){
			var idList = ids || selectedIDs;
            var selecetData = window.caiyun.util.cache.getFileShareCache(constants.FILE_MY_FILE_SHARE_LIST_CACHEGROUP,idList[0]);
			var flag = true;
			switch(operation) {
				case 'cancelMyShare':
					if(selecetData.shareType == 4||idList.length>1){
						flag = false;
	                }
					break;
				case 'meberMyShare':
					if(idList.length>1){
						flag = false;
					}
					break;
                case 'enterEPDir':
                    if(selecetData.shareType != 4 ||idList.length>1){
                        flag = false;
                    }
                    break;
                case 'enterEPDirTools':
                    if(selecetData.shareType != 4 ||idList.length>1){
                        flag = false;
                    }
                    break;
			}
			return flag;
		};
		
		
		//返回showMessage时，提示对应错误信息
		var formatReturnMsg = function(showMessage){
			var tipstr = "系统繁忙，请稍后再试...";
			if(null == showMessage || "" == showMessage)
			{
				return tipstr;
			}
			else if("error_01" == showMessage)
			{
				tipstr = "您尚未登录";
			}
			else if("error_02" == showMessage)
			{
				tipstr = "请求参数不正确";
			}
			else if("error_03" == showMessage)
			{
				tipstr = "系统异常，请稍后再试...";
			}
			else if("error_04" == showMessage)
			{
				tipstr = "请求文件数不能超过20";
			}
			else if("error_05" == showMessage)
			{
				tipstr = "请求文件夹数不能超过20";
			}
			else if("error_06" == showMessage)
			{
				tipstr = "共享人数不能超过50";
			}
				else if("error_07" == showMessage)
			{
				tipstr = "每次分享最多10个人";
			}
			else if("error_08" == showMessage)
			{
				tipstr = "分享次数过多";
			}
			return tipstr;
		};
		
		var addListen = function(key, fun) {
			var ref, stack;
			key = $.trim(key);

			if (keys[key]) {
				stack = (ref = listens[key]) == null ? [] : ref;
				stack.push(fun);
				listens[key] = stack;
			}
			return this;
		};
		
		var removeListen = function(key) {
			delete listens[$.trim(key)];
			return this;
		};

		var trigger = function(key) {
			var events = listens[key] || {} ,params = [],i = 1,length = arguments.length;
			if(length > 1){
				for(;i < length ; i ++){
					params.push(arguments[i]);
				}
			}
			
			$.each(events, function() {
				this.apply(null, params);
			});
		};
		
		return {
			selectedIDs : selectedIDs,
			getFileSrc : getFileSrc,
            loadFileShareInfos : loadFileShareInfos,
            scrollLoadData : scrollBottomLoadData,
			canExecute : canExecute,
            inivteShareFile : inivteShareFile,
			sortHandler : sortHandler,
			reload   :  reload,
			selectHandler : selectHandler,
            enterEnterpriseSpace: enterEnterpriseSpace,
			cancelFileShare : cancelFileShare,
			leaveFileShare : leaveFileShare,
			memberManager : memberManager,
			getShareInfo : getShareInfo,
			replyShare : replyShare,
			onListen : addListen
        }
        
    })();
})()
