/**
 * 文件右键菜单
 */
(function() {
    var self = caiyun.ui.model.fileRightClickMenu;

    self.init = function() {
        var menu;
        var fileOperator = caiyun.operate;
        // 创建右键菜单
        var menu = $('body').CyDropDownMenu({
            id : 'operaionMenu',
            items : [ {
                id : 'open',
                iconClass : 'ico-1',
                name : '打开',
                click : function() {
                    fileOperator.enterDir();
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('open');
                }
            },
            {
                id : 'browse',
                name : '打开',
                click : function() {
                    fileOperator.browseImage();
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('browse');
                }
            },
            {
                id : 'edit',
                iconClass : 'ico-edit',
                name : '编辑',
                click : function() {
                    fileOperator.edit();
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('edit');
                }
            },
             {
                id : 'play',
                name : '打开',
                click : function() {
                    fileOperator.viewFile();
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('play');
                }
            },
            {
                id : 'link',
                iconClass : 'ico-3',
                name : '分享文件链接',
                click : function() {
                    fileOperator.creatFileLink();
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('link');
                }
            },

            {
                id : 'shareToUser',
                iconClass : 'ico-3-2',
                name : '分享给其他用户',
                click : function() {
                    fileOperator.createShareFile();
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('share');
                }
            },
            
            {
                id : 'download',
                iconClass : 'ico-2',
                name : '下载',
                click : function() {
                    fileOperator.userDownload();
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('download');
                }
            },
            
            {
                id : 'move',
                name : '移动',
                iconClass : 'ico-move',
                click : function() {
                    fileOperator.moveOrCopy('move');
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('move');
                }
            },

            {
                id : 'copy',
                name : '复制',
                iconClass : 'ico-5',
                click : function() {
                    fileOperator.moveOrCopy('copy');
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('copy');
                }
            },
            
            {
                id : 'rename',
                name : '重命名',
                iconClass : 'ico-6',
                click : function() {
                    fileOperator.userRename();
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('rename');
                }
            },

            {
                id : 'reCopy',
                name : '转存',
                iconClass:'ico-3-7',
                click : function() {
                    fileOperator.moveOrCopy('copy');
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('reCopy');
                }
            },
            

            {
                id : 'delete',
                name : '删除',
                iconClass : 'ico-7',
                click : function() {
                    fileOperator.userDelete();
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('delete');
                }
            },

            {
                id : 'showVersionList',
                iconClass : 'ico-8',
                name : '历史版本管理',
                click : function() {
                    caiyun.ui.model.versionList.show();
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('showVersionList');
                }
            },
            
            {
                id : 'leaveShare',
                name : '删除分享',
                iconClass:'ico-3-6',
                click : function() {
                    fileOperator.userDelete();
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('leaveShare');
                }
            }, {
                id : 'cancelSync',
                name : '取消同步',
                iconClass : 'ico-cancelSync',
                click : function() {
                    fileOperator.syncCancel();
                },
                hiddenBy : function() {
                    return !fileOperator.canExecute('cancelSync');
                }
            } ]
        })[0];

        menu.hover(function() {
        }, function() {
            menu.close();
            $(window).unbind('scroll',locateByScroll);
        });

        var _scrollBegin = 0;
        // 传入右键点击的鼠标事件
        self.openAndLocate = function(event) {
            var position = {
                top : event.clientY - 5,// 偏移几个像素使鼠标能够悬浮在菜单区域内
                left : event.clientX - 15
            };
            menu.open();
            var menuHeight = menu.height();
            var windowHeight = $(window).height();
            // 判断菜单是否超过显示范围，超出则反过来显示
            if (position.top + menuHeight > windowHeight) {
                // 如果往上能放下则往上弹
                if(position.top - menuHeight > 10){
                   position.top = position.top - menuHeight + 10;
                }else{
                   if(menuHeight < windowHeight){
                      position.top = (windowHeight - menuHeight) / 2;
                   }else{
                      position.top = 0;
                   }
                }
            }
            _scrollBegin = $(window).scrollTop();
            position.top += _scrollBegin;
            menu.locate(position, true);
            $(window).bind('scroll',locateByScroll);
        };
        
        
        function locateByScroll(){
            var position = menu.getPosition();
            var newTop = $(window).scrollTop();
            position.top += (newTop - _scrollBegin);
            _scrollBegin = newTop;
            menu.locate(position,true);
        }
        
        // 阻止在右键菜单上再点击右键菜单
        menu.unbind('contextmenu').bind('contextmenu', function(e) {
            e.preventDefault();
            e.stopPropagation();
        });

    };

    // 将自己的初始化方法加载到ui的initList中
    caiyun.ui.initList.push(self);
})();