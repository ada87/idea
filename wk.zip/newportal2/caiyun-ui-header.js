/*
 * 彩云头部
 */
caiyun.ui.model.header = {};

/*
 * 开始实现彩云头部
 */
(function() {
	// 记住自己是谁
	var self = caiyun.ui.model.header;

	// 定义初始化方法
	self.init = function() {
		var $cy_header = $('#cy_header');
		var $top_thumb = $(".top-thumb");
		var $user_u = $(".user_u");
		var $mySetup = $("#mySetup");
		var $userMenu = $(".userMenu");
		var $toFile = $('#toFile');
		var $toMyphone = $('#toMyphone');
		var $toTimeLine = $('#toTimeLine');
		var fileContent = caiyun.ui.model.fileContent;
		var fileOperate = caiyun.operate;
		var myfileID = caiyun.constants.rootIds.myFolder;
		var $headerSwitch = $('#header_switch');
		var constants = caiyun.constants;

		$toFile.bind('click', function() {
			fileContent.switchToView(caiyun.constants.DEFAULT_FILE_CONTENT_VIEW);
			fileOperate.enterDir(myfileID);
			//pv统计
			caiyun.util.sendPvlog('feature','mcloud');
		});
		
		$toTimeLine.bind('click',function(){
			fileContent.switchToView(caiyun.constants.TIMELINE_CONTENT_VIEW);
			//pv统计
			caiyun.util.sendPvlog('feature','timeLine');
		});
		
		$toMyphone.bind('click',function(){
			fileContent.switchToView(caiyun.constants.MY_PHONE_CONTENT_VIEW);
			//pv统计
			caiyun.util.sendPvlog('feature','myPhone');
		}
		);
		
		$('#toFile,#toTimeLine,#toMyphone').click(function(){
		    $('#header_switch .current').removeClass('current');
		    $(this).addClass('current');
		}).hover(function(){
		    $(this).addClass('hover');
		},function(){
		    $(this).removeClass('hover');
		});
		
		// 监听内容切换事件
		fileOperate.onListen('fileContentSwitch', function(e) {
			var newView = e.newView;
			$('#header_switch .current').removeClass('current');
			 if(newView.name === constants.TIMELINE_CONTENT_VIEW){
				 $headerSwitch.removeClass();
				 $headerSwitch.addClass('ul_2');
				 $toTimeLine.addClass('current');
			}else if(newView.name === constants.MY_PHONE_CONTENT_VIEW){
				$headerSwitch.removeClass();
				 $headerSwitch.addClass('ul_1');
				 $toMyphone.addClass('current');
			}else if(newView.name === constants.DEFAULT_FILE_CONTENT_VIEW){
				$headerSwitch.removeClass();
				$headerSwitch.addClass('ul_0');
				$toFile.addClass('current');
			}else {
				$headerSwitch.removeClass();
				$headerSwitch.addClass('ul_0');
				$toFile.addClass('current');
			}
		});

		// 去掉IE6下a标签框框
		$user_u.find("a").focus(function() {
			$(this).blur();
		});

		//鼠标移出设置下拉框时 下拉框消失
		$('#setupIcon').click(function(event){
		    if($userMenu.is(":hidden")){
				$userMenu.show()
			}else{
				$userMenu.hide();
			}
			$('#umcpassportplugin').hide();
			event.stopPropagation();
			return false;
		});
		
		$("html").click(function(){
		    $userMenu.hide();
		});
		
		//设置悬浮鼠标滑过效果
		$('#userMenu_pri,#userMenu_his,#userMenu_sms,#userMenu_out').hover(function() {
			$(this).addClass('hover');
		}, function() {
			$(this).removeClass('hover');
		});
		
		//读取广告
		$.ajax({
		    type    : 'post', 
		    url     : '../marketplat/getAdvertAction.action?date=' + new Date().getTime(), 
		    dataType: 'json',
		    data    : {advertPos:'2007'}, 
		    success : function(response){
			    if(response != null && response.showMessage == "")
				{
					var res = response.getAdvertResult;
					if(res != null && res.resultCode == "0")
					{
						var advertImg = res.advertInfos;
						if(advertImg[0] && advertImg[0].linkUrl)
						{
						  $('.ad_box a').attr('href', advertImg[0].linkUrl + '&mssc=' + rcsToken).html(advertImg[0].title);
						}
					}
				}
			},
            error   : null
		}); 
		
		
		// 初始化统一通行证
		if (passid != "") {
			$.ajax({
				url : "../sso/cmartifact.action",
				dataType : "json",
				type : "POST",
				success : function(res) {
					if (res.code == "0") {
						// 本地调试rdcmpassport.com:30030/UmcSSO,现网切换cmpassport.com/umcsso,修改配置文件
						var h = mobilePassBoxUrl + '/plugin?func=plug:init&ver=1.0&anchor=mobilePassBox&passid='
								+ passid
								+ '&artifact='
								+ res.auth
								+ '&sourceid=5&skin=grayskin';
						$.getScript(h).done(function(){
							$("#mobilePassBox").find("a").addClass("ua").bind('click', function(){
							    $(".userMenu").hide();
							    setTimeout(function() {$("#umcpassportplugin a").attr("onclick","javascript:return false;")}, 2);
							});
							$("#mobilePassBox a").attr("onclick","javascript:return false;");
							$(".user_a em").show();
							
							//通行证插件后台报错容错处理
							if ($("#mobilePassBox").children().length == 0){
							    $("#mobilePassBox").css({"font-size":"14px","color":"#baa2de"}).html(ownerMSISDN);
							}
						}).fail(function(){
							$("#mobilePassBox").css({"font-size":"14px","color":"#baa2de"}).html(ownerMSISDN);
						});
					}
					else {
					    $("#mobilePassBox").css({"font-size":"14px","color":"#baa2de"}).html(ownerMSISDN);
					}
				}
			});
		}
		else {
		    $('#myAccount').hover(function(){$('#upgradePass').show();$(".userMenu").hide();},function(){$('#upgradePass').hide();});
		}
	};
	
	window.onscroll = function(){
		
		$("#umcpassportplugin").hide();
		
	};

	// 定义隐藏方法
	self.hide = function() {
		$header.hide();
	};

	// 定义显示方法
	self.show = function() {
		$header.show();
	};

	// 注册初始化事件
	caiyun.ui.initList.push(self);
})();
