/**
 * 文件右键菜单
 */
(function() {
    var recycleBinRightClick = caiyun.ui.model.recycleBinRightClickMenu;

    recycleBinRightClick.init = function() {
        var fileOperator = caiyun.recycleBinOperate;
        // 创建右键菜单
        var menu = $('body').CyDropDownMenu({
            id: 'recycleBinMenu',
            items: [{
                id: 'revert',
                name: '还原',
                iconClass: 'ico-restore',
                click: function(e) {
                    fileOperator.revertFile();
                },
                hiddenBy: function() {
                    //return !fileOperator.canExecute('revert');
                }
            }, {
                id: 'delete',
                name: '彻底删除',
                iconClass: 'ico-7',
                click: function(e) {
                    fileOperator.deleteFile();
                },
                hiddenBy: function() {
                    //return !fileOperator.canExecute('delete');
                }
            }]
        })[0];

        menu.hover(function() {}, function() {
            menu.close();
            $(window).unbind('scroll', locateByScroll);
        });

        var _scrollBegin = 0;
        // 传入右键点击的鼠标事件
        recycleBinRightClick.openAndLocate = function(event) {
            var position = {
                top: event.clientY - 5, // 偏移几个像素使鼠标能够悬浮在菜单区域内
                left: event.clientX - 5
            };
            menu.open();
            var menuHeight = menu.height();
            var windowHeight = $(window).height();
            // 判断菜单是否超过显示范围，超出则反过来显示
            if (position.top + menuHeight > windowHeight) {
                position.top = position.top - menuHeight + 10;
            }
            _scrollBegin = $(window).scrollTop();
            position.top += _scrollBegin;
            menu.locate(position, true);
            $(window).bind('scroll', locateByScroll);
        };

        function locateByScroll() {
            var position = menu.getPosition();
            var newTop = $(window).scrollTop();
            position.top += (newTop - _scrollBegin);
            _scrollBegin = newTop;
            menu.locate(position, true);
        };

        // 阻止在右键菜单上再点击右键菜单
        menu.unbind('contextmenu').bind('contextmenu', function(e) {
            e.preventDefault();
            e.stopPropagation();
        });

    };

    caiyun.ui.initList.push(recycleBinRightClick);
})();